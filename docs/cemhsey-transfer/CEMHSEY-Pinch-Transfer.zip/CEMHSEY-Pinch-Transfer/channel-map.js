"use strict";
// Facts derived from CEMHSEY device numbering; see the source links in channel-map.json.
globalThis.CEMHSEY_ARRAY_MAP = [
  {
    "grid_id": 1,
    "matlab_row_range_inclusive_1based": [
      1,
      64
    ],
    "row_index_range_half_open_0based": [
      0,
      64
    ],
    "array_model": "GR10MM0808",
    "site_right_forearm": "proximal third",
    "local_reference_frame": "printed back view, connector below",
    "cell_pitch_mm_both_axes": 10,
    "matlab_row_1based_by_local_cell": [
      [
        8,
        16,
        24,
        32,
        40,
        48,
        56,
        64
      ],
      [
        7,
        15,
        23,
        31,
        39,
        47,
        55,
        63
      ],
      [
        6,
        14,
        22,
        30,
        38,
        46,
        54,
        62
      ],
      [
        5,
        13,
        21,
        29,
        37,
        45,
        53,
        61
      ],
      [
        4,
        12,
        20,
        28,
        36,
        44,
        52,
        60
      ],
      [
        3,
        11,
        19,
        27,
        35,
        43,
        51,
        59
      ],
      [
        2,
        10,
        18,
        26,
        34,
        42,
        50,
        58
      ],
      [
        1,
        9,
        17,
        25,
        33,
        41,
        49,
        57
      ]
    ],
    "within_grid_manhattan_edge_count": 112
  },
  {
    "grid_id": 2,
    "matlab_row_range_inclusive_1based": [
      65,
      128
    ],
    "row_index_range_half_open_0based": [
      64,
      128
    ],
    "array_model": "GR10MM0808",
    "site_right_forearm": "proximal third",
    "local_reference_frame": "printed back view, connector below",
    "cell_pitch_mm_both_axes": 10,
    "matlab_row_1based_by_local_cell": [
      [
        72,
        80,
        88,
        96,
        104,
        112,
        120,
        128
      ],
      [
        71,
        79,
        87,
        95,
        103,
        111,
        119,
        127
      ],
      [
        70,
        78,
        86,
        94,
        102,
        110,
        118,
        126
      ],
      [
        69,
        77,
        85,
        93,
        101,
        109,
        117,
        125
      ],
      [
        68,
        76,
        84,
        92,
        100,
        108,
        116,
        124
      ],
      [
        67,
        75,
        83,
        91,
        99,
        107,
        115,
        123
      ],
      [
        66,
        74,
        82,
        90,
        98,
        106,
        114,
        122
      ],
      [
        65,
        73,
        81,
        89,
        97,
        105,
        113,
        121
      ]
    ],
    "within_grid_manhattan_edge_count": 112
  },
  {
    "grid_id": 3,
    "matlab_row_range_inclusive_1based": [
      129,
      192
    ],
    "row_index_range_half_open_0based": [
      128,
      192
    ],
    "array_model": "GR10MM0808",
    "site_right_forearm": "proximal third",
    "local_reference_frame": "printed back view, connector below",
    "cell_pitch_mm_both_axes": 10,
    "matlab_row_1based_by_local_cell": [
      [
        136,
        144,
        152,
        160,
        168,
        176,
        184,
        192
      ],
      [
        135,
        143,
        151,
        159,
        167,
        175,
        183,
        191
      ],
      [
        134,
        142,
        150,
        158,
        166,
        174,
        182,
        190
      ],
      [
        133,
        141,
        149,
        157,
        165,
        173,
        181,
        189
      ],
      [
        132,
        140,
        148,
        156,
        164,
        172,
        180,
        188
      ],
      [
        131,
        139,
        147,
        155,
        163,
        171,
        179,
        187
      ],
      [
        130,
        138,
        146,
        154,
        162,
        170,
        178,
        186
      ],
      [
        129,
        137,
        145,
        153,
        161,
        169,
        177,
        185
      ]
    ],
    "within_grid_manhattan_edge_count": 112
  },
  {
    "grid_id": 4,
    "matlab_row_range_inclusive_1based": [
      193,
      256
    ],
    "row_index_range_half_open_0based": [
      192,
      256
    ],
    "array_model": "GR08MM1305",
    "site_right_forearm": "distal third",
    "local_reference_frame": "printed back view, connector left",
    "cell_pitch_mm_both_axes": 8,
    "matlab_row_1based_by_local_cell": [
      [
        204,
        203,
        202,
        201,
        200,
        199,
        198,
        197,
        196,
        195,
        194,
        193,
        null
      ],
      [
        205,
        206,
        207,
        208,
        209,
        210,
        211,
        212,
        213,
        214,
        215,
        216,
        217
      ],
      [
        230,
        229,
        228,
        227,
        226,
        225,
        224,
        223,
        222,
        221,
        220,
        219,
        218
      ],
      [
        231,
        232,
        233,
        234,
        235,
        236,
        237,
        238,
        239,
        240,
        241,
        242,
        243
      ],
      [
        256,
        255,
        254,
        253,
        252,
        251,
        250,
        249,
        248,
        247,
        246,
        245,
        244
      ]
    ],
    "within_grid_manhattan_edge_count": 110
  },
  {
    "grid_id": 5,
    "matlab_row_range_inclusive_1based": [
      257,
      320
    ],
    "row_index_range_half_open_0based": [
      256,
      320
    ],
    "array_model": "GR08MM1305",
    "site_right_forearm": "distal third",
    "local_reference_frame": "printed back view, connector left",
    "cell_pitch_mm_both_axes": 8,
    "matlab_row_1based_by_local_cell": [
      [
        268,
        267,
        266,
        265,
        264,
        263,
        262,
        261,
        260,
        259,
        258,
        257,
        null
      ],
      [
        269,
        270,
        271,
        272,
        273,
        274,
        275,
        276,
        277,
        278,
        279,
        280,
        281
      ],
      [
        294,
        293,
        292,
        291,
        290,
        289,
        288,
        287,
        286,
        285,
        284,
        283,
        282
      ],
      [
        295,
        296,
        297,
        298,
        299,
        300,
        301,
        302,
        303,
        304,
        305,
        306,
        307
      ],
      [
        320,
        319,
        318,
        317,
        316,
        315,
        314,
        313,
        312,
        311,
        310,
        309,
        308
      ]
    ],
    "within_grid_manhattan_edge_count": 110
  }
];
