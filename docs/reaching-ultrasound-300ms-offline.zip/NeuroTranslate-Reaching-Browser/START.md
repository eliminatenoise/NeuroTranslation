# Open the reaching forecast offline

Extract the whole ZIP. Open `index.html` in your browser or use the launcher for your computer.

| Computer | Launcher |
| --- | --- |
| Windows | Open `Launch-Windows.cmd` |
| macOS | In Terminal, run `sh Launch-macOS.command` from the extracted folder |
| Linux | From a terminal in the extracted folder, run `sh Launch-Linux.sh` |

Choose an ultrasound setting to compare the three forecasts. The page starts with an invented example. Use **Open a local JSON file** for a compatible recorded history. The **Example JSON** link gives you the same input file to inspect. The [field order and units](FIELDS.md) are included in this folder. All calculations and file reading take place on your device.

The browser page and its saved checkpoints are in this folder. You can read the results offline in [SIMPLE.md](SIMPLE.md) and [TECHNICAL.md](TECHNICAL.md). The project and game links on the page open online.
