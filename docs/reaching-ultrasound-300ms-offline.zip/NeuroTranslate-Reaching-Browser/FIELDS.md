# JSON field order and units

Start with `example.json`. Give `history` ten rows of 26 numbers. The rows cover 20 ms each, from 200 ms before the forecast starts to the start time. Include the matching ten values under `ultrasound_times_from_issue_s`. Times are negative seconds relative to the start of the forecast. Use `null` for an absent ultrasound time.

| Fields in each row | Readings in order |
| --- | --- |
| 1–3 | Hand, x, y, z relative to shoulder, in mm |
| 4–6 | Forearm, x, y, z relative to shoulder, in mm |
| 7–9 | Elbow, x, y, z relative to shoulder, in mm |
| 10–12 | Upper arm, x, y, z relative to shoulder, in mm |
| 13–16 | Position availability for hand, forearm, elbow, upper arm |
| 17–19 | Root mean square muscle voltage for triceps, biceps and palm over the slot, in millivolts |
| 20–22 | Muscle reading availability for triceps, biceps and palm |
| 23–24 | Ultrasound point spread for triceps and brachialis, in mm |
| 25–26 | Ultrasound availability for triceps and brachialis |

For motion, use the newest recorded position in each slot. Ultrasound spread is the root mean square distance of four points from their centre in the image. Use 1 for an available reading and 0 for an absent reading. Put 0 in the numeric fields for a missing measurement. For a file with no ultrasound, set those entries and flags to 0 and use ten `null` times. [Technical study](TECHNICAL.md)
