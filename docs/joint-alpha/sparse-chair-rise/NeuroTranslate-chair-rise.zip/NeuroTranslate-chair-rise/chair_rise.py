"""Run the shared chair-rise forecaster using NumPy and prepared earlier readings."""
import argparse
import json
import math
import os
from pathlib import Path

if __name__ == "__main__":
    for variable in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"):
        os.environ.setdefault(variable, "1")
try:
    import numpy as np
except ModuleNotFoundError as error:
    if __name__ == "__main__" and error.name == "numpy":
        raise SystemExit("Install NumPy with python -m pip install numpy, then run this file again.") from error
    raise

ROOT = Path(__file__).resolve().parent
GEOMETRY = 36
TRACK = 73
FORCE = 76
CHANNELS = 88
MEASUREMENTS = ("camera", "force", "muscle", "both")
POSITIONS = ("full", "sparse")


def normalize(x, mean, scale, camera, sensors):
    """Accept NaNs in unavailable channels and use the same explicit masks as training."""
    if camera not in POSITIONS or sensors not in MEASUREMENTS:
        raise ValueError("Choose full or sparse camera history and one of the four sensor combinations.")
    if x.ndim != 3 or x.shape[1:] != (4, CHANNELS) or not len(x):
        raise ValueError("Provide one or more four-row earlier histories with 88 measurements per row.")
    provided = np.asarray(x, dtype=np.float64).copy()
    seen = np.ones((4, CHANNELS), dtype=bool)
    if camera == "sparse":
        seen[1:3, :TRACK] = False
        seen[0, GEOMETRY:2*GEOMETRY] = False
        provided[:, -1, GEOMETRY:2*GEOMETRY] = (
            provided[:, -1, :GEOMETRY] - provided[:, 0, :GEOMETRY]
        ) / 3
    use_force = sensors in ("force", "both")
    use_muscle = sensors in ("muscle", "both")
    seen[:, TRACK:FORCE] = use_force
    seen[:, FORCE:CHANNELS] = use_muscle
    if not np.isfinite(provided[:, seen]).all():
        raise ValueError("A reading needed for the selected camera and sensor mode is missing or infinite.")
    flags = np.ones((4, 4), dtype=np.float32)
    if camera == "sparse":
        flags[1:3, :2] = 0
        flags[0, 1] = 0
    flags[:, 2:] = use_force, use_muscle
    z = np.zeros((len(x), 4, CHANNELS + 4), dtype=np.float32)
    z[:, :, :CHANNELS][:, seen] = ((provided[:, seen] - mean[seen]) / scale[seen]).astype(np.float32)
    z[:, :, CHANNELS:] = flags
    if not np.isfinite(z).all():
        raise ValueError("A supplied reading exceeded the model's numeric range.")
    return z


def one_checkpoint(data, parameters):
    def linear(x, key):
        return x @ parameters[key + ".weight"].T + parameters[key + ".bias"]

    def layer(x, key):
        center = x - x.mean(axis=-1, keepdims=True)
        normalized = center / np.sqrt(np.mean(center**2, axis=-1, keepdims=True) + np.float32(1e-5))
        return normalized * parameters[key + ".weight"] + parameters[key + ".bias"]

    camera_and_other = linear(data, "input")
    readout = np.broadcast_to(parameters["readout"], (len(data), 1, 32))
    memory = np.concatenate((camera_and_other, readout), axis=1) + parameters["position"]
    normalized = layer(memory, "norm_attention")
    packed = normalized @ parameters["attention.in_proj_weight"].T + parameters["attention.in_proj_bias"]
    q, k, v = (block.reshape(len(data), 5, 4, 8) for block in np.split(packed, 3, axis=-1))
    scores = np.einsum("nhd,nthd->nht", q[:, -1], k) / np.float32(math.sqrt(8))
    exp = np.exp(scores - scores.max(axis=-1, keepdims=True))
    attention = exp / exp.sum(axis=-1, keepdims=True)
    attended = np.einsum("nht,nthd->nhd", attention, v).reshape(len(data), 32)
    state = memory[:, -1] + linear(attended, "attention.out_proj")
    hidden = linear(layer(state, "norm_features"), "features.0")
    # PyTorch trains the exact GELU. Evaluate its definition on the single readout token.
    argument = hidden / np.float32(math.sqrt(2))
    probabilities = np.fromiter((math.erf(v) for v in argument.flat),
                                dtype=np.float32, count=argument.size).reshape(argument.shape)
    hidden = np.float32(.5) * hidden * (1 + probabilities)
    state = state + linear(hidden, "features.2")
    return linear(layer(state, "finish"), "forecast").ravel().astype(np.float64)


class ChairRiseForecast:
    def __init__(self, path=ROOT / "chair-rise-model.npz"):
        with np.load(path, allow_pickle=False) as npz:
            self.center = npz["feature_center"]
            self.scale = npz["feature_spread"]
            self.y_center = npz["target_center"].item()
            self.y_scale = npz["target_spread"].item()
            self.ensemble = [
                {key.split("/", 1)[1]: npz[key] for key in npz.files if key.startswith(f"{seed}/")}
                for seed in npz["seeds"].tolist()
            ]

    def predict(self, earlier, camera="sparse", sensors="camera"):
        x = normalize(np.asarray(earlier, dtype=np.float64), self.center, self.scale, camera, sensors)
        with np.errstate(over="ignore", invalid="ignore"):
            estimates = [self.y_center + self.y_scale * one_checkpoint(x, p) for p in self.ensemble]
        prediction = np.mean(estimates, axis=0)
        if not np.isfinite(prediction).all():
            raise ValueError("The supplied readings exceed the model's numeric range.")
        return prediction


def main():
    options = argparse.ArgumentParser(description=__doc__)
    options.add_argument("--history", type=Path, default=ROOT / "synthetic-history.json")
    options.add_argument("--camera", choices=POSITIONS, default="sparse")
    options.add_argument("--sensors", choices=MEASUREMENTS, default="camera")
    options.add_argument("--self-check", action="store_true", help="Check all eight example forecasts.")
    args = options.parse_args()
    try:
        data = json.loads(args.history.read_text())
        model = ChairRiseForecast()
        if args.self_check:
            if args.history != ROOT / "synthetic-history.json":
                options.error("--self-check uses the included example")
            result = json.loads((ROOT / "example-reference.json").read_text())
            deltas = []
            for key, expected in result["expected_mm"].items():
                camera, sensors = key.split("/")
                delta = abs(model.predict([data["earlier"]], camera, sensors)[0] - expected)
                if delta > result["tolerance_mm"]:
                    raise ValueError(f"The saved reference differs for {camera} camera and {sensors} inputs.")
                deltas.append(delta)
            print(f"All {len(deltas)} example forecasts match. Largest difference {max(deltas):.8g} mm.")
            return
        y = model.predict([data["earlier"]], camera=args.camera, sensors=args.sensors)
    except (OSError, KeyError, TypeError, ValueError, FloatingPointError) as error:
        options.error(str(error))
    print(f"The hip markers are predicted to move {y[0]:+.3f} mm vertically in 100 milliseconds.")
    print("The default example uses invented inputs." if args.history.name == "synthetic-history.json"
          else "The forecast uses the prepared readings in the supplied file.")


if __name__ == "__main__":
    main()
