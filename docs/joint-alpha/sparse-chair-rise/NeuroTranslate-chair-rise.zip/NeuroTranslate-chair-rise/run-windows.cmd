@echo off
setlocal
cd /d "%~dp0" || exit /b 2
where py >nul 2>nul
if errorlevel 1 (
  python chair_rise.py %*
) else (
  py -3 chair_rise.py %*
)
set "status=%ERRORLEVEL%"
if "%~1"=="" pause
exit /b %status%
