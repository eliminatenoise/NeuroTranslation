@echo off
setlocal
cd /d "%~dp0" || exit /b 2
where py >nul 2>nul
if errorlevel 1 (
  python forecast.py %*
) else (
  py -3 forecast.py %*
)
set "status=%ERRORLEVEL%"
if "%~1"=="" pause
exit /b %status%
