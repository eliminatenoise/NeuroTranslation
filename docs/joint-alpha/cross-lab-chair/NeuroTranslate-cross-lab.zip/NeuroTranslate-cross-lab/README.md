# Run a cross-lab chair forecast

The model estimates how far four camera markers on the pelvis will move vertically in the next 100 milliseconds. The download includes models trained on one or two collections of recordings. Its example uses invented readings.

## Open the example

Install Python and NumPy. If NumPy is missing, run `python -m pip install numpy`. Use `python3` or `py -3` in place of `python` where appropriate.

- Linux or macOS. In the extracted folder, run `./run-linux.sh` or `./run-macos.command`.
- Windows. Open `run-windows.cmd`, or run it in a terminal.
- Any platform. Run `python forecast.py`. Add `--self-check` to compare all 20 forecasts with the saved references.

Try `python forecast.py --camera sparse --family attention --sensors force` to supply floor force and two earlier camera positions. The default uses a linear fit with full camera history. The `--training` switch selects `one_lab` or `two_labs`. Linear fits use camera readings alone. The attention model supports camera, force, muscle and both as sensor choices. Here `force`, `muscle` and `both` add those signals to the camera.

## Supply earlier readings

Use `--history file.json` with an `earlier` array of four rows ending 150, 100, 50 and zero milliseconds before prediction. Each row has thirteen entries.

| Columns, starting at 1 | What to supply |
| --- | --- |
| 1–4 | Height of each marker in millimetres relative to the average marker height at prediction time |
| 5–8 | Their changes in height in the preceding 50 ms, in millimetres |
| 9 | Average marker height at prediction time, in millimetres |
| 10 | Natural log of mean vertical floor force in the preceding 40 ms (at least 1 N), less the same value for the first row |
| 11–13 | Natural log of each muscle’s root-mean-square voltage over the 40 ms ending 50 ms before the row, less the same value for the second row. Add 1e-10 V before taking the log. |

The marker order is left front, right front, left back and right back. The muscle channel order is tibialis anterior, vastus medialis and biceps femoris. The first muscle row sets a fixed reference without a measured muscle input. Use JSON `null` where the selected mode omits a reading. Sparse camera mode uses the first and last positions and calculates the slope from them.

These are research models fitted to archives. Their comparison uses earlier and later archived positions. Their results leave performance on live, directly observed camera tracks open.

[Interactive study](https://eliminatenoise.github.io/NeuroTranslation/joint-alpha/cross-lab-chair/)

Training used [Gait120](https://doi.org/10.6084/m9.figshare.27677016.v1) by Koo, Boo, Seo and Kim, and [the Monash sit-to-walk archive](https://doi.org/10.26180/24515092.v4) by Perera and colleagues. Both retain CC BY 4.0 attribution. The external test used [Hunt and colleagues’ stand-and-sit recordings](https://doi.org/10.6084/m9.figshare.26282872.v2). It supplied no training inputs. The archive distributes original model contributions under the CC0 dedication in LICENSE.txt and includes no recordings from any participant.
