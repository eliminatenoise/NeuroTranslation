"""Forecast vertical pelvis movement from prepared camera, force and muscle readings."""
import argparse
import json
import os
from pathlib import Path

if __name__ == "__main__":
    for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
        os.environ.setdefault(name,"1")
try:
    import numpy as np
except ModuleNotFoundError as error:
    if __name__ == "__main__" and error.name == "numpy":
        raise SystemExit("Install NumPy with python -m pip install numpy, then run this file again.") from error
    raise

from numpy_attention import one_checkpoint

HERE=Path(__file__).resolve().parent
MODELS=("one_lab","two_labs")
DENSITY=("full","sparse")
SIGNALS=("camera","force","muscle","both")


def encode(earlier,center,scale,camera,sensors):
    if camera not in DENSITY or sensors not in SIGNALS:
        raise ValueError("Choose a supported camera and sensor combination")
    x=np.asarray(earlier,dtype=np.float64).copy()
    if x.ndim!=3 or x.shape[1:]!=(4,13) or not len(x):
        raise ValueError("Provide earlier histories with four rows and thirteen columns")
    mask=np.ones((4,13),bool)
    flags=np.ones((4,4),np.float32)
    floor=sensors in ("force","both")
    emg=sensors in ("muscle","both")
    flags[:,2:]=floor,emg
    flags[0,3]=0
    # The first muscle token has the fixed reference value, with no measurement flag.
    x[:,0,10:13]=0
    if camera=="sparse":
        mask[1:3,:9]=False
        mask[0,4:8]=False
        flags[1:3,:2]=0
        flags[0,1]=0
        x[:,-1,4:8]=(x[:,-1,:4]-x[:,0,:4])/3
    mask[:,9]=floor
    mask[:,10:13]=emg
    if not np.isfinite(x[:,mask]).all():
        raise ValueError("A reading required for that input combination is missing or infinite")
    clean=np.zeros((len(x),4,17),np.float32)
    clean[:,:,:13][:,mask]=((x[:,mask]-center[mask])/scale[mask]).astype(np.float32)
    clean[:,:,13:]=flags
    if not np.isfinite(clean).all():
        raise ValueError("The input exceeds the forecast's numeric range")
    return clean


class Forecast:
    def __init__(self,path=HERE/"weights.npz"):
        with np.load(path,allow_pickle=False) as saved:
            self.values={name:saved[name] for name in saved.files}

    def predict(self,earlier,training="two_labs",camera="full",sensors="camera",family="linear"):
        if training not in MODELS or family not in ("attention","linear") or (family=="linear" and sensors!="camera"):
            raise ValueError("The linear fits use camera readings alone")
        def array(key):return self.values[training+"/"+key]
        x=encode(earlier,array("center"),array("variation"),camera,sensors)
        if family=="linear":
            flat=x[:,:,:9].astype(np.float64).reshape(len(x),-1)
            estimate=flat@array(camera+"_ridge")
        else:
            combined=[]
            with np.errstate(over="ignore",invalid="ignore"):
                for seed in array("seeds").tolist():
                    prefix=f"{training}/{seed}/"
                    checkpoint={k.removeprefix(prefix):p for k,p in self.values.items() if k.startswith(prefix)}
                    combined.append(one_checkpoint(x,checkpoint))
            estimate=np.mean(combined,axis=0)
        result=array("mean")+array("scale")*estimate
        if not np.isfinite(result).all():
            raise ValueError("The input exceeds the forecast's numeric range")
        return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--history",type=Path,default=HERE/"synthetic-history.json")
    parser.add_argument("--training",choices=MODELS,default="two_labs")
    parser.add_argument("--camera",choices=DENSITY,default="full")
    parser.add_argument("--sensors",choices=SIGNALS,default="camera")
    parser.add_argument("--family",choices=("linear","attention"),default="linear")
    parser.add_argument("--self-check",action="store_true")
    args=parser.parse_args()
    try:
        if args.self_check and args.history!=HERE/"synthetic-history.json":
            parser.error("--self-check uses the included invented history")
        data=json.loads(args.history.read_text())
        net=Forecast()
        if args.self_check:
            reference=json.loads((HERE/"example-reference.json").read_text())
            errors=[]
            for key,expected in reference["values_mm"].items():
                training,camera,sensor,family=key.split("/")
                estimate=net.predict([data["earlier"]],training,camera,sensor,family)[0]
                errors.append(abs(estimate-expected))
            largest=max(errors)
            if largest>reference["tolerance_mm"]:raise ValueError("A saved example forecast differs from the runtime")
            print(f"All {len(errors)} example forecasts match. Largest difference {largest:.8g} mm.")
            return
        value=net.predict([data["earlier"]],args.training,args.camera,args.sensors,args.family)[0]
        print(f"Predicted vertical movement over 100 milliseconds is {value:+.3f} mm.")
        if args.history==HERE/"synthetic-history.json":print("This example uses invented readings.")
    except (OSError,ValueError,KeyError,TypeError) as error:
        parser.error(str(error))


if __name__=="__main__":
    main()
