"""NumPy replay of the temporal attention layer."""
import math
import numpy as np

def one_checkpoint(data, parameters):
    def linear(x, key):
        return x @ parameters[key + ".weight"].T + parameters[key + ".bias"]

    def layer(x, key):
        center = x - x.mean(axis=-1, keepdims=True)
        normalized = center / np.sqrt(np.mean(center**2, axis=-1, keepdims=True) + np.float32(1e-5))
        return normalized * parameters[key + ".weight"] + parameters[key + ".bias"]

    camera_and_other = linear(data, "input")
    readout = np.broadcast_to(parameters["readout"], (len(data), 1, 32))
    memory = np.concatenate((camera_and_other, readout), axis=1) + parameters["position"]
    normalized = layer(memory, "norm_attention")
    packed = normalized @ parameters["attention.in_proj_weight"].T + parameters["attention.in_proj_bias"]
    q, k, v = (block.reshape(len(data), 5, 4, 8) for block in np.split(packed, 3, axis=-1))
    scores = np.einsum("nhd,nthd->nht", q[:, -1], k) / np.float32(math.sqrt(8))
    exp = np.exp(scores - scores.max(axis=-1, keepdims=True))
    attention = exp / exp.sum(axis=-1, keepdims=True)
    attended = np.einsum("nht,nthd->nhd", attention, v).reshape(len(data), 32)
    state = memory[:, -1] + linear(attended, "attention.out_proj")
    hidden = linear(layer(state, "norm_features"), "features.0")
    # PyTorch trains the exact GELU. Evaluate its definition on the single readout token.
    argument = hidden / np.float32(math.sqrt(2))
    probabilities = np.fromiter((math.erf(v) for v in argument.flat),
                                dtype=np.float32, count=argument.size).reshape(argument.shape)
    hidden = np.float32(.5) * hidden * (1 + probabilities)
    state = state + linear(hidden, "features.2")
    return linear(layer(state, "finish"), "forecast").ravel().astype(np.float64)

