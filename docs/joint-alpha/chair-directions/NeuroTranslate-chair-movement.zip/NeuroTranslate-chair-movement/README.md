# Forecast standing up and sitting down

Give the model a short series of earlier readings and it estimates how far four camera markers on the hips will move vertically over the next tenth of a second. The included example uses invented readings. It runs locally with Python 3.11 or newer and NumPy.

## Run the example

If Python needs NumPy, install it with `python -m pip install numpy`. If your command starts Python with `python3` or `py -3`, use that name for the install and run commands.

- On Linux, open a terminal in this folder and run `./run-linux.sh`.
- On macOS, open `run-macos.command` or run it from a terminal in this folder.
- On Windows, open `run-windows.cmd`.
- From any terminal, run `python chair_movement.py`. Add `--self-check` to compare all eight example forecasts with their saved reference values.

The output is a signed distance in millimetres. A positive value means upward movement. Try `python chair_movement.py --camera sparse --sensors both` to see one of the supported input combinations. The shared model uses the same weights across these combinations within each training run. The packaged prediction averages three runs.

## Use a prepared history

Supply `--history file.json` with an `earlier` array of four rows. The rows end 150, 100, 50 and zero milliseconds before prediction. Each row has 88 numbers in this order:

| Columns, starting at 1 | Reading |
| --- | --- |
| 1–36 | X, Y and Z for each marker, in millimetres, relative to the centre of the pelvis at issue time |
| 37–72 | Earlier 50 ms movement of the same markers, in millimetres |
| 73 | Vertical pelvis height at issue time, in millimetres, repeated in the supplied camera rows |
| 74–76 | X, Y and Z floor-force means in newtons, summed across the plates over the preceding 40 ms |
| 77–88 | Natural log of the root mean square of each muscle voltage over the preceding 40 ms, adding 1e-10 before taking the log |

The marker order is left and right front pelvis, left and right back pelvis, left and right knee, left and right ankle, left and right heel, left and right toe. Each triplet follows the source lab orientation, with Y pointing up. The muscle order is vastus lateralis, rectus femoris, vastus medialis, tibialis anterior, biceps femoris, semitendinosus, inner gastrocnemius, outer gastrocnemius, inner soleus, outer soleus, peroneus longus and peroneus brevis.

Sparse mode uses camera positions only in the first and last rows. Leave unused entries as JSON `null`. The model calculates its sparse movement estimate from the two supplied positions. The `--sensors` options are `camera`, `force`, `muscle` and `both`. An included sensor must have a valid reading in each of the four rows.

The model learned from standing-up and sitting-down recordings from healthy adult men in Gait120. It uses the same weights for both movements within each training run. Each forecast averages three runs. The study used camera tracks the authors had already filled and smoothed. This package demonstrates a forecast for prepared recordings and leaves camera connection, live timing and other movements outside its tested scope.

[Study and matched results](https://eliminatenoise.github.io/NeuroTranslation/joint-alpha/chair-directions/)

Model inputs derive from Gait120 by Seungbum Koo, Junyo Boo, Dongwook Seo and Minseung Kim. Their source data retain [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) attribution. The [source archive](https://doi.org/10.6084/m9.figshare.27677016.v1) and [recording methods](https://doi.org/10.1038/s41597-025-05391-0) describe the original measurements. The package applies the CC0 dedication in LICENSE.txt to original project contributions and preserves the upstream attribution. The archive contains model weights and an invented example, with no participant recordings.
