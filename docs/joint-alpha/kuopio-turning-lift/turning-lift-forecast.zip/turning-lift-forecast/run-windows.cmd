@echo off
setlocal
if defined VIRTUAL_ENV if exist "%VIRTUAL_ENV%\Scripts\python.exe" goto venv
where py >nul 2>nul
if errorlevel 1 goto python
py -3 -B "%~dp0forecast.py" %*
goto finished
:venv
"%VIRTUAL_ENV%\Scripts\python.exe" -B "%~dp0forecast.py" %*
goto finished
:python
python -B "%~dp0forecast.py" %*
:finished
set "status=%errorlevel%"
if "%~1"=="" pause
exit /b %status%
