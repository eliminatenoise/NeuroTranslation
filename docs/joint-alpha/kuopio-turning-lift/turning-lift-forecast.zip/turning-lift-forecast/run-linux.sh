#!/bin/sh
folder=$(CDPATH= cd -P "$(dirname "$0")" && pwd) || exit 1
if [ -n "${VIRTUAL_ENV:-}" ] && [ -x "$VIRTUAL_ENV/bin/python" ]; then
    interpreter="$VIRTUAL_ENV/bin/python"
else
    interpreter=python3
fi
"$interpreter" -B "$folder/forecast.py" "$@"
status=$?
if [ "$#" -eq 0 ] && [ -t 0 ] && [ -t 1 ]; then
    printf '\nPress Return to close. '
    read -r answer
fi
exit "$status"
