# Where will the right wrist move in the next tenth of a second?

Pause a turning lift. Keep the last 25 positions of both wrists and hide what happens next. These models forecast how far the right wrist will move in the next 100 milliseconds, in millimetres along the laboratory’s X, Y and Z axes. The first run uses a hand-written movement and sensor signals generated from equations. You can change those inputs and make a new forecast.

## Run the example

Extract the entire ZIP. With Python and NumPy installed, open a terminal in the extracted folder and run

```sh
python forecast.py
```

The table shows two simple guesses alongside six fitted forecasts using wrist motion alone. One guess leaves the wrist still. The other keeps it moving at the speed and in the direction it travelled over the last 50 ms. In the synthetic example that second guess moves it about 17.5 mm along X, −9.0 mm along Y and 36.5 mm along Z. A negative value means movement along the negative laboratory axis.

Each training set has the same number of examples from each contributor as the other two sets. The first used straight lifts, the second turning lifts, and the third half of each. For each set, a linear model (`ridge`) learns a fixed weight for each reading. A small NeuroTranslate attention model can put different weights on earlier moments as the movement changes. Its forecast averages three separately fitted networks.

| To try | Command from the extracted folder |
| --- | --- |
| Compare every sensor choice for every model | `python forecast.py --arm all` |
| Use turning-lift training with wrist, muscle and floor readings | `python forecast.py --mixture rotation_only --family attention --arm all_current` |
| Compare a supplied history using just the wrists | `python forecast.py --input my-history.json --arm motion --json` |
| Replay all 38 forecasts and compare them with the included reference | `python forecast.py --self-check` |

The text table rounds to three decimals. The `--json` option gives the calculated values in millimetres. By default, all three training sets and both model families run on the same wrist history. Every selection includes both simple guesses.

## Supply one history

Copy `example.json` as `my-history.json`. Keep its schema field. Each array inside `history` has 25 rows, oldest first. One row represents one 100 Hz camera frame. The last row is the moment of the forecast, 240 ms after the first row. This input format takes prepared readings. The caller establishes observation quality, calibration, channel order and timing from the original instruments.

| Array | Six numbers in one row |
| --- | --- |
| `motion_mm` | Right wrist X, Y, Z followed by left wrist X, Y, Z in mm. For each wrist, take the midpoint of its two markers and subtract its own midpoint at the last frame. All six final entries are zero. The recorded markers were RWRA/RWRB and LWRA/LWRB. |
| `current_emg` or `earlier_emg` | Root mean square (RMS) of six surface muscle signals over the specified block. Right then left middle deltoid, middle trapezius and lower trapezius. On each side the native Quattro label order was EMG 2, EMG 1, EMG 3, with sensor 62782 on the right and 62780 on the left. |
| `current_force` or `earlier_force` | Mean Fx, Fy, Fz readings for floor plate 2 followed by Fx, Fy, Fz for plate 3, in declared newtons and each plate’s own axes. |

For an optical frame numbered *g*, each current muscle or plate reading summarizes the 24 analog samples in block *g* − 2 on the 2400 Hz instrument clock. Each earlier reading uses block *g* − 102, one second before the corresponding current block. Zero muscle RMS is a valid observed value. For a selected sensor group, supply every reading. You may omit groups the selected models do not use.

| Sensor choice (`--arm`) | Inputs besides the two wrists |
| --- | --- |
| `motion` | Wrists alone |
| `motion_and_emg` | Current muscle |
| `motion_and_ground_force` | Current plates |
| `all_current` | Current muscle and current plates |
| `earlier_emg` | Earlier muscle and **current** plates |
| `earlier_emg_and_ground_force` | Earlier muscle and earlier plates |

For every arm, the model puts the six wrist coordinates, six muscle readings and six plate readings in that order. It uses the training set’s means and scales to standardize present signals. Eighteen additional flags identify which values are present. An observed zero keeps its flag. A training-constant input maps to zero with its availability preserved. The model restores each output axis to millimetres with its own training scale and mean before averaging the three attention forecasts.

The target is displacement of the midpoint of two markers on the skin. To obtain a forecast of absolute position, add the XYZ displacement to the right wrist’s position at the final input frame in the same laboratory coordinates. The example supplies no observed endpoint. To measure error on new data, compare that predicted position with the observed marker midpoint ten camera frames later. Muscle channels retain the archive’s native scale because the source labels disagree about voltage units. Floor forces describe the loads at the plates. The archive supplies no independent known-load calibration for this comparison. These models were fitted to this lifting task and instrument setup. A different movement or device needs its own test.

## Launch on a desktop

The example and weights are included. After Python and its dependencies are present, forecasting and the self-check run locally with the network disconnected.

| System | Launcher |
| --- | --- |
| Windows | Double-click `run-windows.cmd`, or run it from an activated Python environment. |
| macOS | Open `run-macos.command` in Terminal or type `sh run-macos.command` in the extracted folder. |
| Linux | In the extracted folder run `sh run-linux.sh`. |

With Python 3.12 or newer available, the pinned environment uses `python -m pip install -r requirements.txt`. On systems that use `python3` or `py -3`, substitute that command for `python`. You can install into a virtual environment and run the launcher from its activated terminal. For a machine kept offline, bring matching package wheels for its Python version and operating system, then run `python -m pip install --no-index --find-links /path/to/wheels -r requirements.txt`. The archive contains the forecast program and its fitted parameters. Python and dependency wheels are supplied separately. Linux execution was verified. The macOS and Windows launchers are provided for compatible local installations.

## Sources and contents

Alexander K. Beattie, Matti J. Kortelainen, Paavo Vartiainen and Pasi A. Karjalainen released the Kuopio Full-Body Dataset under CC BY 4.0. We formed time-aligned histories from the straight and turning lifts, fitted the models and retained the parameters and training scales. The example contains generated signals. The upstream NeuroTranslate inference code carries a CC0 1.0 dedication. [Dataset v1.2.1](https://doi.org/10.5281/zenodo.24194741) · [Recording methods](https://doi.org/10.1038/s41597-026-08550-z) · [Dataset licence](https://creativecommons.org/licenses/by/4.0/) · [NeuroTranslate source](https://github.com/eliminatenoise/NeuroTranslation/tree/3277eb7ca195b85c8963cf0ed3e6fcc284558e1e/models/neurotranslate-0.0)

| Files | Purpose |
| --- | --- |
| `forecast.py`, `wrist_forecast.py`, `numpy_inference.py` | Command-line entry, feature preparation and fitted model inference. |
| `weights/` | One file of training scales, six fitted linear models and 18 attention checkpoints for each training mixture. The index gives the SHA-256 digest of each numerical file. |
| `position-25x32.npy` | The attention model’s fixed float32 position values for the 25 input frames. The NumPy reader uses these original CPU values and multiplies the dense layers in the CPU reference’s layout. |
| `example.json`, `example-reference.json` | One generated history and the corresponding full-precision reference forecasts. |
| `run-linux.sh`, `run-macos.command`, `run-windows.cmd`, `requirements.txt` | Desktop launchers and pinned dependencies. |
| `NUMPY-INFERENCE-LICENSE.txt`, `SHA256SUMS.txt` | Upstream licence and checksums for the other supplied files. |
