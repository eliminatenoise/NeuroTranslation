"""Where will the right wrist move in the next tenth of a second?"""

import argparse
import json
import os
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent


def print_forecasts(source, predictions):
    training = {"lift_only": "Straight", "rotation_only": "Turning", "mixed_tasks": "Both"}
    sensors = {"motion": "Wrists", "motion_and_emg": "Wrists, muscle",
               "motion_and_ground_force": "Wrists, plates", "all_current": "Wrists, muscle, plates",
               "earlier_emg": "Wrists, earlier muscle, plates",
               "earlier_emg_and_ground_force": "Wrists, earlier muscle and plates"}
    controls = {"persistence": "Hold still", "velocity": "Continue"}
    print("Right wrist displacement over the next 100 ms")
    print(f"Forecast from the {source}. X, Y and Z are in laboratory millimetres.")
    print(f"{'Training lifts':<15} {'Model':<10} {'Readings':<34} {'X':>9} {'Y':>9} {'Z':>9}")
    for method, (x, y, z) in predictions.items():
        if method in controls:
            mix_label, model_label, sensor_label = "—", controls[method], "Right wrist"
        else:
            mix, family, arm = method.split("/")
            mix_label, model_label, sensor_label = training[mix], family.title(), sensors[arm]
        print(f"{mix_label:<15} {model_label:<10} {sensor_label:<34} {x:9.3f} {y:9.3f} {z:9.3f}")


def check_example(model, runtime):
    import numpy as np

    reference = json.loads((HERE / "example-reference.json").read_text(encoding="utf-8"))
    signals = runtime.read_history(HERE / "example.json")
    predictions = model.forecast(signals, arm="all")
    if set(reference["expected_mm"]) != set(predictions):
        raise ValueError("The example methods differ from the reference.")
    biggest = 0.0
    for name, value in predictions.items():
        expected = np.asarray(reference["expected_mm"][name])
        if expected.shape != (3,):
            raise ValueError(f"Expected one XYZ reference vector for {name}.")
        error = np.abs(value[0] - expected)
        # Attention limits follow the fitted target scales; ridge and controls use mm.
        if "/attention/" in name:
            limit = reference["attention_tolerance_mm_by_mixture"][name.split("/")[0]]
        else:
            limit = reference["ridge_and_control_tolerance_mm"]
        if not np.all(error <= limit):
            raise ValueError(f"Example forecast differs from reference for {name}: {error.tolist()} mm.")
        biggest = max(biggest, float(np.max(error)))
    return {"methods_checked": len(predictions), "max_absolute_difference_mm": biggest}


def main():
    # The CLI handles tiny matrices. Only set local defaults when the caller has
    # not selected pool sizes. Importing the model as a library leaves them alone.
    for variable in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
        os.environ.setdefault(variable, "1")
    try:
        import wrist_forecast as runtime
    except ModuleNotFoundError as error:
        if error.name != "numpy":
            raise
        print("This Python needs NumPy. See the setup commands in README.md.", file=sys.stderr)
        return 1
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, help="One prepared JSON history. The default is the synthetic example.")
    parser.add_argument("--mixture", choices=(*runtime.MIXTURES, "all"), default="all", help="Training examples to use.")
    parser.add_argument("--family", choices=(*runtime.FAMILIES, "all"), default="all", help="Ridge, attention or both.")
    parser.add_argument("--arm", choices=(*runtime.SENSORS, "all"), default="motion", help="Signals used for the forecast.")
    parser.add_argument("--json", action="store_true", help="Print full-precision values as JSON.")
    parser.add_argument("--self-check", action="store_true", help="Check all 38 methods on the included synthetic history.")
    args = parser.parse_args()
    try:
        model = runtime.ForecastModel()
        if args.self_check:
            if args.input is not None or (args.mixture, args.family, args.arm) != ("all", "all", "motion"):
                parser.error("--self-check uses the fixed synthetic example and every model.")
            result = check_example(model, runtime)
            if args.json:
                print(json.dumps(result, allow_nan=False))
            else:
                print(f"{result['methods_checked']} synthetic forecasts matched the reference. "
                      f"The largest axis difference was {result['max_absolute_difference_mm']:.8g} mm.")
            return 0
        inputs = runtime.read_history(args.input or HERE / "example.json")
        source = "supplied history" if args.input is not None else "synthetic example"
        forecasts = model.forecast(inputs, mixture=args.mixture, family=args.family, arm=args.arm)
        predictions = {method: array[0].tolist() for method, array in forecasts.items()}
        if args.json:
            print(json.dumps({"input": source, "horizon_ms": 100, "axes": ["X", "Y", "Z"],
                              "unit": "mm", "right_wrist_displacement_forecast": predictions}, allow_nan=False))
        else:
            print_forecasts(source, predictions)
    except (KeyError, ValueError, OSError, FloatingPointError, OverflowError) as error:
        parser.exit(2, f"Cannot forecast: {error}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
