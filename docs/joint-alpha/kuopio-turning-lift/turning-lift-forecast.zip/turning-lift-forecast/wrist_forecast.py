"""Predict the next 100 ms of right-wrist displacement from prepared sensor histories."""

from hashlib import sha256
import io
import json
from pathlib import Path

import numpy as np

from numpy_inference import JointModel


HERE = Path(__file__).resolve().parent
MIXTURES = ("lift_only", "rotation_only", "mixed_tasks")
FAMILIES = ("ridge", "attention")
SENSORS = {
    "motion": (None, None),
    "motion_and_emg": ("current_emg", None),
    "motion_and_ground_force": (None, "current_force"),
    "all_current": ("current_emg", "current_force"),
    "earlier_emg": ("earlier_emg", "current_force"),
    "earlier_emg_and_ground_force": ("earlier_emg", "earlier_force"),
}
GROUPS = {"motion_mm", "current_emg", "current_force", "earlier_emg", "earlier_force"}
SEEDS = (17, 29, 41)
TASK = "right_wrist_displacement"
HISTORY_SCHEMA = "turning-lift-history-v1"
INDEX_SHA256 = "e59e3e58ad9a4a97ceabd82013b5818a7700ef6fdff7dc6ebb0a27c2c1259088"


def choose(value, choices):
    if value == "all":
        return tuple(choices)
    if value not in choices:
        raise ValueError(f"Choose one of {', '.join(choices)} or all.")
    return (value,)


def read_history(path):
    """Read one 25-frame issue from JSON and add the batch dimension."""
    def unique_fields(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"Repeated input field {key}.")
            result[key] = value
        return result

    record = json.loads(Path(path).read_text(encoding="utf-8"), object_pairs_hook=unique_fields)
    if (not isinstance(record, dict) or set(record) != {"schema", "history"}
            or record["schema"] != HISTORY_SCHEMA or not isinstance(record["history"], dict)):
        raise ValueError(f"Supply schema {HISTORY_SCHEMA} and one history object.")
    signals = {}
    for name, rows in record["history"].items():
        if (not isinstance(rows, list) or len(rows) != 25 or
                any(not isinstance(row, list) or len(row) != 6 or
                    any(type(value) not in (float, int) for value in row) for row in rows)):
            raise ValueError(f"{name} needs 25 rows of six numbers, oldest first.")
        signals[name] = np.asarray(rows, dtype=np.float64)[None]
    return signals


def validated_inputs(signals, arms):
    if not isinstance(signals, dict) or not set(signals) <= GROUPS:
        raise ValueError("Supply only the named wrist, muscle and force histories.")
    required = {"motion_mm"} | {s for arm in arms for s in SENSORS[arm] if s is not None}
    missing = sorted(required - signals.keys())
    if missing:
        raise ValueError("Missing histories for these sensor choices: " + ", ".join(missing))
    inputs = {}
    for name, raw in signals.items():
        array = np.asarray(raw)
        if array.ndim != 3 or array.shape[1:] != (25, 6) or not len(array) or array.dtype.kind not in "fiu":
            raise ValueError(f"{name} needs numerical histories with shape (cases, 25, 6).")
        values = np.asarray(array, dtype=np.float64)
        if not np.isfinite(values).all() or (name.endswith("emg") and np.any(values < 0)):
            raise ValueError(f"{name} requires finite readings. Muscle RMS values must be nonnegative.")
        inputs[name] = values
    n = len(inputs["motion_mm"])
    if any(len(a) != n for a in inputs.values()):
        raise ValueError("Each signal group must have the same number of histories.")
    if np.any(inputs["motion_mm"][:, -1] != 0):
        raise ValueError("Subtract each wrist's own final XYZ from its history. Its last row must be zero.")
    return inputs


def normalized_arms(inputs, stats, arm):
    """The fitted float32 grid has 18 values followed by 18 availability flags."""
    mean, scale, constant = stats
    picked_signals = (("motion_mm", slice(0, 6)),
                      (SENSORS[arm][0], slice(6, 12)),
                      (SENSORS[arm][1], slice(12, 18)))
    values = np.zeros(inputs["motion_mm"].shape[:-1] + (18,), dtype=np.float32)
    present = np.zeros_like(values)
    for name, cols in picked_signals:
        if name is not None:
            values[..., cols] = (inputs[name] - mean[cols]) / scale[cols]
            present[..., cols] = 1
    values[..., constant] = 0
    grid = np.concatenate((values, present), axis=-1)
    if not np.isfinite(grid).all():
        raise ValueError("A standardized value exceeds the float32 model range.")
    return grid


def displacement(z, scales):
    standardized = np.asarray(z, dtype=np.float64)
    return np.where(scales["y_constant"], 0.0, standardized) * scales["y_scale"] + scales["y_mean"]


class ForecastModel:
    """Read fitted parameters from the package and forecast one or more histories."""

    def __init__(self):
        self.weights = HERE / "weights"
        index = (self.weights / "index.json").read_bytes()
        if sha256(index).hexdigest() != INDEX_SHA256:
            raise ValueError("The fitted parameter inventory differs from this edition.")
        self.hashes = json.loads(index)
        self.cache = {}

    def _load(self, mix, filename):
        key = f"{mix}/{filename}"
        if key not in self.cache:
            raw = (self.weights / key).read_bytes()
            if sha256(raw).hexdigest() != self.hashes[key]:
                raise ValueError(f"The fitted file {key} differs from this edition.")
            with np.load(io.BytesIO(raw), allow_pickle=False) as fitted:
                self.cache[key] = {name: fitted[name] for name in fitted.files}
        return self.cache[key]

    def forecast(self, signals, mixture="all", family="all", arm="motion"):
        """Return arrays of XYZ displacement in mm, one [cases,3] array per method."""
        mixtures = choose(mixture, MIXTURES)
        families = choose(family, FAMILIES)
        arms = choose(arm, SENSORS)
        inputs = validated_inputs(signals, arms)
        n = len(inputs["motion_mm"])
        with np.errstate(over="raise", invalid="raise", divide="raise"):
            predictions = {"persistence": np.zeros((n, 3)), "velocity": -2.0 * inputs["motion_mm"][:, -6, :3]}
            for mix in mixtures:
                scales = self._load(mix, "scales.npz")
                stats = tuple(scales[f"x_{field}"] for field in ("mean", "scale", "constant"))
                for sensor in arms:
                    grid = normalized_arms(inputs, stats, sensor)
                    if "ridge" in families:
                        ridge = self._load(mix, f"{sensor}-ridge.npz")
                        z = grid.reshape(n, 25 * 36).astype(np.float64) @ ridge["coefficients"] + ridge["intercept"]
                        predictions[f"{mix}/ridge/{sensor}"] = displacement(z, scales)
                    if "attention" in families:
                        # The published reader rebuilds binary availability from finite inputs.
                        observed = np.where(grid[..., 18:] == 1, grid[..., :18], np.float32(np.nan))
                        members = []
                        for seed in SEEDS:
                            network = JointModel(self._load(mix, f"{sensor}-{seed}.npz"))
                            members.append(displacement(network.predict(TASK, observed), scales))
                        predictions[f"{mix}/attention/{sensor}"] = np.mean(np.stack(members), axis=0)
        if any(not np.isfinite(value).all() for value in predictions.values()):
            raise ValueError("The supplied values exceed the forecast range.")
        return predictions
