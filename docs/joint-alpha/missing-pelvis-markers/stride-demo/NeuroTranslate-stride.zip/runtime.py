"""Run the frozen 100 ms stride forecast with NumPy and the shipped weights."""

from dataclasses import dataclass
import hashlib
from io import BytesIO
from math import erf, sqrt
from pathlib import Path

import numpy as np

if __package__:
    from .cadence_cycle import repeat_cycle
else:
    from cadence_cycle import repeat_cycle


TARGETS = ("four_marker", "rear_pair")
MARKERS = ("left_front", "right_front", "left_rear", "right_rear")
RATES_HZ = (100, 150, 250)
HISTORY_SAMPLES = {100: 80, 150: 120, 250: 200}
HORIZON_MS = 100
WEIGHTS_SHA256 = "2960e3f5b075118d071c42375bf34c099011f63da1c61c5d03f179bd34d46add"
AGES_MS = np.arange(750, -1, -50)
LAYERS = {
    "positions": (16, 32),
    "token.weight": (32, 16),
    "token.bias": (32,),
    "context.weight": (32, 3),
    "context.bias": (32,),
    "attention.in_proj_weight": (96, 32),
    "attention.in_proj_bias": (96,),
    "attention.out_proj.weight": (32, 32),
    "attention.out_proj.bias": (32,),
    "norm.weight": (32,),
    "norm.bias": (32,),
    "readout.0.weight": (32, 64),
    "readout.0.bias": (32,),
    "readout.2.weight": (2, 32),
    "readout.2.bias": (2,),
}
SCALES = {
    "position_center": (8,),
    "position_scale": (8,),
    "context_center": (3,),
    "context_scale": (3,),
    "target_scale": (2,),
}


@dataclass(frozen=True)
class Forecast:
    """Parallel outputs in batch order, with both physical targets in millimetres."""

    prediction_mm: np.ndarray
    stride_mm: np.ndarray
    cycle_frames: np.ndarray
    issued: np.ndarray


def _read_arrays(saved, prefix, shapes):
    dtype = np.float32 if prefix == "state" else np.float64
    arrays = {}
    for name, shape in shapes.items():
        value = saved[f"{prefix}.{name}"]
        if value.shape != shape or value.dtype != dtype or not np.isfinite(value).all():
            raise ValueError(f"Invalid {prefix} array {name}.")
        value.flags.writeable = False
        arrays[name] = value
    return arrays


class CadenceForecaster:
    def __init__(self, state, scale):
        self._state = state
        self._scale = scale

    @classmethod
    def load(cls, weights_path):
        """Load the exact frozen checkpoint from its NumPy archive."""
        data = Path(weights_path).read_bytes()
        if hashlib.sha256(data).hexdigest() != WEIGHTS_SHA256:
            raise ValueError("The weights file differs from the frozen stride checkpoint.")
        with np.load(BytesIO(data), allow_pickle=False) as saved:
            expected = {f"state.{key}" for key in LAYERS} | {f"scale.{key}" for key in SCALES}
            if set(saved.files) != expected:
                raise ValueError("Unexpected arrays in the weights file.")
            state = _read_arrays(saved, "state", LAYERS)
            scale = _read_arrays(saved, "scale", SCALES)
        if any((scale[name] <= 0).any() for name in ("position_scale", "context_scale", "target_scale")):
            raise ValueError("The weights contain invalid normalization scales.")
        return cls(state, scale)

    def predict(self, history_mm, rate_hz, *, chunk_size=256):
        """Forecast from histories ending at issue, with shape (rows, samples, 4).

        Use the order in MARKERS and NaN for readings that are unavailable. Give
        at least 80 native samples at 100 Hz, 120 at 150 Hz or 200 at 250 Hz.
        Both targets are NaN if fewer than two issue markers are visible. With
        no usable earlier cycle, both targets and cycle_frames are zero.
        """
        if rate_hz not in RATES_HZ:
            raise ValueError("Use a native sampling rate of 100, 150 or 250 Hz.")
        if not isinstance(chunk_size, int) or chunk_size < 1:
            raise ValueError("Use a positive whole-number chunk size.")
        values = np.asarray(history_mm, dtype=np.float64)
        needed = HISTORY_SAMPLES[rate_hz]
        if values.ndim != 3 or values.shape[-1] != 4 or values.shape[1] < needed:
            raise ValueError(f"Provide rows of at least {needed} samples with four named marker heights.")
        n_rows = len(values)
        prediction = np.empty((n_rows, 2), dtype=np.float64)
        stride = np.empty_like(prediction)
        cycles = np.empty(n_rows, dtype=int)
        horizon = int(rate_hz * HORIZON_MS / 1000)
        for start in range(0, n_rows, chunk_size):
            rows = slice(start, start + chunk_size)
            past = values[rows]
            baseline, selected = repeat_cycle(past, rate_hz, horizon)
            stride[rows], cycles[rows] = baseline, selected
            corrected = baseline.copy()
            active = selected > 0
            if active.any():
                tokens, context = self._inputs(past[active], baseline[active], selected[active], rate_hz)
                corrected[active] += self._correction(tokens, context) * self._scale["target_scale"]
            prediction[rows] = corrected
        return Forecast(prediction, stride, cycles, np.isfinite(stride).all(axis=1))

    def _inputs(self, history, stride, cycle, rate_hz):
        observed = np.isfinite(history)
        frames = np.arange(history.shape[1])
        latest = np.where(observed, frames[None, :, None], -1).max(axis=1)
        anchor = np.take_along_axis(history, np.maximum(latest, 0)[:, None], axis=1)
        slots = history.shape[1] - 1 - np.ceil(AGES_MS * rate_hz / 1000).astype(int)
        current = history[:, slots]
        present = observed[:, slots]
        earlier = slots[None] - cycle[:, None]
        past = history[np.arange(len(history))[:, None], earlier.clip(min=0)]
        paired = present & np.isfinite(past) & (earlier >= 0)[..., None]
        positions = np.concatenate((current - anchor, current - past), axis=2)
        mask = np.concatenate((present, paired), axis=2)
        normalized = (positions - self._scale["position_center"]) / self._scale["position_scale"]
        tokens = np.concatenate((np.where(mask, normalized, 0.), mask), axis=2).astype(np.float32)
        context = np.column_stack((stride, cycle / rate_hz))
        context = (context - self._scale["context_center"]) / self._scale["context_scale"]
        return tokens, context.astype(np.float32)

    def _linear(self, x, layer):
        return x @ self._state[layer + ".weight"].T + self._state[layer + ".bias"]

    def _correction(self, tokens, context):
        state = self._state
        sequence = self._linear(tokens, "token") + state["positions"] + self._linear(context, "context")[:, None]
        packed = sequence @ state["attention.in_proj_weight"].T + state["attention.in_proj_bias"]
        q, k, v = (part.reshape(len(tokens), 16, 4, 8).transpose(0, 2, 1, 3)
                   for part in np.split(packed, 3, axis=2))
        logits = (q @ k.swapaxes(-1, -2)) / np.float32(sqrt(8))
        exp = np.exp(logits - logits.max(axis=-1, keepdims=True))
        attention = exp / exp.sum(axis=-1, keepdims=True)
        attended = (attention @ v).transpose(0, 2, 1, 3).reshape(len(tokens), 16, 32)
        residual = sequence + self._linear(attended, "attention.out_proj")
        centered = residual - residual.mean(axis=2, keepdims=True)
        normalized = centered / np.sqrt(np.mean(centered**2, axis=2, keepdims=True) + np.float32(1e-5))
        normalized = normalized * state["norm.weight"] + state["norm.bias"]
        readout = np.concatenate((normalized[:, -1], normalized.mean(axis=1)), axis=1)
        hidden = self._linear(readout, "readout.0")
        # The frozen model uses exact GELU rather than the tanh approximation.
        erf_arg = hidden / np.float32(sqrt(2))
        probabilities = np.fromiter(map(erf, erf_arg.flat), dtype=np.float32, count=hidden.size).reshape(hidden.shape)
        activated = np.float32(.5) * hidden * (1 + probabilities)
        return self._linear(activated, "readout.2")
