"""Forecast from three invented histories of four pelvis markers."""

import argparse
import os
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rate", type=int, choices=(150, 250), default=250,
                        help="camera readings per second")
    rate = parser.parse_args().rate
    for variable in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS",
                     "BLIS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
        os.environ.setdefault(variable, "1")
    try:
        import numpy as np
    except ModuleNotFoundError as error:
        if error.name != "numpy":
            raise
        parser.exit(1, "The Python example needs NumPy. Use a Python environment with NumPy, "
                       "or open index.html in your browser.\n")
    from runtime import CadenceForecaster

    samples = np.arange(4 * rate // 5)
    phase = 2 * np.pi * samples[:, None] / (0.32 * rate) + [0.0, 0.2, 0.5, 0.7]
    complete = [986, 990, 998, 994] + 26 * np.sin(phase)
    histories = np.stack((complete, complete, complete))
    histories[1, :-1] = np.nan
    histories[2, -1, 1:] = np.nan
    checkpoint = Path(__file__).resolve().with_name("stride-weights.npz")
    forecast = CadenceForecaster.load(checkpoint).predict(histories, rate)

    print(f"Invented marker histories at {rate} readings per second")
    print("Predicted height change 100 ms after the last reading")
    for name, issued, frames, pair in zip(
        ("Repeating stride", "Markers visible only in the final reading", "One final marker"),
        forecast.issued, forecast.cycle_frames, forecast.prediction_mm, strict=True,
    ):
        print(f"\n{name}")
        if not issued:
            print("Forecast withheld. The last reading needs at least two visible markers.")
            continue
        if frames == 0:
            print("No usable earlier stride. The forecast assumes zero height change.")
        else:
            print(f"Earlier stride matched {frames * 1000 / rate:.0f} ms back.")
        four, rear = pair
        print(f"All four markers {four:+.2f} mm   Rear pair {rear:+.2f} mm")


if __name__ == "__main__":
    main()
