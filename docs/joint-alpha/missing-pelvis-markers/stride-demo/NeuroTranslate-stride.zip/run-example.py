"""Forecast from invented readings or a prepared file of four marker heights."""

import argparse
import csv
from math import isfinite
import os
from pathlib import Path


CSV_COLUMNS = ("frame", "left_front_mm", "right_front_mm", "left_rear_mm", "right_rear_mm")


def read_history(path, sample_count, horizon_frames):
    heights = []
    last = None
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.reader(stream, strict=True)
        if next(reader, []) != list(CSV_COLUMNS):
            raise ValueError("The CSV needs this header: " + ",".join(CSV_COLUMNS))
        for row in reader:
            if len(heights) == sample_count:
                raise ValueError(f"Provide exactly {sample_count} consecutive native readings.")
            if len(row) != len(CSV_COLUMNS):
                raise ValueError(f"Line {reader.line_num} needs a frame number and four marker cells.")
            frame_text = row[0].strip()
            if not frame_text.isascii() or not frame_text.isdecimal() or len(frame_text) > 19:
                raise ValueError(f"Line {reader.line_num} needs a nonnegative whole frame number.")
            frame = int(frame_text)
            if frame > (1 << 63) - 1 - horizon_frames:
                raise ValueError(f"Line {reader.line_num} has a frame number too large to forecast.")
            if last is not None and frame != last + 1:
                raise ValueError(f"Frame numbers must be consecutive. Check line {reader.line_num}.")
            last = frame
            try:
                values = [float(text) if text else None for text in map(str.strip, row[1:])]
            except ValueError:
                raise ValueError(f"Line {reader.line_num} needs finite heights or blank cells.") from None
            if any(value is not None and not isfinite(value) for value in values):
                raise ValueError(f"Line {reader.line_num} needs finite heights or blank cells.")
            heights.append(values)
    if len(heights) != sample_count:
        raise ValueError(f"Provide exactly {sample_count} consecutive native readings.")
    return heights, last


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rate", type=int, choices=(100, 150, 250),
                        help="native camera readings per second (invented example defaults to 250)")
    parser.add_argument("--csv", type=Path, help="prepared frame numbers and four marker heights in millimetres")
    args = parser.parse_args()
    if args.csv is not None and args.rate is None:
        parser.error("Pass --rate with the camera's verified native rate when using --csv.")
    rate = args.rate if args.rate is not None else 250

    for variable in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS",
                     "BLIS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
        os.environ.setdefault(variable, "1")
    try:
        import numpy as np
    except ModuleNotFoundError as error:
        if error.name != "numpy":
            raise
        parser.exit(1, "The Python example needs NumPy. Use a Python environment with NumPy, "
                       "or open index.html in your browser.\n")
    from runtime import CadenceForecaster, HISTORY_SAMPLES, HORIZON_MS

    sample_count = HISTORY_SAMPLES[rate]
    checkpoint = Path(__file__).resolve().with_name("stride-weights.npz")
    model = CadenceForecaster.load(checkpoint)
    if args.csv is None:
        samples = np.arange(sample_count)
        phase = 2 * np.pi * samples[:, None] / (0.32 * rate) + [0.0, 0.2, 0.5, 0.7]
        complete = [986, 990, 998, 994] + 26 * np.sin(phase)
        histories = np.stack((complete, complete, complete))
        histories[1, :-1] = np.nan
        histories[2, -1, 1:] = np.nan
        forecast = model.predict(histories, rate)
        names = ("Repeating stride", "Markers visible only in the final reading", "One final marker")
        print(f"Invented marker histories at {rate} readings per second")
    else:
        horizon = rate * HORIZON_MS // 1000
        try:
            heights, last = read_history(args.csv, sample_count, horizon)
        except (OSError, UnicodeError, csv.Error):
            parser.error("Could not read the prepared CSV. Use a readable UTF-8 comma-separated file.")
        except ValueError as error:
            parser.error(str(error))
        histories = np.asarray([heights], dtype=float)
        try:
            with np.errstate(over="raise", invalid="raise"):
                forecast = model.predict(histories, rate)
        except FloatingPointError:
            parser.error("The marker heights are outside the numeric range. Check the scale in millimetres.")
        names = ("Prepared marker history",)
        print(f"Readings {last - sample_count + 1} through {last} at {rate} readings per second")
        print(f"Last reading {last}. Forecast target {last + horizon}.")

    print("Predicted height change 100 ms after the last reading")
    for name, issued, frames, pair in zip(
        names, forecast.issued, forecast.cycle_frames, forecast.prediction_mm, strict=True,
    ):
        print(f"\n{name}")
        if not issued:
            print("Forecast withheld. The last reading needs at least two visible markers.")
            continue
        if frames == 0:
            print("No usable earlier stride. The forecast assumes zero height change.")
        else:
            print(f"Earlier stride matched {frames * 1000 / rate:.0f} ms back.")
        four, rear = pair
        print(f"All four markers {four:+.2f} mm   Rear pair {rear:+.2f} mm")


if __name__ == "__main__":
    main()
