@echo off
setlocal DisableDelayedExpansion
if not exist "%~dp0index.html" (
    >&2 echo Extract the whole ZIP, then run this launcher in the same folder as index.html.
    exit /b 1
)
start "" "%~dp0index.html"
