#!/bin/sh

folder=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd -P) || exit 1
page="$folder/index.html"
if [ ! -f "$page" ]; then
    printf '%s\n' 'Extract the whole ZIP, then run this launcher in the same folder as index.html.' >&2
    exit 1
fi
if command -v xdg-open >/dev/null 2>&1; then
    exec xdg-open "$page"
fi
if command -v gio >/dev/null 2>&1; then
    exec gio open "$page"
fi
printf 'Open this file in your browser\n%s\n' "$page" >&2
exit 1
