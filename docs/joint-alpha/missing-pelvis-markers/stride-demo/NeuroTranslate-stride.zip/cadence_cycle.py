"""Forecast periodic vertical movement by comparing earlier cycles."""

import numpy as np


def repeat_cycle(history, rate_hz, horizon_frames):
    """Use only supplied histories, each ending at its prediction issue.

    Match the last 200 ms against earlier same-marker samples, then replay
    the measured displacement at the equivalent point in the previous cycle.
    Return a zero-displacement estimate when there is no usable earlier cycle.
    """
    values = np.asarray(history, dtype=np.float64)
    if values.ndim != 3 or values.shape[-1] != 4 or np.isinf(values).any():
        raise ValueError("Provide a batch of camera histories with four named marker heights.")
    if rate_hz <= 0 or not isinstance(horizon_frames, int) or horizon_frames <= 0:
        raise ValueError("Use a positive camera rate and a positive whole-frame horizon.")
    tail = round(.20 * rate_hz)
    min_lag = max(horizon_frames + 1, round(.22 * rate_hz))
    max_lag = round(.60 * rate_hz)
    if min_lag > max_lag or values.shape[1] < tail + max_lag:
        raise ValueError("History is too short to test the declared period range.")
    present = np.isfinite(values)
    can_issue = present[:, -1].sum(axis=1) >= 2
    prediction = np.where(can_issue[:, None], np.zeros((len(values), 2)), np.nan)
    chosen = np.zeros(len(values), dtype=int)
    smallest = np.full(len(values), np.inf)

    recent = values[:, -tail:]
    recent_ok = present[:, -tail:]
    for lag in range(min_lag, max_lag + 1):
        old = values[:, -tail - lag:-lag]
        both = recent_ok & present[:, -tail - lag:-lag]
        enough = (both.sum(axis=1) >= round(.75 * tail)).sum(axis=1) >= 2
        displacement_valid = present[:, -1 - lag] & present[:, -1 - lag + horizon_frames]
        eligible = can_issue & enough & displacement_valid[:, 2:].any(axis=1)
        squared = np.square(np.where(both, recent - old, 0.))
        error = np.divide(squared.sum(axis=(1, 2)), both.sum(axis=(1, 2)),
                          out=np.full(len(values), np.inf), where=enough)
        better = eligible & (error < smallest)
        chosen[better], smallest[better] = lag, error[better]

    for lag in np.unique(chosen[chosen > 0]):
        selected = chosen == lag
        earlier = values[selected, -1 - lag]
        later = values[selected, -1 - lag + horizon_frames]
        common = np.isfinite(earlier) & np.isfinite(later)
        displacement = np.where(common, later - earlier, 0.)
        prediction[selected, 0] = displacement.sum(1) / common.sum(1)
        prediction[selected, 1] = displacement[:, 2:].sum(1) / common[:, 2:].sum(1)
    return prediction, chosen
