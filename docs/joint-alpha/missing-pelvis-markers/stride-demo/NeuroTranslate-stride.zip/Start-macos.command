#!/bin/sh

folder=$(CDPATH='' cd "$(dirname "$0")" && pwd -P) || exit 1
page="$folder/index.html"
if [ ! -f "$page" ]; then
    printf '%s\n' 'Extract the whole ZIP, then run this launcher in the same folder as index.html.' >&2
    exit 1
fi
exec /usr/bin/open "$page"
