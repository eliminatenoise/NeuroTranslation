"""Open the downloaded NeuroTranslate preview on this computer."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import argparse
import webbrowser


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--no-browser", action="store_true", help="Print the local address without opening a tab.")
    args = parser.parse_args()
    assets = Path(__file__).resolve().parent / "app"
    handler = partial(SimpleHTTPRequestHandler, directory=str(assets))
    with ThreadingHTTPServer(("127.0.0.1", 0), handler) as server:
        address = f"http://127.0.0.1:{server.server_address[1]}/"
        print(f"Open {address} in your browser. Press Ctrl+C in this window to stop.", flush=True)
        if not args.no_browser:
            webbrowser.open(address)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
