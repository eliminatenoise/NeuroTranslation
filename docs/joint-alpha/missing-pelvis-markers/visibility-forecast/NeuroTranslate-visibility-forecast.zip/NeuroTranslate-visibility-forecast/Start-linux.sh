#!/bin/sh
exec python3 "$(dirname -- "$0")/launch.py" "$@"
