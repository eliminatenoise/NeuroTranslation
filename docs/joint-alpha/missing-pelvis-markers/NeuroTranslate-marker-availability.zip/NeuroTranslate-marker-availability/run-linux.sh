#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 2
exec python3 pelvis.py "$@"
