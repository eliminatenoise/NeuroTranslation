"""Predict movement for two explicitly named pelvis marker targets."""
import argparse
import json
import os
from pathlib import Path

if __name__=="__main__":
    for name in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS"):
        os.environ.setdefault(name,"1")
try:
    import numpy as np
except ModuleNotFoundError as error:
    if __name__=="__main__" and error.name=="numpy":
        raise SystemExit("Install NumPy with python -m pip install numpy, then run this file again.") from error
    raise
from numpy_attention import one_checkpoint

ROOT=Path(__file__).resolve().parent
TARGETS=("four_marker_centre","back_pair_centre")


def encode(heights,force,centres,scales):
    x=np.asarray(heights,dtype=np.float64)
    if x.ndim!=3 or x.shape[1:]!=(5,4) or not len(x):
        raise ValueError("Provide five earlier rows of four named marker heights.")
    if np.isinf(x).any():
        raise ValueError("Use null when a marker is unavailable.")
    visible=np.isfinite(x)
    count=visible[:,-1].sum(axis=1)
    if np.any(count<2):
        raise ValueError("At least two marker heights are needed at prediction time.")
    measured=np.where(visible,x,0.)
    origin=measured[:,-1].sum(axis=1)/count
    ref=np.broadcast_to(origin[:,None,None],(len(x),4,1))
    previous=visible[:,1:]&visible[:,:-1]
    available=np.ones((len(x),4,1),dtype=bool)
    if force is None:
        load=np.zeros((len(x),4,1))
        load_flag=np.zeros((len(x),4,1),dtype=bool)
    else:
        load=np.asarray(force,dtype=np.float64)
        if load.shape!=(len(x),4) or not np.isfinite(load).all():
            raise ValueError("Force mode needs four prepared and finite plate values per history.")
        load=load[:,:,None]
        load_flag=available
    active=np.concatenate((visible[:,1:],previous,available,load_flag),axis=2)
    values=np.concatenate((measured[:,1:]-ref,measured[:,1:]-measured[:,:-1],ref,load),axis=2)
    scaled=np.where(active,(values-centres)/scales,0.).astype(np.float32)
    model_input=np.concatenate((scaled,active[:,:,:8],load_flag),axis=2).astype(np.float32)
    if not np.isfinite(model_input).all():
        raise ValueError("The supplied measurements exceed the input range.")
    return model_input


class PelvisForecast:
    def __init__(self,path=ROOT/"weights.npz"):
        with np.load(path,allow_pickle=False) as source:
            self.arrays={k:source[k] for k in source.files}

    def predict(self,heights,force=None,training="mixed"):
        if training not in ("mixed","complete"):
            raise ValueError("Choose mixed or complete training.")
        arrays=self.arrays
        x=encode(heights,force,arrays["center"],arrays["scale"])
        outputs=[]
        for seed in arrays["seeds"]:
            prefix=f"{training}/{seed}/"
            weights={k.removeprefix(prefix):v for k,v in arrays.items() if k.startswith(prefix)}
            with np.errstate(over="ignore",invalid="ignore"):
                outputs.append(one_checkpoint(x,weights))
        result=np.mean(outputs,axis=0)*arrays["target_spread"]+arrays["target_average"]
        if not np.isfinite(result).all():
            raise ValueError("The model could not forecast that input magnitude.")
        return result


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--history",type=Path,default=ROOT/"invented-inputs.json")
    cli.add_argument("--back-only",action="store_true",help="Hide both front markers from the example.")
    cli.add_argument("--use-force",action="store_true",help="Include the four prepared force readings.")
    cli.add_argument("--training",choices=("mixed","complete"),default="mixed")
    cli.add_argument("--self-check",action="store_true")
    args=cli.parse_args()
    try:
        model=PelvisForecast()
        doc=json.loads(args.history.read_text())
        values=np.array([doc["heights_mm"]],dtype=float)
        force=np.array([doc["force_log_change"]],dtype=float) if args.use_force else None
        if args.self_check:
            if args.history!=ROOT/"invented-inputs.json":cli.error("--self-check uses the included example.")
            proof=json.loads((ROOT/"example-reference.json").read_text())
            errors=[]
            for n,row in proof["forecasts"].items():
                visible=np.array(row["visible"],dtype=bool)
                readings=np.where(visible,values,np.nan)
                feed=np.array([doc["force_log_change"]]) if row["with_force"] else None
                pred=model.predict(readings,feed,row["training"])[0]
                errors.extend(np.abs(pred-np.array(row["value_mm"])).tolist())
            if max(errors)>proof["tolerance_mm"]:raise ValueError("A saved two-target example differs from the model.")
            print(f"All {len(errors)} target outputs match. Largest error {max(errors):.8g} mm.")
            return
        if args.back_only:values[:,:,:2]=np.nan
        both=model.predict(values,force,args.training)[0]
        print(f"Four-marker centre moves {both[0]:+.3f} mm in the next 100 ms.")
        print(f"Back-marker centre moves {both[1]:+.3f} mm in the next 100 ms.")
        if args.history==ROOT/"invented-inputs.json":print("The example uses invented readings.")
    except (ValueError,KeyError,OSError,TypeError) as error:
        cli.error(str(error))


if __name__=="__main__":
    main()
