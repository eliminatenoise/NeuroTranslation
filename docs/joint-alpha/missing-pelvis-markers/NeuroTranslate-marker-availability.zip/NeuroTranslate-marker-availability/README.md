# Forecast movement with some pelvis markers missing

This program predicts vertical movement 100 milliseconds ahead. It prints two distances in millimetres. One follows the centre of four pelvis markers. The other follows the centre of the two back markers. The program keeps these two targets distinct when the front readings are missing.

## Open the example

Extract the download. The program uses Python 3 and NumPy. If NumPy is missing, run `python -m pip install numpy`. Use the command your computer recognizes for Python.

- Linux. Run `./run-linux.sh` from the extracted folder.
- macOS. Open `run-macos.command`, or run it from the extracted folder.
- Windows. Open `run-windows.cmd`.
- Any platform. Run `python pelvis.py`. Add `--back-only` to remove the front markers. Add `--self-check` to verify the saved forecasts for all tested input combinations.

The default example uses invented readings. The default model saw several different marker combinations during training. Use `--training complete` to try the version trained on complete camera readings. Include `--use-force` to supply the four prepared force values.

## Supply earlier measurements

Run `python pelvis.py --history my-history.json`. Include a `heights_mm` array with five rows. They end 200, 150, 100, 50 and zero milliseconds before your forecast. Use the column order left front, right front, left back and right back. Use absolute vertical heights in millimetres above the lab’s origin. Use JSON `null` for unavailable positions. At least two marker readings must be present in the last row.

If you use the force option, include `force_log_change` with four numbers for the four most recent camera times. For each time, find the mean vertical force of the two foot plates over the preceding 40 ms, floor it at one newton, and take the natural log. Subtract the first window's value from all four.

The downloadable models use the attention architecture. The study also reports separate linear and recent-speed baselines. The models learned from archived recordings. The held test deliberately removed originally recorded marker positions. It does not establish how the program will perform with naturally missing tracks, different movements, or a live camera.

[Interactive study and results](https://eliminatenoise.github.io/NeuroTranslation/joint-alpha/missing-pelvis-markers/)

Training draws on [Gait120](https://doi.org/10.6084/m9.figshare.27677016.v1) by Koo, Boo, Seo and Kim and [Monash sit-to-walk](https://doi.org/10.26180/24515092.v4) by Perera and colleagues. The test source is [Notre Dame’s non-cyclic recordings](https://doi.org/10.7274/28689221.v1) by Alizadeh Noghani, Green and Bolívar-Nieto. Source data retain CC BY 4.0 attribution. The package contains original model contributions and invented inputs, with no participant recordings. See LICENSE.txt for the project’s CC0 dedication.
