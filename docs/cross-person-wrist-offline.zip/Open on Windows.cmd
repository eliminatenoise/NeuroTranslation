@echo off
start "" "%~dp0cross-person-wrist\index.html"
