#!/bin/sh
cd "$(dirname "$0")/cross-person-wrist" || exit 1
exec open "$(pwd -P)/index.html"
