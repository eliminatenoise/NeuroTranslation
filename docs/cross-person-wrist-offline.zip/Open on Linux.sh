#!/bin/sh
cd "$(dirname "$0")/cross-person-wrist" || exit 1
exec xdg-open "$(pwd -P)/index.html"
