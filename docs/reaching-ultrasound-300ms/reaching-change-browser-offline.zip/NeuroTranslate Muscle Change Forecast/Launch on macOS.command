#!/bin/sh
cd "$(dirname "$0")" || exit 1
exec open "$PWD/index.html"
