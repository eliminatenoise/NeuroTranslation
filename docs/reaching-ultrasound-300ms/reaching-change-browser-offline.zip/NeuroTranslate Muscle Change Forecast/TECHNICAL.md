# Browser implementation of the signed change forecast

Run the extracted `index.html` in a current browser. The three launchers open that file. All calculations use local scripts and the included example or your JSON file. Full and Lite NeuroSurge link through Movement mirror and the existing reaching page when online. The forecast page requests no camera access.

Supply `history` as one array of shape `[10, 22]` or `[10, 26]`, or batch up to 50 identically shaped histories. Each row covers one prior 20 ms bin. Values 1–12 are shoulder-centred xyz coordinates of the hand, forearm, elbow and upper arm in mm. Values 13–16 are their presence flags. Values 17–19 are root mean square triceps, biceps and palm voltages in mV. Values 20–22 are voltage presence flags. Flags accept 0 or 1. Set absent values to zero. Columns 23–26 are ignored.

All methods forecast the signed 300 ms change in point spread in the ultrasound plane. They use zero change, a linear motion fit, or a recurrent fit that uses absolute or first-position-relative motion with or without voltages. The software retains the published weights and averages two fitted seeds per recurrent method. The two tissues share one symmetric display scale.

The withheld same-study cohort consists of six people and 7,503 forecast times per tissue. The table gives mean absolute error with equal participant weight. The motion-only linear fit averaged 0.153 mm across the two tissues. The participant-level intervals versus zero change include a tie in both tissues. The example has no measured outcome. The replay does not measure physical sensor delivery. [Methods and scores](https://github.com/eliminatenoise/NeuroTranslation/blob/main/benchmarks/reaching-ultrasound-300ms/change-forecast/reserved/TECHNICAL.md)
