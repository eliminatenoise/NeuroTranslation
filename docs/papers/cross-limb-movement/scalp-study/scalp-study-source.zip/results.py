"""Turn the published aggregate records into the tables and figure in the manuscript."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DOMAINS = ('balance', 'way')
NAMES = {'balance': 'Balance', 'way': 'Grasp'}
MUSCLE = 'muscle_mae'
PATH = 'path_mean_distance_mm'
END = 'endpoint_distance_mm'
OUTCOMES = (MUSCLE, PATH)


def number(value, digits):
    return f'{value:.{digits}f}'.replace('-', '−')


def precision(study, metric):
    return 6 if study == 'way' and metric == MUSCLE else 4


def interval(values, digits):
    return ' to '.join(number(v, digits) for v in values)


def table(caption, columns, rows):
    return {'caption': caption, 'columns': columns, 'rows': rows}


def outcome(study, metric):
    if metric == MUSCLE:
        return 'Leg muscles (µV)' if study == 'balance' else 'Arm muscles (native)'
    return 'Sacrum path (mm)' if study == 'balance' else 'Wrist path (mm)'


def coverage_figure(coverage):
    counts = coverage['joint_sites']['balance']
    guides = []
    for x, label in [(192, '0%'), (335, '50%'), (478, '100%')]:
        guides.append(f'<line x1="{x}" x2="{x}" y1="17" y2="87" stroke="#c4cfce"/>'
                      f'<text x="{x}" y="103" text-anchor="middle">{label}</text>')
    for i, (name, key) in enumerate([('Any central site', 'at_least_one_of_three_central'),
                                     ('All three central sites', 'three_central'), ('All nine sites', 'nine')]):
        y = 23 + 24*i
        events, people = counts[key]['events'], counts[key]['contributors']
        width = 286 * events / coverage['events']['balance']
        guides.append(f'<text x="0" y="{y+7}">{name}</text>'
                      f'<rect x="192" y="{y-3}" width="{width:.4f}" height="12" fill="#477684"/>'
                      f'<text x="494" y="{y+7}">{events:,} / {people}</text>')
    return ('<figure class="intervalFigure"><svg viewBox="0 0 620 110" role="img" '
            'aria-labelledby="cov-title cov-desc" xmlns="http://www.w3.org/2000/svg">'
            '<title id="cov-title">Balance events with available scalp sites</title><desc id="cov-desc">'
            'At least one central site was usable in 5,179 events from 18 people. All three were usable in '
            '2,572 events from nine people. All nine candidate sites were usable in 541 events from two people.'
            '</desc><g fill="#203f45" font-family="PaperSans,Arial,sans-serif" font-size="14">'
            + ''.join(guides) + '</g></svg><figcaption><b>Figure 2.</b> Share of 5,179 balance events '
            'retained as more sites are required. Labels give events / people. All nine includes FC1, '
            'FC2, CP1 and CP2. All nine were present on every eligible lift.</figcaption></figure>')


def sections():
    studies = json.loads((ROOT / 'transformer.json').read_text())['studies']
    linear = json.loads((ROOT / 'linear.json').read_text())
    cov = json.loads((ROOT / 'coverage.json').read_text())
    prose = json.loads((ROOT / 'interpretation.json').read_text())
    sites, primary, seed_rows, controls, axes, artifacts, regression = ([] for _ in range(7))
    for site in ('C3', 'Cz', 'C4', 'Fp1', 'Fp2'):
        row = [site, cov['socket'][site]]
        for dom in DOMAINS:
            n = studies[dom]['availability']['all']['channels'][site]
            row.append(f"{n['events']:,} / {n['people']}")
        sites.append(row)
    for dom in DOMAINS:
        study = studies[dom]
        comp = study['central_minus']['reference']
        for metric in OUTCOMES:
            n = precision(dom, metric)
            label = outcome(dom, metric)
            # Keep the two native amplitude units and the two marker frames separate.
            item = study['primary'][metric]
            primary.append([label, number(comp['central'][metric], n), number(comp['comparator'][metric], n),
                            number(item['mean'], n), interval(item['ci95'], n), number(item['upper98_75'], n),
                            f"{item['people_lower']}/{study['people']}"])
            seed_rows.append([label, *[number(v, n) for v in item['seed_means']], number(item['seed_sd'], n)])
            line = linear[dom]['reference']['metrics'][metric]
            regression.append([label, number(line['central'], n), number(line['comparison'], n),
                               number(line['central_minus_comparison'], n), interval(line['ci95'], n),
                               number(line['upper98_75'], n), f"{line['people_lower']}/{study['people']}"])
        for label, key in [('Wrong trial', 'wrong_trial'), ('Forehead', 'frontal'), ('Eye', 'eye'), ('Neck', 'neck')]:
            item = study['central_minus'][key]
            digits = (6 if dom == 'way' else 5, precision(dom, PATH))
            vals = []
            if item['people'] == 0:
                if key == 'eye':
                    artifacts.append(['Grasp · Eye / neck', '0 / 0', 'Unavailable', 'Unavailable'])
                continue
            for metric, n in zip(OUTCOMES, digits):
                q = item['paired_intervals'][metric]
                vals.append(number(q['mean'], n) + ' [' + interval(q['ci95'], n) + ']')
            artifacts.append([f"{NAMES[dom]} · {label}", f"{item['events']:,} / {item['people']}", *vals])
        for tag, side in [('Measured', 'central'), ('Reference', 'comparator')]:
            val = comp[side]
            vals = [number(val[f'axis{i}_mae_mm'], 3) for i in range(3)]
            bias = [number(val[f'axis{i}_bias_mm'], 3) for i in range(3)]
            axes.append([f'{NAMES[dom]} · {tag}', ' / '.join(study['axes']), ' / '.join(vals), ' / '.join(bias)])
    subset_rows = []
    subsets = {'balance': [('standing','Standing'),('walking','Walking'),
                           ('available_central_sites_1','One central site'),('available_central_sites_2','Two central sites'),
                           ('available_central_sites_3','Three central sites')],
               'way': [('fully_observed','All five muscles'),('quality_masked','Three or four muscles')]}
    for dom in DOMAINS:
        for key, label in subsets[dom]:
            item = studies[dom]['primary_subgroups'][key]
            n = item['people']
            vals = ([number(item['central_minus_reference'][m],precision(dom,m)) for m in OUTCOMES]
                    if n >= 2 else ['Not reported','Not reported'])
            subset_rows.append([f'{NAMES[dom]} · {label}', f"{item['events']:,} / {n}", *vals])
    for name, key in [('Measured central', 'central'), ('Reference input', 'reference'), ('Original shared', 'original'),
                      ('Half specialist', 'specialist_exposure'), ('Full specialist', 'specialist_steps'),
                      ('Hold position', 'stationary'), ('Velocity · 31.25 ms', 'velocity_exact_31_25ms'),
                      ('Velocity · 125 ms', 'velocity_exact_125ms')]:
        row = [name]
        for dom in DOMAINS:
            comp = studies[dom]['central_minus']['reference' if key == 'central' else key]
            vals = comp['central' if key == 'central' else 'comparator']
            row.extend(number(vals[m], 6 if dom == 'way' and m == MUSCLE else 3) for m in (MUSCLE, PATH, END))
        controls.append(row)
    return {'prose': prose, 'illustrations': {'COVERAGE_FIGURE': coverage_figure(cov)}, 'tables': {
        'SITES': table('Table 1. Which electrodes were available?', ['Site', 'Balance socket', 'Balance (of 5,179 / 18)', 'Grasp (of 1,764 / 6)'], sites),
        'PRIMARY': table('Table 2. Measured scalp versus fixed references', ['Outcome', 'Measured', 'Reference', 'Difference', '95% interval', 'U', 'Lower'], primary),
        'SEEDS': table('Table 3. Difference at each training seed', ['Outcome', '1641', '2718', '3917', 'Seed SD'], seed_rows),
        'ARTIFACT': table('Table 4. Does the same-trial central recording do better?', ['Study · Control', 'Events / people', 'Muscle difference [95% interval]', 'Path difference [95% interval]'], artifacts),
        'CONTROLS': table('Table 5. Errors of trained models and simple forecasts',
                          ['Method', 'Leg (µV)', 'Sacrum path (mm)', 'Sacrum end (mm)', 'Arm (native)', 'Wrist path (mm)', 'Wrist end (mm)'], controls),
        'AXES': table('Table 6. Path errors along three axes (mm)', ['Study · Input', 'Axis order', 'Absolute errors', 'Signed errors'], axes),
        'SUBSETS': table('Table 7. Changes in error within the observed groups', ['Study · Observed group','Events / people','Muscle difference','Path difference'], subset_rows),
        'LINEAR': table('Table 8. Measured scalp versus fixed references in a linear model', ['Outcome', 'Measured', 'Reference', 'Difference', '95% interval', 'U', 'Lower'], regression)}}
