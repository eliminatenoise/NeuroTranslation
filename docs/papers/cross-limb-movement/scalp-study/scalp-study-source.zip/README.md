# What does the scalp add to a movement forecast?

Extract all files into a directory, then run this command there with Python 3,
Chromium or Google Chrome, and pypdf installed.

    python -m pip install pypdf==6.21.2
    python build.py --out output

The original local render used Python 3.14.8, Chromium 155.0.8059.84 and
pypdf 6.21.2. Specify another local executable with --browser PATH. To build
only the self-contained HTML and source archive, run with --html-only, using
Python alone. The fonts, figure, tables and scores are local. After installing
the software the build works offline. A different renderer may change the PDF.

Edit paper.html.in for the manuscript, interpretation.json for the study
interpretation, style.css for typography, and results.py for table and figure
generation. transformer.json gives the full study-level Transformer results,
including absolute and signed errors by axis, named-muscle outcomes, comparisons
on matched participants/events, and group-specific results. Its availability
object gives electrode and muscle coverage for the individual task conditions.
linear.json contains the separate weighted linear regression results. coverage.json
gives the electrode correspondence and joint-site counts. No participant-level
recordings or outcomes are needed to reproduce the paper.

The PDF includes this source archive and notices as attachments. Original study
credits and reuse terms are in DATA-LICENCE.txt. The main cross-limb movement
article and model have their own source packages.

[Main paper](https://eliminatenoise.github.io/NeuroTranslation/papers/cross-limb-movement/)
· [Movement model](https://eliminatenoise.github.io/NeuroTranslation/cross-limb-movement/)
· [Recorded examples](https://eliminatenoise.github.io/Interoceptomics/cross-limb-movement/)
