# Should the wrist and pelvis have separate movement decoders?

This editable supplement contains the manuscript (paper.html.in), tables
and results copy (tables.json), stylesheet, embedded sans-serif font sources,
license notices and the build script. Full-precision study-level scores, control contrasts, channel denominators, training times and group summaries are in aggregate.json. Numerical results are aggregate scores.
No trial arrays are needed to rebuild the paper.

Run from this directory with Python 3, Chromium or Google Chrome, and pypdf:

    python -m pip install pypdf==6.21.2
    python build.py --out output

The output directory contains the standalone HTML, PDF and editable ZIP.
Use --html-only to rebuild the HTML and ZIP using Python's standard library.
Use --browser to specify another Chromium-compatible executable. Public links
in the PDF use the published paper's address. The source archive and notices
are also embedded in the PDF. The original render used Chromium 155 on Linux.
See DATA-LICENCE.txt for study credits, transformations, and licensing.
