# Can a model trained on balance help forecast a reach?

The manuscript, CSS, embedded Liberation Sans files, Python build and group results
in this directory rebuild the six-page paper and its standalone HTML edition. The
PDF carries the editable ZIP and the four attribution/licence texts as attachments.

## Build the paper

Extract all files into one folder. Install Python, Chromium (or Google Chrome) and
pypdf. From that folder run

    python -m pip install pypdf==6.21.2
    python build.py --out output

Open output/index.html or output/cross-limb-movement.pdf. The original build used
Python 3.14.8, pypdf 6.21.2 and Chromium 155.0.8059.84 on Linux. Use --browser
with the path to another local Chromium executable. With --html-only, Python's
standard library rebuilds the HTML and ZIP. The fonts, figures and results are
local, so building and reading the paper work offline once the required software
is installed. Other rendering engines and versions may produce different PDFs.

Edit paper.html.in for the manuscript, style.css for typography and layout, and
build.py for the two data-bound tables and statistical figure. scores.json holds
the aggregate development and historical assessment results. The trained Transformer
and linear control packages include their own source-to-model instructions.
[Transformer](https://eliminatenoise.github.io/NeuroTranslation/cross-limb-movement/) ·
[Linear controls](https://eliminatenoise.github.io/NeuroTranslation/cross-limb-controls/) ·
[Recorded examples](https://eliminatenoise.github.io/Interoceptomics/cross-limb-movement/) ·
[Paper downloads](https://eliminatenoise.github.io/NeuroTranslation/papers/cross-limb-movement/)

## Read the scores

Each neural and linear summary keeps the original two studies separate. Muscle
amplitude is in microvolts for balance and in native units for the grasp. Path
and final-point errors are millimetres in each study's own coordinates.
Contrasts give a paired difference (first method minus second), the central
95% participant bootstrap interval, the one-sided 98.75th-percentile upper
bound and a count of people with a smaller error for the first method. The
cross_family comparisons are secondary and report ordinary 95% intervals.

In neural summaries, joint means a shared backbone trained for 192 updates
on each study. specialist means the same architecture given the same first 192
batches from its target study, and specialist-total means 384 target updates.
adapt uses 192 source updates then 192 target updates. foreign-frozen uses
unchanged source weights with target-history scales. paired-source and shuffled
compare intact and within-condition permuted labels during source pretraining
with the same admitted source examples before adaptation. The wrong_history_joint
comparisons substitute a nonoverlapping muscle history at assessment time.
Group membership stays fixed by person. Historical arm channel outcomes with one
contributing person are omitted while their support counts are retained.

The linear summaries distinguish a model trained on both domains, a foreign
fit used directly with history-only scaling, fits trained on all or a limited
fraction of the target domain, and calibration towards coefficients from the
other domain. The two constant-velocity controls use different windows. The
Transformer benchmark uses the latest two causal marker knots. The separate
linear benchmark extends the displacement over the previous 125 milliseconds.
See DATA-LICENCE.txt for attribution, transformations and terms.
