"""Build the cross-limb paper, its standalone HTML and its attached editable source."""
import argparse
import base64
import hashlib
from html import escape
import json
from pathlib import Path
import shutil
import subprocess
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

SOURCE = Path(__file__).resolve().parent
STEM = 'cross-limb-movement'
TITLE = 'Can a model trained on balance help forecast a reach?'
FONTS = (('Regular', 'normal', 400), ('Bold', 'normal', 700), ('Italic', 'italic', 400))
NOTICES = ('DATA-LICENCE.txt', 'CC-BY-4.0.txt', 'CC0-1.0.txt', 'Liberation-font-LICENSE.txt')
MEMBERS = ('README.md','build.py','paper.html.in','style.css','scores.json',*NOTICES,
           *(f'LiberationSans-{name}.ttf' for name, _, _ in FONTS))
MUSCLE, PATH = 'muscle_mae', 'path_mean_distance_mm'


def typography():
    rules = []
    for face, style, weight in FONTS:
        data = base64.b64encode((SOURCE/f'LiberationSans-{face}.ttf').read_bytes()).decode('ascii')
        rules.append(f'@font-face{{font-family:PaperSans;src:url(data:font/ttf;base64,{data}) format("truetype");'
                     f'font-style:{style};font-weight:{weight}}}')
    return '\n'.join(rules) + (SOURCE/'style.css').read_text()


def table(headings, rows, caption):
    columns = ''.join(f'<th scope="col">{escape(c)}</th>' for c in headings)
    body = []
    for row in rows:
        cells = ''.join(f'<td data-label="{escape(h)}">{escape(v)}</td>' for h,v in zip(headings[1:], row[1:], strict=True))
        body.append(f'<tr><th scope="row">{escape(row[0])}</th>{cells}</tr>')
    return (f'<table aria-label="{escape(caption)}"><thead><tr>{columns}</tr></thead><tbody>'
            + ''.join(body) + '</tbody></table>')


def signed(value, digits):
    return f'{value:+.{digits}f}'.replace('-', '−')


def interval(item, digits):
    lo, hi = item['ci95']
    return f'{signed(item["mean"], digits)} [{signed(lo, digits)}, {signed(hi, digits)}]'


def benchmark(record):
    rows = []
    for label, key in [('Joint · 384 updates','joint'),('One study · 192','specialist'),
                       ('One study · 384','specialist-total'),('Recent RMS + velocity¹','persistence-linear')]:
        lower, upper = [record[d]['methods'][key] for d in ['lower','upper']]
        rows.append((label,f'{lower[MUSCLE]:.4f}',f'{lower[PATH]:.4f}',f'{upper[MUSCLE]:.7f}',f'{upper[PATH]:.4f}'))
    return table(('Forecast','Leg (µV)','Sacrum (mm)','Arm (native)','Wrist (mm)'),rows,'Historical errors by study and training budget')


def effect_figure(record):
    panels = [('lower',MUSCLE,'Leg amplitude (µV)',(-.025,.025),3),
              ('lower',PATH,'Sacrum path (mm)',(-.3,.3),3),
              ('upper',MUSCLE,'Arm amplitude (native)',(-.00015,.00015),7),
              ('upper',PATH,'Wrist path (mm)',(-.35,.35),3)]
    html = []
    for dom,metric,label,(lo,hi),digits in panels:
        m = record[dom]['contrasts']['joint minus specialist']['differences'][metric]
        def x(value):
            return 8 + (value-lo)/(hi-lo)*204
        value = interval(m,digits)
        left, right = m['ci95']
        html.append(f'<div class="plotrow"><div><b>{label}</b><span>{value}</span></div>'
                    f'<svg viewBox="0 0 220 42" role="img" aria-label="{escape(label)} difference {escape(value)}">'
                    '<path d="M8 12 H212" stroke="#cfdbdf"/><path d="M110 2 V23" stroke="#617b88"/>'
                    f'<path d="M{x(left)} 6v12 M{x(left)} 12 H{x(right)} M{x(right)} 6v12" stroke="#1c5970" stroke-width="2.5" fill="none"/>'
                    f'<circle cx="{x(m["mean"])}" cy="12" r="4" fill="#b95325"/>'
                    f'<text x="8" y="37">{lo:g}</text><text x="110" y="37" text-anchor="middle">0</text><text x="212" y="37" text-anchor="end">+{hi:g}</text>'
                    '</svg></div>')
    return ''.join(html)


def transfers(data):
    rows = []
    for family in ['Transformer', 'Linear']:
        for domain, name, direction in [('lower','balance','arm to leg'),('upper','grasp_lift','leg to arm')]:
            if family == 'Transformer':
                result = data['neural_assessment'][domain]['contrasts']['adapt minus specialist']['differences']
                m, p = result[MUSCLE], result[PATH]
            else:
                contrast = 'arm_to_leg_minus_leg_limited' if domain == 'lower' else 'leg_to_arm_minus_arm_limited'
                orig = data['linear_assessment'][name]['paired_differences'][contrast]
                m,p = ({'mean':orig['mean'][i], 'ci95':orig['ci95'][i]} for i in (0,1))
            rows.append((f'{family} · {direction}', interval(m,5 if domain == 'lower' else 7),
                         interval(p,3)))
    return table(('Pretraining direction','Amplitude change [95% interval]','Path change, mm [95% interval]'),
                 rows, 'Transfer minus a fit with the same target data')


def build(out, browser):
    data = json.loads((SOURCE/'scores.json').read_text())
    manuscript = (SOURCE/'paper.html.in').read_text()
    for page in range(1, 7):
        folio = f'<header class="folio"><span>NeuroTranslation <i>/</i> Cross-limb movement</span><span>{page} / 6</span></header>'
        manuscript = manuscript.replace('@@FOLIO@@', folio, 1)
    for key, value in {'STYLE':typography(), 'BENCHMARK':benchmark(data['neural_assessment']),
                       'EFFECTS':effect_figure(data['neural_assessment']), 'TRANSFER':transfers(data)}.items():
        field = f'@@{key}@@'
        if manuscript.count(field) != 1:
            raise ValueError(f'Missing or repeated field {key}')
        manuscript = manuscript.replace(field, value)
    if '@@' in manuscript:
        raise ValueError('Unresolved manuscript field')
    out.mkdir(parents=True, exist_ok=True)
    page = out/'index.html'
    page.write_text(manuscript, encoding='utf-8')
    archive = out/f'{STEM}-source.zip'
    with ZipFile(archive, 'w') as bundle:
        for name in MEMBERS:
            info = ZipInfo(name, (2026,11,21,0,0,0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = ZIP_DEFLATED
            bundle.writestr(info,(SOURCE/name).read_bytes())
    if browser:
        print_pdf(page, archive, browser)


def print_pdf(page, archive, browser):
    from pypdf import PdfReader, PdfWriter
    from pypdf.generic import ArrayObject, ByteStringObject
    with TemporaryDirectory() as directory:
        temp = Path(directory)
        pdf = temp/'print.pdf'
        subprocess.run([browser,'--headless','--disable-gpu','--disable-background-networking',
                        '--no-first-run','--no-default-browser-check','--no-pdf-header-footer',
                        f'--user-data-dir={temp/"profile"}',f'--print-to-pdf={pdf}',page.as_uri()],
                       check=True, capture_output=True, timeout=90)
        reader = PdfReader(pdf)
        if len(reader.pages) != 6:
            raise ValueError(f'Expected six pages, found {len(reader.pages)}')
        writer = PdfWriter(clone_from=reader)
        writer.metadata = {'/Title':TITLE,'/Author':'@eliminatenoise',
                           '/Subject':'Short-horizon muscle and marker forecasts in a cued grasp and a visual balance task'}
        for file in [archive, *(SOURCE/name for name in NOTICES)]:
            writer.add_attachment(file.name,file.read_bytes())
        identity = ByteStringObject(hashlib.sha256(archive.read_bytes()).digest()[:16])
        writer._ID = ArrayObject([identity,identity])
        writer.write(page.with_name(f'{STEM}.pdf'))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=SOURCE/'output')
    parser.add_argument('--browser', help='Chromium or Google Chrome executable')
    parser.add_argument('--html-only', action='store_true')
    args = parser.parse_args()
    browser = None if args.html_only else args.browser or shutil.which('chromium') or shutil.which('google-chrome')
    if not args.html_only and browser is None:
        parser.error('Install Chromium or pass its path with --browser.')
    build(args.out.resolve(), browser)
