"""Build the heel-and-force manuscript from published aggregate results."""
import argparse
import hashlib
from html import escape
import json
from pathlib import Path
import shutil
import subprocess
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parent
GROUPS = ('development', 'historical-primary', 'historical-supplement')
LABELS = ('Development', 'Original walks', 'Later walks')
MEMBERS = ('README.md','paper.html.in','style.css','scores.json','build.py','CC-BY-4.0.txt','CC0-1.0.txt','Liberation-font-LICENSE.txt')

def table(labels, rows, first_heading='Forecast', extra_class=''):
    header = ''.join(f'<th scope="col">{escape(label)}</th>' for label in labels)
    rows_html=[]
    for name, values, highlighted in rows:
        cells = ''.join(f'<td data-label="{escape(label)}">{escape(value)}</td>' for label,value in zip(labels,values,strict=True))
        style = ' class="key"' if highlighted else ''
        rows_html.append(f'<tr{style}><th scope="row">{escape(name)}</th>{cells}</tr>')
    return f'<table class="scores {extra_class}"><thead><tr><th scope="col">{first_heading}</th>{header}</tr></thead><tbody>{"".join(rows_html)}</tbody></table>'

def pair(metrics, first='heel_mm', second='force_N'):
    def n(obj,places):
        if obj is None:
            return '—'
        value=obj['mean'] if isinstance(obj,dict) else obj
        return f'{value:.{places}f}'
    return f'{n(metrics.get(first),3)} / {n(metrics.get(second),2)}'

def transformer_table(data):
    methods = (
        ('Shared Transformer','joint','joint'),('Separate specialists','heel','force'),
        ('Transformer without voltage','marker','marker'),('Three similar walks','marker_knn','marker_knn'),
        ('Linear ridge, all inputs','ridge_full','ridge_full'),('Linear ridge without voltage','ridge_marker','ridge_marker'),
        ('Stationary heel / typical force','stationary','phase'),('Carry forward measured force','privileged_hold','privileged_hold'))
    rows=[]
    for label,heel,force in methods:
        values=[]
        for key in GROUPS:
            m=data[key]['transformer']['models']
            values.append(pair({'heel_mm':m[heel]['heel_mm'],'force_N':m[force]['force_N']}))
        rows.append((label,values,heel=='joint'))
    return table(LABELS,rows)

def fixed_table(data):
    methods=(('Rank-two correction','encoder_full_rank2'),('Unrestricted correction','encoder_full_unrestricted'),
             ('Rank two without voltage','encoder_motion_rank2'),('Full linear correction','linear_full'),
             ('Random encoder, rank two','random_full_rank2'),('Starting guess','recent_heel'))
    return table(LABELS,[(label,[pair(data[key]['fixed']['main']['methods'][model],'heel_error_mm','force_error_n')
                                 for key in GROUPS],model=='encoder_full_rank2') for label,model in methods])

def signed(value,places):
    return f'{value:+.{places}f}'.replace('-','−')

def contrasts(data):
    rows=[]
    for label,key in zip(LABELS,GROUPS):
        difference=data[key]['transformer']['joint_minus']
        values=[]
        for model,measure,places in (('heel','heel_mm',3),('force','force_N',2)):
            d=difference[model][measure]
            low, high = d['participant_bootstrap_95']
            values.append(f"{signed(d['mean'],places)} [{signed(low,places)}, {signed(high,places)}]")
        rows.append((label,values,False))
    return table(('Heel difference (mm)','Force difference (N)'),rows,'Walks')

def matched(data):
    rows=[]
    for label,model in [('Transformer, correct voltage','joint'),('Transformer, other walk','wrong_emg'),('Transformer, without voltage','marker')]:
        rows.append((label,[pair(data[key]['transformer']['donor_metrics'][model]) for key in GROUPS],model=='joint'))
    for label,model in [('Rank two, correct voltage','encoder_full_rank2'),('Rank two, other walk','wrong_full'),('Rank two, without voltage','encoder_motion_rank2')]:
        rows.append((label,[pair(data[key]['fixed']['same_phase_donor_support']['methods'][model],'heel_error_mm','force_error_n')
                            for key in GROUPS],model=='encoder_full_rank2'))
    return table(LABELS,rows)

def roster(data):
    rows=[]
    for label,key,selected in zip(LABELS,GROUPS,('30 / 90','10 / 30','10 / 18')):
        cohort=data[key]['fixed']['main']
        rows.append((label,[selected,f"{cohort['people']} / {cohort['repeats']}",str(cohort['windows'])],False))
    return table(('Selected people / walks','Eligible people / walks','Windows'),rows,'Recordings','roster')

def build(folder):
    data=json.loads((ROOT/'scores.json').read_text())
    template=(ROOT/'paper.html.in').read_text()
    for page in range(1,7):
        template=template.replace('@@FOLIO@@', f'<header><span>NeuroTranslation · Heel and force</span><span>{page} / 6</span></header>',1)
    abstract=('In the original assessment the shared model missed the heel by 1.156 mm and the force by 92.36 N, '
              'against 1.183 mm and 93.73 N for the specialists. The later walks also favoured sharing on both averages. '
              'All four uncertainty intervals for those differences included zero. In the fixed-encoder experiment, '
              'compressing the correction increased heel error in both assessments. Neither experiment established '
              'an advantage for the matched muscle recordings under its prespecified test.')
    slots={'STYLE':(ROOT/'style.css').read_text(),'ROSTER':roster(data),'TRANSFORMERS':transformer_table(data),
           'FIXED':fixed_table(data),'MATCHED':matched(data),'CONTRASTS':contrasts(data),'ABSTRACT_RESULT':abstract}
    for key,value in slots.items():
        token=f'@@{key}@@'
        assert template.count(token)==1,token
        template=template.replace(token,value)
    assert '@@' not in template
    folder.mkdir(parents=True,exist_ok=True)
    (folder/'index.html').write_text(template,encoding='utf-8')
    archive=folder/'heel-and-force-source.zip'
    with ZipFile(archive,'w') as bundle:
        for name in MEMBERS:
            info=ZipInfo(name,(2026,11,21,0,0,0))
            info.create_system=3
            info.external_attr=0o100644 << 16
            info.compress_type=ZIP_DEFLATED
            bundle.writestr(info,(ROOT/name).read_bytes())
    return archive

def print_pdf(folder,archive,browser):
    from pypdf import PdfReader,PdfWriter
    from pypdf.generic import ArrayObject,ByteStringObject
    with TemporaryDirectory() as tmp:
        work=Path(tmp)
        raw=work/'pages.pdf'
        subprocess.run([browser,'--headless','--disable-gpu','--disable-background-networking','--no-first-run',
                        '--no-default-browser-check','--no-pdf-header-footer',f'--user-data-dir={work/"profile"}',
                        f'--print-to-pdf={raw}',(folder/'index.html').as_uri()],check=True,capture_output=True,timeout=90)
        reader=PdfReader(raw)
        if len(reader.pages)!=6:
            raise ValueError(f'Expected six pages, found {len(reader.pages)}')
        writer=PdfWriter(clone_from=reader)
        writer.metadata={'/Title':'One footstep, two forecasts','/Author':'@eliminatenoise',
                         '/Subject':'Predicting 100-millisecond heel movement and upward plate force in recorded walking'}
        writer.add_attachment(archive.name,archive.read_bytes())
        for notice in ('CC-BY-4.0.txt','CC0-1.0.txt','Liberation-font-LICENSE.txt'):
            writer.add_attachment(notice,(ROOT/notice).read_bytes())
        identity=ByteStringObject(hashlib.sha256(archive.read_bytes()).digest()[:16])
        writer._ID=ArrayObject([identity,identity])
        writer.write(folder/'heel-and-force.pdf')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=ROOT/'output')
    parser.add_argument('--html-only',action='store_true')
    parser.add_argument('--browser',help='Chrome or Chromium executable')
    args=parser.parse_args()
    out=args.out.resolve()
    bundle=build(out)
    if not args.html_only:
        browser=args.browser or shutil.which('chromium') or shutil.which('google-chrome')
        if not browser:
            parser.error('Supply the path to a Chrome or Chromium executable with --browser.')
        print_pdf(out,bundle,browser)
