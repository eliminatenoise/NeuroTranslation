# One footstep, two forecasts

This archive contains the full editable manuscript, print and screen styles, aggregate results and the build script for the heel-and-force study. It builds the HTML, PDF (with an attached copy of this archive) and a deterministic ZIP. All text, tables and the timing figure render offline. Outside links open the cited experiment or source.

## Rebuild

Extract the archive to a directory. Use Python 3, pypdf (tested with 6.21.2), Chromium or Chrome, and the Liberation Sans font family. Run from the extracted directory.

```sh
python -m pip install pypdf==6.21.2
python -B build.py --browser /usr/bin/chromium
```

Output appears in `output/`. An alternative browser path can be supplied on Windows or macOS. Use `python -B build.py --html-only` to rebuild the screen version and source ZIP with the Python standard library alone. The verified PDF route used Chromium on Linux. Browser, font or PDF-library changes can change PDF bytes.

## What was measured

Céline Schreiber and Florent Moissenet collected synchronised barefoot walking recordings on a level walkway. C2 targeted 0.4–0.8 m/s. For each original roster we took the three lowest available numbered C2 walks. Sorting the 50 source participants fixed the first 30 for development, the next ten for the original assessment and the final ten in reserve. The supplementary set used the 18 available fourth/fifth C2 recordings for the same ten historical participants. The reserve was unopened.

Of 90 initial development walks, 28 lacked the required two-plate assignment and one failed the marker geometry test at foot strike. The resulting 61 walks offered 244 candidate windows; 41 lacked the full input history. Twenty windows remained at 140 ms since strike; 61 each survived at 240, 340 and 440 ms. The two historical sets used the same contact criteria. The first supplied 16 qualifying walks from 30 recordings, the second 10 from 18. Eleven of the 18 carried the required two-plate contact code.

The authors' contact table identifies plate order. The first digit of code 12 or 21 gives the right plate, the second digit the left. We checked the physical four-corner plate outline at the first right strike and target, required exactly one right foot-off before the next right strike, and kept the complete 15-sample future force window before foot-off. Finite marker and voltage histories and both valid targets were required. The original vertical plate channel points down in its local coordinates; the calibrated target is upward laboratory force. At zero-based cutoff frame t the final allowed muscle sample is 15t+7. At u=t+10 the force mean spans 15u through 15u+14 inclusive.

The marker positions are ordered as right heel, right second metatarsal head, laboratory X/Y/Z (Z up) in millimetres. Each voltage bin is the root-mean-square in microvolts over 90 analog samples. The eight muscles in order are tibialis anterior, soleus, medial gastrocnemius, vastus medialis, rectus femoris, semitendinosus, gluteus maximus and gluteus medius; all are right-sided. Muscle voltage, external upward reaction force and individual muscle force are different quantities.

## End-to-end shared Transformer

The network uses four ordered tokens (short groups of measurements). In each token, the 22 features are the final heel position relative to the first observed heel position, final forefoot minus heel, within-bin heel and forefoot displacements (four three-component vectors), final heel height, known number of camera frames since right strike and eight log(1 + voltage RMS) values. No prior force enters the model. All token and output standardizations use only the fitting people, with participant/repeat/window-balanced weights, population standard deviations and a scale floor of 0.000001.

The trainable 22-to-16 projection, four learned positions, two self-attention heads of width eight, residual connections, two layer normalizations and a 32-unit tanh feedforward stage yield the final 16-number token. One linear output layer predicts three displacement coordinates and one predicts upward load. Each specialist has an identical trunk, inputs and initialization; the pair uses two trunks. The full model averages the standardized mean squared errors for 3D movement (mean over axes) and for force with equal task weight. AdamW uses learning rate 0.003 and weight decay 0.01, full batches, seed 8347, 32-bit floating point, and no dropout. Inner selection considered 12, 36 or 90 updates. Each of the three outer fits withheld entire people. Final training durations selected from outer validation losses were 12 updates each for joint and specialists, and 36 for the joint model without muscle voltages (all voltage features zero in training and use). A separate diagnostic gave gradient norms of 1.3302 and 3.9749 in the shared trunk for movement and force at the first update. The difference between their half-weighted sum and the joint gradient had length 0.000000859. After 12 updates the shared trunk had moved 1.2516 in parameter-space distance.

Controls include a stationary heel, the last 60 ms velocity carried forward, the preceding 100 ms heel change, the training mean force at the given offset, the mean of three nearest distinct training participants' histories, ridge regression on flattened tokens with or without muscle data, and ridge regression on an untrained random encoder. The model selection score uses a training-scale-normalised endpoint error and absolute force error; tables restore native mm and N. The force hold and extrapolated force trend have privileged access to actual earlier force samples.

## Fixed movement encoder

A previously trained 5,184-parameter encoder transforms six standardised within-group marker changes into a final 24-element summary. Each of four bins additionally records the three forefoot-minus-heel coordinates and eight transformed voltage bins. Flatten those features, add elapsed-strike-offset indicators and past 100 ms heel movement, then add the encoder output. Fit a correction to a recent-heel-change and phase-specific median-force baseline. Fit all training transforms with equal weight per person, per repeat within person, and per valid row within repeat. Divide centred three-coordinate movement residuals by their combined root mean squared length and centred force residuals by their standard deviation.

The linear readout has ridge penalty 0.05 and an unpenalized intercept. With standardized features X, diagonal observation weights W, target residuals Y and D = XᵀWX + 0.05 I, the unrestricted coefficient matrix is C = D⁻¹ XᵀWY. The rank-two coefficients are C V Vᵀ, where the two columns of V are the leading eigenvectors of Cᵀ D C. This shares two learned correction factors across movement and load. Four unconstrained output columns are equivalent to independent linear fits on the same features. Initializing the encoder randomly (seed 20261121), omitting it, or removing voltage provides separate controls. The five outer development folds leave people out together. No force clipping or model update occurs on the historical recordings.

## Comparisons and aggregate results

`scores.json` holds three separately scored sets. The two historical sets are different walks from one previously studied roster. The two model families use different development folds and feature sets. Comparisons of rank or shared training therefore use each family's own controls.

In the Transformer experiment the primary comparison pairs the joint-minus-specialist error within each person, for each outcome. A claimed joint advantage requires the mean and the upper end of the paired 95% participant-bootstrap interval to be below zero for **both**. These intervals use 5,000 draws of whole people with replacement, seed 7103 and central 2.5 and 97.5 percentiles. The separate added-voltage comparison requires a negative upper endpoint for full minus marker-only on all eligible windows and for full minus wrong-repeat voltage on the donor-eligible subset for the given outcome. The same-subset correct/wrong/without-voltage means appear in Table 5. The tests have no multiple-comparison adjustment.

In the fixed-encoder experiment the rank-two full model must be within 2% of the full unrestricted model on both native losses, beat both recent-change/phase-force baselines on average and improve on the corresponding baseline for a strict majority of people. A joint muscle advantage requires at least 5% lower error than both same-architecture motion-only and wrong-repeat controls on both outcomes and strict improvement over both controls for a majority of eligible people per outcome. Every swapped history comes from a different repeat by the same person at exactly the same elapsed time since strike, using cyclic reassignment within each recording set. No cross-person or cross-set substitution is allowed.

In the JSON, heel error is Euclidean 3D endpoint distance (mm), load error is absolute upward force error (N), X/Y/Z biases are signed mean prediction minus recorded value (mm), and force bias uses N. `models` and `main.methods` summarize the complete applicable support, except that wrong-repeat muscle controls only use rows with a donor. `donor_metrics` and `same_phase_donor_support` are matched subsets. `joint_minus` contains paired comparisons, also restricted to their common support. Null means a model supplies no comparable outcome. Full-precision means precede the paper's rounding.

## Sources and licence

Céline Schreiber and Florent Moissenet (2019). *A multimodal dataset of human gait at different walking speeds established on injury-free adult participants.* Scientific Data 6, 111. [Article including contact table](https://doi.org/10.1038/s41597-019-0124-4).

Florent Moissenet and Céline Schreiber released [Figshare version 8](https://doi.org/10.6084/m9.figshare.7734767.v8) under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). The present work derived windowed signals, forecast targets, model fits and aggregate error comparisons from their recordings. The original article, measurements and authors' [processing toolbox](https://github.com/fmoissenet/CGA_Rehazenter_Toolbox/tree/e35dc90c1acd24da134897fd1b4241152cff6005) retain their own terms. The project's original text, code and timing figure use CC0 1.0 to the extent of its rights. The embedded Liberation Sans fonts retain their own licence. The three licence notices are included. The ZIP contains the manuscript and aggregate results only; the original recordings are available from Figshare.

[Paper and source](https://eliminatenoise.github.io/NeuroTranslation/papers/heel-and-force/) · [Transformer and forecasts](https://eliminatenoise.github.io/NeuroTranslation/heel-and-force/) · [Fixed-encoder model](https://eliminatenoise.github.io/NeuroTranslation/shared-heel-and-force/) · [Interoceptomics measured step](https://eliminatenoise.github.io/Interoceptomics/heel-and-force/)
