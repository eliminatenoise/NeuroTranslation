"""Build the self-contained paper and its source archive from aggregate results."""
import argparse
from html import escape
import json
from pathlib import Path
import shutil
import subprocess
from tempfile import TemporaryDirectory
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parent
TITLE = "Can a recording at the armpit improve a forecast at the neck?"
SOURCE_FILES = ("README.md", "build.py", "paper.html.in", "style.css", "scores.json",
                "CC0-1.0.txt", "CC-BY-4.0.txt")
METHODS = (
    ("Training mean", "transformer", "event_mean"),
    ("Recent neck voltage", "robust", "persistence"),
    ("Ridge, no armpit", "transformer", "ridge_noneng"),
    ("Ridge, with armpit", "transformer", "ridge_eng"),
    ("Transformer, no armpit", "transformer", "transformer_noneng"),
    ("Transformer, with armpit", "transformer", "transformer_eng"),
    ("Transformer, trained with wrong events", "transformer", "transformer_deranged"),
    ("Transformer, wrong events at scoring only", "transformer", "transformer_same_fit_wrong"),
    ("Robust regression, no armpit", "robust", "other_sites"),
    ("Robust regression, with armpit", "robust", "with_axilla"),
    ("Robust regression, wrong events", "robust", "wrong_event"),
)


def score_table(data):
    body = []
    for label, model, method in METHODS:
        cells = []
        for stage in ("development", "assessment"):
            result = data[stage][model]["macro"].get(method)
            cells.extend(f'<td>{result[key]:.2f}</td>' if result else '<td>–</td>'
                         for key in ("mae_uV", "rmse_uV"))
        body.append('<tr><th scope="row">' + escape(label) + '</th>' + ''.join(cells) + '</tr>')
    return ('<table class="scores"><caption>Table 2. Forecast error, µV (lower is better)</caption>'
            '<thead><tr><th rowspan="2" scope="col">Forecast</th><th colspan="2" scope="colgroup">Development<br>4 people</th>'
            '<th colspan="2" scope="colgroup">Assessment<br>6 new people</th></tr>'
            '<tr><th scope="col">MAE</th><th scope="col">RMSE</th><th scope="col">MAE</th><th scope="col">RMSE</th></tr></thead>'
            '<tbody>' + ''.join(body) + '</tbody></table>')


def gains_table(data):
    groups = []
    for stage, label in (("development", "Development"), ("assessment", "Assessment")):
        number = data[stage]["people"]
        columns = [data[stage][model]["gains"][control] for model in ("transformer", "robust")
                   for control in ("omitted", "wrong")]
        if any(len(c) != number for c in columns):
            raise ValueError("One paired gain required for every person")
        rows = []
        for i in range(number):
            cells = ''.join(f'<td>{c[i]:+.2f}</td>' for c in columns)
            rows.append(f'<tr><th scope="row">{label} {i + 1}</th>{cells}</tr>')
        averages = ''.join(f'<td>{sum(c)/number:+.2f}</td>' for c in columns)
        rows.append(f'<tr class="average"><th scope="row">Mean</th>{averages}</tr>')
        groups.append('<tbody>' + ''.join(rows) + '</tbody>')
    return ('<table class="pairs"><caption>Table 3. Error saved by the correctly paired armpit reading, µV</caption>'
            '<thead><tr><th rowspan="2" scope="col">Person</th><th colspan="2" scope="colgroup">Transformer</th>'
            '<th colspan="2" scope="colgroup">Robust</th></tr><tr><th scope="col">Omitted</th><th scope="col">Wrong</th>'
            '<th scope="col">Omitted</th><th scope="col">Wrong</th></tr></thead>' + ''.join(groups) + '</table>')


def render(out):
    data = json.loads((ROOT / "scores.json").read_text())
    out.mkdir(parents=True, exist_ok=True)
    html = (ROOT / "paper.html.in").read_text()
    for key, value in (("STYLE", (ROOT / "style.css").read_text()), ("SCORE_TABLE", score_table(data)),
                       ("PAIRS", gains_table(data))):
        token = f"@@{key}@@"
        if html.count(token) != 1:
            raise ValueError("Missing or repeated slot " + key)
        html = html.replace(token, value)
    if "@@" in html:
        raise ValueError("Unfilled manuscript text")
    (out / "index.html").write_text(html, encoding="utf-8")
    archive = out / "cervical-forecast-source.zip"
    with ZipFile(archive, "w") as z:
        for name in SOURCE_FILES:
            info = ZipInfo(name, date_time=(2026, 11, 21, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, (ROOT / name).read_bytes())
    return archive


def pdf(out, archive, browser):
    from pypdf import PdfReader, PdfWriter
    with TemporaryDirectory() as work:
        work = Path(work)
        raw = work / "paper.pdf"
        subprocess.run([browser, "--headless", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
                        "--disable-background-networking", "--no-pdf-header-footer", f"--user-data-dir={work / 'profile'}",
                        f"--print-to-pdf={raw}", (out / "index.html").as_uri()],
                       check=True, capture_output=True, timeout=90)
        reader = PdfReader(raw)
        if len(reader.pages) != 5:
            raise ValueError(f"Expected 5 pages, got {len(reader.pages)}")
        writer = PdfWriter(clone_from=reader)
        writer.metadata = {"/Title": TITLE, "/Author": "@eliminatenoise", "/Subject": "Early surface recordings and later neck voltage"}
        writer.add_attachment(archive.name, archive.read_bytes())
        for name in ("CC0-1.0.txt", "CC-BY-4.0.txt"):
            writer.add_attachment(name, (ROOT / name).read_bytes())
        writer.write(out / "cervical-forecast.pdf")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT / "output")
    parser.add_argument("--html-only", action="store_true")
    parser.add_argument("--browser", help="Chrome or Chromium executable")
    args = parser.parse_args()
    output = args.out.resolve()
    archive = render(output)
    if not args.html_only:
        browser = args.browser or shutil.which("chromium") or shutil.which("google-chrome")
        if not browser:
            parser.error("Provide a Chrome or Chromium executable with --browser")
        pdf(output, archive, browser)
