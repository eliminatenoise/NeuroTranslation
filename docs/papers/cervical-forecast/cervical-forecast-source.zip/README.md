# Can a recording at the armpit improve a forecast at the neck?

This NeuroTranslation research supplement compares two forecasts of neck-surface voltage. Each forecast uses recordings through 8 milliseconds after a median-nerve stimulus to predict a voltage change 12–14 milliseconds after the marker.

## Read or rebuild the supplement

Open index.html from the paper’s download directory with a browser. The text and tables work offline. The PDF contains the same five sections and embeds this source archive and both licence texts.

To rebuild from this archive, use Python 3.10 or newer. For HTML and the source ZIP, run:

    python build.py --html-only

For PDF too, install pypdf and a Chromium-based browser, then run:

    python -m pip install pypdf
    python build.py

The files appear under output/. Use --out to choose another directory and --browser to identify Chrome or Chromium if it is outside PATH. Liberation Sans or Arial is recommended. The development build used Liberation Sans and checks for five PDF pages. Browser versions and typefaces can affect pagination.

The score file contains aggregate errors, anonymous within-person differences and signed-result file digests. All table rows come directly from those values. The fit and the six-person assessment were completed separately. Building the paper neither downloads recordings nor fits new models.

## Scientific sources

Birgit Nierula and colleagues (2024). A multichannel electrophysiological approach to noninvasively and precisely record human spinal cord activity. PLOS Biology 22(10), e3002828. [Original article](https://doi.org/10.1371/journal.pbio.3002828) · [Table 1](https://doi.org/10.1371/journal.pbio.3002828.t001) · [OpenNeuro dataset ds004388 v1.0.0](https://doi.org/10.18112/openneuro.ds004388.v1.0.0).

[NeuroTranslation forecast reader](https://eliminatenoise.github.io/NeuroTranslation/cervical-forecast/) · [Interoceptomics signal atlas](https://eliminatenoise.github.io/Interoceptomics/cervical-signals/).

The original recordings are available under CC0 1.0. The original article is CC BY 4.0. This supplement adds its own analyses and explanatory text. The project contribution uses CC0 1.0. The included legal texts apply to their respective works.
