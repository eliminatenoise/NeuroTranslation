# Will the arm forecast work for someone new?

The paper compares two separate analyses of the seven arm cues. The task-specific Transformer learned its time encoder on fitting people. The shared movement model kept an earlier encoder and fitted new readouts. A later-run comparison tested an individual correction. A separate atlas counts the direction of recorded change in the seven fitting participants. Trial traces and individual correction profiles are not needed to plot any result here.

This source ZIP contains the aggregate numerical inputs used in the paper, the protocols and the HTML, numerical chart and PDF generator. For a rebuild with Python, Chromium and pypdf installed, run `python build.py --out output`. Open `output/index.html`, or read `output/arm-transfer.pdf`. The source studies and the original data are linked from the paper.

Patrick Ofner, Andreas Schwarz, Joana Pereira and Gernot R. Müller-Putz (2017) released the original recordings under CC BY 4.0. This reanalysis selected motor-execution runs, fitted new model weights, compared forecasts and compiled counts. Retain attribution and identify further changes. The project-authored generator and text carry CC0. Licence texts accompany the source.
