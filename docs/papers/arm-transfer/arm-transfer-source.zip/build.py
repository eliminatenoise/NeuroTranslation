"""Rebuild the paper from cohort summaries; all values plotted appear in the source bundle."""
from pathlib import Path
from html import escape
import argparse,base64,json,math,shutil,subprocess,tempfile
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED

ROOT=Path(__file__).resolve().parent
FILES=('build.py','paper.html.in','style.css','README.md','CC-BY-4.0.txt','CC0-1.0.txt','shared-protocol.md',
       'offset-check.md','transformer-protocol.md','task-results.json','shared-results.json','development.json',
       'agreement.json','findings.json')
METHODS={'cue':'Cue alone','still':'No change','ridge':'Cue and history, linear','mlp':'Cue and history, dense network',
         'transformer':'Cue and history, Transformer','transformer_no_cue':'Transformer without the cue',
         'transformer_wrong':'Transformer given a different cue'}
SHARED={'cue':'Cue alone, linear','cue_median':'Group median for the cue','s1_shared_cue_motion':'Encoder fitted on one person',
        'cue_motion':'Cue and history, linear','shared_cue_motion':'Encoder fitted across people',
        'offset_free_shared':'Encoder without absolute starting levels','personal_median':'Own first-run cue median',
        'calibrated_shared':'Encoder after first-run correction'}

def read(n):return json.loads((ROOT/n).read_bytes())
def row(label,values):
    return '<tr><th scope="row">'+escape(label)+'</th>'+''.join('<td>'+escape(str(v))+'</td>' for v in values)+'</tr>'
def chart(methods):
    cap=math.ceil(max(methods[k]['score'] for k in METHODS)*2)/2
    bars=[]
    for k,title in METHODS.items():
        value=methods[k]['score'];focus=' focus' if k in ('transformer','cue') else ''
        bars.append(f'<div class="bar-row{focus}"><span>{escape(title)}</span><span class="track" aria-hidden="true"><i style="width:{value/cap*100:.7f}%"></i></span><b>{value:.3f}</b></div>')
    axis=f'<div class="bar-axis" aria-hidden="true"><span></span><div><span>0</span><span>{cap/2:g}</span><span>{cap:g}</span></div><span></span></div>'
    return '<figure><h3>Mean forecast error on people held out of fitting</h3><p class="unit">Fitting-group standard deviations · smaller is closer</p><div class="bars">'+''.join(bars)+axis+'</div></figure>'
def build(out):
    task=read('task-results.json');old=read('shared-results.json');numbers=read('agreement.json');prose=read('findings.json')
    main=old['unseen_person'];later=old['after_first_run'];fit=old['training'];dev=read('development.json')
    def metric(c,k):
        a=c['models'].get(k,{}).get('standardized_mae')
        return '—' if a is None else f'{a:.3f}'
    rows=''.join(row(label,[metric(main,k),metric(later,k)]) for k,label in SHARED.items())
    signs=[]
    for i,word in [(0,'bend'),(1,'straighten')]:
        w=numbers['tasks'][i]['windows'][-1]
        signs.extend([row('Cz scalp · '+word,w['eeg'][29]),row('Elbow · '+word,w['mechanics'][0])])
    assert numbers['count_order']==['higher','lower','unchanged','unavailable']
    v={'STYLE':(ROOT/'style.css').read_text(),'CHART':chart(task['summary']['methods']),'ROWS':rows,'SIGNS':''.join(signs),
       'LICENSE':base64.b64encode((ROOT/'CC-BY-4.0.txt').read_bytes()).decode(),
       'FIT':f'{fit["eligible_trials"]} eligible trials across {fit["eligible_runs"]} runs for the shared study. The separately trained Transformer used {dev["n"]} fitting trials and was also tested within the fitting group by holding out each person in turn.',
       'HELD':f'{task["n"]} trials for the task-trained network and {main["coverage"]["trials"]} for the shared study. The first comparison uses no measurements from later trials for calibration.',
       'LATER':f'{later["coverage"]["trials"]} trials across {later["coverage"]["runs"]} later runs. Only the correction and personal cue median use first-run outcomes.'}
    v.update({k:escape(val) for k,val in prose.items()})
    html=(ROOT/'paper.html.in').read_text()
    for k,val in v.items():
        tag='@@'+k+'@@'
        if html.count(tag)!=1:raise ValueError('Missing or duplicated marker '+tag)
        html=html.replace(tag,val)
    if '@@' in html:raise ValueError('Unfilled manuscript')
    (out/'index.html').write_text(html)
    source=out/'arm-transfer-source.zip'
    with ZipFile(source,'w') as z:
        for n in FILES:
            meta=ZipInfo(n,date_time=(2026,11,21,0,0,0));meta.compress_type=ZIP_DEFLATED;meta.external_attr=0o100644 << 16
            z.writestr(meta,(ROOT/n).read_bytes())
    return source


def make_pdf(out, source):
    from pypdf import PdfReader, PdfWriter

    browser = shutil.which("chromium") or shutil.which("google-chrome")
    if not browser:
        raise SystemExit("Install Chromium or Chrome for PDF export.")
    with tempfile.TemporaryDirectory() as workspace:
        tmp = Path(workspace)
        raw = tmp/"print.pdf"
        subprocess.run([browser, "--headless", "--disable-gpu", "--disable-background-networking",
                        "--no-first-run", "--no-default-browser-check", "--no-pdf-header-footer",
                        f"--user-data-dir={tmp/'profile'}", f"--print-to-pdf={raw}",
                        (out/"index.html").as_uri()], check=True, capture_output=True, timeout=90)
        reader = PdfReader(raw)
        if len(reader.pages) != 4:
            raise ValueError(f"Expected 4 pages, found {len(reader.pages)}")
        writer = PdfWriter(clone_from=reader)
        writer.metadata = {"/Title":"Will the arm forecast work for someone new?",
                           "/Subject":"Held-person arm forecasts, a first-run correction and electrode direction counts"}
        writer.add_attachment("CC-BY-4.0.txt", (ROOT/"CC-BY-4.0.txt").read_bytes())
        writer.add_attachment(source.name, source.read_bytes())
        writer.write(out/"arm-transfer.pdf")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT/"output")
    parser.add_argument("--html-only", action="store_true", help="Build the page and its source ZIP.")
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    source = build(out)
    if not args.html_only:
        make_pdf(out, source)


if __name__ == "__main__":
    main()
