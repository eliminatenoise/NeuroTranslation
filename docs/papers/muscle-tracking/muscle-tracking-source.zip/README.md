# Does a muscle bundle’s angle help predict its next change in length?

An independent reanalysis of AnkleImage Task 3 for NeuroTranslation. The five-page research supplement, its measured-results chart and its geometric illustration can be rebuilt from this archive alone. The plotted values summarize people and trials. This ZIP contains no participant time series.

## Build or read offline

Extract the archive to an ordinary folder. These commands run from that folder.

```sh
python build.py --html-only
python -m pip install pypdf
python build.py --browser /path/to/chromium
```

Python 3.10 or later builds the self-contained HTML and normalized source ZIP with the standard library. Open `output/index.html` directly. To create the PDF, install pypdf and supply a Chrome or Chromium executable, or allow automatic discovery of chromium or google-chrome on PATH. Install Liberation Sans to match the verified typography. The PDF contains the full source ZIP and the two licence texts as attachments, which a PDF reader with attachment support can save. No model, web server or fixed port is required. Online links lead to the original papers and working models. The tested build used Python 3.14.8, pypdf 6.21.2, Chromium 155 and Liberation Sans on Linux. Different browser or font versions can change line breaks.

`scores.json` contains the exact aggregate results behind the table and bars, before display rounding. `paper.html.in` contains the original manuscript and diagram. `style.css` controls screen and print typography. `build.py` renders the aggregate scores, writes the three deliverables and attaches the ZIP inside the PDF. Each ZIP member has a fixed order, permission and date.

## Measurements

The public source is BioImage Archive S-BIAD1482, original Task 3 files for trials 1 and 2. During seated dorsiflexion the person raised and lowered the forefoot. The outcome is a change in image-plane fascicle length, L[i+10] − L[i], in the dataset’s millimetres. All forecasts used a common sequence of eligible cutoffs. Starting at zero-based row 20, take every tenth native row for which the full 31-row interval from i−20 to i+10 exists within one qualified segment. Check original row order, file-specific time labels, matching lengths and angles and their source identities. Keep the authors’ signed angle for that particular trial. A video playback rate or nominal imaging frequency cannot establish a common physical duration for ten exported rows.

Each file was checked against its native tracking fields. A01’s pennation reconstructs as the difference of two saved orientations in degrees. A02 and A04 use a sum. A03’s released display reproduces the first numbered fascicle’s own angle and length. A second numbered fascicle describes another bundle. The reference sheet’s independent orientation is unavailable in those recordings. A01, A03 and A04 have 992 native rows per trial; A02 has 9,920. The first trial reviewed for eligibility was A01 trial 1. Trials 1 and 2 for A01–A04 then formed development. A05–A08 were set aside before fitting. A09 stayed in reserve. The original authors' units are used throughout; an independent per-trial physical scale check is unavailable.

## The two forecasting models

The specialist produces a signed length increment. For each 21-length history and its 20 preceding angles, five four-interval tokens contain ending length, net length change, mean of the four preceding angles, and change across those four angles. A length-only twin sets the standardized angle channels to zero. Inputs and target use training-weighted means and population standard deviations with a floor of 0.000001. Each model uses a single transformer block of width 16, two attention heads, learned positions, a 32-unit ReLU layer and a linear output from the last token. AdamW fits 120 full batches at learning rate 0.003 with seed 2718, smooth L1 loss and no early stopping. The separate length ridge fits the ten flattened standardized length features with squared error, an unpenalized intercept and penalty 0.01.

The shared movement encoder in NeuroTranslate 0.0 remains frozen. Each of four overlapping groups contains six knots spanning five intervals. Its six features are ending length, net length change, the mean deviation from linear interpolation between endpoints, ending angle, angle change and change in the longitudinal projection. The readout receives the standardized tokens, recent ten-step change and the 24-unit encoder’s last representation. A weighted ridge with penalty 0.05 and an unpenalized intercept predicts the residual after the recent-change forecast. It bounds the lower prediction at minus the current length. The length-only arm omits angle and projection by zeroing their standardized features. Linear readouts omit encoder features. The random control keeps the same encoder shape with one fixed random initialization and fits the readout in the same way.

Equal weights go to people and to trials within each person. Cutoffs share the weight of their own trial. The typical-change control uses a weighted training median. Held-person scoring uses only fixed coefficients and training scales. For the specialist wrong-angle control, take the other trial of the same person and transport the earlier angle features at the nearest proportional eligible-cutoff rank. For the shared control, take the lower proportional rank (floor of recipient rank times donor count divided by recipient count) and recompute the projection features with recipient lengths. The complete-trial ranking makes these retrospective checks on pairing.

The geometric comparisons have different assumptions. Write x[k] = L[k] cos θ[k] and h[k] = L[k] sin θ[k]; use radians inside trigonometric functions. The specialist predicts (x[i−1] − x[i−11]) / cos θ[i−1] whenever |cos θ[i−1]| ≥ 0.1. It extends a change along the reference direction and converts it using the last angle it observed. The shared comparison predicts sqrt((2x[i] − x[i−10])² + h[i]²) − L[i]. It freezes the cutoff’s transverse span. Both are straight-line geometric assumptions, independent of fitting.

## Scoring and prospective decisions

Absolute forecast errors are averaged within trial, between a person’s trials, then between independent people. Development left one person out at a time. Each family refitted on all four development people once for independent assessment. A positive paired gain means that the comparator had higher absolute error than the angle-aware model. Where reported, an exact two-sided sign test drops ties. Overlapping windows do not multiply the independent sample size.

For the specialist, the length-only model is compared with zero and recent change, and separately with training-typical and length ridge. Each comparison requires lower person-balanced error and individual improvements in at least three of the four new people. An angle benefit requires the full model to beat each of length-only transformer, length ridge, zero, recent change, training-typical and other-trial angle by the same two criteria. Projection is an exploratory comparison. For the shared model, a paired-angle benefit requires at least 5% lower mean absolute error than both length-only and other-trial angles and concordant improvements in at least three of four people. Linear and random-encoder comparisons are separate tests of what the frozen representation contributes. Missing planned people prevent a registered four-person decision.

## Observed assessment

All four planned new participants and eight trials qualified. Each trial had 992 native knots, and 97 of 97 candidate forecasts qualified. Matching angles lowered average error against withheld and swapped angle inputs in both families. Neither family met its prespecified angle criterion. The length-only specialist beat both zero and typical training change in four people. It met neither paired test because it improved on recent change and on ridge in only two people each. The shared error fell 2.94% against length alone and 9.20% against swapped angles. One of four people improved on both. See the manuscript for the complete comparisons.

## Sources and rights

Qiang Zhang, Noor Hakam, Oluwasegun Akinniyi, Ashwin Iyer, Xuefeng Bao and Nitin Sharma (2024). *AnkleImage – An ultrafast ultrasound image dataset to understand the ankle joint muscle contractility.* Scientific Data 11, 1439. [Article](https://doi.org/10.1038/s41597-024-04285-x). The article is licensed [CC BY-NC-ND 4.0](https://creativecommons.org/licenses/by-nc-nd/4.0/).

The same authors deposited the [dataset](https://doi.org/10.6019/S-BIAD1482) under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). We selected tracking estimates, compared signed length-change forecasts and computed aggregate results. The manuscript, plot and schematic are original. Project text, code and illustrations use [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/). The legal texts for CC BY 4.0 and CC0 accompany the archive.

[Run the specialist](https://eliminatenoise.github.io/NeuroTranslation/muscle-tracking/) · [Run the shared movement model](https://eliminatenoise.github.io/NeuroTranslation/shared-muscle-tracking/) · [Explore the teaching atlas](https://eliminatenoise.github.io/Interoceptomics/muscle-tracking/).
