"""Build the muscle-tracking research supplement from its published aggregate results."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parent
TITLE = "Does a muscle bundle’s angle help predict its next change in length?"
SOURCE_FILES = ("README.md", "build.py", "paper.html.in", "style.css", "scores.json",
                "CC-BY-4.0.txt", "CC0-1.0.txt")
METHODS = (
    ("Assume zero change", "zero", "hold"),
    ("Repeat the previous change", "recent", "recent"),
    ("Typical training change", "typical", "typical"),
    ("Geometric estimate", "projection", "geometry"),
    ("Linear, length only", "ridge", "linear_length"),
    ("Model, length only", "length", "shared_length"),
    ("Model, length and angle", "full", "shared_both"),
    ("Same fit, other trial’s angle", "wrong", "wrong_both"),
    ("Linear, length and angle", None, "linear_both"),
    ("Random encoder, length and angle", None, "random_both")
)


def scores_table(data):
    header = ('<table class="scores"><thead><tr><th rowspan="2" scope="col">Forecast</th>'
              '<th colspan="2" scope="colgroup" class="group">Specialist</th>'
              '<th colspan="2" scope="colgroup" class="group">Shared</th></tr>'
              '<tr><th scope="col">Dev.</th><th scope="col">Test</th>'
              '<th scope="col">Dev.</th><th scope="col">Test</th></tr></thead><tbody>')
    rows = []
    for label, sp, sh in METHODS:
        cells = []
        for family, method in (("specialist", sp), ("shared", sh)):
            for stage in ("development", "test"):
                if method is None:
                    cells.append('<td class="gap" aria-label="Not evaluated">—</td>')
                else:
                    value = data[stage][family]["mae_mm"][method]
                    cells.append(f'<td>{value:.4f}</td>')
        attr = ' class="full"' if sp == "full" else ''
        rows.append(f'<tr{attr}><th scope="row">{label}</th>{"".join(cells)}</tr>')
    return header + ''.join(rows) + '</tbody></table>'


def error_chart(data):
    groups = (("Specialist · length", "specialist", "length", "length"),
              ("With matched angle", "specialist", "full", "matched"),
              ("With swapped angle", "specialist", "wrong", "swapped"),
              ("Shared · length", "shared", "shared_length", "length"),
              ("With matched angle", "shared", "shared_both", "matched"),
              ("With swapped angle", "shared", "wrong_both", "swapped"))
    maximum = math.ceil(20 * max(data["test"][family]["mae_mm"][method] for _,family,method,_ in groups)) / 20
    rows = []
    for label, family, key, shade in groups:
        value = data["test"][family]["mae_mm"][key]
        rows.append(f'<div class="chartrow"><span>{label}</span><div class="track" aria-hidden="true">'
                    f'<div class="bar {shade}" style="width:{value/maximum*100:.7f}%"></div></div>'
                    f'<span class="value">{value:.3f}</span></div>')
    ticks = (f'<div class="chartrow scale" aria-hidden="true"><span></span><div class="ticks">'
             f'<span>0</span><span>{maximum/2:g}</span><span>{maximum:g}</span></div><span>mm</span></div>')
    return '<div class="chart">' + ''.join(rows) + ticks + '</div>'


def build(out):
    data = json.loads((ROOT/"scores.json").read_text())
    html = (ROOT/"paper.html.in").read_text()
    for number in range(1, 6):
        folio = f'<header class="folio"><span>NeuroTranslation / Muscle tracking</span><span>{number} / 5</span></header>'
        html = html.replace("@@FOLIO@@", folio, 1)
    for slot, value in (("STYLE", (ROOT/"style.css").read_text()), ("PLOT", error_chart(data)),
                        ("TABLE", scores_table(data))):
        if html.count(f"@@{slot}@@") != 1:
            raise ValueError(f"Invalid slot {slot}")
        html = html.replace(f"@@{slot}@@", value)
    if "@@" in html:
        raise ValueError("Unfilled manuscript slot")
    out.mkdir(parents=True, exist_ok=True)
    (out/"index.html").write_text(html, encoding="utf-8")
    archive = out/"muscle-tracking-source.zip"
    with ZipFile(archive, "w") as zipped:
        for name in SOURCE_FILES:
            info = ZipInfo(name, date_time=(2026,11,21,0,0,0))
            info.create_system = 3
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            zipped.writestr(info, (ROOT/name).read_bytes())
    return archive


def print_pdf(out, archive, browser):
    from pypdf import PdfReader, PdfWriter
    from pypdf.generic import ArrayObject, ByteStringObject
    with TemporaryDirectory() as temp:
        work = Path(temp)
        raw = work/"pages.pdf"
        subprocess.run([browser, "--headless", "--disable-gpu", "--disable-background-networking",
                        "--no-first-run", "--no-default-browser-check", "--no-pdf-header-footer",
                        f"--user-data-dir={work/'profile'}", f"--print-to-pdf={raw}",
                        (out/"index.html").as_uri()], check=True, capture_output=True, timeout=90)
        reader = PdfReader(raw)
        if len(reader.pages) != 5:
            raise ValueError(f"Expected five A4 pages, got {len(reader.pages)}")
        writer = PdfWriter(clone_from=reader)
        writer.metadata = {"/Title": TITLE, "/Author": "@eliminatenoise",
                           "/Subject": "Forecasting ten tracking steps of change in image-plane fascicle length"}
        for name in ("CC-BY-4.0.txt", "CC0-1.0.txt"):
            writer.add_attachment(name, (ROOT/name).read_bytes())
        writer.add_attachment(archive.name, archive.read_bytes())
        identity = ByteStringObject(hashlib.sha256(archive.read_bytes()).digest()[:16])
        writer._ID = ArrayObject([identity,identity])
        writer.write(out/"muscle-tracking.pdf")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT/"output")
    parser.add_argument("--browser", help="Path to Chrome or Chromium for the PDF")
    parser.add_argument("--html-only", action="store_true", help="Build only HTML and the source archive")
    args = parser.parse_args()
    out = args.out.resolve()
    archive = build(out)
    if not args.html_only:
        browser = args.browser or shutil.which("chromium") or shutil.which("google-chrome")
        if not browser:
            parser.error("Supply --browser with the path to a Chrome or Chromium executable.")
        print_pdf(out, archive, browser)
