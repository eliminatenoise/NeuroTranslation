# Does the scalp tell us where the arm will go?

NeuroTranslation research supplement, November 2026. The HTML reads offline. The PDF embeds the source ZIP and full legal texts. The two vector figures, two result tables and text use cohort summaries only.

## Rebuild

Extract all files into one directory. Provide Python 3.12 or newer, Matplotlib, pypdf and Chromium or Chrome. The original build used Matplotlib 3.11.2, pypdf 7.1.1, Liberation Sans and Chromium on Linux. Other versions or font installations can change the layout. The builder checks the four-page count.

    python -m pip install matplotlib pypdf
    python build.py --out output

Use `--browser /path/to/chrome` if the browser is outside PATH. Use `--html-only` for the offline HTML and source ZIP without a browser. The paper rebuild reads only the local files in this archive. The archive contains the same files needed to run the build again.

## Sources

Patrick Ofner, Andreas Schwarz, Joana Pereira and Gernot R. Müller-Putz (2017). Upper limb movements can be decoded from the time-domain of low-frequency EEG. PLOS ONE 12(8), e0182578. [Acquisition paper](https://doi.org/10.1371/journal.pone.0182578) · [Original recordings, codebook and file inventory](https://zenodo.org/records/834976).

For the task-trained Transformer, the [source and weights](https://github.com/eliminatenoise/NeuroTranslation/tree/main/models/scalp-forecast) include frozen protocols, scoring and original-file download instructions. [Portable model ZIP](https://raw.githubusercontent.com/eliminatenoise/NeuroTranslation/main/models/scalp-forecast-model.zip). For the robust correction, use the [method and evaluation scripts](https://github.com/eliminatenoise/NeuroTranslation/tree/main/models/neurotranslate-0.0/scalp-residual) with its [parent code and weights](https://github.com/eliminatenoise/NeuroTranslation/tree/main/models/neurotranslate-0.0). For the training-only scalp–eye analysis use the [Interoceptomics atlas](https://eliminatenoise.github.io/Interoceptomics/scalp-and-arm/) and [cohort builder and results](https://github.com/eliminatenoise/Interoceptomics/tree/main/docs/scalp-and-arm/eyes).

The three supplied protocols describe extraction, fit and comparisons. The publicly downloadable input reports are assessment-summary.json in the task-trained model directory, results.json in the robust method directory, and cohort.json in the atlas eyes directory. Their original SHA-256 digests are recorded under input_sha256 in cohort-summaries.json. The supplied projection retains model-level errors, comparison statistics, counts and the four C3/C4–eye 63 cells. It omits individual trial data and participant profiles. The paper’s timeline describes the protocol and its charts plot recorded cohort results.

## Rights

Credit the four named original data authors. This supplement adds the figures, cohort comparison and interpretation. The original recordings and data-derived numerical results, figures and arm-specific coefficients retain [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). Indicate changes and retain attribution. Original project code, this paper’s layout and manuscript text, and invented examples are provided under [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/). These terms do not relicense unrelated components of the linked projects. The complete CC BY 4.0 and CC0 1.0 legal texts accompany this source.
