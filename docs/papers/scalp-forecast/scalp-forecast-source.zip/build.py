"""Build the offline supplement, figure panels, PDF and paper source ZIP."""
import argparse
import base64
from html import escape
from io import BytesIO
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pypdf import PdfReader, PdfWriter

ROOT = Path(__file__).resolve().parent
TITLE = "Does the scalp tell us where the arm will go?"
BLUE = "#164e61"
MUTED = "#738a91"
FILES = ("README.md", "build.py", "paper.html.in", "style.css", "cohort-summaries.json",
         "transformer-protocol.md", "robust-protocol.md", "eye-protocol.json",
         "CC-BY-4.0.txt", "CC0-1.0.txt")
matplotlib.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["Liberation Sans", "Arial", "DejaVu Sans"],
    "font.size": 10.5, "text.color": "#1b3139", "axes.labelcolor": "#1b3139",
    "xtick.color": "#1b3139", "ytick.color": "#1b3139", "svg.hashsalt": "scalp-forecast-v1",
    "svg.fonttype": "none", "axes.unicode_minus": False,
})


def image(fig, alt):
    buffer = BytesIO()
    fig.savefig(buffer, format="svg", metadata={"Date": None, "Creator": "NeuroTranslation supplement"})
    plt.close(fig)
    encoded = base64.b64encode(buffer.getvalue()).decode("ascii")
    return f'<img alt="{escape(alt, quote=True)}" src="data:image/svg+xml;base64,{encoded}">'


def forest(summary):
    comparisons = [
        ("scalp_over_cue_median", "Cue median"),
        ("scalp_over_history", "Cue + arm history"),
        ("scalp_over_wrong_pair", "Mismatched scalp"),
        ("scalp_over_eye", "Eyes + cue + arm"),
    ]
    fig, ax = plt.subplots(figsize=(6.40, 1.65))
    fig.subplots_adjust(left=.245, right=.965, top=.96, bottom=.23)
    ax.axvline(0, color=MUTED, ls="--", linewidth=1, zorder=1)
    for i, (key, _) in enumerate(comparisons):
        row = summary["contrasts"][key]
        lo, hi = row["paired_95pct"]
        ax.plot([lo, hi], [i, i], color=BLUE, lw=2.4, solid_capstyle="round")
        ax.scatter(row["mean_difference"], i, color=BLUE, s=29, zorder=3)
    ax.set_yticks(range(len(comparisons)), [title for _, title in comparisons])
    ax.set_ylim(len(comparisons)-.5, -.5)
    ax.set_xlim(-.011, .0305)
    ax.set_xticks([-.01, 0, .01, .02, .03], ["−0.01", "0", "+0.01", "+0.02", "+0.03"])
    ax.tick_params(axis="y", length=0, pad=8)
    ax.tick_params(axis="x", width=.7, length=3)
    for side in ("left", "top", "right"):
        ax.spines[side].set_visible(False)
    ax.spines["bottom"].set_color(MUTED)
    return ('<figure class="full-chart"><h3>Difference in error, scalp model minus comparator</h3>'
            + image(fig, "Against the cue median the scalp model had higher error. Its intervals against history, mismatched scalp and eyes crossed zero.")
            + '<figcaption><b>Figure 1.</b> Dots are mean paired differences across five people. Positive values favor the comparator. Lines span exploratory 95% percentile intervals from 10,000 whole-person resamples. For each trial we divided absolute errors by each target’s fitting standard deviation and averaged the nine values. We then averaged trials within cues, cues within runs, runs within people, and people equally.</figcaption></figure>')


def eye_figure(cells):
    rows = {cell["window"]: cell["mean_r2"] for cell in cells if cell["scope"] == "finite_pairs"}
    fig, ax = plt.subplots(figsize=(6.4, 1.06))
    fig.subplots_adjust(left=.18, right=.945, top=.94, bottom=.28)
    for i, win in enumerate(("precue", "postcue")):
        for j, (label, color) in enumerate((("same", BLUE), ("shifted", MUTED))):
            value = rows[win][label]["estimate"]*100
            coord = i + (j-.5)*.33
            ax.barh(coord, value, height=.24, color=color)
            ax.text(value+.35, coord, f"{value:.1f}%", va="center", fontsize=9.1)
    ax.set_yticks([0, 1], ["Before cue", "After cue"])
    ax.set_ylim(1.48, -.45)
    ax.set_xlim(0, 22)
    ax.set_xticks([0, 5, 10, 15, 20], ["0", "5%", "10%", "15%", "20%"])
    ax.tick_params(axis="y", length=0, pad=8)
    ax.tick_params(axis="x", labelsize=8.7, length=2)
    for side in ("top", "left", "right"):
        ax.spines[side].set_visible(False)
    ax.spines["bottom"].set_color(MUTED)
    return ('<figure><h3>Shared within-trial variation, C3/C4 mean and eye channel 63</h3>'
            + image(fig, "Mean within-trial r squared for the same and shifted eye trace was 18.6% and 7.7% before the cue, 17.9% and 7.7% after.")
            + '<figcaption><b>Figure 2.</b> Dark bars pair simultaneous traces. Light bars substitute the next repeat. Mean within-trial <i>r</i>² was 18.6% vs 7.7% before and 17.9% vs 7.7% after the cue. Each value averages trial-level squared correlations within run, then runs within person, then the seven people.</figcaption></figure>')


def robust_table(data):
    rows = data["groups"]["paired"]["models"]
    methods = (("cue_median", "Nested cue median"), ("mechanics", "Arm"), ("scalp", "Arm + scalp"),
               ("scalp_shifted", "Arm + mismatched scalp"), ("eye", "Arm + eyes"),
               ("residual_scalp", "Arm + eye-adjusted scalp"), ("joint", "Arm + eyes + adjusted scalp"),
               ("joint_shifted", "Arm + eyes + mismatched adjusted scalp"))
    body = "".join(f'<tr><th scope="row">{name}</th><td>{rows[key]["scaled_mae"]:.6f}</td></tr>' for key, name in methods)
    return ('<table><caption>Table 2. Robust corrections on the same 210 fourth-run trials</caption><thead><tr><th scope="col">'
            'Inputs alongside the known cue</th><th scope="col">Standardized error ↓</th></tr></thead>'
            '<tbody>' + body + '</tbody></table>')


def native_table(data):
    rows = data["methods"]
    names = (("history", "Cue and arm"), ("scalp", "Cue, arm and scalp"))
    body = ""
    for key, name in names:
        vals = rows[key]["native_mae"][1]
        body += f'<tr><th scope="row">{name}</th>' + "".join(f"<td>{v:.6f}</td>" for v in vals) + "</tr>"
    return ('<table><caption>Table 3. Task-trained Transformer, one second after cutoff</caption><thead><tr>'
            '<th scope="col">Inputs</th><th scope="col">Elbow</th><th scope="col">Forearm</th><th scope="col">Index glove</th>'
            '</tr></thead><tbody>' + body + '</tbody></table><p class="small">Mean absolute errors in each instrument’s native units. Adding scalp slightly reduced the elbow and index errors and increased the forearm error. The headers of the original files leave physical units blank.</p>')


def render(out):
    data = json.loads((ROOT / "cohort-summaries.json").read_bytes())
    html = (ROOT / "paper.html.in").read_text()
    slots = {"STYLE": (ROOT / "style.css").read_text(), "FOREST": forest(data["transformer"]),
             "ROBUST_TABLE": robust_table(data["robust"]), "NATIVE_TABLE": native_table(data["transformer"]),
             "EYE_FIGURE": eye_figure(data["eye"])}
    for name, content in slots.items():
        tag = "@@" + name + "@@"
        if html.count(tag) != 1:
            raise ValueError(f"Expected one {tag}")
        html = html.replace(tag, content)
    (out / "index.html").write_text(html, encoding="utf-8")
    archive = out / "scalp-forecast-source.zip"
    with ZipFile(archive, "w") as z:
        for name in FILES:
            member = ZipInfo(name, date_time=(2026, 11, 21, 0, 0, 0))
            member.external_attr = 0o100644 << 16
            member.compress_type = ZIP_DEFLATED
            z.writestr(member, (ROOT / name).read_bytes())
    return archive


def print_pdf(out, archive, browser):
    with tempfile.TemporaryDirectory() as temp:
        tmp = Path(temp)
        raw = tmp / "print.pdf"
        subprocess.run([browser, "--headless", "--disable-gpu", "--no-first-run",
                        "--no-default-browser-check", "--disable-background-networking", "--no-pdf-header-footer",
                        f"--user-data-dir={tmp / 'profile'}", f"--print-to-pdf={raw}", (out / "index.html").as_uri()],
                       check=True, capture_output=True, timeout=90)
        pdf = PdfReader(raw)
        if len(pdf.pages) != 4:
            raise ValueError(f"Expected four pages, got {len(pdf.pages)}")
        writer = PdfWriter(clone_from=pdf)
        writer.metadata = {"/Title": TITLE, "/Author": "@eliminatenoise", "/Subject": "Early scalp and right-arm forecasting"}
        for file in (archive, ROOT / "CC-BY-4.0.txt", ROOT / "CC0-1.0.txt"):
            writer.add_attachment(file.name, file.read_bytes())
        writer.write(out / "scalp-forecast.pdf")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT / "output")
    parser.add_argument("--html-only", action="store_true")
    parser.add_argument("--browser", help="Chromium or Chrome executable for the PDF")
    args = parser.parse_args()
    destination = args.out.resolve()
    destination.mkdir(parents=True, exist_ok=True)
    source = render(destination)
    if not args.html_only:
        browser = args.browser or shutil.which("chromium") or shutil.which("google-chrome")
        if not browser:
            parser.error("Provide --browser with the path to Chromium or Chrome.")
        print_pdf(destination, source, browser)
