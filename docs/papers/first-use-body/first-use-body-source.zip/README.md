# Forecasting movement on first sight of a new body

Open the supplied index.html directly. It contains both figures, the tables and the complete paper. No network is required to read it. External links lead to the original data and companion model.

To edit the paper, change paper.html.in. Recording-level numerical summaries are in aggregates.json. From this extracted folder run:

    python build.py index.html

The builder uses only the Python standard library. Use Print → Save as PDF with A4 paper, background graphics enabled and browser headers and footers disabled. Print styles separate the six printed sections. Screen readers can read the comparison tables and the text accompanying both figures.

The source bundle contains recording-level summaries. It contains no animal trajectories or footage. SOURCES.md lists the original record links, contributors, licensing and units. The external model repository supplies the downloader referenced in the upstream source notes at https://github.com/eliminatenoise/NeuroTranslation/tree/main/models/first-use-body/sources/ . The original source terms apply as indicated there. Readiness times and horizon ranges use elapsed recording time. Normalized endpoint errors use the visible configuration’s root-mean-square radius. Each dot in the shape plot is a pair of recording medians.
