"""Rebuild the self-contained paper from its editable HTML and recording summaries."""
import argparse
import json
from html import escape
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = json.loads((ROOT / "aggregates.json").read_text())

def number(x):
    x = round(x, 1)
    return f"{x:g}"

def extent(x):
    a, b = (number(n) for n in x)
    return a if a == b else f"{a}–{b}"

def stats(fit, panel, horizon):
    return next(row for row in DATA["all_natural"] if row["fit"] == fit and row["panel"] == panel and row["target_s"] == horizon)

def performance():
    blocks = []
    labels = ["Two mammals", "Three phyla", "Stay still"]
    styles = ["mammal", "mixed", "still"]
    for horizon, label in [(0.12, "Near 120 ms · 10 recordings"), (0.2, "At 200 ms · one locust recording")]:
        m = stats("mammal", "common", horizon)["recording_mean"]
        x = stats("mixed", "common", horizon)["recording_mean"]
        bars = []
        for name, css, val in zip(labels, styles, [m[0], x[0], m[2]]):
            bars.append(f'<div class="barrow"><span>{name}</span><span class="track"><i class="{css}" style="width:{100*val/0.25:.4f}%"></i></span><b>{val:.4f}</b></div>')
        blocks.append(f'<div class="bars"><h3>{label}</h3>{"".join(bars)}<div class="ticks"><span>0</span><span>0.25</span></div></div>')
    return "".join(blocks)

def shape_plot():
    a = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 560 235" role="img" aria-labelledby="plotTitle plotDesc"><title id="plotTitle">Projected lengths and mean widths from nine worm recordings</title><desc id="plotDesc">Each point is a recording median. Long-body strain recordings are longer and narrower than dumpy strain recordings. Exact recorded ranges appear below.</desc>']
    x = lambda u: 57+(u-800)/500*470
    y = lambda u: 184-(u-60)/40*155
    a.append('<g font-family="Inter,Arial,sans-serif" fill="#303737" font-size="13"><text x="9" y="14">Mean width (µm)</text>')
    for t in [60,70,80,90,100]:
        a.append(f'<path d="M57 {y(t):.1f}H527" stroke="#ccd3d0"/><text x="46" y="{y(t)+4:.1f}" text-anchor="end">{t}</text>')
    for t in [800,900,1000,1100,1200,1300]:
        a.append(f'<text x="{x(t):.1f}" y="204" text-anchor="middle">{t:,}</text>')
    a.append('<text x="292" y="227" text-anchor="middle">Centreline length (µm)</text></g>')
    for r in DATA["worm_recording_medians"]:
        xx, yy = x(r["length_um"]), y(r["width_um"])
        if r["strain"] == "N2":
            mark = f'<circle cx="{xx:.2f}" cy="{yy:.2f}" r="6" fill="#20584f"/>'
        elif r["strain"] == "CB1282":
            mark = f'<rect x="{xx-5:.2f}" y="{yy-5:.2f}" width="10" height="10" fill="#fff" stroke="#9b422f" stroke-width="2.6"/>'
        else:
            mark = f'<path d="M{xx:.2f} {yy-7:.2f} l7 12h-14z" fill="#263747"/>'
        a.append(f'<g><title>{escape(r["strain"])}: {r["length_um"]:.1f} µm long, {r["width_um"]:.1f} µm mean width</title>{mark}</g>')
    return "".join(a) + "</svg>"

def shapes():
    labels = {"N2":"N2", "CB1282":"CB1282 · dumpy", "CB678":"CB678 · long"}
    codes = {"N2":"●", "CB1282":"□", "CB678":"▲"}
    rows = []
    for key, name in labels.items():
        group = [r for r in DATA["worm_recording_medians"] if r["strain"] == key]
        fields = [extent((min(r[f] for r in group),max(r[f] for r in group))) for f in ["length_um","width_um"]]
        rows.append(f'<tr><th scope="row"><span aria-hidden="true">{codes[key]}</span> {name}</th><td>{fields[0]}</td><td>{fields[1]}</td></tr>')
    return "".join(rows)

def timing():
    groups = [("flies13","Paired flies"),("fly32","Single fly"),("bees","Bumblebees"),("mice_hc","Home-cage mice"),("N2","Worm · N2"),("CB1282","Worm · dumpy"),("CB678","Worm · long"),("locust","Desert locusts")]
    rows = []
    for key, label in groups:
        v = DATA["readiness_range_by_source_ms"][key]
        cells = "".join(f"<td>{extent(v[axis])}</td>" for axis in ["fallback_ms","eligible_ms","target_ms"])
        rows.append(f'<tr><th scope="row">{label}</th>{cells}</tr>')
    return "".join(rows)

def comparison():
    sets = [("mammal","all_test",0.12),("mammal","common",0.12),("mixed","common",0.12),("mammal","common",0.2),("mixed","common",0.2)]
    methods = ["With geometry","Without geometry","Stay still","Last velocity","Half velocity","Rigid motion"]
    rows = []
    for i, label in enumerate(methods):
        cells = "".join(f"<td>{stats(*args)['recording_mean'][i]:.4f}</td>" for args in sets)
        rows.append(f'<tr><th scope="row">{label}</th>{cells}</tr>')
    return "".join(rows)

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("output", nargs="?", default="index.html", type=Path)
args = parser.parse_args()
page = (ROOT / "paper.html.in").read_text()
for key, fn in {"performance":performance, "shape_plot":shape_plot, "shapes":shapes, "timing":timing, "comparison":comparison}.items():
    page = page.replace("{{" + key + "}}", fn())
args.output.write_text(page, encoding="utf-8")
