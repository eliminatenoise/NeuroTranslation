# Acquisition sources and attribution

## Rodents, fruit flies and bumblebees

Use the continuous **Tracking (.slp)** example for each of the six datasets. The study's rates are 80 Hz for open-field mice, 40 Hz for home-cage mice, 25 Hz for gerbils, 100 Hz for single flies, 150 Hz for paired flies and 100 Hz for bumblebees. All six demonstration MP4s encode playback at 25 Hz. Five native tracking files store label-type points without point confidence, so the amount of manual editing is unknown. The single-fly file includes scored predictions. The tracks identify recorded positions in the image. Tracking or identity errors can propagate to the forecast target. [SLEAP datasets](https://docs.sleap.ai/latest/reference/datasets/) · [Pereira et al., Nature Methods, 2022](https://doi.org/10.1038/s41592-022-01426-1)

| Recording | Acquisition contributors |
| --- | --- |
| Open-field mice | John D’Uva, Mikhail Kislin, Samuel S.-H. Wang |
| Home-cage mice | Eleni Papadoyannis, Mala Murthy, Annegret Falkner |
| Gerbils | Catalin Mitelut, Marielisa Diez Castro, Dan H. Sanes |
| Single fruit fly | Talmo Pereira, Gordon Berman, Joshua Shaevitz |
| Paired fruit flies | Junyu Li, Shruthi Ravindranath, Talmo Pereira, Mala Murthy |
| Bumblebees | Grace McKenzie-Smith, Z. Yan Wang, Joshua Shaevitz, Sarah Kocher |

The SLEAP project applies its BSD license to the datasets. The applicable SLEAP notice is the Clear BSD License. Retain `SLEAP-LICENSE.txt`, the paper citation and the relevant acquisition credits when redistributing these data. [Maintainer's data-license statement](https://github.com/talmolab/sleap/discussions/2906#discussioncomment-19503747)

## Desert locusts

Angela Albi and Daniele Carlesso provided tracks for five animals recorded together. The seven indexed pixel coordinates come from a TRex/YOLO pose export. Its internal time column reflects playback at 30 Hz. The video was acquired at 5 Hz. The movement sample archive matches the five original files at the historical Git revision below. The current GitHub branch has different tracks. The study's calibration of the 60 cm arena does not establish a pixel-to-body-length conversion for each animal. Credit Angela Albi, Tristan Walter and Daniele Carlesso for the video. The tracking data and video are licensed under CC BY 4.0. [Original tracks](https://github.com/albiangela/TRex-tutorials-data/tree/e3423e3920e89d6018bc123371b7fb9cdd47f2f5/TRex-tracking-output/locusts-5/data) · [Source license](https://github.com/albiangela/TRex-tutorials-data/blob/e3423e3920e89d6018bc123371b7fb9cdd47f2f5/dataset-info-files/LICENSE) · [Original video record](https://doi.org/10.17617/3.7F5MGE)

## Nematodes

Each of these nine adult *Caenorhabditis elegans* recordings contains an optical segmentation with 49 head-to-tail centreline samples, measured times in seconds and coordinates in micrometres. Samples at corresponding fractional positions along the body can move relative to the tissue. Local worm ID 1 identifies only the animal within that recording. Each of the three recordings per strain has a distinct capture date. A cross-day individual identifier is unavailable. The archive credits Avelino Javer, Michael Currie, Jim Hokanson, Chee Wai Lee, Kezhi Li, Eviatar Yemini, Laura J. Grundy, Chris Li, Quee-Lim Ch’ng, William R. Schafer, Rex Kerr and André E. X. Brown. Each record licenses its data under CC BY 4.0. [Acquisition methods](https://doi.org/10.1038/nmeth.2560) · [Tracking and database](https://doi.org/10.1038/s41592-018-0112-1) · [WCON format](https://github.com/openworm/tracker-commons/blob/master/WCON_format.md)

| Strain | Recording records |
| --- | --- |
| N2 | [September 2009](https://doi.org/10.5281/zenodo.1032845), [January 2010](https://doi.org/10.5281/zenodo.1005864), [July 2009](https://doi.org/10.5281/zenodo.1032915) |
| CB1282 dpy-20(e1282) IV | [25 August 2011](https://doi.org/10.5281/zenodo.1024230), [24 August 2011](https://doi.org/10.5281/zenodo.1019605), [19 August 2011](https://doi.org/10.5281/zenodo.1025134) |
| CB678 lon-2(e678) X | [19 August 2011](https://doi.org/10.5281/zenodo.1013091), [4 August 2011](https://doi.org/10.5281/zenodo.1011834), [9 August 2011](https://doi.org/10.5281/zenodo.1018179) |

## Derivation and terms

This paper reports recording-level summaries derived from the above optical tracks. The model release preserves the acquisition clocks and missing positions. Paper tables and figures report shape descriptors, forecast delays and normalized endpoint errors. Tracking errors and identities remain source-dependent. The archives accompanying this paper contain aggregate results and no raw coordinates, footage or biological samples. The locust and worm data retain their CC BY 4.0 terms; the SLEAP data retain Clear BSD terms. The original contributors are credited for their data and do not endorse any downstream use.

[Model release and reproducible source downloader](https://github.com/eliminatenoise/NeuroTranslation/tree/main/models/first-use-body/sources/)
