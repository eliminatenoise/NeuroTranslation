# How far will a sensor on your back turn in a tenth of a second?

This NeuroTranslation research supplement asks whether two skin-electrode patches improve a 100 ms rotation forecast during instructed walking and standing. Four people supplied eight development trials. Only three of the four people set aside for the original test provided two trials with four numbered orientation channels. Both trials from the fourth person have a fourth row labelled BufferChannel. The included six trials (2,304 intervals) supply a descriptive subset. The planned four-person test remains incomplete for both models, and the reserve volunteer was never substituted. The HTML and PDF contain the same five sections. The HTML runs offline, including the measured-results chart. The PDF embeds this ZIP and the two licence texts.

## Rebuild the paper

Extract the ZIP into its own folder. Run the following command there with Python 3.10 or later. It builds the HTML and the source ZIP in output/.

    python build.py --html-only

For the PDF, install pypdf and use a Chromium-based browser with Liberation Sans available. Then run the complete build.

    python -m pip install pypdf
    python build.py

Use --browser to identify the browser executable and --out to choose the output directory. The reference export used Python 3.14.8, pypdf 6.21.2 and Chromium 155.0.8059.84 with Liberation Sans. A different browser, library or typeface can affect the PDF. The HTML and tables derive directly from the bundled manuscript and aggregate scores. Rebuilding the paper does not fetch recordings or refit models.

## Read the score file

For each family and stage, scores.json gives error in degrees within standing, walking and both tasks. Mean absolute error (MAE) is the average magnitude of a miss. The shared model also reports root mean squared error (RMSE), which gives large misses more weight. Each model follows its original rule for pooling trials. Each person counts equally in the final average. For the shared model the file gives observed target-angle summaries separately for each task. It gives counts, mean differences and uncertainty summaries without cross-model participant identifiers.

The specialist used one attention layer, two attention heads and 16 features per time bin inside the network. Its three raw-voltage summaries per patch were the median channel standard deviation, median channel root mean square of successive differences and the standard deviation of the across-contact median. Positive spreads were compressed with log(1 + value). It standardized the features on fitting people, bounded standardized values to −8 through 8 and masked the omitted patch after scaling. Each variant started at seed 1941 and trained for 18 passes with a smooth absolute-error loss (1° crossover) and AdamW. The linear motion comparator used ridge penalty 0.01. Output angles were bounded to 0°–180° for scoring.

The shared encoder retained the original projection, position, attention, feed-forward and normalization weights. The loader verified the released parent weights. Its four 25 ms bins held net angle, path length and two features per patch. Each patch supplied the median across usable channels of within-bin standard deviation and of the root mean square of first differences. It required at least 16 finite channels per patch and bin. The shared model and random encoder used the same architecture. Each readout combined the 24 flattened standardized inputs, the log-transformed recent angle and the task code. Encoder models also included the 24-value final encoded representation. The readout used a 0.05 ridge penalty with an unpenalized intercept. The target was the difference between log(1 + future angle) and log(1 + recent angle). The random encoder used one fixed initialization, seed 20261121.

Across both studies, two quaternions with opposite signs can describe the very same physical orientation. Normalizing the endpoints and taking the absolute dot product puts them at the same angle. The forecast windows advance 100 ms at a time. Neighbouring target intervals can share one endpoint. The preceding window's last instant is the following target's first instant. Neither the following measured angle nor a later task code entered the features. The scoring restriction requires the next 100 ms to remain in the same task. The published forward-backward filters, centered artifact templates and whole-trial flag masks were excluded from inputs. The authors’ source data and article describe the recording quality.

## Which comparisons were fixed in advance?

The specialist required at least 5% lower balanced MAE than the best simple or motion-only comparator and 2% lower than its same-trial shifted-patch control. It also required improvement over motion alone and wrongly timed patches in the same three or more of four people, with no higher task-mean error against either comparator. Regional attribution further required the whole test to pass, plus a 2% gain against the model with that patch removed and improvement in at least three of four people. The shared model required at least 5% lower MAE than both its motion-only and other-trial controls, concordant gains in at least three of four people, and no increased task-mean MAE against motion alone. The development scores describe separate leave-one-person-out folds. Both development criteria failed. The four-person held assessment is incomplete. Three-person between-model comparisons remain descriptive.

## Source and rights

Desirée Irene Gracia Laso, Eduardo Iáñez, Mario Ortiz and Jose M. Azorin collected and published the measurements. Experiment 2, version 2 of *An Electrospinography Database of Spinal Cord Activity During Gait-Related Tasks and Motor Imagery Exercises*, is available under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). This supplement derives unsigned sensor angles, forecast comparisons and original figures. The archive contains publication aggregates. [Dataset](https://doi.org/10.5281/zenodo.19065545) · [Original study and methods](https://doi.org/10.1038/s41597-026-07592-7).

The paper's new project text, code and graphics use CC0 1.0. Original data keep their CC BY 4.0 licence. Both legal texts are included.

[Specialist forecast](https://eliminatenoise.github.io/NeuroTranslation/back-rotation/) · [Shared forecast](https://eliminatenoise.github.io/NeuroTranslation/shared-back-rotation/) · [Interoceptomics recording atlas](https://eliminatenoise.github.io/Interoceptomics/back-rotation/).
