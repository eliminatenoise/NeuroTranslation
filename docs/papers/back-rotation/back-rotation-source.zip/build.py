"""Build the back-rotation supplement from its aggregate score file, without recordings."""
import argparse
import hashlib
from html import escape
import json
import math
from pathlib import Path
import shutil
import subprocess
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parent
TITLE = "How far will a sensor on your back turn in a tenth of a second?"
FILES = ("README.md", "build.py", "paper.html.in", "style.css", "scores.json",
         "CC-BY-4.0.txt", "CC0-1.0.txt")
NAMES = {
    "specialist": (
        ("zero", "Assume zero turn"), ("constant_speed", "Repeat the recent turn"),
        ("task_median", "Typical angle for this task"), ("ridge_motion", "Linear, motion only"),
        ("motion", "Transformer, motion only"), ("upper", "Add upper patch"),
        ("lower", "Add lower patch"), ("full", "Add both patches"), ("wrong", "Shift both patches")
    ),
    "shared": (
        ("zero", "Assume zero turn"), ("recent", "Repeat the recent turn"),
        ("task_median", "Typical angle for this task"), ("linear_motion", "Linear, motion only"),
        ("shared_motion", "Shared encoder, motion only"), ("shared_upper", "Add upper patch"),
        ("shared_lower", "Add lower patch"), ("shared_full", "Add both patches"),
        ("wrong_full", "Swap patches across trials"), ("linear_full", "Linear, both patches"),
        ("random_full", "Random encoder, both patches")
    )
}
FULL = {"specialist": "full", "shared": "shared_full"}
MOTION = {"specialist": "motion", "shared": "shared_motion"}
WRONG = {"specialist": "wrong", "shared": "wrong_full"}


def scores_table(data, family):
    heading = ('<thead><tr><th rowspan="2" scope="col">Forecast</th>'
               '<th scope="col">Development</th><th colspan="3" scope="colgroup">Descriptive test</th></tr>'
               '<tr><th scope="col">Both</th><th scope="col">Stand</th>'
               '<th scope="col">Walk</th><th scope="col">Both</th></tr></thead>')
    rows = []
    for method, label in NAMES[family]:
        development = data["development"][family]["mae_deg"][method]
        held = data["assessment"][family]["mae_deg"][method]
        values = [development["balanced"], held["standing"], held["walking"], held["balanced"]]
        cells = "".join(f"<td>{v:.3f}</td>" for v in values)
        attr = ' class="full"' if method == FULL[family] else ''
        rows.append(f'<tr{attr}><th scope="row">{escape(label)}</th>{cells}</tr>')
    return '<table class="scores">' + heading + '<tbody>' + ''.join(rows) + '</tbody></table>'


def results_plot(data):
    groups = (
        ("Assume zero turn", "specialist", "zero"),
        ("Repeat the recent turn", "specialist", "constant_speed"),
        ("Specialist · motion only", "specialist", "motion"),
        ("Specialist · both patches", "specialist", "full"),
        ("Shared · motion only", "shared", "shared_motion"),
        ("Shared · both patches", "shared", "shared_full"))
    maximum = max(0.25, math.ceil(4 * max(data["assessment"][family]["mae_deg"][method]["balanced"]
                                        for _, family, method in groups)) / 4)
    rows = []
    for label, family, method in groups:
        value = data["assessment"][family]["mae_deg"][method]["balanced"]
        if not 0 <= value <= maximum:
            raise ValueError("Review chart scale for new score")
        shade = "patches" if method == FULL[family] else "motion" if method == MOTION[family] else "base"
        rows.append(f'<div class="chartrow"><span>{label}</span><div class="track" aria-hidden="true">'
                    f'<div class="bar {shade}" style="width:{100 * value/maximum:.7f}%"></div></div>'
                    f'<span class="value">{value:.3f}°</span></div>')
    axis = (f'<div class="chartrow scale" aria-hidden="true"><span></span><div class="ticks">'
            f'<span>0°</span><span>{maximum / 2:g}°</span><span>{maximum:g}°</span></div><span></span></div>')
    return '<div class="chart">' + ''.join(rows) + axis + '</div>'


def build(out):
    data = json.loads((ROOT / "scores.json").read_text())
    slots = {"STYLE": (ROOT / "style.css").read_text(),
             "PLOT": results_plot(data),
             "SPECIALIST_TABLE": scores_table(data, "specialist"),
             "SHARED_TABLE": scores_table(data, "shared")}
    html = (ROOT / "paper.html.in").read_text()
    for key, value in slots.items():
        token = "@@" + key + "@@"
        if html.count(token) != 1:
            raise ValueError("Missing or repeated manuscript slot " + key)
        html = html.replace(token, value)
    if "@@" in html:
        raise ValueError("Unfilled manuscript text")
    out.mkdir(parents=True, exist_ok=True)
    (out / "index.html").write_text(html, encoding="utf-8")
    archive = out / "back-rotation-source.zip"
    with ZipFile(archive, "w") as z:
        for name in FILES:
            info = ZipInfo(name, date_time=(2026, 11, 21, 0, 0, 0))
            info.create_system = 3
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, (ROOT / name).read_bytes())
    return archive


def print_pdf(out, archive, browser):
    from pypdf import PdfReader, PdfWriter
    from pypdf.generic import ArrayObject, ByteStringObject

    with TemporaryDirectory() as work:
        work = Path(work)
        raw = work / "printed.pdf"
        subprocess.run([browser, "--headless", "--disable-gpu", "--disable-background-networking",
                        "--no-first-run", "--no-default-browser-check", "--no-pdf-header-footer",
                        f"--user-data-dir={work / 'profile'}", f"--print-to-pdf={raw}",
                        (out / "index.html").as_uri()], check=True, capture_output=True, timeout=90)
        reader = PdfReader(raw)
        if len(reader.pages) != 5:
            raise ValueError(f"Expected five A4 pages, got {len(reader.pages)}")
        writer = PdfWriter(clone_from=reader)
        writer.metadata = {"/Title": TITLE, "/Author": "@eliminatenoise",
                           "/Subject": "Motion and skin electrodes in a forecast of back sensor rotation"}
        for name in ("CC-BY-4.0.txt", "CC0-1.0.txt"):
            writer.add_attachment(name, (ROOT / name).read_bytes())
        writer.add_attachment(archive.name, archive.read_bytes())
        content_id = ByteStringObject(hashlib.sha256(archive.read_bytes()).digest()[:16])
        writer._ID = ArrayObject([content_id, content_id])
        writer.write(out / "back-rotation.pdf")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", type=Path, default=ROOT / "output")
    p.add_argument("--browser", help="Chromium or Chrome executable")
    p.add_argument("--html-only", action="store_true")
    args = p.parse_args()
    destination = args.out.resolve()
    zipped = build(destination)
    if not args.html_only:
        browser = args.browser or shutil.which("chromium") or shutil.which("google-chrome")
        if not browser:
            p.error("Please supply --browser with a Chrome or Chromium executable.")
        print_pdf(destination, zipped, browser)
