"""Build the offline HTML, attached-source PDF and deterministic editable source archive."""
import argparse
import base64
import hashlib
import html
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

HERE=Path(__file__).resolve().parent
TITLE="How much does cortical voltage add to a wrist forecast on the next recording day?"
FILES=("article.html","style.css","results.json","build.py","figures.py","selection.svg","endpoint.svg","four-hour.svg","README.md","CC-BY-4.0.txt","CC0-1.0.txt")
SEEDS=(17,37,73)
HEADS=[(side,h) for side in ('right','left') for h in ('8','15')]

def number(value,digits=2,signed=False):
    if value is None:
        return "—"
    return format(value,('+' if signed else '')+'.'+str(digits)+'f').replace('-','−')

def table(caption,headings,rows):
    heads=''.join('<th scope="col">'+html.escape(x)+'</th>' for x in headings)
    body=''.join('<tr><th scope="row">'+html.escape(str(row[0]))+'</th>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in row[1:])+'</tr>' for row in rows)
    return '<div class="tablebox" role="region" tabindex="0" aria-label="'+html.escape(caption)+'"><table><caption>'+html.escape(caption)+'</caption><thead><tr>'+heads+'</tr></thead><tbody>'+body+'</tbody></table></div>'

def compose():
    data=json.loads((HERE/'results.json').read_bytes()); abs_scores=data['absolute']
    values={'style':(HERE/'style.css').read_text()}
    for key,name,alt in [('flow','selection','The training day contributed 60 of 81 annotated movements. The test day contributed 58 of 196 movements, of which 57 had an earlier donor.'),('endpoint','endpoint','For both wrists and both horizons, the direct Transformer gave a larger mean error than the bounded correction. The training mean was best on the right and holding position was best on the left.'),('timefig','four-hour','Right-wrist error contrasts change direction across six four-hour periods. Both control comparisons have positive and negative entries in the grid. The exact contrast values are also in the editable aggregate source.')]:
        blob=base64.b64encode((HERE/(name+'.svg')).read_bytes()).decode()
        values[key]='<img src="data:image/svg+xml;base64,'+blob+'" alt="'+html.escape(alt)+'">'
    def absolute_row(label,key):
        return [label,*[number(abs_scores[key][side][h]['mean_px']) for side,h in HEADS]]
    four=['Forecast','Right +8','Right +15','Left +8','Left +15']
    simple={'Stay at last position':'zero','Add mean training displacement':'mean','Continue recent velocity':'velocity','Continue at half velocity':'half_velocity','Fit a damped velocity':'fitted_velocity','Direct linear ridge, pose + voltage':'ridge_direct_full','Bounded ridge with fitted prior, pose + voltage':'ridge_anchored_full','Shared whole-wrist slopes':'geo_whole_shared','Shared joint-component slopes':'geo_segments_shared','Side-specific joint-component slopes':'geo_segments_by_side'}
    values['absolute_table']=table('Table 1. Mean endpoint error in pixels on all 58 test blocks.',four,[absolute_row(label,key) for label,key in simple.items()])
    arch=[]
    for t,label in [('direct','Direct'),('bounded_zero','Bounded, zero prior'),('anchored','Bounded, fitted prior')]:
        for s in SEEDS:
            arch.append(absolute_row(label+' · '+str(s),f'transformer_{t}_full_s{s}'))
    values['heads_table']=table('Table 2. Both input streams, full 60-block training. Means over all 58 test blocks (px).',four,arch)
    for side,n in [('right',3),('left',4)]:
        rows=[]
        for s in SEEDS:
            a=f'transformer_anchored_full_s{s}'
            for h in ('8','15'):
                u=data['primary_common'][a+'__minus__'+a.replace('_full_','_pose_')][side][h]
                v=data['primary_common'][a+'__minus__'+a+'_wrong'][side][h]
                assert u['n']==v['n']==57
                wt=lambda k:' / '.join(str(k[x]) for x in ['wins','ties','losses'])
                rows.append([str(s)+' · '+h,number(u['mean_delta_px'],6,True),wt(u),number(v['mean_delta_px'],6,True),wt(v)])
        values['pairs_'+side]=table(f'Table {n}. {side.capitalize()} wrist. Each row compares the same 57 test blocks.',('Seed · frames','Minus pose (px)','W / T / L','Minus donor (px)','W / T / L'),rows)
    histrows=[]
    for fit in (16,60):
        for t,label in [('direct','Direct'),('bounded_zero','Bounded, zero'),('anchored','Bounded, fitted')]:
            r=[str(fit)+' · '+label]
            for s in SEEDS:
                key=('small16_' if fit==16 else '')+f'transformer_{t}_full_s{s}'
                r.append(' / '.join(number(abs_scores[key]['right'][h]['mean_px']) for h in ('8','15')))
            histrows.append(r)
    values['count_table']=table('Table 5. Right-wrist error in pixels at +8 / +15 frames over all 58 test blocks.',('Rows fitted · readout','Seed 17','Seed 37','Seed 73'),histrows)
    template=(HERE/'article.html').read_text()
    assert set(re.findall(r'\{\{(\w+)\}\}',template))==set(values)
    return re.sub(r'\{\{(\w+)\}\}',lambda m:values[m[1]],template)

def build(out):
    from pypdf import PdfReader,PdfWriter
    from pypdf.generic import ArrayObject,ByteStringObject
    out.mkdir(parents=True,exist_ok=True)
    page=compose()
    (out/'index.html').write_text(page)
    members={name:(HERE/name).read_bytes() for name in FILES}
    # The extracted reading copy needs neither a network connection nor a sibling PDF.
    members['read.html']=re.sub(r'<a download href="[^"]+">[^<]+</a>', '',page).encode()
    archive=out/'human-wrist-source.zip'
    with ZipFile(archive,'w') as z:
        for name,data in members.items():
            entry=ZipInfo(name,(2026,11,21,0,0,0))
            entry.create_system=3
            entry.external_attr=0o100644<<16
            z.writestr(entry,data,compress_type=ZIP_DEFLATED)
    browser=shutil.which('chromium') or shutil.which('google-chrome')
    if not browser:
        raise SystemExit('Install Chromium or Google Chrome to rebuild the PDF.')
    with tempfile.TemporaryDirectory(dir=out) as name:
        tmp=Path(name); source=tmp/'index.html'; source.write_text(page)
        pdf=tmp/'printed.pdf'
        subprocess.run([browser,'--headless','--disable-gpu','--disable-background-networking','--no-pdf-header-footer','--user-data-dir='+str(tmp/'profile'),'--print-to-pdf='+str(pdf),source.as_uri()],check=True,capture_output=True,timeout=90)
        writer=PdfWriter(clone_from=PdfReader(pdf))
        writer.metadata={'/Title':TITLE,'/Author':'NeuroTranslation','/Subject':'Cross-recording conditional human wrist forecasts from AJILE12'}
        writer.add_attachment(archive.name,archive.read_bytes())
        ident=ByteStringObject(hashlib.sha256(archive.read_bytes()).digest()[:16])
        writer._ID=ArrayObject([ident,ident])
        writer.write(out/'human-wrist.pdf')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=HERE/'output')
    build(parser.parse_args().out.resolve())
