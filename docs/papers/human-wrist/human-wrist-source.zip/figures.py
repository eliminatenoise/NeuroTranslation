"""Draw three original vector figures from the published study aggregates."""
import json
from pathlib import Path

import matplotlib
matplotlib.use("svg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm, LinearSegmentedColormap
from matplotlib.ticker import MultipleLocator
import numpy as np

HERE=Path(__file__).resolve().parent
data=json.loads((HERE/"results.json").read_text())
ink="#172f35"
green="#006e64"
plum="#86396b"
rust="#ab5525"
slate="#58717d"
plt.rcParams.update({"font.family":"Liberation Sans","font.size":11,"text.color":ink,"axes.labelcolor":ink,"axes.edgecolor":"#abb7b8","xtick.color":ink,"ytick.color":ink,"svg.fonttype":"none","svg.hashsalt":"wrist-forecast-1","axes.spines.top":False,"axes.spines.right":False})
def save(f,n):
    f.savefig(HERE/n,format="svg",metadata={"Date":None},facecolor="white")
    plt.close(f)

def flow():
    fig,axs=plt.subplots(1,2,figsize=(8.6,2.75))
    fig.subplots_adjust(left=.075,right=.985,top=.80,bottom=.26,wspace=.30)
    for axis,(ttl,labels,vals) in zip(axs,[("Session 3  ·  first 16 h",["Annotations","Training blocks"],[81,60]),("Session 4  ·  24 h",["Annotations","Test blocks","With donor"],[196,58,57])]):
        x=np.arange(len(vals))
        axis.bar(x,vals,color=[slate,green,rust][:len(vals)],width=.57)
        axis.set_xticks(x,labels,fontsize=10);axis.set_ylim(0,215);axis.set_title(ttl,loc='left',fontsize=13,fontweight='bold')
        axis.yaxis.set_major_locator(MultipleLocator(50));axis.grid(axis='y',alpha=.18);axis.set_axisbelow(True)
        for i,v in enumerate(vals):axis.text(i,v+5,str(v),ha='center',fontweight='bold')
        axis.set_xlim(-.65,len(vals)-.35)
    axs[0].set_ylabel("Movement events (count)")
    save(fig,"selection.svg")

def absolute():
    fig,axs=plt.subplots(1,2,figsize=(8.6,3.6),sharey=True)
    fig.subplots_adjust(left=.078,right=.99,bottom=.17,top=.75,wspace=.09)
    methods=[("Direct Transformer","transformer_direct_full_s{seed}",plum,"o"),("Bounded correction","transformer_anchored_full_s{seed}",green,"s"),("Training mean","mean",rust,"v"),("Last position","zero",slate,"D")]
    offsets=[-.14,-.046,.046,.14]
    for ax,side in zip(axs,["right","left"]):
        for (label,name,color,mk),off in zip(methods,offsets):
            for n,h in enumerate(["8","15"]):
                vals=[data['absolute'][name.format(seed=s)][side][h]['mean_px'] for s in ([17,37,73] if '{seed}' in name else [17])]
                xx=n+off
                ax.plot([xx,xx],[min(vals),max(vals)],color=color,lw=1)
                ax.scatter([xx]*len(vals),vals,s=23,color=color,marker=mk,label=label if n==0 else None,zorder=3)
        ax.set_xticks([0,1],["8 frames","15 frames"]);ax.set_xlim(-.36,1.36);ax.set_ylim(0,165);ax.grid(axis='y',alpha=.18);ax.set_axisbelow(True)
        ax.set_title(side.capitalize()+" wrist",fontweight="bold",fontsize=13,loc="left",pad=8)
    axs[0].set_ylabel("Mean endpoint error (px)")
    handles,labels=axs[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc="upper center",ncol=4,fontsize=9.5,frameon=False,handletextpad=.2,columnspacing=1.1)
    save(fig,"endpoint.svg")

def time():
    fig,axs=plt.subplots(2,1,figsize=(8.6,5.0),sharex=True)
    fig.subplots_adjust(left=.145,right=.987,top=.91,bottom=.11,hspace=.34)
    cm=LinearSegmentedColormap.from_list('difference',[green,'#f7f7f4',plum])
    for ax,comp,title in zip(axs,['pose','wrong'],['A   Actual voltage minus pose alone','B   Actual voltage minus borrowed voltage']):
        cells=[]
        for s in (17,37,73):
            a='transformer_anchored_full_s'+str(s)
            b=a.replace('_full_','_pose_') if comp=='pose' else a+'_wrong'
            for h in ('8','15'):
                c=data['primary_common'][a+'__minus__'+b]['right'][h]['four_hour_strata']
                cells.append([c[str(i)]['mean_delta_px'] for i in range(6)])
        ax.imshow(cells,cmap=cm,norm=TwoSlopeNorm(0,vmin=-4,vmax=4),aspect='auto')
        ax.set_yticks(range(6),['17 · 8','17 · 15','37 · 8','37 · 15','73 · 8','73 · 15'],fontsize=9)
        for y,row in enumerate(cells):
            for x,val in enumerate(row):
                ax.text(x,y,format(val,'+.2f').replace('-','−'),ha='center',va='center',color="white" if abs(val)>2.6 else ink,fontsize=9.8)
        ax.set_ylabel('Seed · frames',fontsize=10);ax.tick_params(length=0);ax.set_title(title,loc='left',fontweight='bold',fontsize=12,pad=6)
    axs[-1].set_xticks(range(6),['0–4','4–8','8–12','12–16','16–20','20–24'])
    axs[-1].set_xlabel('Hours from start of held recording')
    save(fig,"four-hour.svg")

if __name__=="__main__":flow();absolute();time()
