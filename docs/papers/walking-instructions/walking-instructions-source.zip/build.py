"""Build the walking-instruction paper and its attached reproducible source."""
import argparse
import base64
import hashlib
from html import escape
import json
from pathlib import Path
import shutil
import subprocess
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

SOURCE = Path(__file__).resolve().parent
NOTICES = ('DATA-LICENCE.txt', 'CC0-1.0.txt', 'Liberation-font-LICENSE.txt')
FONTS = (('Regular', 'normal', 400), ('Bold', 'normal', 700), ('Italic', 'italic', 400))
MEMBERS = ('README.md', 'paper.html.in', 'style.css', 'scores.json', 'build.py',
           *NOTICES, *(f'LiberationSans-{name}.ttf' for name, _, _ in FONTS))
GROUPS = ('development', 'historical')


def typography():
    faces = []
    for name, style, weight in FONTS:
        font = (SOURCE / f'LiberationSans-{name}.ttf').read_bytes()
        encoded = base64.b64encode(font).decode('ascii')
        faces.append(f'@font-face{{font-family:PaperSans;src:url(data:font/ttf;base64,{encoded}) format("truetype");'
                     f'font-weight:{weight};font-style:{style};}}')
    return '\n'.join(faces) + (SOURCE / 'style.css').read_text()


def table(headings, rows, caption):
    heading = ''.join(f'<th scope="col">{escape(label)}</th>' for label in headings)
    body = []
    for label, values in rows:
        cells = ''.join(f'<td data-label="{escape(title)}">{escape(value)}</td>'
                        for title, value in zip(headings[1:], values, strict=True))
        body.append(f'<tr><th scope="row">{escape(label)}</th>{cells}</tr>')
    return (f'<table class="scores" aria-label="{escape(caption)}"><thead><tr>{heading}</tr></thead>'
            f'<tbody>{"".join(body)}</tbody></table>')


def pair(values):
    return ' / '.join(f'{value:.3f}' for value in values)


def coverage(data):
    rows = []
    for group in GROUPS:
        item = data[group]
        result, counts = item['transformer'], item['coverage']['conditions']
        rows.append((group.capitalize(), [str(result['people']), str(result['trials']),
                     f"{counts['4']['qualified_windows']} / {counts['5']['qualified_windows']}",
                     str(result['windows'])]))
    return table(('Group', 'People', 'Walks', 'Usual / fast windows', 'Total windows'), rows, 'Walks and eligible windows')


def methods(data):
    rows = []
    for name, family, key in (
            ('Transformer, correct cue', 'transformer', 'cue'),
            ('Transformer, cue withheld', 'transformer', 'withheld'),
            ('Transformer, cue swapped', 'transformer', 'swapped'),
            ('Transformer, shuffled training labels', 'transformer', 'permuted'),
            ('Pretrained encoder, correct cue', 'readouts', 'encoder_cue'),
            ('Linear model, correct cue', 'readouts', 'linear_cue'),
            ('Past pace and time since strike¹', 'readouts', 'pace_phase'),
            ('Typical displacement at cue and offset', 'transformer', 'cue_phase'),
            ('Continue last 50 ms velocity', 'readouts', 'velocity_50ms'),
            ('Repeat last 100 ms movement', 'readouts', 'repeat_100ms'),
            ('Hold position', 'readouts', 'hold')):
        values = []
        for group in GROUPS:
            results = data[group][family]
            models = results['results']['both']['models'] if family == 'transformer' else results['methods']
            values.append(pair(models[key]['endpoint_mm']))
        rows.append((name, values))
    return table(('Forecast', 'Development', 'Historical'), rows, 'Mean pelvis and heel endpoint errors')


def conditions(data):
    rows = []
    for key, label in [('4', 'Usual'), ('5', 'Fast')]:
        values = [pair(data[group]['transformer']['results'][key]['models']['cue']['endpoint_mm']) for group in GROUPS]
        rows.append((label, values))
    return table(('Condition', 'Development', 'Historical'), rows, 'Forecast errors by walking instruction')


def sign(value):
    return f'{value:+.3f}'.replace('-', '−')


def comparisons(data):
    t = data['historical']['transformer']['results']['both']['cue_minus']
    f = data['historical']['readouts']['paired']
    items = (('Transformer − withheld', t['withheld']), ('Transformer − swapped', t['swapped']),
             ('Fixed encoder − withheld', f['encoder_cue']['encoder_motion']),
             ('Fixed encoder − swapped', f['encoder_cue']['swapped_encoder']),
             ('Linear − withheld', f['linear_cue']['linear_motion']),
             ('Linear − swapped', f['linear_cue']['swapped_linear']))
    rows = []
    for label, result in items:
        cells = []
        for mean, (low, high) in zip(result['mean_mm'], result['ci95_mm'], strict=True):
            cells.append(f'{sign(mean)} [{sign(low)}, {sign(high)}]')
        rows.append((label, cells))
    return table(('Correct cue minus control', 'Pelvis (mm)', 'Heel (mm)'), rows, 'Paired differences by model and control')


def forest(data):
    contrasts = data['historical']['transformer']['results']['both']['cue_minus']
    parts = ['<svg viewBox="0 0 600 172" role="img" aria-labelledby="plot-title plot-desc">',
             '<title id="plot-title">Does the correct instruction reduce Transformer error?</title>',
             '<desc id="plot-desc">Both correct-minus-swapped intervals are below zero. Both correct-minus-withheld intervals cross zero. Table 4 supplies the exact values.</desc>']
    def x(value):
        return 152 + (value + .9) * 340
    ticks = (-.8, -.6, -.4, -.2, 0, .2)
    for tick in ticks:
        px = x(tick)
        ink = '#224c4a' if tick == 0 else '#dde5e4'
        parts.append(f'<line x1="{px}" x2="{px}" y1="13" y2="130" stroke="{ink}" />')
        label = f'{tick:.1f}'.replace('-', '−') if tick else '0'
        parts.append(f'<text x="{px}" y="150" text-anchor="middle">{label}</text>')
    parts.append('<text x="345" y="170" text-anchor="middle">Difference in endpoint error (mm)</text>')
    accessible_rows = []
    for row, (control, endpoint, label) in enumerate((('withheld', 0, 'Pelvis · withheld'),
            ('withheld', 1, 'Heel · withheld'), ('swapped', 0, 'Pelvis · swapped'), ('swapped', 1, 'Heel · swapped'))):
        values = contrasts[control]
        mean, limits = values['mean_mm'][endpoint], values['ci95_mm'][endpoint]
        accessible_rows.append(f'<li><strong>{label}</strong> {sign(mean)} mm [{sign(limits[0])}, {sign(limits[1])}]</li>')
        y = 25 + row * 31
        low, high = map(x, limits)
        parts += [f'<text x="2" y="{y+5}">{label}</text>',
                  f'<path d="M{low},{y} H{high} M{low},{y-5} v10 M{high},{y-5} v10" stroke="#2b6360" stroke-width="2.5" fill="none"/>',
                  f'<circle cx="{x(mean)}" cy="{y}" r="4.5" fill="#1d5752"/>']
    return ''.join(parts) + '</svg><ul class="plot-small">' + ''.join(accessible_rows) + '</ul>'


def build(out, browser):
    data = json.loads((SOURCE / 'scores.json').read_text())
    html = (SOURCE / 'paper.html.in').read_text()
    for page in range(1, 7):
        header = f'<header><span>NeuroTranslation · Walking instructions</span><span>{page} / 6</span></header>'
        html = html.replace('@@FOLIO@@', header, 1)
    for key, value in {'STYLE': typography(), 'FOREST': forest(data), 'COVERAGE': coverage(data),
                       'MODELS': methods(data), 'STRATA': conditions(data), 'CONTRASTS': comparisons(data)}.items():
        token = f'@@{key}@@'
        if html.count(token) != 1:
            raise ValueError(f'Missing or repeated manuscript field {key}')
        html = html.replace(token, value)
    if '@@' in html:
        raise ValueError('Unresolved manuscript field')
    out.mkdir(parents=True, exist_ok=True)
    page = out / 'index.html'
    page.write_text(html, encoding='utf-8')
    archive = out / 'walking-instructions-source.zip'
    with ZipFile(archive, 'w') as bundle:
        for name in MEMBERS:
            info = ZipInfo(name, (2026, 11, 21, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = ZIP_DEFLATED
            bundle.writestr(info, (SOURCE / name).read_bytes())
    if browser:
        print_pdf(page, archive, browser)


def print_pdf(page, archive, browser):
    from pypdf import PdfReader, PdfWriter
    from pypdf.generic import ArrayObject, ByteStringObject
    with TemporaryDirectory() as directory:
        temp = Path(directory)
        raw = temp / 'print.pdf'
        subprocess.run([browser, '--headless', '--disable-gpu', '--disable-background-networking',
                        '--no-first-run', '--no-default-browser-check', '--no-pdf-header-footer',
                        f'--user-data-dir={temp/"profile"}', f'--print-to-pdf={raw}', page.as_uri()],
                       check=True, capture_output=True, timeout=90)
        reader = PdfReader(raw)
        if len(reader.pages) != 6:
            raise ValueError(f'Expected six pages, found {len(reader.pages)}')
        writer = PdfWriter(clone_from=reader)
        writer.metadata = {'/Title': 'What does “fast” add once a person is moving?',
                           '/Author': '@eliminatenoise', '/Subject': 'Two walking instructions and a 100-millisecond movement forecast'}
        for file in [archive, *(SOURCE / name for name in NOTICES)]:
            writer.add_attachment(file.name, file.read_bytes())
        identity = ByteStringObject(hashlib.sha256(archive.read_bytes()).digest()[:16])
        writer._ID = ArrayObject([identity, identity])
        writer.write(page.with_name('walking-instructions.pdf'))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=SOURCE / 'output')
    parser.add_argument('--browser', help='Path to Chrome or Chromium')
    parser.add_argument('--html-only', action='store_true')
    args = parser.parse_args()
    browser = None if args.html_only else args.browser or shutil.which('chromium') or shutil.which('google-chrome')
    if not args.html_only and browser is None:
        parser.error('Install Chromium or pass its path with --browser.')
    build(args.out.resolve(), browser)
