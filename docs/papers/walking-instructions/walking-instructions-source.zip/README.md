# What does “fast” add once a person is moving?

Open the published index.html directly in a browser. It contains the complete paper and figure, including fonts and styles. The attached source ZIP in the PDF is identical to the separate paper-source download. If a PDF reader hides attachments, use the separate ZIP.

## Rebuild

Extract this ZIP to one folder, then run these commands in that folder with Python and Chromium installed. No measurement archive, model, account, local server or network connection is needed to rebuild the paper after installing the tools.

    python -m pip install pypdf==6.21.2
    python build.py --out output

Pass a Chrome/Chromium executable with --browser if it is outside your search path. For HTML and ZIP alone, use --html-only. Tested with Python 3.14, pypdf 6.21.2 and Chromium 155.0.8059.84 on Linux. Other Chromium and PDF-library versions can change print bytes and line breaks. The ZIP includes unchanged Liberation Sans Regular, Bold and Italic fonts. The builder embeds them in the standalone HTML and the printer subsets them in the PDF. Fixed archive timestamps and PDF metadata allow two clean builds to be compared.

## Reading the results

The scores.json object contains the two evaluation groups, each with three branches. The coverage branch records counts of scheduled and eligible people, walks and windows. The transformer branch holds mean Euclidean endpoint errors, percentile intervals and signed mean bias by model in results.both, results.4 (usual) and results.5 (fast). Each pair is pelvis then right heel in millimetres. Axis triples are forward, left and up, each in millimetres. cue_minus compares the fitted correct-cue Transformer with each comparator on the same people. A negative difference favours the correct-cue Transformer.

The readouts branch gives corresponding aggregate results for the fitted ridge models and simple forecasts. methods contains results pooled over conditions and conditions reports the two task contexts. paired holds correct-cue minus comparator statistics. cue_test separates the prespecified two-control decision (correct beats withheld and swapped on the same endpoint, with both upper bounds below zero) from the descriptive comparison with simple mean errors. Development used three participant-held-out folds for the Transformer and five for the readouts. The final estimates were fitted on the complete development cohort and scored once on the released historical walks. All historical architecture contrasts use the same 216 windows. The separate secondary object holds model-to-model comparisons and numbers of people who improved. These are secondary, unadjusted comparisons. Each interval uses 5,000 paired bootstrap draws of whole participants with replacement and percentile limits (seed 1207).

The fitted models and source reader are distributed separately with the [Transformer](https://eliminatenoise.github.io/NeuroTranslation/walking-instructions/) and [linear and fixed-encoder controls](https://eliminatenoise.github.io/NeuroTranslation/walking-instruction-controls/). The [Interoceptomics atlas](https://eliminatenoise.github.io/Interoceptomics/walking-instructions/) shows two measured walks with their recording context. This archive regenerates the manuscript from the included aggregate scores. Original participant identifiers, individual trajectories and model predictions by person are outside its contents.

## Sources and rights

Schreiber C, Moissenet F (2019). *A multimodal dataset of human gait at different walking speeds established on injury-free adult participants*. Scientific Data 6, 111. [Original paper](https://doi.org/10.1038/s41597-019-0124-4).

Moissenet F, Schreiber C (2020). [Figshare walking recordings, version 8](https://doi.org/10.6084/m9.figshare.7734767.v8). The original data and adaptations retain [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). DATA-LICENCE.txt is the authors’ original licence and attribution notice. The analysis selects two walking conditions and three repeats, transforms skin-marker positions into local displacement targets, and reports aggregate prediction errors. The [authors’ marker-processing code](https://github.com/fmoissenet/CGA_Rehazenter_Toolbox/blob/e35dc90c1acd24da134897fd1b4241152cff6005/importTrialMarker.m) documents gap reconstruction, filtering and cropping.

Original paper text, figure and build code are dedicated under CC0 1.0 to the extent of the project's rights. See CC0-1.0.txt. Liberation Sans is distributed under the SIL Open Font License 1.1. The font authors’ copyright and licensing terms are in Liberation-font-LICENSE.txt.
