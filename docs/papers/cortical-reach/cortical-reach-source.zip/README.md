# Can a sensory brain signal improve a reach forecast?

This editable research paper compares forecasts of a macaque's planar robot-handle displacement in the next 100 ms. It uses one day in one animal, two events from the same original trials, ten recorded rows per forecast horizon and centimetres for both endpoint coordinates. The PDF contains the same seven sections as the HTML. The PDF's attachments include this source ZIP and the CC0 legal terms. The HTML is self-contained and can be opened without a server.

## Rebuild the paper

Extract the ZIP into its own directory. Python 3.10 or later builds the HTML and the source ZIP using the bundled tables. It makes no network request and does no model fitting.

    python build.py --html-only

To generate the PDF, install pypdf, use a Chromium or Chrome installation and make Liberation Sans available. Run:

    python -m pip install pypdf
    python build.py

The output directory defaults to output/. Pass --out to choose another or --browser to provide the browser executable. The main page and the source archive can be reproduced byte for byte from these sources. The PDF's binary identity can vary with the browser, PDF library, font version or metadata. The interval plot is supplied as intervals.svg. To redraw it after changing the scores, install Matplotlib and run python plot.py before the build. Editing manuscript.html or style.css changes the text or layout. The Python builder reads the publication data in tables/ and inserts the figures and tables into the HTML.

## Contents of the tables

- validation-handle.json and test-handle.json contain the full unrounded primary scores from the validation and final chronological blocks. In each, subsets.matched contains trial, event and window counts, model errors with per-seed values, and paired contrasts. The models' mean fields are straight-line distance ('euclidean'), unsigned error along each axis ('x_mae', 'y_mae') and signed forecast-minus-recorded bias along each axis ('x_bias', 'y_bias'), in cm. A deterministic model has one result; a Transformer has three separate fits. The paper averages the seed-specific errors. It does not calculate the error of the average prediction.
- matched_bump, matched_reach, each recorded direction (or direction unavailable) and matched_both_epochs recalculate scores on their own rows. all_eligible_no_donor_required compares the joint Transformer with and without spikes using all windows, without imposing the other-trial matching requirement. Two-sided percentile bootstrap intervals ('ci95') were fixed for pooled and phase contrasts. Directional scores show descriptive means and seed ranges. No direction-specific test or confidence interval was defined.
- validation-landmarks.json and test-landmarks.json preserve the separate linear-model analyses with unrounded errors, axis biases, root mean square endpoint errors and paired 95% intervals. primary uses the common eligible marker rows. timing uses common support for both the recipient's and donor's landmarks, and replaces each stream separately. cells lists source and missing-landmark support by event and offset. The marker additions are addition-minus-reference, so negative values favor the added measurements. The main handle comparisons are reference-minus-joint, so positive values favor correctly paired spikes.
- input-identities.json records file checksums and dataset, processing and model references. The publication ZIP contains aggregate scientific data. The original Dryad MAT file and raw training examples are distributed by the original authors.

## Reproduce the analysis design

Download the selected member of the Dryad archive (DOI 10.5061/dryad.nk98sf7q7, version 6) and verify the hash in the paper. Keep the 540 rewarded original trials in time order; assign the first 324 to fitting, the next 108 to validation and the final 108 to testing. Build the two epochs from each original only after assigning its split. Require one bump, one target and one go, with bump before both; include a bump outcome only when it ends strictly before the target and go. A reach observation requires the target by the cutoff. All input rows and both output endpoints must belong to their own original. A cue is visible to a token only after the end of its event row. The test demonstration is original trial 499.

For each forecast use five consecutive 40-ms groups ending at k. Sum the four completed spike-count rows in each group; include the endpoint x,y, its change over those four rows, and the visible event/direction flags. At k predict p[k+10]−p[k] on the 10-ms archive clock. The six Transformer input masks have the same 41-dimensional input shape, hidden width 16, two attention heads, one residual attention block, feedforward hidden width 32 and one final two-dimensional prediction. Each fit uses the final epoch after 24 passes, batch size 128, AdamW learning rate 0.002, weight decay 0.001, gradient norm limit 1.0, and seeds 17, 41 and 73. The fitting block alone estimates normalizers. Every contrast keeps the same recipient times. A donor is the most recent earlier original from the same chronological split matching the event, offset and exact cutoff-visible cue flags and directions.

Primary linear controls use ridge penalty 0.01. Rates include both a subset retaining five time-resolved population totals and a subset retaining the 30 units' separate mean rates. The marker analysis uses an independently fixed penalty of 0.1. Its handle-based fits correct the 40-ms velocity forecast. Its no-handle fits forecast the full target directly. The primary block bootstrap uses a block length of eight originals, 5,000 draws and NumPy PCG64 seed 20261121. The secondary analysis uses 12 originals, 5,000 draws and seed 1641. Neither uncertainty estimate can establish replication between animals.

## Source and rights

Chowdhury RH, Glaser JI, Miller LE (2020). *Area 2 of primary somatosensory cortex encodes kinematics of the whole arm*. eLife 9:e48198. https://doi.org/10.7554/eLife.48198

Original recordings and metadata: https://doi.org/10.5061/dryad.nk98sf7q7 . Version 6. Raeed Chowdhury, Joshua Glaser and Lee Miller. CC0 1.0. Data have been transformed to produce forecast targets, control comparisons and aggregate error estimates. No microscopy, trial videos, original article figures or third-party source code are bundled. Public documentation and the authors' original code are cited in the manuscript. The NeuroTranslation project's new paper, builder and original tables use CC0 1.0, with the legal text included.

Model viewer: https://eliminatenoise.github.io/NeuroTranslation/cortical-reach/

Recording viewer: https://eliminatenoise.github.io/Interoceptomics/cortical-reach/

Reanalysis source and frozen downloadable models: https://github.com/eliminatenoise/NeuroTranslation/tree/main/models/cortical-reach
