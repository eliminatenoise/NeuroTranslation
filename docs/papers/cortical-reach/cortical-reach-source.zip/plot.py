"""Redraw the publication interval plot from the two included handle score tables."""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

HERE = Path(__file__).resolve().parent
def draw():
    plt.rcParams.update({"font.family":"Liberation Sans","font.size":9,"svg.fonttype":"none",
                         "svg.hashsalt":"cortical-reach-1","axes.unicode_minus":True})
    fig,ax=plt.subplots(figsize=(6.65,1.95),layout="constrained")
    positions={"validation":(3.25,1.25),"test":(2.75,.75)}
    for stage,color,marker,title in (("validation","#5d635a","o","Validation"),("test","#136041","s","Later trials")):
        sub=json.loads((HERE/"tables"/f"{stage}-handle.json").read_text())["subsets"]["matched"]["contrasts_cm"]
        for i,key in enumerate(("transformer_movement_cue_minus_joint","transformer_wrong_neural_minus_joint")):
            d=sub[key];value=d["mean"];lo,hi=d["ci95"];y=positions[stage][i]
            ax.errorbar(value,y,xerr=[[value-lo],[hi-value]],color=color,marker=marker,
                        markersize=4.8,linewidth=1.5,capsize=3,label=title if i==0 else None)
    ax.axvline(0,color="#463e35",lw=1,ls="--")
    ax.set(ylim=(.25,3.75),yticks=[3.,1.],yticklabels=["Handle + cues minus joint","Wrong spikes minus correct"])
    ax.set_xlabel("Paired difference in mean error (cm) · positive favors correctly paired spikes")
    ax.xaxis.set_major_locator(MaxNLocator(nbins=6))
    ax.tick_params(axis="both",length=0)
    ax.grid(axis="x",lw=.5,color="#d4ddd4")
    ax.spines[["top","right","left"]].set_visible(False)
    ax.legend(loc="lower center",bbox_to_anchor=(.49,1.0),ncol=2,frameon=False,fontsize=8.5)
    fig.savefig(HERE/"intervals.svg",format="svg",metadata={"Date":None,"Title":"Mean error differences in validation and later original trials"})
    plt.close(fig)

if __name__=="__main__":
    draw()
