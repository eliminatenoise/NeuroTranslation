"""Rebuild the cortical-reach paper using the included publication tables."""
import argparse
import base64
import hashlib
import json
import shutil
import subprocess
import tempfile
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

HERE = Path(__file__).resolve().parent
TITLE = "Can a sensory brain signal improve a reach forecast?"
BASE_URL = "https://eliminatenoise.github.io/NeuroTranslation/papers/cortical-reach/"
MOTION = "transformer_movement_cue_minus_joint"
WRONG = "transformer_wrong_neural_minus_joint"

def read(name):
    return json.loads((HERE / "tables" / name).read_text())

def num(value):
    return f"{value:.3f}".replace("-0.000", "0.000").replace("-", "−")

def count(value):
    return f"{value:,}"

def effect(entry, marker=False):
    bounds = entry["interval95" if marker else "ci95"]
    return f'{num(entry["mean"])} [{num(bounds[0])}, {num(bounds[1])}]'

def table(caption, headers, rows, style=""):
    headings = "".join(f'<th scope="col">{name}</th>' for name in headers)
    body = []
    for label, *values in rows:
        fields = "".join(f"<td>{v}</td>" for v in values)
        body.append(f'<tr><th scope="row">{label}</th>{fields}</tr>')
    return (f'<div class="tablewrap"><table class="{style}"><caption>{caption}</caption>'
            f'<thead><tr>{headings}</tr></thead><tbody>{"".join(body)}</tbody></table></div>')

def primary(main, validation):
    model = "transformer_all"
    mov = "transformer_movement_cue"
    def score(cell, model_name):
        return num(cell["models"][model_name]["mean"]["euclidean"])
    held = main["subsets"]["matched"]
    dev = validation["subsets"]["matched"]
    bump, reach = (main["subsets"]["matched_"+s] for s in ("bump","reach"))
    model_list = (("Assume no movement","stationary"),("Continue last 40 ms","constant_velocity_40ms"),
       ("Continue last 100 ms","constant_velocity_100ms"),("Continue last 200 ms","constant_velocity_200ms"),
       ("Linear, handle + cues","ridge_movement_cue"),("Linear, handle + cues + spikes","ridge_all"),
       ("Transformer, cues only","transformer_cue_only"),("Transformer, spikes only","transformer_neural_only"),
       ("Transformer, handle only","transformer_movement_only"),("Transformer, spikes + cues","transformer_neural_cue"),
       ("Transformer, handle + cues",mov),("Transformer, handle + cues + spikes",model),
       ("Joint Transformer, other trial’s spikes","transformer_wrong_neural"))
    rows = [[name, *(score(i,m) for i in (dev,held,bump,reach))] for name,m in model_list]
    tab = table("Table 1. Mean distance missed in cm. Smaller is better. Later push and reach are also shown separately.",
                ["Forecast","Validation","Later","Later push","Later reach"],rows)
    cm,wr = (held["contrasts_cm"][k] for k in (MOTION,WRONG))
    evidence = {
       "improvement":"the interval supports a smaller error with spikes",
       "worsening":"the interval supports a larger error with spikes",
       "unresolved":"the interval includes zero, leaving the added value of spikes unresolved",
    }[main["decision"]["incremental"]]
    timing = {
       "improvement":"using spikes from the correct trial reduced error relative to the matched wrong trial",
       "worsening":"the forecaster did better with the other trial’s spikes",
       "unresolved":"the interval does not resolve an advantage over the other trial’s spikes",
    }[main["decision"]["wrong_trial_control"]]
    finding = (f'<b>On later trials from this animal,</b> the handle-and-cue model missed by '
               f'{score(held,mov)} cm on average. Adding the cortical spikes gave {score(held,model)} cm. '
               f'The paired difference was {effect(cm)} cm (95% interval)' + f', so {evidence}.')
    contrasts = (f'<p>On validation, the paired advantage from adding spikes was '
        f'{effect(dev["contrasts_cm"][MOTION])} cm. The later-trial wrong-minus-correct difference '
        f'was {effect(wr)} cm. With the other observations fixed, {timing}. Positive differences '
        'favor the joint model with the correct spikes.</p>')
    axis=held["models"][model]["mean"]
    allrows=main["subsets"]["all_eligible_no_donor_required"]
    contrasts += (f'<p>On matched later trials the joint model’s mean absolute x and y errors were '
        f'{num(axis["x_mae"])} and {num(axis["y_mae"])} cm. Its signed biases (forecast minus recording) were '
        f'{num(axis["x_bias"])} and {num(axis["y_bias"])} cm. Including windows without donors, '
        f'the joint and motion-plus-cue errors were {score(allrows,model)} and {score(allrows,mov)} cm.</p>')
    rates=("ridge_movement_cue_population_rate","ridge_movement_cue_unit_rate","ridge_wrong_neural")
    rstats=[score(held,n) for n in rates]
    seedvals=cm["by_seed"]
    contrasts += (f'<p class="note">In the linear model, pooling spikes across neurons in each interval gave '
        f'{rstats[0]} cm, averaging each neuron’s firing across time gave {rstats[1]} cm, and swapping '
        f'the full spike history gave {rstats[2]} cm. The Transformer added-spike differences at seeds '
        f'17, 41 and 73 were {num(seedvals["17"])}, {num(seedvals["41"])} and {num(seedvals["73"])} cm.</p>')
    return finding,tab,contrasts

def directions(main, validation):
    sub = main["subsets"]
    dev = validation["subsets"]["matched"]
    held = sub["matched"]
    coverage = main["support"]
    p = (f'<p>Of 108 later originals, {held["n_trials"]} had a matching earlier donor for at least one '
       f'forecast ({count(held["n_windows"])} of {count(main["n_eligible_windows"])} eligible windows). '
       f'The matching requirement removed {coverage["bump"]["no_earlier_exact_donor_windows"]} push and '
       f'{coverage["reach"]["no_earlier_exact_donor_windows"]} reach windows. In validation it left '
       f'{dev["n_trials"]} of 108 originals and {count(dev["n_windows"])} of {count(validation["n_eligible_windows"])} eligible windows. '
       f'The later source retained {count(main["n_eligible_windows"])} of {count(main["n_originals_in_block"]*8)} attempted windows before donor matching.</p>')
    rows = []
    def read_row(label, data):
        if not data["n_windows"]:
            return [label,"0","0","—","—","—"]
        measures = data["models"]["transformer_all"]["mean"]
        contrast = data["contrasts_cm"][MOTION]
        return [label,count(data["n_trials"]),count(data["n_windows"]),num(measures["euclidean"]),
                num(contrast["mean"]),num(data["contrasts_cm"][WRONG]["mean"])]
    for phase,label in (("bump","Push"),("reach","Reach")):
        pool = sub["matched_"+phase]
        rows.append(read_row(f'<b>{label}, all</b>',pool))
        for angle in ("0deg","90deg","180deg","270deg","direction_unavailable"):
            key = "matched_"+phase+"_"+angle
            suffix = "unknown at cutoff" if angle=="direction_unavailable" else angle.replace("deg","°")
            rows.append(read_row(f'{label}, {suffix}',sub.get(key,{"n_windows":0})))
    tab = table("Table 2. Later, donor-matched trials. Joint is the distance missed, gain is handle-and-cue error minus joint error, and swap is wrong-trial error minus joint error. All three columns are in cm.",
        ["Event and direction","Trials","Windows","Joint","Gain","Swap"],rows,"dir")
    s = {k:sub["matched_"+k]["contrasts_cm"] for k in ("bump","reach")}
    diag = (f'<p>For the push, the added-spike difference was {effect(s["bump"][MOTION])} cm (95% interval). '
       f'For the reach it was {effect(s["reach"][MOTION])} cm. The corresponding wrong-minus-correct '
       f'differences were {effect(s["bump"][WRONG])} and {effect(s["reach"][WRONG])} cm. '
       'Inference was defined for the pooled and phase comparisons. The direction rows describe individual conditions.</p>')
    both=sub["matched_both_epochs"]
    diag += (f'<p class="note">Restricting the pooled analysis to {both["n_trials"]} later originals with both events retained gave '
        f'an added-spike difference of {effect(both["contrasts_cm"][MOTION])} cm.</p>')
    return p,tab,diag

def markers(main, val):
    m,valm = main["primary"],val["primary"]
    timing = main["timing"]
    model_list = (("Only the two 3D landmarks","markers"),("Only the spikes","neural"),
       ("Handle + cues","body_control"),("Handle + cues + landmarks","body_markers"),
       ("Handle + cues + spikes","body_neural"),("Handle + cues + landmarks + spikes","full"))
    def distance(report,name):return num(report["methods"][name]["distance_cm"])
    rows = [[label,*(distance(z,name) for z in (valm,m,m["by_epoch"]["perturbation"],m["by_epoch"]["reach"]))]
            for label,name in model_list]
    tab = table(f'Table 3. Mean planar handle error (cm), using all rows with both landmarks. Later trials contribute {count(m["total_rows"])} windows from {m["original_trials"]} originals. Validation contributes {count(valm["total_rows"])} windows from {valm["original_trials"]} originals.',
       ["Linear model inputs","Validation","Later","Later push","Later reach"],rows)
    c1,c2=(m["contrasts"][k] for k in ("body_markers_minus_body_control","full_minus_body_markers"))
    reason = lambda r:"met" if r["gate"] else "did not meet"
    result = (f'<p>Adding the landmarks changed the later error by {effect(c1,True)} cm. Adding spikes after the landmarks changed it by {effect(c2,True)} cm. '
       f'Here a <em>negative</em> change favors the addition. Landmarks changed push error by {num(c1["epoch_means"]["perturbation"])} cm and reach error by {num(c1["epoch_means"]["reach"])} cm. The landmark comparison {reason(c1)} the preset criterion, and the added-spike comparison {reason(c2)} it. '
       'Each required the interval’s upper endpoint below zero and lower mean error in both phases. The intervals used 5,000 draws of 12 consecutive trials. '
       f'On {count(timing["total_rows"])} donor-matched windows, full-minus-swapped error was '
       f'{effect(timing["contrasts"]["full_minus_wrong_marker"],True)} cm when swapping landmarks and '
       f'{effect(timing["contrasts"]["full_minus_wrong_neural"],True)} cm when swapping spikes.</p>')
    return tab,result

FILES = ("README.md","plot.py","intervals.svg","CC0-1.0.txt","build.py","manuscript.html","style.css",
         "tables/validation-handle.json","tables/test-handle.json",
         "tables/validation-landmarks.json","tables/test-landmarks.json","tables/input-identities.json")

def render():
    held,dev = (read(n+"-handle.json") for n in ("test","validation"))
    lead,tab1,contrast = primary(held,dev)
    support,tab2,diagnostic = directions(held,dev)
    tab3,marker_result = markers(read("test-landmarks.json"),read("validation-landmarks.json"))
    svg=base64.b64encode((HERE/"intervals.svg").read_bytes()).decode("ascii")
    chart=(f'<img class="forest" alt="Two paired error comparisons and 95% intervals for validation and later trials. The corresponding pooled numbers appear in the text and tables." src="data:image/svg+xml;base64,{svg}">')
    slots = dict(CHART=chart, STYLE=(HERE/"style.css").read_text(), LEAD_RESULT=lead, HANDLE_TABLE=tab1,
                 HANDLE_CONTRAST=contrast,SUPPORT=support,DIR_TABLE=tab2,DIAGNOSTIC=diagnostic,
                 MARKER_TABLE=tab3,MARKER_RESULT=marker_result)
    html = (HERE/"manuscript.html").read_text()
    for key,value in slots.items():
        token="@@"+key+"@@"
        if html.count(token)!=1:raise ValueError("Unexpected manuscript slot: "+key)
        html=html.replace(token,value)
    if "@@" in html:raise ValueError("Unfilled manuscript slot")
    return html

def build(out,browser,html_only):
    out.mkdir(parents=True,exist_ok=True)
    html=render()
    (out/"index.html").write_text(html)
    archive=out/"cortical-reach-source.zip"
    with ZipFile(archive,"w") as z:
        for name in FILES:
            item=ZipInfo(name,date_time=(2026,11,21,0,0,0))
            item.create_system=3
            item.external_attr=0o100644<<16
            item.compress_type=ZIP_DEFLATED
            z.writestr(item,(HERE/name).read_bytes())
    if html_only:return
    from pypdf import PdfReader,PdfWriter
    from pypdf.generic import ArrayObject,ByteStringObject
    with tempfile.TemporaryDirectory(dir=out) as tmp:
        tmp=Path(tmp)
        export=tmp/"export.html"
        # Print all local navigation as durable HTTPS links. HTML remains relative for offline use.
        export.write_text(html.replace('href="../../cortical-reach/"','href="https://eliminatenoise.github.io/NeuroTranslation/cortical-reach/"')
          .replace('href="cortical-reach.pdf"',f'href="{BASE_URL}cortical-reach.pdf"')
          .replace('href="cortical-reach-source.zip"',f'href="{BASE_URL}cortical-reach-source.zip"'))
        raw=tmp/"print.pdf"
        subprocess.run([browser,"--headless","--disable-gpu","--disable-background-networking",
           "--no-first-run","--no-default-browser-check","--no-pdf-header-footer",
           f'--user-data-dir={tmp/"profile"}',f'--print-to-pdf={raw}',export.as_uri()],
           capture_output=True,check=True,timeout=90)
        writer=PdfWriter(clone_from=PdfReader(raw))
        writer.metadata={"/Title":TITLE,"/Author":"NeuroTranslation","/Subject":"Area 2 firing and 100 ms handle-displacement forecasts in one macaque session"}
        writer.add_attachment(archive.name,archive.read_bytes())
        writer.add_attachment("CC0-1.0.txt",(HERE/"CC0-1.0.txt").read_bytes())
        key=ByteStringObject(hashlib.sha256(archive.read_bytes()).digest()[:16])
        writer._ID=ArrayObject([key,key])
        writer.write(out/"cortical-reach.pdf")

if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--out",type=Path,default=HERE/"output")
    cli.add_argument("--browser",default=shutil.which("chromium") or shutil.which("google-chrome"))
    cli.add_argument("--html-only",action="store_true")
    args=cli.parse_args()
    if not args.html_only and not args.browser:cli.error("Supply --browser with Chromium or Chrome.")
    build(args.out.resolve(),args.browser,args.html_only)
