"""Regenerate the elapsed-time figure from the public aggregate results."""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

source = Path(__file__).resolve().parent
data = json.loads((source / "aggregate-results.json").read_bytes())["test"]["groups"]
times = [200, 600, 1000, 1400, 1800, 2200, 2600]
plt.rcParams.update({"font.family":"Liberation Sans", "font.size":12, "svg.fonttype":"path",
                      "svg.hashsalt":"cylinder-rotation-elapsed-v1", "axes.spines.top":False, "axes.spines.right":False})
fig, ax = plt.subplots(figsize=(6.2, 2.35), layout="constrained")
for key, label, color, marker, linestyle in [
    ("transformer_full","Gyro + acceleration + task","#075b62","o","-"),
    ("transformer_gyro_task","Gyro + task","#a84d21","s","--"),
    ("transformer_wrong_accel","Substituted acceleration","#46516c","^",":")]:
    errors = [data[f"matched/cutoff_{t}ms/gyro"]["scores"][key]["error"] for t in times]
    ax.plot([t/1000 for t in times], errors, label=label, color=color, marker=marker,
            linestyle=linestyle, markersize=3.5, linewidth=1.6)
ax.grid(axis="y",color="#dde4e2",zorder=0)
ax.set(xlabel="Cutoff after recording began (s)", ylabel="Miss (rad/s)",ylim=(0,None),xticks=[t/1000 for t in times])
ax.legend(loc="upper right",fontsize=8.8, frameon=False)
fig.savefig(source/"rate-by-time.svg",format="svg",metadata={"Date":None,"Title":"Held angular-velocity error across seven cutoffs"})
