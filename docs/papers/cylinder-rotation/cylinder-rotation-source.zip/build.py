"""Build the offline article, printable edition and editable source archive."""
import argparse
import base64
import hashlib
import html
import json
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

HERE = Path(__file__).resolve().parent
TITLE = "How fast will the cylinder turn?"
FILES = ("README.md","article.html","style.css","aggregate-results.json","gesture-aggregates.json",
         "build.py","figure.py","rate-by-time.svg","cylinder.jpg","targets.png","CC-BY-4.0.txt","CC0-1.0.txt")

def image(name, mime, description):
    encoded=base64.b64encode((HERE/name).read_bytes()).decode("ascii")
    return f'<img alt="{html.escape(description)}" src="data:{mime};base64,{encoded}">'

def numeric(value, digits=4, signed=False):
    return format(value, ("+" if signed else "")+"."+str(digits)+"f").replace("-","−")

def table(title, headings, rows):
    cols = ''.join(f'<th scope="col">{html.escape(h)}</th>' for h in headings)
    body=[]
    for label,*values in rows:
        cells=''.join(f'<td>{html.escape(str(x))}</td>' for x in values)
        body.append(f'<tr><th scope="row">{html.escape(label)}</th>{cells}</tr>')
    return f'<table><caption>{title}</caption><thead><tr>{cols}</tr></thead><tbody>{"".join(body)}</tbody></table>'

def interval(contrast, digits=4, amount="difference"):
    center=numeric(contrast[amount],digits,True)
    lo,hi=(numeric(v,digits,True) for v in contrast["interval"])
    return f"{center} [{lo}, {hi}]"

def coverage(data):
    rows=[]
    for split,label in (("train","Fit (3–6)"),("validation","Check (7–8)"),("test","Test (9–10)")):
        block=data[split]
        all_rows=block["groups"]["all/overall/gyro"]
        matched=block["groups"]["matched/overall/gyro"]
        rows.append((label,f'{all_rows["recordings"]:,} / {block["coverage"]["assigned_originals"]:,}',
                     f'{all_rows["windows"]:,}',f'{matched["recordings"]:,}',f'{matched["windows"]:,}'))
    return table("Table 1. Support by within-target assignment number. Each stage includes 24 people.",
                 ("Stage","Eligible / assigned trials","Eligible windows","Matched trials","Matched windows"),rows)

def rate(data):
    test=data["test"]; g=test["groups"]["matched/overall/gyro"]
    scores=g["scores"]; d=g["full_minus"]; a=test["groups"]["all/overall/gyro"]
    ac=test["groups"]["matched/overall/accel"]
    compare="transformer_gyro_task"; wrong="transformer_wrong_accel"; full="transformer_full"
    s=lambda k:numeric(scores[k]["error"])
    lower="established" if test["primary_passed"] else "did not establish"
    verdict=f"The two prespecified comparisons {lower} an incremental acceleration benefit on the donor-matched repetitions."
    assert not test["primary_passed"] and d[compare]["interval"][1]>0 and d[wrong]["interval"][1]<0
    abstract=(f'The full model missed the future angular-rate vector by {s(full)} rad/s on {g["windows"]:,} matched windows. '
              f'The gyro-plus-task model missed by {s(compare)} rad/s. Their paired difference was '
              f'{interval(d[compare],5)} rad/s (95% interval). Borrowing another trial’s acceleration made forecasts worse, '
              'but the matched comparison with gyro plus task remained uncertain.')
    primary=(f'<p>On the same {g["recordings"]} held recordings, the full model’s error minus that of gyro plus task was '
             f'<strong>{interval(d[compare],5)} rad/s</strong>. Against substituted acceleration the difference was '
             f'<strong>{interval(d[wrong],5)} rad/s</strong> (95% paired intervals). {verdict} '
             f'With all {a["windows"]:,} valid windows, the full-minus-gyro difference was {interval(a["full_minus"][compare],5)} rad/s. '
             'That larger set includes recordings with no earlier donor, so it answers only the first comparison.</p>')
    methods=[(full,"Both sensors + task"),(compare,"Gyro + task"),(wrong,"Substituted acceleration"),
             ("transformer_accel_task","Acceleration + task"),("transformer_sensors","Both sensors, hand and time"),
             ("transformer_task","Task only"),("transformer_gyro_loss","Both sensors, trained on gyro alone"),
             ("ridge_full","Linear fit, both sensors + task"),("ridge_gyro_task","Linear fit, gyro + task"),
             ("ridge_sensors","Linear fit, both sensors, hand and time"),
             ("hand_target_time_mean","Training mean by hand, target and time"),("persistence","Repeat latest 100 ms mean"),
             ("linear_trend","Continue recent linear trend")]
    rows=[(name,s(key),numeric(ac["scores"][key]["error"],3) if key in ac["scores"] else "—") for key,name in methods]
    forecasts=table("Table 2. Error on matched held windows. Each column has its own physical unit.",
                    ("Forecast","Angular rate (rad/s)","Acceleration (m/s²)"),rows)
    seeds=', '.join(numeric(x) for x in scores[full]["by_fit"])
    check=data["validation"]["groups"]["matched/overall/gyro"]
    val_miss=numeric(check["scores"][full]["error"])
    aux=interval(d["transformer_gyro_loss"])
    fit_note=(f'On development repetitions the full model missed by {val_miss} rad/s on {check["windows"]:,} matched windows. On test repetitions the three full-model errors were {seeds} rad/s in seed order. Jointly learning acceleration changed gyro error '
              f'by {aux} rad/s against gyro-only training. The smallest matched angular-rate error came from the model given '
              f'both sensors, hand and time, with the assigned target omitted ({s("transformer_sensors")} rad/s).')
    spread=scores[full]["person_range"]
    per_person=(f'Across people, the median full-model miss was {numeric(spread["median"])} rad/s '
                f'(range {numeric(spread["minimum"])}–{numeric(spread["maximum"])}). '
                f'The full model beat gyro plus task in {d[compare]["better_people"]} of 24 people and '
                f'beat substituted acceleration in {d[wrong]["better_people"]} of 24.')
    return abstract,primary,forecasts,fit_note,per_person

def phases(data):
    groups=data["test"]["groups"];rows=[]
    for key,name in [("hand_left","Left hand"),("hand_right","Right hand")]+[(f"cutoff_{t}ms",f"{t:,} ms") for t in range(200,2601,400)]:
        g=groups[f"matched/{key}/gyro"]
        rows.append((name,f'{g["windows"]:,}',numeric(g["scores"]["transformer_full"]["error"],3),
                     interval(g["full_minus"]["transformer_gyro_task"],4)))
    return table("Table 3. Error by hand and elapsed time on matched held recordings. Δ is full minus gyro plus task.",
                 ("Group","Windows","Full (rad/s)","Δ [95% interval] (rad/s)"),rows)

def orientation(data):
    o=data["orientation"]; g=o["results"]["matched/overall"];m=g["methods"];delta=g["full_minus"]
    rows=[]
    for k,label in (("transformer_full","Both sensors + task"),("transformer_gyro_task","Gyro + task"),
                    ("transformer_wrong_accel","Substituted acceleration"),("transformer_gyro_loss","Gyro-only training"),
                    ("ridge_full","Full linear fit"),("hold_orientation","Hold the last orientation"),
                    ("persistence","Repeat recent mean gyro"),("linear_trend","Continue recent gyro trend")):
        rows.append((label,numeric(m[k],3),"—" if k=="transformer_full" else interval(delta[k],3,"mean_degrees")))
    output=table("Table 4. Shortest angle between predicted and device-estimated orientation on matched held windows.",
                 ("Rate used for projection","Miss (°)","Full minus comparator [95%] (°)"),rows)
    output+=f'<p>All {o["eligible_windows"]:,} held windows had usable endpoint quaternions. The full projection beat both the unchanged-orientation and repeated-rate baselines on the {g["rows"]:,} matched windows. Integrating the ten <em>actual future</em> gyro readings in sequence left {numeric(m["future_gyro_integration_diagnostic"],3)}° mean mismatch. This last number checks the convention and timing after the fact. Those readings are unavailable at prediction time.</p>'
    hand = [o["results"][f"matched/{name}"]["methods"]["transformer_full"] for name in ("left","right")]
    seeds = ", ".join(numeric(v,3)+"°" for v in g["by_fit_degrees"]["transformer_full"])
    output+=f'<p>Mean full-model angle error was {numeric(hand[0],3)}° in left-hand trials and {numeric(hand[1],3)}° in right-hand trials. The three seed-specific means on common support were {seeds}. Angle errors and intervals at every cutoff appear in the source tables.</p>'
    return output

def gesture():
    summary=json.loads((HERE/"gesture-aggregates.json").read_bytes())
    return table("Table 5. Average wrist endpoint miss on 80 held repeat gestures (mm).",
                 ("Inputs / forecast","Left, shoulder-relative","Right, shoulder-relative","Both, shoulder-relative","Both, camera frame"),
                 [(row["method"],*(f"{n:.2f}" for n in row["mm"])) for row in summary["table"]])

def render():
    data=json.loads((HERE/"aggregate-results.json").read_bytes())
    abstract,primary,scores,seed_note,spread=rate(data)
    chart=(f'<figure class="chart">{image("rate-by-time.svg","image/svg+xml","Angular-rate miss across seven elapsed cutoffs for the full, gyro-plus-task and substituted-acceleration forecasts. The numeric full results appear in Table 3.")}'
           '<figcaption><strong>Figure 2.</strong> Angular-rate errors on the same recordings, averaged first within person. Points mark sampled windows. Lines connect the estimates across elapsed time.</figcaption></figure>')
    source=(HERE/"article.html").read_text()
    fields={"style":(HERE/"style.css").read_text(),"abstract":abstract,"coverage":coverage(data),"primary":primary,
            "forecast_table":scores,"fit_note":seed_note,"phase_chart":chart,"phase_table":phases(data),"spread":spread,
            "orientation":orientation(data),"gesture_table":gesture(),
            "apparatus":image("cylinder.jpg","image/jpeg","Published photograph of the tracked cylinder with a latched sensor and two reflective markers."),
            "targets":image("targets.png","image/png","Published plan showing nine numbered targets arranged on a semicircle around a common starting point."),
            "discussion":"<p>Borrowing acceleration from another repetition disturbed the forecast more than removing acceleration and retraining. A model can learn to use a second signal even when a model trained without it predicts almost as well. On these repetitions, the sensor pair also worked best when the hand and clock were supplied without the target number. Giving the model a destination did not guarantee a better description of how the object turned along the way.</p>"}
    for key,content in fields.items():
        token="{{"+key+"}}"; assert source.count(token)==1,token
        source=source.replace(token,content)
    assert not re.search(r"\{\{[a-z_]+\}\}",source)
    return source

def build(out):
    out.mkdir(exist_ok=True,parents=True)
    page=render()
    (out/"index.html").write_text(page)
    archive=out/"cylinder-rotation-source.zip"
    with ZipFile(archive,"w") as z:
        for name in FILES:
            item=ZipInfo(name,date_time=(2026,11,21,0,0,0))
            item.create_system=3; item.external_attr=0o100644<<16
            z.writestr(item,(HERE/name).read_bytes(),compress_type=ZIP_DEFLATED)
    from pypdf import PdfReader,PdfWriter
    from pypdf.generic import ArrayObject,ByteStringObject
    browser=shutil.which("chromium") or shutil.which("google-chrome")
    if not browser: raise RuntimeError("Install Chromium or Google Chrome to print the PDF.")
    with tempfile.TemporaryDirectory() as directory:
        temp=Path(directory);manuscript=temp/"article.html";printed=temp/"print.pdf"
        manuscript.write_text(page)
        subprocess.run([browser,"--headless","--disable-gpu","--disable-background-networking",
                        "--no-pdf-header-footer",f"--user-data-dir={temp/'profile'}",
                        f"--print-to-pdf={printed}",manuscript.as_uri()],capture_output=True,check=True,timeout=90)
        writer=PdfWriter(clone_from=PdfReader(printed))
        writer.metadata={"/Title":TITLE,"/Author":"NeuroTranslation","/Subject":"Angular-velocity forecasts from the Ruhr Hand Motion Catalog"}
        writer.add_attachment(archive.name,archive.read_bytes())
        identity=ByteStringObject(hashlib.sha256(archive.read_bytes()).digest()[:16])
        writer._ID=ArrayObject([identity,identity])
        writer.write(out/"cylinder-rotation.pdf")

if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--out",type=Path,default=HERE/"output")
    build(cli.parse_args().out)
