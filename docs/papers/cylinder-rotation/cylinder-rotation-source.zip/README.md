# How fast will the cylinder turn?

An experimental paper from NeuroTranslation, issued 21 November 2026. The web edition, eight-page printable PDF and editable source archive describe the same analysis. Read the web article offline in a browser. Readers with support for PDF attachments can extract cylinder-rotation-source.zip from the PDF’s attachments panel. The separate ZIP has identical contents.

## Rebuild this edition

Unzip the source, open a terminal in the extracted folder, and run:

    python -B build.py

Python 3.11 or later, pypdf, Liberation Sans and Chromium or Google Chrome are needed. No account, server or network is required to build or read the paper. The output folder contains index.html, cylinder-rotation.pdf and cylinder-rotation-source.zip. Edit article.html and style.css to revise the text and layout. The build replaces named tokens in the text with tables and numerical statements. The figures are embedded in the generated HTML. To regenerate the elapsed-time chart with Matplotlib, run python -B figure.py before rebuilding. Numerical results are fixed to this edition.

## Results and grouping

aggregate-results.json contains Ruhr stage coverage and aggregate errors from the 24 previously studied people. Keys distinguish all valid windows from those with a strictly earlier donor for the same hand, participant, target, cutoff and split. They also identify either hand, all seven cutoffs, nine targets, the angular-rate or acceleration endpoint and the fitting method. Scores give the participant-equal mean error, each fitted model’s error in seed order (17, 41, 73 for neural models), and the lowest, median and highest participant-equal error. Full-minus-control differences include participant-paired 95% percentile intervals. The orientation section uses degrees and the same weighting. Its future-rate integration is descriptive and unavailable to a forecaster. Study identifiers, data clips and fit weights are unnecessary to rebuild the paper.

gesture-aggregates.json contains only a newly compiled group-level table and contrasts from the separate repeated-gesture study. A positive contrast means the full model missed by more. The original data owners supplied no redistribution licence for the Lowlands recording deposit. This source archive contains no private gesture recordings, labels by individual, fitted parameters, logs or model outputs by recording.

## Rights and provenance

Tim Sziburis, Susanne Blex, Tobias Glasmachers and Ioannis Iossifidis (2025). Ruhr Hand Motion Catalog. Original deposit https://doi.org/10.17605/OSF.IO/J3QC8. Original study https://doi.org/10.1038/s41597-025-05576-7. The paper’s cylinder photograph reproduces Figure 2 at reduced resolution and the target plan reproduces Figure 4. Both are resized for the layout. The figures, Ruhr-derived result tables and new chart carry Creative Commons Attribution 4.0. Modifications to the measurements include selection of trials and windows, construction of mean outcomes, modelling and aggregate scoring. See CC-BY-4.0.txt. Version 1 archive SHA-256 ebcde74b260f4a1e7b57ce0bb626bb6ee0703e6ba75c258267211933da3d8c79.

Jan de Wit, Emiel Krahmer and Paul Vogt (2021). NEMO-Lowlands iconic gesture dataset. Study https://doi.org/10.3758/s13428-020-01487-0, deposit https://osf.io/r59hj/. The original project code and prose in this edition are dedicated under CC0 1.0. See CC0-1.0.txt.
