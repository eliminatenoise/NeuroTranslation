"""Regenerate the two quantitative figures from the edition's aggregate results."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

HERE=Path(__file__).resolve().parent
data=json.loads((HERE/'results.json').read_text())
plt.rcParams.update({'font.family':'Liberation Sans','font.size':9,'svg.fonttype':'none','svg.hashsalt':'two-workspaces-1','axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#26313c','text.color':'#26313c','axes.edgecolor':'#849099','xtick.color':'#46525d','ytick.color':'#46525d'})
teal='#006866';orange='#a54513'
fig,axs=plt.subplots(1,2,figsize=(7.2,2.81),sharey=True)
for ax,limb in zip(axs,('hand','elbow')):
    for key,col,ls,label in [('full',teal,'-','Pose, cues and spikes'),('pose_cue',orange,'--','Pose and cues')]:
        points=data['transfer']['motor'][key][limb]['distance_by_horizon']
        ax.plot(range(10,101,10),points,color=col,linestyle=ls,linewidth=2,label=label)
    ax.set_title(limb.capitalize()+' marker',loc='left',fontweight='bold',fontsize=11)
    ax.grid(axis='y',color='#dce2e4',linewidth=.7)
    ax.set_xlabel('Time from last known pose (ms)')
    ax.set_xticks([10, 30, 50, 70, 100])
    ax.set_ylim(bottom=0)
axs[0].set_ylabel('Mean distance missed (mm)')
fig.legend(*axs[0].get_legend_handles_labels(),loc='lower center',ncols=2,frameon=False,bbox_to_anchor=(.5,0))
fig.subplots_adjust(top=.88,bottom=.32,left=.096,right=.98,wspace=.16)
fig.savefig(HERE/'movement.svg',metadata={'Date':None});plt.close(fig)
fig,ax=plt.subplots(figsize=(7.2,2.4))
for y,(s,k,label) in zip([3,2,1,0],[('within','direct','Same workspace · direct'),('within','wrong','Same workspace · borrowed path'),('transfer','direct','Other workspace · direct'),('transfer','wrong','Other workspace · borrowed path')]):
    entry=data[s]['primary']['count_minus_'+k]
    mean=entry['delta'];low,high=entry['block95'];color=teal if s=='within' else orange
    ax.errorbar(mean,y,xerr=[[mean-low],[high-mean]],fmt='o' if s=='within' else 'D',color=color,capsize=4,linewidth=1.8,markersize=5.8)
ax.axvline(0,color='#59646c',linestyle='--',linewidth=.9)
ax.set_yticks([3,2,1,0],labels=['Same workspace · direct','Same workspace · borrowed path','Other workspace · direct','Other workspace · borrowed path'])
ax.set_ylim(-.6,3.6);ax.set_xlim(-.043,.033)
ax.grid(axis='x',color='#e1e6e7',linewidth=.6)
ax.xaxis.set_major_locator(MaxNLocator(nbins=7));ax.set_xlabel('Predicted-path minus comparator deviance per unit')
fig.subplots_adjust(top=.98,bottom=.25,left=.352,right=.978)
fig.savefig(HERE/'counts.svg',metadata={'Date':None});plt.close(fig)
