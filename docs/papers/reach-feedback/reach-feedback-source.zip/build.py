"""Build the paper offline from its editable text, aggregate tables and figures."""
import argparse
import base64
import hashlib
import html
import json
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

HERE=Path(__file__).resolve().parent
TITLE="Can a forecast of the arm improve a forecast of sensory cortex?"
FILES=("README.md","article.html","style.css","build.py","figures.py","results.json","counts.svg","movement.svg","apparatus.webp","workspaces.webp","workspace-plan.png","CC0-1.0.txt","CC-BY-4.0.txt")
SPLITS=('within','transfer')
def number(x,n=3,sign=False):
    return format(x,('+' if sign else '')+'.'+str(n)+'f').replace('-','−')
def interval(x,n):
    low,high=x['block95']
    return f"{number(x['delta'],n,True)} <span class='limits'>[{number(low,n,True)}, {number(high,n,True)}]</span>"
def table(caption,headers,rows):
    headings=''.join(f'<th scope="col">{h}</th>' for h in headers)
    body=[]
    for name,*fields in rows:
        body.append(f'<tr><th scope="row">{name}</th>'+''.join(f'<td>{x}</td>' for x in fields)+'</tr>')
    return f'<table class="wide"><caption>{caption}</caption><thead><tr>{headings}</tr></thead><tbody>'+''.join(body)+'</tbody></table>'
def picture(name,mime,alt):
    return f'<img alt="{html.escape(alt)}" src="data:image/{mime};base64,'+base64.b64encode((HERE/name).read_bytes()).decode()+'">'
def render():
    r=json.loads((HERE/'results.json').read_text())
    cohort_rows=[('Fitting · workspace 1',198,198,519),('Validation · workspace 1',42,42,113)]
    for split,name in zip(SPLITS,('Later · workspace 1','Transfer · workspace 2')):
        c=r[split]['cohort'];cohort_rows.append((name,c['assigned'],c['represented'],c['eligible']))
    cohort=table('Table 1. Each sequence can contain several eligible go cues.',('Group','Assigned sequences','Represented sequences','Reach windows'),cohort_rows)
    motor=table('Table 2. Endpoint change from adding earlier spikes to pose and cues, with paired 95% intervals. All eligible reaches.',
                ('Endpoint','Later · workspace 1','Transfer · workspace 2'),
                [(label,*(interval(r[s]['primary'][key],3) for s in SPLITS)) for key,label in [('hand','Hand (mm)'),('elbow','Elbow (mm)'),('handle','Handle (cm)')]])
    counts=table('Table 3. Augmented Transformer minus comparator, in total-count deviance per unit [95% interval].',
                 ('Comparator','Later · workspace 1','Transfer · workspace 2'),
                 [(label,*(interval(r[s]['primary']['count_minus_'+key],4) for s in SPLITS)) for key,label in [('direct','Direct history'),('wrong','Borrowed path')]]+
                 [('Matched reaches / sequences',*(f"{r[s]['cohort']['paired']} / {r[s]['cohort']['paired_sequences']}" for s in SPLITS))])
    methods=[('full','Transformer · history + predicted path'),('direct','Transformer · direct history'),('wrong','Transformer · borrowed path'),('pose_cue','Transformer · pose + cues'),('predicted_only','Transformer · predicted path alone'),('glm_direct','GLM · direct history'),('glm_full','GLM · history + predicted path'),('glm_wrong','GLM · borrowed path'),('glm_pose_cue','GLM · pose + cues'),('glm_predicted_only','GLM · predicted path alone'),('train_mean','Training mean'),('ordinal_mean','Training mean by go ordinal'),('persistence','Repeat last 100 ms mean')]
    baseline=table('Table 4. Total-count deviance per unit on matched reaches. Lower values mean closer forecasts.',
                   ('Forecast','Later · workspace 1','Transfer · workspace 2'),
                   [(label,*(number(r[s]['counts'][key]['matched']['total_deviance'],4) for s in SPLITS)) for key,label in methods])
    arch=[]
    for s,short in zip(SPLITS,('Same','Other')):
        for key,name in [('parallel','Parallel'),('recurrent','Hidden state'),('rollout','State + own displacement')]:
            m=r[s]['joint']['metrics'][key]
            arch.append((f'{short} · {name}',*(number(m[k]['mean'],n) for k,n in (('hand_mm_endpoint',3),('elbow_mm_endpoint',3),('count_deviance',4)))))
    joint=table('Table 5. Jointly trained models across all 116 later and 825 transfer windows. Motion scores are endpoint errors.',
                ('Workspace · decoder','Hand (mm)','Elbow (mm)','Count deviance / unit'),arch)
    values={'style':(HERE/'style.css').read_text(),'cohort':cohort,'motor_delta':motor,'count_delta':counts,'count_points':baseline,'joint_points':joint,
            'apparatus':picture('apparatus.webp','webp','Macaque gripping a planar robot handle in front of a screen. Green reflective markers follow the arm in the camera’s view.'),
            'plan':picture('workspace-plan.png','png','Top-down drawing of the arm angled into one of two square target workspaces; shifting the square changes the arm posture.'),
            'movement':picture('movement.svg','svg+xml','Across ten horizons, the two models separate: the full model misses the hand by less and the elbow by more at 100 ms. Values and paired endpoint intervals follow.'),
            'count_chart':picture('counts.svg','svg+xml','Four paired changes in count deviance. The same-workspace interval against borrowed movement lies below zero, and the other-workspace interval against direct history lies above zero. Table 3 gives exact estimates.')}
    page=(HERE/'article.html').read_text()
    for k,v in values.items():
        t='{{'+k+'}}';assert page.count(t)==1,k
        page=page.replace(t,v)
    assert not re.search(r'\{\{[a-z_]+\}\}',page)
    return page

def build(out):
    from pypdf import PdfReader,PdfWriter
    from pypdf.generic import ArrayObject, ByteStringObject
    out.mkdir(exist_ok=True,parents=True)
    page=render();(out/'index.html').write_text(page)
    archive=out/'reach-feedback-source.zip'
    offline = re.sub(r'<a download href="[^"]+">[^<]+</a>', '', page)
    members = {name: (HERE/name).read_bytes() for name in FILES}
    members['read.html'] = offline.encode('utf-8')
    with ZipFile(archive,'w') as z:
        for name, contents in members.items():
            item=ZipInfo(name,(2026,11,21,0,0,0));item.create_system=3;item.external_attr=0o100644<<16
            z.writestr(item,contents,compress_type=ZIP_DEFLATED)
    browser=shutil.which('chromium') or shutil.which('google-chrome')
    if not browser:raise RuntimeError('Install Chromium or Google Chrome to build the printable edition.')
    with tempfile.TemporaryDirectory(dir=out) as path:
        temp=Path(path); html_file=temp/'article.html'; html_file.write_text(page)
        plain=temp/'printed.pdf'
        subprocess.run([browser,'--headless','--disable-gpu','--disable-background-networking','--no-pdf-header-footer',
                        f'--user-data-dir={temp/"profile"}',f'--print-to-pdf={plain}',html_file.resolve().as_uri()],
                       check=True,capture_output=True,timeout=90)
        writer=PdfWriter(clone_from=PdfReader(plain))
        writer.metadata={'/Title':TITLE,'/Author':'NeuroTranslation','/Subject':'Forecasting recorded arm movement and later area 2 spike counts'}
        writer.add_attachment(archive.name,archive.read_bytes())
        identity=ByteStringObject(hashlib.sha256(archive.read_bytes()).digest()[:16]);writer._ID=ArrayObject([identity,identity])
        writer.write(out/'reach-feedback.pdf')
if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__);cli.add_argument('--out',type=Path,default=HERE/'output');build(cli.parse_args().out)
