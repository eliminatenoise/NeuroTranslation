# Can a forecast of the arm improve a forecast of sensory cortex?

NeuroTranslation experimental supplement, 21 November 2026. The HTML and printable PDF contain the same paper. The HTML embeds its figures and the PDF carries this editable source ZIP as an attachment. To read immediately after extraction, open read.html in a browser. It includes all figures and tables. Only the references and external study viewers need internet access.

## Rebuild the paper

Extract this ZIP and open a terminal in the extracted folder. Use Python 3.11 or newer with pypdf, Chromium or Google Chrome and Liberation Sans installed. Run:

    python -B build.py

Open output/index.html to read offline. The PDF and editable source ZIP are beside it. Edit article.html for the prose, style.css for the layout, and build.py for the table definitions. The layout uses system sans-serif fallbacks. Numerical tables are built from results.json. The included final SVG figures need no plotting libraries to rebuild the document. To recreate the plots after editing the results, install Matplotlib with Liberation Sans available and run:

    python -B figures.py
    python -B build.py

Each workspace record in results.json includes all main motor model errors, count scores on all and matched reaches, paired differences, both joint-model comparisons, seed-specific primary differences and the sensitivity analysis that resampled sequences individually. The wrong and glm_wrong keys under counts describe donor-supported reaches in either population. Values refer to errors averaged over individual seeds after computing their losses, with sequences weighted equally. See the paper for the direction, units and time windows of each contrast. The seed-averaged, chronological-block intervals are the primary intervals.

## Study and source materials

Chowdhury RH, Glaser JI, Miller LE (2020). Area 2 of primary somatosensory cortex encodes kinematics of the whole arm. eLife 9:e48198. https://doi.org/10.7554/eLife.48198

The published apparatus artwork (Figure 2) and workspace illustration (Figure 3A) are by the original authors under CC BY 4.0. The workspace illustration is a crop of the complete, resized Figure 3, included as workspaces.webp. The pixel crop in that file has width 346, height 244, x = 5 and y = 0. Both original illustrations were resized and encoded in WebP. All other figures show the present reanalysis. CC-BY-4.0.txt contains the illustration licence.

The released recordings are under CC0. Data deposit https://doi.org/10.5061/dryad.nk98sf7q7. Selected MATLAB member (211,140,370 bytes): reaching_experiments/C_20170907_TRT_TD.mat. SHA-256: 6062b7e8dacdf46f7eee465bd844ffe1fb3b7ce0793c34d3e4d106be357f4746. This analysis used one recorded animal, one day and two interleaved workspaces. New results, paper, code and plots are dedicated under CC0 1.0. See CC0-1.0.txt.

Reproduce the scientific analysis with the study materials at https://eliminatenoise.github.io/NeuroTranslation/reach-feedback/. The offline paper build only recreates the editions of the manuscript. Inspect the measurements and forecasts interactively at https://eliminatenoise.github.io/Interoceptomics/reach-feedback/.
