"""Plot the published numerical results. No network access or model fitting."""
import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt

HERE = Path(__file__).resolve().parent
DATA = json.loads((HERE / "results.json").read_text())
GREEN = "#00665e"
RUST = "#964b29"
INK = "#172e39"
plt.rcParams.update({"font.family":"Liberation Sans", "font.size":10, "axes.spines.top":False, "axes.spines.right":False,
                    "axes.labelcolor":INK, "xtick.color":INK, "ytick.color":INK, "svg.fonttype":"none","svg.hashsalt":"one-week-reach"})

def save(fig, name):
    fig.savefig(HERE / name, bbox_inches="tight", pad_inches=.12, metadata={"Date":None})
    plt.close(fig)

def count_plot():
    f,ax = plt.subplots(figsize=(6.75,2.1))
    ys = [3.1,2.15,.95,0]
    labels = []
    for y,(ws,control) in zip(ys,[("1","base"),("2","base"),("1","wrong_motion"),("2","wrong_motion")]):
        mean,lo,hi = DATA["workspaces"][ws]["count_scores"]["primary"]["update_minus_" + control]
        color = GREEN if ws=="1" else RUST
        ax.errorbar(mean,y,xerr=[[mean-lo],[hi-mean]],fmt="o" if ws=="1" else "s",color=color,capsize=3.8,lw=2.1)
        labels.append("Workspace " + ws + (" · earlier forecast" if control=="base" else " · borrowed movement"))
    ax.axvline(0,color=INK,lw=1); ax.set_yticks(ys,labels)
    ax.set_xlim(-1.52,.29); ax.set_ylim(-.65,3.72); ax.set_xticks([-1.5,-1,-.5,0])
    ax.set_xlabel("Measured update minus comparator (count deviance per contact)")
    ax.spines['left'].set_visible(False);ax.tick_params(axis="y",length=0)
    save(f,"count-differences.svg")

def hand_plot():
    f,axes=plt.subplots(1,2,sharey=True,figsize=(7.1,2.5))
    for w,ax in zip(("1","2"),axes):
        d=DATA["examples"][w]["hand_excursion_mm"]
        for k,label,color,style in [("movement","Recorded hand",INK,"-"),("full","Count-informed",GREEN,"--"),("pose","Pose + cue",RUST,":")]:
            ax.plot(range(0,101,10),[0,*d[k]],style,color=color,lw=2.2,label=label)
        ax.set_title("Workspace " + w,fontsize=11,loc="left",weight="bold");ax.set_xlabel("Time from last position (ms)")
        ax.set_xticks([0,50,100]);ax.grid(axis="y",color="#d7dedc",lw=.7);ax.set_ylim(-.5,16)
    axes[0].set_ylabel("Distance from start (mm)"); axes[0].set_yticks([0,5,10,15])
    f.legend(*axes[0].get_legend_handles_labels(),loc="lower center",ncol=3,frameon=False,bbox_to_anchor=(.5,-.09))
    f.subplots_adjust(bottom=.25,wspace=.23);save(f,"two-hands.svg")

def length_plot():
    f,axes=plt.subplots(1,2,sharex=True,sharey=True,figsize=(6.85,2.35))
    rows=[("stationary","No change"),("direct","History directly to length"),("full","Count-informed arm"),("measured_path","Observed arm, after the fact")]
    for w,ax in zip(("1","2"),axes):
        for y,(k,_) in enumerate(rows):
            mu,lo,hi=DATA["workspaces"][w]["path_scores"][k]["endpoint"]
            ax.errorbar(mu,3-y,xerr=[[mu-lo],[hi-mu]],fmt="o",capsize=3.5,lw=1.8,color=GREEN if k=="stationary" else INK)
        ax.set_yticks([3,2,1,0],[label for _,label in rows]);ax.set_ylim(-.6,3.6)
        ax.set_xlim(0,2.2);ax.set_xticks([0,.5,1,1.5,2]);ax.set_xlabel("Endpoint error (mm)")
        ax.set_title("Workspace "+w,loc="left",fontsize=11,weight="bold");ax.grid(axis="x",color="#d7dedc",lw=.7)
        ax.tick_params(axis="y",length=0);ax.spines['left'].set_visible(False)
    f.subplots_adjust(wspace=.12);save(f,"path-lengths.svg")

if __name__=="__main__":
    count_plot();hand_plot();length_plot()
