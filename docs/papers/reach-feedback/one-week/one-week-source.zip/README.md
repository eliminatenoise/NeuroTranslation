# A week later, does seeing the arm improve a forecast of the brain?

Open read.html to read the paper offline, including tables, figures and numerical examples. The external studies and online models require an internet connection. The PDF contains this editable ZIP as an attachment.

## Rebuild the editions

Install Python 3.11 or later with pypdf (tested with 6.21.2), Chromium or Google Chrome, and Liberation Sans. Run from the extracted folder:

    python -B build.py

The output directory contains index.html, one-week.pdf, and one-week-source.zip. No model fitting, external data download, fonts from the web or network connection is needed for this build. Edit article.html for the manuscript, style.css for the layout, and build.py for table definitions. The finished SVG plots are included. To regenerate them from results.json with Matplotlib installed and Liberation Sans available:

    python -B figures.py
    python -B build.py

## Read the numbers

Each three-number array in count_scores, motor_scores (except seed_range) and path_scores gives the unrounded point estimate, lower 2.5th percentile and upper 97.5th percentile of 5,000 moving-block bootstrap estimates. W1 and W2 mean workspace 1 and 2. Estimate and uncertainty come from the same later-day sequences. Regional mean trajectory errors average ten horizons. Endpoint errors measure the last horizon. Paired names give the left method minus the right. Under recent_common, recent_equal, recent_growing and recent_shrinking the count score comes from the separate late-spike study on the named positive-sort contact population. There is one contact each in the growing and shrinking categories. Inspect methods.md for fitting and control definitions. The source data retain full numerical precision. Tables in the paper round results to three decimals.

Figure 2 uses the aggregate paired cortical-count comparisons. Figure 3 uses the first donor-supported recorded hand trajectory in each workspace and its corresponding forecasts. No reach was selected for how well a model performed. Figure 4 gives aggregate held-day path-length errors. Each plot can be redrawn from results.json.

## Data and image credits

Raeed H. Chowdhury, Joshua I. Glaser and Lee E. Miller (2020), “Area 2 of primary somatosensory cortex encodes kinematics of the whole arm,” eLife 9, e48198. Original article and biological experiment: https://doi.org/10.7554/eLife.48198

The apparatus image is their figure 2, resized and converted to WebP. The workspace image is a crop of their figure 3A, taken from a resized image of figure 3 (346 × 244 pixels starting at x=5, y=0). These two illustrations retain CC BY 4.0. See CC-BY-4.0.txt. Further adaptation should retain creator credit and identify changes.

The authors' Dryad data carry CC0 1.0: https://doi.org/10.5061/dryad.nk98sf7q7. Selected MATLAB members C_20170907_TRT_TD.mat and C_20170914_TRT_TD.mat have SHA-256 identifiers 6062b7e8dacdf46f7eee465bd844ffe1fb3b7ce0793c34d3e4d106be357f4746 and 4456c7bf8cda177f31c849e3fe794100269ca951c741c1718dd5c750d5432a76. The recording authors did not create the new models. New text, aggregate results, plots and paper-building code are released under CC0 1.0 to the extent of project rights. See CC0-1.0.txt.

## Run the scientific comparison

The paper rebuild regenerates the publication from the fixed aggregate evidence. The recording reconstruction and fitted models are available at https://eliminatenoise.github.io/NeuroTranslation/reach-feedback/one-week/. Individual modeled paths can be inspected at https://eliminatenoise.github.io/NeuroTranslation/reach-feedback/one-week/muscle-paths/. Recorded arm movement and cortical forecasts can be explored at https://eliminatenoise.github.io/Interoceptomics/reach-feedback/one-week/.
