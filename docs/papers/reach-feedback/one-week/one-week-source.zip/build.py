"""Build an offline manuscript, source ZIP and PDF with editable source attached."""
import argparse
import base64
import hashlib
import html
import json
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

HERE = Path(__file__).resolve().parent
TITLE = "A week later, does seeing the arm improve a forecast of the brain?"
FILES = ("README.md", "methods.md", "article.html", "style.css", "build.py", "figures.py", "results.json",
         "apparatus.webp", "workspace-plan.png", "count-differences.svg", "two-hands.svg", "path-lengths.svg",
         "CC0-1.0.txt", "CC-BY-4.0.txt")
REGIONS = {"hand_mm":"Hand (mm)", "elbow_mm":"Elbow (mm)", "handle_cm":"Handle (cm)"}
MOVE = {"full":"Count-informed correction", "pose":"Pose + cue correction", "wrong":"Borrowed counts",
        "ridge_full":"Linear · count-informed", "ridge_pose":"Linear · pose + cue", "ridge_wrong":"Linear · borrowed counts",
        "frozen":"Original Transformer", "velocity":"Continue recent velocity", "stationary":"Stay at last position"}
PATH = {k: MOVE[k] for k in ("full","pose","wrong","ridge_full","ridge_pose","frozen","velocity")}
PATH.update(stationary="No change", direct="History directly to length", measured_path="Measured arm, retrospective")

def number(x):
    return f"{x:.3f}".replace("-", "−")

def cell(values):
    estimate,lo,hi = values
    return f'{number(estimate)} <span class="limits">[{number(lo)}, {number(hi)}]</span>'

def table(caption, headings, rows):
    headers = ''.join(f'<th scope="col">{h}</th>' for h in headings)
    body = ''.join('<tr><th scope="row">'+row[0]+'</th>'+''.join(f'<td>{v}</td>' for v in row[1:])+'</tr>' for row in rows)
    return f'<div class="tablebox" tabindex="0" role="region" aria-label="{html.escape(caption)}"><table><caption>{caption}</caption><thead><tr>{headers}</tr></thead><tbody>{body}</tbody></table></div>'

def picture(name, mime, alt):
    data = base64.b64encode((HERE/name).read_bytes()).decode()
    return f'<img alt="{html.escape(alt)}" src="data:image/{mime};base64,{data}">'

def compose():
    ws=json.loads((HERE/"results.json").read_text())["workspaces"]
    data={"style":(HERE/"style.css").read_text()}
    imgs = [("apparatus","apparatus.webp","webp","Published diagram of a macaque grasping a planar handle while a camera tracks arm markers."),
            ("plan","workspace-plan.png","png","Two square target areas on opposite sides of the reaching apparatus, with the arm in different postures."),
            ("forest","count-differences.svg","svg+xml","Update minus earlier forecast falls below zero in workspace 1 and above zero in workspace 2. Both intervals comparing the update with borrowed movement fall below zero. Table 2 gives the values."),
            ("hand","two-hands.svg","svg+xml","The recorded hand moved 1.88 mm from its start in workspace 1 and 14.45 mm in workspace 2 over 100 milliseconds. Both forecasts overshoot in the first example and undershoot in the second."),
            ("lengthchart","path-lengths.svg","svg+xml","No change has the lowest point error in both workspaces. History directly to length comes next among the four shown. Table 12 gives values for all ten methods.")]
    for token,name,mime,alt in imgs: data[token]=picture(name,mime,alt)

    cohort=[]
    for w in ws:
        for b,d in ws[w]["blocks"].items():
            cohort.append([f'{w} · {b}', d["assigned_originals"],d["rewarded_originals"],f'{d["metadata"]["windows"]} / {d["metadata"]["originals"]}',f'{d["matched"]["windows"]} / {d["matched"]["originals"]}'])
    data["cohort"]=table("Table 1. September 14 support. The last two columns show windows / sequences.",
        ("Workspace · block","Assigned sequences","Rewarded sequences","Eligible","Matched"),cohort)
    def counts(pop, methods):
        return [[label,*(cell(ws[w]["count_scores"][pop][k]) for w in ws)] for k,label in methods.items()]

    direct={"update":"Measured movement update","base":"Earlier forecast","wrong_motion":"Borrowed movement","train_mean":"Always predict the training mean","known_at_k_100ms":"Repeat pre-cutoff 100-ms count","previous_late_100ms":"Repeat intervening 100-ms count","update_minus_base":"Update minus earlier forecast","update_minus_wrong_motion":"Update minus borrowed movement"}
    columns=("Forecast or paired difference","Workspace 1","Workspace 2")
    data["primary"]=table("Table 2. Mean count deviance per contact per 100 ms [95% interval].",columns,counts("primary",direct))
    simpler = {"update":"Update","base":"Earlier","wrong_motion":"Borrowed","train_mean":"Training mean","update_minus_base":"Update minus earlier","update_minus_wrong_motion":"Update minus borrowed"}
    data["sens"]="".join(table(f"Table {n}. {label}. Count deviance per contact [95% interval].",columns,counts(pop,simpler)) for n,pop,label in [(3,"zero","Only unassigned events on the 37 contacts"),(4,"positive","Only positively sorted events on 17 contacts")])
    late={"measured_update":"Recent spikes + measured positions","stale_position":"Recent spikes + earlier position","wrong_donor":"Recent spikes + borrowed movement","earlier":"Pre-cutoff spikes + earlier position","movement_only":"Measured positions without spikes","zero_displacement":"Recent spikes + zero movement","previous_100ms":"Repeat intervening count","pre_k_100ms":"Repeat pre-cutoff count","train_mean":"Always predict the training mean","measured_minus_stale":"Update minus earlier position","measured_minus_donor":"Update minus borrowed movement","measured_minus_zero_displacement":"Update minus zero movement"}
    data["late"]=table("Table 5. Positive-sort count deviance per contact [95% interval].",columns,counts("recent_common",late))
    contrasts=[]
    for w in ws:
        for k,label in REGIONS.items():
            m=ws[w]["motor_scores"][k]
            contrasts.append([w+" · "+label,cell(m["full_minus_pose"]["trajectory"]),cell(m["full_minus_wrong"]["trajectory"])])
    data["motorcontrast"]=table("Table 6. Change in mean trajectory error [95% interval]. Negative favours using spikes from the same reach.",
                           ("Workspace · position","Count-informed minus pose + cue","Count-informed minus borrowed counts"),contrasts)
    for w in ws:
        views=[]
        for t,label in (("trajectory","Ten-sample trajectory error"),("endpoint","Endpoint error at 100 ms")):
            n=7+(int(w)-1)*2+int(t=="endpoint")
            rows=[[name,*(cell(ws[w]["motor_scores"][k][key][t]) for k in REGIONS)] for key,name in MOVE.items()]
            views.append(table(f"Table {n}. {label} [95% interval], workspace {w}.",("Forecast",*REGIONS.values()),rows))
        paired_rows=[[kind,*(cell(ws[w]["motor_scores"][k][name]["endpoint"]) for k in REGIONS)] for name,kind in (("full_minus_pose","Count-informed minus pose"),("full_minus_wrong","Count-informed minus borrowed"))]
        views.append(table(f"Paired endpoint differences [95% interval], workspace {w}.",("Comparison",*REGIONS.values()),paired_rows))
        data["motor_w"+w]="".join(views)
    paired=[["Count-informed minus "+label,*(cell(ws[w]["path_scores"][key]["endpoint"]) for w in ws)] for key,label in [("full_minus_pose","pose + cue"),("full_minus_wrong","borrowed counts")]]
    data["pathpaired"]=table("Table 11. Paired change in endpoint error (mm) across 39 paths [95% interval].",columns,paired)
    path_rows=[[name,*(cell(ws[w]["path_scores"][key][t]) for w in ws for t in ("trajectory","endpoint"))] for key,name in PATH.items()]
    data["pathabs"]=table("Table 12. Path-length change error (mm) [95% interval].",("Forecast","W1 trajectory","W1 endpoint","W2 trajectory","W2 endpoint"),path_rows)
    text=(HERE/"article.html").read_text()
    expected=set(re.findall(r"\{\{(\w+)\}\}",text))
    if expected!=set(data): raise ValueError(f"Template mismatch {expected ^ set(data)}")
    return re.sub(r"\{\{(\w+)\}\}", lambda match:data[match[1]], text)

def build(out):
    from pypdf import PdfReader, PdfWriter
    from pypdf.generic import ArrayObject, ByteStringObject
    out.mkdir(parents=True, exist_ok=True)
    page=compose()
    (out/"index.html").write_text(page)
    archive=out/"one-week-source.zip"
    members={name:(HERE/name).read_bytes() for name in FILES}
    members["read.html"]=re.sub(r'<a download href="[^"]+">[^<]+</a>', '',page).encode()
    with ZipFile(archive,"w") as z:
        for name,data in members.items():
            entry=ZipInfo(name,(2026,11,21,0,0,0))
            entry.create_system=3; entry.external_attr=0o100644<<16
            z.writestr(entry,data,compress_type=ZIP_DEFLATED)
    browser=shutil.which("chromium") or shutil.which("google-chrome")
    if not browser: raise SystemExit("Chromium or Google Chrome is needed to print the PDF.")
    with tempfile.TemporaryDirectory(dir=out) as tmp:
        tmp=Path(tmp); h=tmp/"index.html"; h.write_text(page); printed=tmp/"printed.pdf"
        subprocess.run([browser,"--headless","--disable-gpu","--disable-background-networking","--no-pdf-header-footer",
                        f"--user-data-dir={tmp/'profile'}", f"--print-to-pdf={printed}",h.resolve().as_uri()],
                       capture_output=True,check=True,timeout=90)
        writer=PdfWriter(clone_from=PdfReader(printed))
        writer.metadata={"/Title":TITLE,"/Author":"NeuroTranslation","/Subject":"One-week transfer of reach and cortical-count forecasts"}
        writer.add_attachment(archive.name,archive.read_bytes())
        ident=ByteStringObject(hashlib.sha256(archive.read_bytes()).digest()[:16])
        writer._ID=ArrayObject([ident,ident])
        writer.write(out/"one-week.pdf")

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out",type=Path,default=HERE/"output")
    build(parser.parse_args().out.resolve())
