"""Build the reader, editable archive and matched research PDF. All inputs are included."""
import argparse
import base64
import hashlib
import json
import shutil
import subprocess
import tempfile
from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED

HERE=Path(__file__).resolve().parent
TITLE='The same electrodes, one day later'
BASE='https://eliminatenoise.github.io/NeuroTranslation/papers/contact-forecast/'
GROUPS={'pre_target_bump':'Push, before the cue','post_bump_go':'Reach cue after a push','unbumped_go':'Reach cue without a push'}
def signed(n):return f'{n:+.4f}'.replace('-','−')
def effect(group,control):return group['contrasts']['transformer_all-minus-transformer_'+control]['deviance']
def pretty(record):
    lo,hi=record['interval']
    return f'{signed(record["estimate"])} [{signed(lo)}, {signed(hi)}]'
def table(caption,head,rows):
    header=''.join(f'<th scope="col">{v}</th>' for v in head)
    body=''.join('<tr>'+f'<th scope="row">{r[0]}</th>'+''.join(f'<td>{v}</td>' for v in r[1:])+'</tr>' for r in rows)
    return f'<div class="wrap"><table><caption>{caption}</caption><thead><tr>{header}</tr></thead><tbody>{body}</tbody></table></div>'

def render():
    data=json.loads((HERE/'results.json').read_text())
    test,val,part=data['test'],data['validation'],data['components']
    pure=test['phases']['pre_target_bump']
    group=pure['matched']
    a,b=effect(group,'count_cue'),effect(group,'wrong_movement')
    both=test['primary']['passed']
    conclusion= ('Both paired intervals favored the full model.' if both else 'The two comparisons did not jointly meet the prespecified criterion for a movement benefit.')
    claims=(f"On {group['windows']:,} matched windows from {group['originals']:,} second-day push trials, the model given movement, counts and cues had mean deviance {group['scores']['transformer_all']['deviance']['estimate']:.4f} per contact. Counts and cues alone gave {group['scores']['transformer_count_cue']['deviance']['estimate']:.4f}. Replacing the recorded movement with movement from an earlier matched trial gave {group['scores']['transformer_wrong_movement']['deviance']['estimate']:.4f}. {conclusion}")
    counts='The post-check totals were '+', '.join(f"{p['support']['eligible_windows']:,} windows for {label}" for p,label in [(pure,'the pre-target push'),(test['phases']['post_bump_go'],'a reach cue after a push'),(test['phases']['unbumped_go'],'a reach cue without a push')])+'.'
    values=[]
    for name,phase in [('Same-day push',val['phases']['pre_target_bump']),*[(label,test['phases'][key]) for key,label in GROUPS.items()]]:
        g=phase['matched']
        values.append([name,f"{g['originals']:,} / {g['windows']:,}",pretty(effect(g,'count_cue')),pretty(effect(g,'wrong_movement'))])
    tbl=table('Table 1. Paired error differences and 95% intervals.', ['Time and event','Trials / windows','Full minus counts and cues','Full minus wrong movement'],values)
    valid=val['phases']['pre_target_bump']['matched']
    sec=(f"On the September 12 validation push trials, the difference against counts and cues was {pretty(effect(valid,'count_cue'))}. On September 13 the corresponding difference was {pretty(a)}. Against the wrong-movement control it was {pretty(b)} on September 13. All differences are full model minus the stated comparison.")
    methods=[('training_mean','First-day mean'),('persistence','Previous 100-ms count'),('poisson_cue','Count regression · cues only'),('poisson_count_cue','Count regression · counts and cues'),('poisson_all','Count regression · full'),('transformer_count','Transformer · previous counts'),('transformer_movement','Transformer · movement'),('transformer_count_cue','Transformer · counts and cues'),('transformer_all','Transformer · full')]
    rows=[[label,*(f'{group["scores"][key][metric]["estimate"]:.3f}' for metric in ('mae','deviance','predicted_mean'))] for key,label in methods]
    offset_table=table('Table 2. How the push comparison changes with time.', ['After the push','Windows','Full minus counts and cues','Full minus wrong movement'], [[key+' ms',str(v['windows']),pretty(v['transformer_all-minus-transformer_count_cue']),pretty(v['transformer_all-minus-transformer_wrong_movement'])] for key,v in sorted(data['offset_ms'].items(),key=lambda item:int(item[0]))])
    models=table('Table 3. Forecasts on matched second-day push trials.', ['Model or baseline','Absolute error','Deviance','Expected count'], rows)
    decomp=part['groups']['bump_matched']['models']
    full=decomp['transformer_all']['mean'];prior=decomp['transformer_count_cue']['mean']
    breakdown=(f'The measured mean was {group["scores"]["transformer_all"]["observed_mean"]["estimate"]:.3f} events per contact per 100 milliseconds. We also split the deviance into error in the total across the electrodes and error in how that total was distributed. Adding movement changed the total-count component by {signed(full[1]-prior[1])} and the distribution component by {signed(full[2]-prior[2])} per contact. Together they give the paired change of {signed(a["estimate"])}.')
    cue=group['scores']['poisson_cue']['deviance']['estimate']
    mae=group['contrasts']['transformer_all-minus-transformer_count_cue']['mae']
    best=min(group['scores'],key=lambda k:group['scores'][k]['deviance']['estimate'])
    assert best=='poisson_cue'
    breakdown+=(f' The cue-only count regression had the lowest measured deviance ({cue:.3f}). The full Transformer missed by {mae["estimate"]:.4f} more events per contact on average than the counts-and-cues Transformer (95% interval {mae["interval"][0]:.4f} to {mae["interval"][1]:.4f}).')
    svg=(HERE/'effects.svg').read_bytes()
    chart='<img class="forest" alt="Four paired effects for pushes on the two dates. The full numerical intervals appear in Table 1." src="data:image/svg+xml;base64,'+base64.b64encode(svg).decode()+'">'
    text=(HERE/'article.html').read_text()
    for token,value in {'STYLE_HERE':(HERE/'style.css').read_text(),'ABSTRACT_RESULT':claims,'FIG_PRIMARY':chart,'DAY2_COUNTS':counts,'TABLE_EFFECTS':tbl,'OFFSET_TABLE':offset_table,'SECONDARY_RESULTS':sec,'TABLE_MODELS':models,'BREAKDOWN':breakdown}.items():
        assert text.count(token)==1
        text=text.replace(token,value)
    return text

def build(out,html_only):
    out.mkdir(exist_ok=True,parents=True)
    html=render()
    (out/'index.html').write_text(html)
    archive=out/'contact-forecast-source.zip'
    with ZipFile(archive,'w') as z:
        for n in ('article.html','style.css','results.json','effects.svg','figure.py','build.py','README.md','CC0-1.0.txt'):
            info=ZipInfo(n,date_time=(2026,11,21,0,0,0));info.create_system=3;info.external_attr=0o100644<<16
            z.writestr(info,(HERE/n).read_bytes(),compress_type=ZIP_DEFLATED)
    if html_only:return
    from pypdf import PdfWriter,PdfReader
    from pypdf.generic import ByteStringObject,ArrayObject
    with tempfile.TemporaryDirectory() as tmp:
        tmp=Path(tmp);page=tmp/'print.html';pdf=tmp/'print.pdf'
        page.write_text(html.replace('href="contact-forecast.pdf"',f'href="{BASE}contact-forecast.pdf"').replace('href="contact-forecast-source.zip"',f'href="{BASE}contact-forecast-source.zip"'))
        browser=shutil.which('chromium') or shutil.which('google-chrome')
        if not browser:raise RuntimeError('Install Chromium or use --html-only.')
        subprocess.run([browser,'--headless','--disable-gpu','--disable-background-networking','--no-pdf-header-footer',f'--user-data-dir={tmp/"profile"}',f'--print-to-pdf={pdf}',page.as_uri()],check=True,capture_output=True,timeout=90)
        writer=PdfWriter(clone_from=PdfReader(pdf));writer.metadata={'/Title':TITLE,'/Author':'NeuroTranslation','/Subject':'Held-day count forecasts from one macaque at shared sensory-cortex contacts'}
        writer.add_attachment(archive.name,archive.read_bytes())
        key=ByteStringObject(hashlib.sha256(archive.read_bytes()).digest()[:16]);writer._ID=ArrayObject([key,key])
        writer.write(out/'contact-forecast.pdf')
if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__);cli.add_argument('--out',type=Path,default=HERE/'output');cli.add_argument('--html-only',action='store_true');args=cli.parse_args();build(args.out,args.html_only)
