"""Plot the prespecified paired effects, using the supplied validated tables."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
here=Path(__file__).resolve().parent
data=json.loads((here/'results.json').read_bytes())
matplotlib.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'path','svg.hashsalt':'ContactForecast20261121','font.size':10})
fig,ax=plt.subplots(figsize=(7.0,2.65),layout='constrained')
labels=[];span=[]
for i,(d,m) in enumerate([('validation','count_cue'),('validation','wrong_movement'),('test','count_cue'),('test','wrong_movement')]):
    z=data[d]['phases']['pre_target_bump']['matched']['contrasts']['transformer_all-minus-transformer_'+m]['deviance']
    x=z['estimate'];lo,hi=z['interval'];y=3-i;span.extend((lo,hi))
    color='#30715d' if d=='test' else '#67747d'
    ax.plot([lo,hi],[y,y],lw=2,color=color)
    ax.plot(x,y,'o',color=color,markersize=6)
    labels.append(('Same day' if d=='validation' else 'Next day')+' · '+('counts and cues' if m=='count_cue' else 'wrong movement'))
ax.set_yticks(range(3,-1,-1),labels);ax.set_ylim(-.65,3.65);ax.axvline(0,color='#24332d',lw=.8,ls='--')
ax.set_xlabel('Full model minus comparison · Poisson deviance per contact',fontsize=9)
ax.grid(axis='x',alpha=.15);ax.spines[['top','right','left']].set_visible(False);ax.tick_params(axis='y',length=0,pad=6)
fig.savefig(here/'effects.svg',format='svg',metadata={'Date':None})
