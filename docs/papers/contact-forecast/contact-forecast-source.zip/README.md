# The same electrodes, one day later

This editable report describes a test in one macaque across two recorded dates. The table file contains the original numerical scores for both dates and the total-count versus electrode-allocation breakdown. The figure and tables use the same paired estimates.

Use Python 3.10 or newer. To build the HTML article and complete editable archive without a browser, run `python build.py --html-only`. To also create the PDF, install pypdf and Chromium, then run `python build.py`. The default output folder is output. The supplied SVG is ready for export. To regenerate it with Matplotlib, use `python figure.py` before building. The complete source ZIP is also embedded in the PDF.

Original research and data are credited in the article. The project text, plots and source code are released under CC0-1.0. The primary endpoint measures exported event counts in 100 milliseconds. The outcome does not identify individual neurons across the two days.
