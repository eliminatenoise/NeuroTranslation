"""Build the four-page supplement, its source archive and a standalone PDF."""
import argparse
import base64
from html import escape
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parent
FILES = (
    "README.md", "build.py", "paper.html.in", "elbow/SOURCE.md", "CC-BY-4.0.txt", "CC0-1.0.txt",
    "elbow/scores.json", "elbow/protocol.json", "elbow/fit.py", "elbow/infer.py",
    "elbow/check_rebuild.py", "elbow/model.json", "elbow/ofner_source.py", "elbow/codebook.json",
    "verify_arm.py", "arm/predict.py", "arm/cued_arm.py", "arm/cued-arm/study.py", "arm/cued-arm/ofner_source.py",
    "arm/cued-arm/codebook.json", "arm/cued-arm/PROTOCOL.md", "arm/cued-arm/results.json",
)
ELBOW = [
    ("persistence", "No change"), ("cue_median", "Cue median"), ("cue_mechanics", "Cue + elbow"),
    ("cue_mechanics_c3", "Add scalp C3"), ("cue_mechanics_eog", "Use eyes instead"),
    ("shifted_c3", "Give C3 the wrong trial"), ("temporal_attention", "Pool C3 with fixed attention"),
]
ARM = [
    ("cue", "Cue alone"), ("still", "No change"), ("motion", "History alone, linear"),
    ("cue_motion", "Cue + history, linear"), ("shuffled_cue_motion", "Cue + history, shuffled encoder"),
    ("shared_cue_motion", "Cue + history, shared encoder"), ("shared_motion", "Shared encoder, no cue"),
    ("wrong_cue", "Shared encoder, wrong cue"),
]


def chart(labels, values, maximum, digits, title, unit, ticks, accent):
    """Numeric labels accompany every zero-based bar, including for screen readers."""
    rows = []
    for key, label in labels:
        value = values[key]
        width = 100 * value / maximum
        color = " focus" if key in accent else ""
        rows.append(f'<div class="bar-row{color}"><span>{escape(label)}</span>'
                    f'<span class="track" aria-hidden="true"><i style="width:{width:.5f}%"></i></span>'
                    f'<b>{value:.{digits}f}</b></div>')
    tick_labels = "".join(f'<span>{tick}</span>' for tick in ticks)
    return (f'<figure><h3>{title}</h3><p class="unit">{unit}</p><div class="bars">'
            + "".join(rows) + f'<div class="bar-axis" aria-hidden="true"><span></span>'
            f'<div>{tick_labels}</div><span></span></div></div></figure>')


def tbody(rows):
    return "".join('<tr><th scope="row">' + escape(label) + '</th>'
                   + "".join(f"<td>{cell}</td>" for cell in cells) + '</tr>' for label, cells in rows)


def render_html(out):
    elbow = json.loads((ROOT/"elbow/scores.json").read_text())
    arm = json.loads((ROOT/"arm/cued-arm/results.json").read_text())
    native = arm["native_mae_by_horizon_and_sensor"]
    native_rows = []
    for col, name in enumerate(["Elbow", "Forearm rotation", "Index finger"]):
        for key, model in [("cue", "cue alone"), ("shared_cue_motion", "shared + cue")]:
            native_rows.append((f"{name} · {model}", [f"{native[key][h][col]:.5f}" for h in range(3)]))
    run_rows = []
    for fold in arm["held_runs"]:
        scores = fold["balanced_standardized_mae"]
        run_rows.append((f"Run {fold['run']} (42)", [f"{scores[key]:.3f}" for key in
                         ("still","cue","shared_cue_motion","shared_motion","wrong_cue")]))
    fields = {
        "ELBOW_CHART": chart(ELBOW, elbow["balanced_mae"], .1, 5, "Mean error in the elbow forecast",
                             "Native elbow-sensor units · smaller is closer", ("0", "0.05", "0.10"),
                             {"cue_mechanics","cue_mechanics_c3"}),
        "ARM_CHART": chart(ARM, arm["balanced_standardized_mae"], 1, 5, "Mean error across the nine targets",
                           "Fitting-set standard deviations · smaller is closer", ("0", "0.5", "1.0"),
                           {"cue","shared_cue_motion"}),
        "RUN_ROWS": tbody(run_rows), "NATIVE_ROWS": tbody(native_rows),
        "LICENCE": base64.b64encode((ROOT/"CC-BY-4.0.txt").read_bytes()).decode(),
    }
    html = (ROOT/"paper.html.in").read_text(encoding="utf-8")
    for key, value in fields.items():
        html = html.replace("{{"+key+"}}", value)
    if "{{" in html:
        raise ValueError("Template has unresolved fields")
    (out/"index.html").write_text(html, encoding="utf-8")


def source_zip(out):
    path = out/"cued-arm-source.zip"
    with ZipFile(path, "w") as archive:
        for name in FILES:
            info = ZipInfo(name, date_time=(2026,11,21,0,0,0))
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, (ROOT/name).read_bytes())
    return path


def make_pdf(out, source):
    from pypdf import PdfReader, PdfWriter

    browser = shutil.which("chromium") or shutil.which("google-chrome")
    if not browser:
        raise SystemExit("Install Chromium or Chrome for PDF export.")
    with tempfile.TemporaryDirectory() as workspace:
        tmp = Path(workspace)
        raw = tmp/"print.pdf"
        subprocess.run([browser, "--headless", "--disable-gpu", "--disable-background-networking",
                        "--no-first-run", "--no-default-browser-check", "--no-pdf-header-footer",
                        f"--user-data-dir={tmp/'profile'}", f"--print-to-pdf={raw}",
                        (out/"index.html").as_uri()], check=True, capture_output=True, timeout=90)
        reader = PdfReader(raw)
        if len(reader.pages) != 4:
            raise ValueError(f"Expected 4 pages, found {len(reader.pages)}")
        writer = PdfWriter(clone_from=reader)
        writer.metadata = {"/Title":"What does the arm cue already tell us?",
                           "/Subject":"Two forecasts from three cued right-arm recordings"}
        writer.add_attachment("CC-BY-4.0.txt", (ROOT/"CC-BY-4.0.txt").read_bytes())
        writer.add_attachment(source.name, source.read_bytes())
        writer.write(out/"cued-arm.pdf")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT/"output")
    parser.add_argument("--html-only", action="store_true", help="Build the page and its source ZIP.")
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    render_html(out)
    source = source_zip(out)
    if not args.html_only:
        make_pdf(out, source)


if __name__ == "__main__":
    main()
