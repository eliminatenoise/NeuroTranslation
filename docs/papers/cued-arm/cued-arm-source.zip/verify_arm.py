"""Check all reported arm scores and decisions against the published aggregate."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/"elbow"))
from check_rebuild import compare


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reproduced_results", type=Path)
    args = parser.parse_args()
    reference = json.loads((ROOT/"arm/cued-arm/results.json").read_text())
    observed = json.loads(args.reproduced_results.read_text())
    expected_weights = reference.pop("checkpoint_sha256")
    obtained_weights = observed.pop("checkpoint_sha256")
    compare(reference, observed, "results")
    print("Counts, decisions, fitting protocol, parent checkpoint and all group errors match.")
    print("Refit archive SHA-256:", obtained_weights)
    print("Matches reference checkpoint bytes:", obtained_weights == expected_weights)


if __name__ == "__main__":
    main()
