# What does the arm cue already tell us?

A NeuroTranslation and Interoceptomics research supplement based on motor-execution runs 1–3 of Ofner et al. participant S1. The 36 elbow cues also belong to the 126 seven-category trials. The source contains aggregate scores, fitted elbow coefficients, the two study protocols and the software that reads the original files and calculates the results. Each row of a score table is a group result.

## Make the paper

Extract this archive and run `python build.py --out output --html-only` with Python 3.10 or newer. The HTML works offline. For a four-page PDF with the source ZIP and full data licence as attachments, install Chromium (or Google Chrome) and pypdf, then run `python build.py --out output`. The reference export used Chromium on Linux and pypdf 6.21.2. Numbers in the two plots, the per-run table and the native-scale table come from elbow/scores.json and arm/cued-arm/results.json. Those files carry additional cues, runs and measurement horizons. Rendering metadata, fonts and pagination can depend on the browser, operating system and installed sans-serif font.

## Fit both models from the measurements

Use Python with NumPy. The reference fits used NumPy 2.5.5, with Python 3.13.15 for the elbow and Python 3.12 for the three-instrument study. Both consume the same three original GDF files (270,251,972 bytes). From the extracted root, use the following commands. The first retrieves the recordings from Zenodo, checking size, publisher MD5 and SHA-256. The second verifies the cached originals. Keep the recordings outside the paper and its source archive.

```sh
python elbow/ofner_source.py fetch ../ofner-execution-cache
python elbow/ofner_source.py verify ../ofner-execution-cache
python elbow/fit.py --cache ../ofner-execution-cache --out ../elbow-refit
python elbow/check_rebuild.py ../elbow-refit
```

The three-instrument study also requires the earlier checkpoint whose unchanged encoder is part of the comparison. Download [movement-weights.npz from the original revision](https://raw.githubusercontent.com/eliminatenoise/NeuroTranslation/c41fcf3b8763a403db9305fe0877a95b64e014ef/models/neurotranslate-0.0/movement-weights.npz) into the extracted root as previous-weights.npz. Its SHA-256 is eac2b0e49ab68ce6d6a2ff2f09a804f2d41fa3af96d632b7bbbb02f73871bed0. The study verifies that digest and the protocol digest before fitting. Use different names for the two weights files. For reference CPU settings, set OPENBLAS_NUM_THREADS=1 and OMP_NUM_THREADS=1 in the local process environment.

```sh
python arm/cued-arm/study.py ../ofner-execution-cache previous-weights.npz ../refit-arm.npz ../refit-results.json
python verify_arm.py ../refit-results.json
```

The final command checks the resulting eligible-trial count, all held-run means, native errors, standardized means, contrasts and decisions against arm/cued-arm/results.json. It checks the expected parent and protocol hashes and reports whether the packaged refit has the same archive hash. Floating-point results may vary in the last digits on another numerical library. Only the all-runs refit produces the downloadable model coefficients. Read elbow/protocol.json and arm/cued-arm/PROTOCOL.md for fixed cutoff definitions, features, controls, exclusions and decision tests.

## Credit and licence

Patrick Ofner, Andreas Schwarz, Joana Pereira and Gernot R. Müller-Putz (2017). *Upper limb movements can be decoded from the time-domain of low-frequency EEG*. Original [dataset v1, Zenodo](https://doi.org/10.5281/zenodo.834976) and [acquisition paper, PLOS ONE 12(8), e0182578](https://doi.org/10.1371/journal.pone.0182578). See elbow/SOURCE.md and elbow/codebook.json for the channel crosswalk and sample clocks.

The source recordings, derived coefficients, tables and plotted results retain Creative Commons Attribution 4.0 International. These studies select runs and cues, bin instrument readings, fit new models and compare forecasts against held-run observations. Credit the four original authors, retain the licence and identify changes when reusing these results. The project dedicates its own software, manuscript and layout to CC0 1.0 Universal to the extent it owns them. Both complete legal texts accompany the source. The separate parent checkpoint retains its original provenance and terms.
