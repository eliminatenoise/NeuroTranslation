# Can scalp voltage improve a 125-millisecond balance forecast?

The standalone HTML and PDF contain the complete six-section paper and its original chart. The PDF includes an attachment identical to the source ZIP, plus the rights notices. The separate ZIP also works with PDF viewers that hide attachments.

## Rebuild the manuscript

Extract the source ZIP in one directory. With Python, pypdf and Chrome or Chromium installed, run the following commands there.

    python -m pip install pypdf==6.21.2
    python build.py --out output

Use --browser with the path to a Chromium executable if necessary. For the HTML and archive alone, use --html-only with Python's standard library. The build uses the included manuscript, numbers, styles and Liberation Sans fonts. It can run offline once these tools are installed. Tested versions are Python 3.14.8, pypdf 6.21.2 and Chromium 155.0.8059.84 on Linux. Changing the typesetting engine or libraries can change line breaks and PDF bytes. The build fixes archive member order, timestamps, PDF metadata and document ID so repeated builds in the same environment can be compared.

## What scores.json contains

Each of the development and historical objects contains coverage, transformer, readouts, directions and neighbors. The coverage counts record logged and retained rotations, separately flagged reasons and reasons assigned first. One rejected rotation can have multiple flags. The 18 assigned development people yielded 17 eligible people. Six of six people contributed to historical evaluation. Both forecast pipelines made predictions for all 2,430 and 880 retained events respectively.

The transformer object records absolute endpoint errors, axis biases and paired differences by scalp condition. The primary donor is the next eligible rotation of the same direction in the same third of the same walk, with no overlap of margin-expanded windows. alternate_donors uses seeded orders. tracking_sensitivity compares admitted rotations next to exclusions in logged sequence with all other admitted rotations. readouts includes ridge fits, frozen-encoder fits with and without scalp and nuisance-adjusted scalp, and simple extrapolations. directions and neighbors give direction and tracking-neighbor results for the auxiliary fits. secondary contains six architecture comparisons on identical historical rows. Each endpoint pair is sacrum then head, in millimetres. Three-component errors follow mediolateral, superior–inferior and anteroposterior source axes. Error differences are full model minus comparator. Negative values favour the first model. The figure draws the ordinary 95% intervals. The paper reports the four one-sided 98.75% upper bounds used for its primary decision.

The source in this ZIP rebuilds the paper, including its figure and tables. For the extraction of the original recordings, fitting, scoring and the trained weights, use the [Transformer package](https://eliminatenoise.github.io/NeuroTranslation/visual-balance/) and [linear and frozen-encoder controls](https://eliminatenoise.github.io/NeuroTranslation/visual-balance-controls/). The [measurement atlas](https://eliminatenoise.github.io/Interoceptomics/visual-balance/) shows one development walker. The [paper landing page](https://eliminatenoise.github.io/NeuroTranslation/papers/visual-balance/) supplies the public manuscript and source together.

## Credit and licensing

Steven M. Peterson and Daniel P. Ferris recorded and released the CC0 [OpenNeuro ds003739 v1.0.3 dataset](https://doi.org/10.18112/openneuro.ds003739.v1.0.3). See the [2021 methods paper](https://doi.org/10.1016/j.dib.2021.107635) and the [2018 balance study](https://doi.org/10.1523/ENEURO.0207-18.2018). The project computed displacement targets, electrode summaries and group forecast statistics from the visual-rotation walking condition. The original chart uses these aggregate model comparisons. DATA-LICENCE.txt records attribution and the dataset metadata. The paper text, figure, analysis aggregates and original build code use CC0 1.0 to the extent of NeuroTranslation's rights. CC0-1.0.txt contains the terms. The three unmodified Liberation Sans faces use SIL Open Font License 1.1 with attribution and terms in Liberation-font-LICENSE.txt.
