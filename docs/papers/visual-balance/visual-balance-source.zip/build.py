"""Build the visual-balance paper and its attached reproducible source."""
import argparse
import base64
import hashlib
from html import escape
import json
from pathlib import Path
import shutil
import subprocess
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

SOURCE = Path(__file__).resolve().parent
NOTICES = ('DATA-LICENCE.txt', 'CC0-1.0.txt', 'Liberation-font-LICENSE.txt')
FONTS = (('Regular', 'normal', 400), ('Bold', 'normal', 700), ('Italic', 'italic', 400))
MEMBERS = ('README.md', 'paper.html.in', 'style.css', 'scores.json', 'build.py',
           *NOTICES, *(f'LiberationSans-{name}.ttf' for name, _, _ in FONTS))
GROUPS = ('development', 'historical')


def typography():
    faces = []
    for name, style, weight in FONTS:
        font = (SOURCE / f'LiberationSans-{name}.ttf').read_bytes()
        encoded = base64.b64encode(font).decode('ascii')
        faces.append(f'@font-face{{font-family:PaperSans;src:url(data:font/ttf;base64,{encoded}) format("truetype");'
                     f'font-weight:{weight};font-style:{style};}}')
    return '\n'.join(faces) + (SOURCE / 'style.css').read_text()


def table(headings, rows, caption):
    heading = ''.join(f'<th scope="col">{escape(label)}</th>' for label in headings)
    body = []
    for label, values in rows:
        cells = ''.join(f'<td data-label="{escape(title)}">{escape(value)}</td>'
                        for title, value in zip(headings[1:], values, strict=True))
        body.append(f'<tr><th scope="row">{escape(label)}</th>{cells}</tr>')
    return (f'<table class="scores" aria-label="{escape(caption)}"><thead><tr>{heading}</tr></thead>'
            f'<tbody>{"".join(body)}</tbody></table>')


def pair(values):
    return ' / '.join(f'{value:.3f}' for value in values)


def signed(value):
    return f'{value:+.3f}'.replace('-', '−')


def forest(results):
    def x(value):
        return 174 + (value + .2) * 870

    parts = ['<svg viewBox="0 0 610 158" role="img" aria-labelledby="plot-title plot-desc">',
             '<title id="plot-title">Effect of correct scalp voltage on the two forecasts</title>',
             '<desc id="plot-desc">Mean differences in millimetres with ordinary 95 percent intervals. Exact values and adjusted bounds appear in Table 2.</desc>']
    for tick in (-.2, -.1, 0, .1, .2):
        px = x(tick)
        color = '#1f524c' if tick == 0 else '#d2dfdb'
        label = f'{tick:+.1f}'.replace('-', '−') if tick else '0'
        parts.append(f'<line x1="{px}" x2="{px}" y1="6" y2="120" stroke="{color}"/>'
                     f'<text x="{px}" y="140" text-anchor="middle">{label}</text>')
    mobile = []
    for row, (control, marker, label) in enumerate((
            ('no_scalp', 0, 'Sacrum · withheld'), ('no_scalp', 1, 'Head · withheld'),
            ('wrong', 0, 'Sacrum · wrong event'), ('wrong', 1, 'Head · wrong event'))):
        effect = results[control]
        mean = effect['mean_mm'][marker]
        lo, hi = effect['ci95_mm'][marker]
        y = 17 + 30 * row
        parts.extend((f'<text x="0" y="{y+5}">{label}</text>',
                      f'<path d="M{x(lo)} {y} H{x(hi)} M{x(lo)} {y-5} v10 M{x(hi)} {y-5} v10" stroke="#295e57" stroke-width="2.5" fill="none"/>',
                      f'<circle cx="{x(mean)}" cy="{y}" r="4.5" fill="#174e47"/>'))
        mobile.append(f'<li><strong>{label}</strong>{signed(mean)} mm [{signed(lo)}, {signed(hi)}]</li>')
    parts.append('<text x="370" y="157" text-anchor="middle">Correct scalp minus control error (mm)</text></svg>')
    return ''.join(parts) + '<ul class="plot-small">' + ''.join(mobile) + '</ul>'


def fields(data):
    cohorts, methods, bounds = [], [], []
    for group in GROUPS:
        coverage = data[group]['coverage']
        cohorts.append((group.capitalize(), [str(coverage['catalogue_selected']), str(coverage['people_represented']),
                                             f"{coverage['original_rotations']:,}", f"{coverage['admitted']:,}"]))
    results = data['historical']['transformer']['primary']['comparisons']
    for control, label in [('no_scalp', 'Withheld'), ('wrong', 'Wrong event')]:
        for index, marker in enumerate(('Sacrum', 'Head')):
            item = results[control]
            lo, hi = item['ci95_mm'][index]
            bounds.append((f'{marker} · {label.lower()}', [signed(item['mean_mm'][index]),
                           f'[{signed(lo)}, {signed(hi)}]', signed(item['upper_9875_mm'][index])]))
    for key, label in [('hold', 'Hold still'), ('recent', 'Repeat last 32-sample change'),
                       ('velocity', 'Continue last 16-sample velocity'), ('linear_motion', 'Linear · motion and direction'),
                       ('motion_eyes', 'Linear · add eye signals'), ('linear_full', 'Linear · all'),
                       ('shared_nuisance', 'Frozen encoder · withhold scalp'), ('shared_full', 'Frozen encoder · all'),
                       ('shared_residual', 'Frozen encoder · adjusted scalp'), ('direct', 'Transformer · all')]:
        values = []
        for group in GROUPS:
            cohort = data[group]
            error = (cohort['transformer']['primary']['methods']['full']['marker_error_mm'] if key == 'direct'
                     else cohort['readouts']['donors']['cycle']['methods'][key]['endpoint_mm'])
            values.append(pair(error))
        methods.append((label, values))
    return {'STYLE': typography(), 'FOREST': forest(results),
            'COVERAGE': table(('Group', 'People selected', 'People scored', 'Rotations logged', 'Rotations scored'), cohorts, 'Source coverage'),
            'BOUNDS': table(('Marker and control', 'Mean Δ (mm)', '95% interval (mm)', 'Upper (mm)'), bounds, 'Historical effect of correct scalp'),
            'METHODS': table(('Forecast', 'Development (mm)', 'Historical (mm)'), methods, 'Average errors for the two markers')}


def build(out, browser):
    data = json.loads((SOURCE / 'scores.json').read_text())
    html = (SOURCE / 'paper.html.in').read_text()
    for page in range(1, 7):
        header = f'<header><span>NeuroTranslation · Visual balance</span><span>{page} / 6</span></header>'
        html = html.replace('@@FOLIO@@', header, 1)
    for key, value in fields(data).items():
        token = f'@@{key}@@'
        if html.count(token) != 1:
            raise ValueError(f'Missing or repeated manuscript field {key}')
        html = html.replace(token, value)
    if '@@' in html:
        raise ValueError('Unresolved manuscript field')
    out.mkdir(parents=True, exist_ok=True)
    page = out / 'index.html'
    page.write_text(html, encoding='utf-8')
    archive = out / 'visual-balance-source.zip'
    with ZipFile(archive, 'w') as bundle:
        for name in MEMBERS:
            info = ZipInfo(name, (2026, 11, 21, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = ZIP_DEFLATED
            bundle.writestr(info, (SOURCE / name).read_bytes())
    if browser:
        print_pdf(page, archive, browser)


def print_pdf(page, archive, browser):
    from pypdf import PdfReader, PdfWriter
    from pypdf.generic import ArrayObject, ByteStringObject
    with TemporaryDirectory() as directory:
        temp = Path(directory)
        raw = temp / 'print.pdf'
        subprocess.run([browser, '--headless', '--disable-gpu', '--disable-background-networking',
                        '--no-first-run', '--no-default-browser-check', '--no-pdf-header-footer',
                        f'--user-data-dir={temp/"profile"}', f'--print-to-pdf={raw}', page.as_uri()],
                       check=True, capture_output=True, timeout=90)
        reader = PdfReader(raw)
        if len(reader.pages) != 6:
            raise ValueError(f'Expected six pages, found {len(reader.pages)}')
        writer = PdfWriter(clone_from=reader)
        writer.metadata = {'/Title': 'Can scalp voltage improve a 125-millisecond balance forecast?',
                           '/Author': '@eliminatenoise', '/Subject': 'Scalp voltage, visual rotation and the next movement of two optical markers'}
        for file in [archive, *(SOURCE / name for name in NOTICES)]:
            writer.add_attachment(file.name, file.read_bytes())
        identity = ByteStringObject(hashlib.sha256(archive.read_bytes()).digest()[:16])
        writer._ID = ArrayObject([identity, identity])
        writer.write(page.with_name('visual-balance.pdf'))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=SOURCE / 'output')
    parser.add_argument('--browser', help='Path to Chrome or Chromium')
    parser.add_argument('--html-only', action='store_true')
    args = parser.parse_args()
    browser = None if args.html_only else args.browser or shutil.which('chromium') or shutil.which('google-chrome')
    if not args.html_only and browser is None:
        parser.error('Install Chromium or pass its path with --browser.')
    build(args.out.resolve(), browser)
