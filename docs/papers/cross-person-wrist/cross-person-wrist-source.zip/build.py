"""Compose the HTML paper and its PDF with an attached, deterministic source package."""
import argparse
from html import escape
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from figures import coverage_circles, primary_chart, role_alignment, timeline

HERE = Path(__file__).resolve().parent
TITLE = 'Can a wrist forecast travel from one person to another?'
HEADS = [('contralateral','8'), ('contralateral','15'), ('ipsilateral','8'), ('ipsilateral','15')]
FILES = ['README.md','article.html','style.css','figures.py','build.py','test_paper.py',
         'aggregate.json','CC-BY-4.0.txt','CC0-1.0.txt']
METHODS = {
    'persistence':'Last position', 'velocity':'Velocity, 15 frames', 'damped_velocity':'Damped velocity',
    'ridge':'Primary ridge', 'joint_zero':'Two-arm zero displacement', 'joint_mean_px':'Mean displacement, pixels',
    'joint_mean_normalized':'Mean displacement, arm lengths', 'joint_constant_velocity':'Velocity, last five frames',
    'joint_kinematic_ridge':'Segment-velocity ridge','joint_intact':'Full intact', 'joint_blocked':'Full blocked',
    'joint_intact_swapped':'Full intact, earlier partner','joint_matched_intact':'Matched intact',
    'joint_matched_blocked':'Matched blocked','joint_matched_intact_swapped':'Matched intact, earlier partner',
    'joint_trained_swap':'Matched, trained with earlier partner'}
PAIRS = {
    'joint_intact__joint_blocked':'Full intact − blocked',
    'joint_intact__joint_intact_swapped':'Full intact − earlier partner',
    'joint_matched_intact__joint_matched_blocked':'Matched intact − blocked',
    'joint_matched_intact__joint_matched_intact_swapped':'Matched intact − earlier partner',
    'joint_matched_intact__joint_trained_swap':'Matched intact − trained substitution'}

def number(x, digits=2, signed=False):
    fmt = f"{'+' if signed else ''}.{digits}f"
    return format(x, fmt).replace('-','−')

def table(caption, header, rows):
    h=''.join(f'<th scope="col">{escape(str(v))}</th>' for v in header)
    body=''
    for first,*rest in rows:
        body+=f'<tr><th scope="row">{escape(str(first))}</th>'+''.join('<td>'+escape(str(v))+'</td>' for v in rest)+'</tr>'
    return f'<div class="tbl" role="region" aria-label="{escape(caption)}" tabindex="0"><table><caption>{escape(caption)}</caption><thead><tr>{h}</tr></thead><tbody>{body}</tbody></table></div>'

def compose(show_downloads=True):
    data=json.loads((HERE/'aggregate.json').read_bytes())
    cells={'style':(HERE/'style.css').read_text(),'clock':timeline(),'errors':primary_chart(data),'mirror':role_alignment(),'circles':coverage_circles()}
    cells['downloads'] = ('<nav aria-label="Download paper"><a download href="cross-person-wrist.pdf">Download PDF</a>'
        '<a download href="cross-person-wrist-source.zip">Editable source and results</a></nav>') if show_downloads else ''
    cells['roles']=table('Table 1. Side is assigned from the implant hemisphere and the archive’s named wrist annotation.',
        ['Recording','Implant side','Reach-defining wrist','Accompanying wrist'],
        [['Source · 60 reaches','Left','Right (contralateral)','Left (ipsilateral)'],
         ['Test · 30 reaches','Right','Left (contralateral)','Right (ipsilateral)']])
    hlabels=['Selected +8','Selected +15','Other +8','Other +15']
    primary=[]
    for key in ['persistence','velocity','damped_velocity','ridge']:
        s=data['absolute'][key]
        primary.append([METHODS[key],*[number(s['px'][r][h]['mean'])+' / '+number(s['widths'][r][h]['mean'],3) for r,h in HEADS]])
    cells['primary']=table('Table 2. Mean miss in detector pixels / earlier shoulder widths. Each cell contains 30 reaches.',
                            ['Forecast',*hlabels],primary)
    intervals=['00–04','04–08','08–12','12–16','16–20','20–24']
    strata=[]
    for i,interval in enumerate(intervals):
        key=str(i); n=data['stratum_counts'][i]
        def effects(which):
            return [number(data['strata']['contralateral_'+h][key][which]['shoulder_widths'],3,True) for h in ['8','15']]
        strata.append([interval,n,*effects('effect'),*effects('omit')] if n>1 else
                      [interval,n,*(['—']*4 if not n else ['Single reach','Single reach','Positive','Positive'])])
    cells['strata']=table('Table 3. Ridge minus damped velocity, selected wrist, in earlier shoulder widths. Omission columns remove the indicated period. Single-reach errors are withheld in this public summary.',
                          ['Hours from start','Reaches','Within +8','Within +15','Omit +8','Omit +15'],strata)
    partner=[]
    for key,name in PAIRS.items():
        s=data['contrasts'][key]
        partner.append([name,s['four_head_intersection'],*[number(s['own_heads_px'][r][h]['mean'],2,True) for r,h in HEADS],
                        number(s['pooled_four_head_px']['mean'],3,True)])
    cells['partners']=table('Table 4. Paired differences in mean miss (px). Each comparison uses all reaches available to both forecasts. Full and matched specify the training set.', ['Pair','Reaches',*hlabels,'Pooled'],partner)
    coverage=[]
    for model,levels in data['coverage'].items():
        for role_i,name in enumerate(['Selected','Other']):
            for h_i,h in enumerate([8,15]):
                row=[model.title()+' · '+name+' +'+str(h)]
                for p in ['0.5','0.8','0.9']:
                    s=levels[p];n=s['denominators_horizon_role'][h_i][role_i];hits=s['hits_horizon_role'][h_i][role_i]
                    row.append(f"{s['radii_shoulder_widths'][h_i][role_i]:.3f}  ·  {hits}/{n}")
                coverage.append(row)
    cells['coverage']=table('Table 5. Each cell gives the frozen radius in earlier shoulder widths, then observed hits / eligible test reaches. An endpoint on the circle counts as inside.',
                     ['Model · wrist +frames','Nominal 50%','Nominal 80%','Nominal 90%'],coverage)
    rows=[]
    for key,name in METHODS.items():
        s=data['absolute'][key]
        rows.append([name,s['four_head_common'],*[number(s['px'][r][h]['mean']) for r,h in HEADS],
                     *[number(s['absolute_span_change_error_px'][h]['mean']) for h in ['8','15']]])
    assert set(METHODS)==set(data['absolute'])
    cells['methods']=table('Table 6. Mean absolute endpoint miss and mean absolute span-change error in detector pixels. Each method has complete four-endpoint support on its indicated reaches.',
                     ['Method','n',*hlabels,'Span +8','Span +15'],rows)
    html=(HERE/'article.html').read_text()
    for key,value in cells.items(): html=html.replace('{{'+key+'}}',value)
    assert '{{' not in html
    return html

def build(out):
    from pypdf import PdfReader, PdfWriter
    out.mkdir(exist_ok=True,parents=True)
    (out/'index.html').write_text(compose())
    files={name:(HERE/name).read_bytes() for name in FILES}
    files['read.html']=compose(False).encode()
    zip_path=out/'cross-person-wrist-source.zip'
    with ZipFile(zip_path,'w',compression=ZIP_DEFLATED) as z:
        for name,content in sorted(files.items()):
            entry=ZipInfo(name,(2026,11,21,0,0,0)); entry.external_attr=0o100644<<16
            z.writestr(entry,content,compress_type=ZIP_DEFLATED)
    browser=shutil.which('chromium') or shutil.which('google-chrome')
    if not browser: raise SystemExit('Chromium or Google Chrome is required for PDF export.')
    with tempfile.TemporaryDirectory(dir=out) as t:
        tmp=Path(t); page=tmp/'read.html'; page.write_text(compose(False))
        pdf=tmp/'paper.pdf'
        subprocess.run([browser,'--headless','--disable-gpu','--disable-background-networking','--no-pdf-header-footer',
                        '--user-data-dir='+str(tmp/'profile'),'--print-to-pdf='+str(pdf),page.as_uri()],
                        check=True,capture_output=True,timeout=90)
        writer=PdfWriter(clone_from=PdfReader(pdf))
        writer.metadata={'/Title':TITLE,'/Author':'NeuroTranslation','/Subject':'Prospective evaluation of an optical wrist forecast on a second person'}
        writer.add_attachment(zip_path.name,zip_path.read_bytes())
        writer.write(out/'cross-person-wrist.pdf')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--out',type=Path,default=HERE/'output')
    build(parser.parse_args().out.resolve())
