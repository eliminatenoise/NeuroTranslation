# Can a wrist forecast travel from one person to another?

Open **read.html** in any browser after extracting this ZIP. The paper and its original figures work offline. The individual references open their primary sources if a connection is available. The public edition also includes a PDF containing this archive as an attachment. Its companion HTML links to the PDF and source archive by relative filename.

## Rebuild the paper

Use Python 3.10 or newer, the Python package pypdf, and Chromium or Google Chrome on your command path. From this directory:

```sh
python -B test_paper.py
python -B build.py --out output
python -B test_paper.py --edition output
```

The PDF follows the A4 print stylesheet. Local installation of Inter and Liberation Sans gives the reference typography. Chromium supplies print layout, and pypdf embeds the source download and sets document metadata. An extracted source archive reproduces the paper from published aggregates. These figures and tables require no network, data download, participant weights or event coordinates. New browser and font versions can change PDF layout.

## What the numbers describe

All events are archival, spontaneous, contralateral wrist onsets. The training set is AJILE12 participant 01 session 3 (60 events) and the held test is participant 02 session 3 (30 events). In the JSON keys, contralateral means the wrist opposite the implant, which defines these reach onsets. Ipsilateral means the other wrist, on the implant side. “8” and “15” are camera frames after the last input. A cell containing both a wrist and a horizon describes one forecast output. A positive paired difference means the first forecast missed by more. Native detector pixels, prior projected shoulder widths and arm lengths are different measures.

The model’s readiness and the later endpoint’s availability were evaluated separately. All held events had bilateral input and all four wrist targets. The first had no earlier partner. A paired score compares the same original reaches for each method. A four-output mean first averages the two arms and horizons within a reach. Per-method errors, per-output and pooled partner perturbations, the 29-event shared comparison, source-derived radii and observed coverage appear in aggregate.json. For radius matrices the first index is horizon (8, 15), the second is role (contralateral, ipsilateral). Each circle’s radius is measured in that event’s earlier projected shoulder widths. “All four inside” counts events rather than endpoints. The stratum table includes all six support counts. Single-reach effect magnitudes and their corresponding omission magnitudes are not included in this aggregate-only edition.

article.html is the editable manuscript template, style.css the stylesheet, figures.py the drawing source and build.py the table/edition generator. test_paper.py checks the arithmetic and the public files. No participant records, fitted weights, neural samples, per-event predictions or camera frames are included. The exact score replication used independently restricted source inputs. The aggregate source lets readers check the arithmetic and rebuild the paper without those inputs.

## Sources and attribution

Steven M. Peterson, Satpreet H. Singh, Benjamin Dichter, Michael Scheid, Rajesh P. N. Rao and Bingni W. Brunton. *AJILE12: Long-term naturalistic human intracranial neural recordings and pose*. Scientific Data 9, 184 (2022). https://doi.org/10.1038/s41597-022-01280-y

Steven M. Peterson, Satpreet H. Singh, Nancy X. R. Wang, Rajesh P. N. Rao and Bingni W. Brunton. *Behavioral and Neural Variability of Naturalistic Arm Movements*. eNeuro 8 (2021). https://doi.org/10.1523/ENEURO.0007-21.2021

AJILE12 contributors. DANDI dataset 000055, version 0.220127.0436. https://doi.org/10.48324/dandi.000055/0.220127.0436. The original dataset and its adaptations are attributed under CC BY 4.0. This analysis selected archived movement blocks from two recordings, projected six body landmarks, froze four primary regressions and controls and compared predicted with recorded future wrist endpoints. The primary articles are also published under CC BY 4.0. See CC-BY-4.0.txt. Neither paper’s images nor article text are reproduced here. The original NWB converter is credited and linked in the manuscript.

The new manuscript, figure designs and paper-building code are dedicated under CC0 1.0 to the extent of the project’s own rights. See CC0-1.0.txt. This dedication preserves the upstream authors’ attribution and license. These new predictions and interpretations are the reanalysis authors’ work.
