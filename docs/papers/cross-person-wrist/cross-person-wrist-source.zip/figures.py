"""Original vector schematics. Distances and time points are specified in the captions."""
import base64
from html import escape

TEAL = '#08756c'
RUST = '#94522f'
INK = '#263a41'
MUTED = '#54706e'

def label(x, y, value, size=17, color=INK, weight=500, anchor='start'):
    return f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{weight}" text-anchor="{anchor}">{escape(str(value))}</text>'

def line(x1,y1,x2,y2,color=INK,w=2):
    return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="{w}"/>'

def fig(parts, height, alt, caption):
    content = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 690 '+str(height)+'" font-family="Liberation Sans, Arial, sans-serif">'+''.join(parts)+'</svg>'
    uri = base64.b64encode(content.encode()).decode()
    return f'<figure><img src="data:image/svg+xml;base64,{uri}" alt="{escape(alt)}"><figcaption>{caption}</figcaption></figure>'

def timeline():
    x=lambda frame:30+(frame+14)*21
    a=[label(21,25,'The detector supplies 15 earlier frames',20,TEAL,650),
       line(x(-14),85,x(15),85,'#8da8a3',2)]
    for k in range(-14,1):
        a.append(f'<circle cx="{x(k)}" cy="85" r="5" fill="{TEAL}"/>')
    for k, s in [(8,'+8'),(15,'+15')]:
        a.extend([line(x(k),58,x(k),97,RUST,2),f'<circle cx="{x(k)}" cy="85" r="7" fill="{RUST}"/>',label(x(k),48,s,19,RUST,650,'middle')])
    a.extend([label(x(-14),117,'First input',16),label(x(0),117,'Last input',16,INK,500,'middle'),
              label(x(8),117,'0.267 s',16,INK,500,'middle'),label(x(15),117,'0.500 s',16,INK,500,'middle')])
    return fig(a,130,'Fifteen input frames end at a reference point. Outcomes are sampled eight and fifteen frames after the last input.',
               '<strong>Figure 1.</strong> A camera clock at 30 frames per second. Time is measured from the final input frame. The archive places onset after that frame, at or before the next one.')

def primary_chart(data):
    a=[label(0,25,'Mean endpoint error on the reach-defining wrist',19,INK,650),
       label(0,49,'Earlier shoulder widths  ·  30 reaches  ·  smaller is better',16,MUTED)]
    x0=173; scale=487/.9
    for tick in [0,.2,.4,.6,.8]:
        x=x0+tick*scale;a.extend([line(x,68,x,181,'#dae2df',1),label(x,201,f'{tick:g}',15,MUTED,500,'middle')])
    for h,y in [('8',92),('15',154)]:
        head=data['primary']['contralateral_'+h]['means']['shoulder_widths']
        a.append(label(0,y+5,h+' frames',18,INK,650))
        p=x0+head['damped_velocity']*scale;q=x0+head['ridge']*scale
        a.extend([line(p,y,q,y,'#abc0bd',3),f'<circle cx="{p}" cy="{y}" r="6" fill="{TEAL}"/>',
                  f'<rect x="{q-5.5}" y="{y-5.5}" width="11" height="11" fill="{RUST}"/>',
                  label(p,y-13,f"{head['damped_velocity']:.3f}",15,TEAL,650,'middle'),
                  label(q,y+23,f"{head['ridge']:.3f}",15,RUST,650,'middle')])
    return fig(a,211,'At eight frames damped velocity misses by 0.154 shoulder widths and ridge by 0.311. At fifteen frames the misses are 0.402 and 0.813.',
               '<strong>Figure 3.</strong> Each line joins two forecasts on the same reaches. The circle marks damped velocity. The square marks ridge regression.')

def role_alignment():
    p=[]
    for x,title,left,right,selected_at in [(12,'SOURCE','R','L',0),(369,'TEST','R','L',1)]:
        p.extend([label(x,22,title,15,MUTED,650),line(x+42,56,x+239,56,'#acb9b7',4)])
        for i,(native,side) in enumerate([(left,'right'),(right,'left')]):
            cx=x+42+i*197;selected=i==selected_at
            p.append(f'<circle cx="{cx}" cy="56" r="13" fill="{TEAL if selected else "#657b82"}"/>')
            p.append(label(cx,61,native,15,'white',650,'middle'))
            p.append(label(cx,88,'Selected' if selected else 'Other',16,TEAL if selected else INK,650,'middle'))
    return fig(p,99,'The source selected wrist is right, while the test selected wrist is left. The opposite wrist accompanies each on its own event.',
        '<strong>Figure 2.</strong> The wrist roles change native sides between recordings. R and L name the person’s anatomical sides. The diagram shows assignments, independent of where the camera puts them on screen.')

def coverage_circles():
    p=[]
    for cx,obs,title in [(81,(103,44),'Inside'),(386,(443,37),'Outside')]:
        ox,oy=obs
        p.append(f'<circle cx="{cx}" cy="61" r="36" fill="#edf5f2" stroke="{TEAL}" stroke-width="2"/>')
        p.extend([line(cx-6,61,cx+6,61,TEAL,2),line(cx,55,cx,67,TEAL,2),
                  f'<circle cx="{ox}" cy="{oy}" r="5" fill="{RUST}"/>',label(cx+86,62,title,19,INK,650)])
    return fig(p,108,'Schematic circles centred on cross-shaped forecast points. A measured dot inside the radius counts as a hit. A dot outside counts as a miss.',
               '<strong>Figure 4.</strong> The cross is the forecast, the dot a later detector position. The radius is fixed from earlier source errors. These drawn positions are illustrative.')
