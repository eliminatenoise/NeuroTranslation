"""Validate the published aggregates and, optionally, an exported edition."""
import argparse
import json
from html.parser import HTMLParser
from math import isclose
from pathlib import Path
from zipfile import ZipFile
from build import FILES, HEADS, PAIRS, TITLE, compose

HERE=Path(__file__).resolve().parent

class Surface(HTMLParser):
    def __init__(self):
        super().__init__();self.images=[];self.links=[];self.sections=0;self.tables=0
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if tag=='img':self.images.append(attrs)
        if tag=='a':self.links.append(attrs['href'])
        if tag=='section':self.sections+=1
        if tag=='table':self.tables+=1

def check(edition=None):
    data=json.loads((HERE/'aggregate.json').read_text())
    assert data['selected']==sum(data['stratum_counts'])==30
    assert len(data['absolute'])==data['audit_methods']==16
    assert data['rank']==[17,28,31] and data['calibration_blocks']==33
    assert len(data['contrasts'])==len(PAIRS)==5
    for role,h in HEADS:
        head=data['primary'][role+'_'+h];assert head['n']==30
        for field in ['pixels','shoulder_widths']:
            means=head['means'][field]
            assert isclose(means['ridge']-means['damped_velocity'],head['ridge_minus_damped'][field],abs_tol=1e-12)
            assert head['ridge_minus_damped'][field]>0
    for levels in data['coverage'].values():
        for p,cell in levels.items():
            hits=sum(cell['hits_horizon_role'],[])
            assert all(n==30 for n in sum(cell['denominators_horizon_role'],[]))
            assert all(h<=30 for h in hits) and cell['all_four_inside']<=min(hits)
    for name,pair in data['contrasts'].items():
        px=[pair['own_heads_px'][role][h]['mean'] for role,h in HEADS]
        assert isclose(sum(px)/4,pair['pooled_four_head_px']['mean'],abs_tol=1e-12)
    surf=Surface();surf.feed(compose());assert (surf.sections,surf.tables,len(surf.images))==(9,6,4)
    assert all(img['src'].startswith('data:image/svg+xml;base64,') and img['alt'] for img in surf.images)
    assert set(a for a in surf.links if not a.startswith(('https://','#')))=={'cross-person-wrist.pdf','cross-person-wrist-source.zip'}
    if edition:
        from pypdf import PdfReader
        assert (edition/'index.html').read_text()==compose()
        archive=edition/'cross-person-wrist-source.zip'
        with ZipFile(archive) as z:
            assert z.testzip() is None and set(z.namelist())==set(FILES+['read.html'])
            assert z.read('read.html').decode()==compose(False)
            for name in FILES:assert z.read(name)==(HERE/name).read_bytes(),name
        pdf=PdfReader(edition/'cross-person-wrist.pdf')
        assert pdf.metadata.title==TITLE and len(pdf.pages)==9
        assert pdf.attachments[archive.name]==[archive.read_bytes()]
        for page in pdf.pages:
            for annot in page.get('/Annots',[]):
                uri=annot.get_object().get('/A',{}).get('/URI','')
                assert not uri or uri.startswith('https://'),uri
    print('Verified 16 method summaries, paired primary arithmetic, five two-arm contrasts, per-head coverage, six tables and four embedded figures.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--edition',type=Path);check(p.parse_args().edition)
