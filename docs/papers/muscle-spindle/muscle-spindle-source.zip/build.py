"""Build the paper from the manuscript and the editable, aggregate table values."""
import argparse
import base64
import hashlib
import json
import shutil
import subprocess
from html import escape
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

SOURCE = Path(__file__).resolve().parent
TITLE = 'What can a stretch tell us about the next sensory spikes?'
NOTICES = ('DATA-LICENCE.txt', 'CC0-1.0.txt', 'Liberation-font-LICENSE.txt')
FONTS = ('LiberationSans-Regular.ttf', 'LiberationSans-Bold.ttf')
MEMBERS = ('README.md', 'build.py', 'paper.html.in', 'measurements.svg', 'format_results.py', 'style.css', 'aggregate.json', *FONTS, *NOTICES)


def table(data):
    labels = data['columns']
    cells = ''.join(f'<th scope="col">{escape(v)}</th>' for v in labels)
    rows = []
    for row in data['rows']:
        values = [f'<th scope="row">{escape(row[0])}</th>']
        for heading, value in zip(labels[1:], row[1:], strict=True):
            values.append(f'<td data-label="{escape(heading)}">{escape(value)}</td>')
        rows.append('<tr>' + ''.join(values) + '</tr>')
    return (f'<table><caption>{escape(data["caption"])}</caption><thead><tr>{cells}</tr></thead>'
            '<tbody>' + ''.join(rows) + '</tbody></table>')


def html():
    css = []
    for filename, weight in zip(FONTS, [400, 700], strict=True):
        encoded = base64.b64encode((SOURCE / filename).read_bytes()).decode('ascii')
        css.append(f'@font-face{{font-family:PaperSans;src:url(data:font/ttf;base64,{encoded}) '
                   f'format("truetype");font-weight:{weight};font-style:normal}}')
    css.append((SOURCE / 'style.css').read_text())
    manuscript = (SOURCE / 'paper.html.in').read_text().replace('@@STYLE@@', '\n'.join(css))
    manuscript = manuscript.replace('@@SITES@@', (SOURCE / 'measurements.svg').read_text())
    n_pages = manuscript.count('@@FOLIO@@')
    for n in range(1, n_pages + 1):
        header = ('<header class="folio"><span>NeuroTranslation · Peripheral sensory signals</span>'
                  f'<span>Muscle spindle study · {n} / {n_pages}</span></header>')
        manuscript = manuscript.replace('@@FOLIO@@', header, 1)
    from format_results import format_results
    data = format_results(json.loads((SOURCE / 'aggregate.json').read_text()))
    for key, value in data['prose'].items():
        assert manuscript.count(f'@@{key}@@') == 1, key
        manuscript = manuscript.replace(f'@@{key}@@', escape(value))
    for key, value in data['tables'].items():
        assert manuscript.count(f'@@{key}@@') == 1, key
        manuscript = manuscript.replace(f'@@{key}@@', table(value))
    if '@@' in manuscript:
        raise ValueError('Unfilled manuscript field')
    return manuscript, n_pages


def archive(output):
    with ZipFile(output, 'w') as zip_file:
        for name in MEMBERS:
            member = ZipInfo(name, (2026, 11, 21, 0, 0, 0))
            member.create_system = 3
            member.external_attr = 0o100644 << 16
            member.compress_type = ZIP_DEFLATED
            zip_file.writestr(member, (SOURCE / name).read_bytes())


def pdf(manuscript, output, zipped, page_count, browser):
    from pypdf import PdfReader, PdfWriter
    from pypdf.generic import ArrayObject, ByteStringObject
    with TemporaryDirectory() as temp_dir:
        tmp = Path(temp_dir)
        page = tmp / 'print.html'
        page.write_text(manuscript)
        raw = tmp / 'print.pdf'
        command = [browser, '--headless', '--disable-gpu', '--disable-background-networking',
                   '--no-first-run', '--no-default-browser-check', '--no-pdf-header-footer',
                   f'--user-data-dir={tmp / "profile"}', f'--print-to-pdf={raw}', page.as_uri()]
        subprocess.run(command, check=True, capture_output=True, timeout=90)
        reader = PdfReader(raw)
        if len(reader.pages) != page_count:
            raise ValueError(f'Expected {page_count} pages, Chromium produced {len(reader.pages)}')
        writer = PdfWriter(clone_from=reader)
        writer.metadata = {'/Title': TITLE, '/Author': 'NeuroTranslation',
                           '/Subject': 'Forecasts of Ia sensory spike counts in passive rat muscle stretches'}
        for file in (zipped, *(SOURCE / name for name in NOTICES)):
            writer.add_attachment(file.name, file.read_bytes())
        identity = ByteStringObject(hashlib.sha256(zipped.read_bytes()).digest()[:16])
        writer._ID = ArrayObject([identity, identity])
        writer.write(output)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=SOURCE / 'output')
    parser.add_argument('--browser')
    parser.add_argument('--html-only', action='store_true')
    args = parser.parse_args()
    output = args.out.resolve()
    output.mkdir(parents=True, exist_ok=True)
    manuscript, pages = html()
    (output / 'index.html').write_text(manuscript)
    zipped = output / 'muscle-spindle-source.zip'
    archive(zipped)
    if not args.html_only:
        executable = args.browser or shutil.which('chromium') or shutil.which('google-chrome')
        if not executable:
            parser.error('Install Chromium or specify --browser PATH.')
        pdf(manuscript, output / 'muscle-spindle.pdf', zipped, pages, executable)
