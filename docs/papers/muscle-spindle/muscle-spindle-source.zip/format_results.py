"""Format frozen group results. Absolute losses retain their native units."""
from collections import Counter

PREFIXES = ('0','1','4')
SEEDS = ('1641','2718','3917')
FAMILIES = (('glm','Poisson'), ('transformer','Transformer'))
BANDS = ('0 to <0.5', '0.5 to <1', '1 to <2', '2 to <4', '4 or more')
def f(x):
    return f'{x:.3f}'
def signed(x):
    return f'{x:+.4f}'.replace('-','−')
def native(x):
    return f'{x:.6f}'
def table(caption, columns, rows):
    return dict(caption=caption,columns=columns,rows=list(rows))
def yesno(result):
    return 'met' if result else 'missed'
def short(n):
    return f'{n:,}'
def span(values):
    return f'{f(min(values))}–{f(max(values))}'

def format_results(data):
    prose, tables = {}, {}
    groups = data['groups']
    strict = data['strict_groups']
    mixed = data['mixed_groups']
    summary = data['summary']
    models = summary['models']['full']
    gates = summary['gates']
    secondary = data['secondary']
    reverse = secondary['primary']
    lagged = secondary['timing']
    paired = data['paired_by_fibre_distributions']
    def score(model,seed=None):
        return models[model][seed or ('mean' if 'mean' in models[model] else 'fixed')]['macro']['all']
    windows = data['support']['full']['macro']['all']
    n_trials = sum(x['included_trials'] for x in groups.values())
    all_fit = {name:score(name+'_all') for name,_ in FAMILIES}
    joint = all_fit['transformer']
    count = all_fit['glm']
    prose['COVERAGE'] = (f'The planned comparison across three filename groups could not be estimated. '
        f'We instead tested the predeclared exploratory fallback on {short(windows)} intervals from '
        f'{n_trials} stretches. Each fold held out all the trials of one sensory fibre and trained on the other two, all from one filename group.')
    hist=score('transformer_history')
    prose['ABSTRACT_PRIMARY'] = (f'The Transformer using firing history alone had lower mean count deviance ({f(hist["deviance"])}) '
        f'than the Transformer that added mechanics ({f(joint["deviance"])}). Its absolute error was also lower '
        f'({f(hist["mae"])} versus {f(joint["mae"])} spikes per 20 ms). With both inputs, the Transformer did outperform '
        f'Poisson regression ({f(count["deviance"])} deviance, {f(count["mae"])} spikes of absolute error). Neither family '
        'showed a consistent benefit from adding mechanics to firing history.')
    rev_stat = reverse['combined_beats_mechanics_everywhere']
    prose['ABSTRACT_SECONDARY'] = ('In a separate test, adding past spikes to the mechanics history '
        + ('reduced the error in each group for both future force and position.' if all(rev_stat.values()) else
           'did not consistently improve forecasts of both future force and actuator position across the three held fibres.')
        + ' The movements were imposed. These scores describe recordings from a passive preparation.')
    tables['COHORT'] = table('Table 1. Archive coverage. Eligibility cells give fibres / trials / windows.',
        ['Prefix', 'Archived fibres / trials', 'Two clocks only', 'Mixed-clock sensitivity'],
        [[g,f"{groups[g]['inventoried_files']} / {groups[g]['inventoried_trials']}",
          *[f"{x[g]['included_files']} / {x[g]['included_trials']} / {short(x[g]['windows'])}" for x in (strict,mixed)]] for g in PREFIXES])
    strict_n=sum(g['windows'] for g in strict.values())
    mixed_n=sum(g['windows'] for g in mixed.values())
    added=mixed_n-strict_n
    prose['CLOCKS']=(f'The original rule admitted {short(strict_n)} windows, all in prefix 0, with electrical signals sampled at 20 kHz and mechanics at 2 kHz. '
        f'The sensitivity rule added {short(added)} windows on a single 10 kHz axis in prefix 1. The transient aligned to actual spikes exceeded all three shifted controls in {data["voltage_corroboration"]["larger_at_events"]} of {data["voltage_corroboration"]["trials"]} qualifying trials.')
    prose['STRICT_OUTCOME']=(f'Neither cohort supplied prefix 4. All 26 trials of the prefix-4 file were excluded because its filename and internal fibre identifier disagreed. Another file in prefix 0 had 39 protocol labels for 38 trials. '
       'Sixteen nearly uniform electrical clocks differed cumulatively from the required integer-sample 20 ms grid by 250 µs, above the 10 ns tolerance. No missing group was replaced, and neither three-group hypothesis has a numerical result.')
    lost_windows = sum(g['candidate_windows_in_parsed_trials'] for g in groups.values()) - windows
    prose['WINDOWS'] = (f'The {n_trials} retained strict trials supplied {short(sum(g["observed_target_spikes"] for g in groups.values()))} detected spikes in eligible target bins. '

        + (f'The coverage mask removed {short(lost_windows)} further candidate windows.' if lost_windows else
           'Every candidate interval in the fully parsed trials passed the joint coverage checks.'))
    rows = []
    for model, label in [('constant','Training mean'),('recent_one','Last bin'),('recent_five','Five-bin mean'),('recent_smoothed','Five bins, smoothed')]:
        m=score(model);rows.append([label,f(m['deviance']),f(m['mae'])])
    for model,label in FAMILIES:
        for mode,name in [('history','firing'),('force','force + rate'),('position','position + rate'),('mechanics','all mechanics'),('all','mechanics + firing')]:
            m=score(model+'_'+mode);rows.append([f'{label} · {name}',f(m['deviance']),f(m['mae'])])
    tables['MODELS'] = table('Table 2. Exploratory means across three held sensory fibres.',
                             ['Forecast','Count deviance','MAE (spikes / 20 ms)'],rows)
    prose['PRIMARY_FINDING'] = (f'The last count repeated as a forecast had the lowest MAE ({f(score("recent_one")["mae"])}), '
        f'and repeated the correct count in {short(data["residual"]["last_bin_exact"])} windows. Yet it forecast zero before '
        f'{short(data["residual"]["last_bin_zero_followed_by_positive_observation"])} intervals that contained a spike. Those cases incur a large deviance penalty, bringing '
        f'its average to {f(score("recent_one")["deviance"])}. The firing-history Transformer had the lowest deviance.')
    def paired_row(label,key,seed):
        item=paired[key][seed]
        d=item['deviance'];a=item['mae']
        return [label,f"{d['lower']} / {d['n']}",signed(d['minimum'])+' to '+signed(d['maximum']),signed(d['mean']),signed(a['mean'])]
    delta_rows = []
    for family,label in FAMILIES:
        for mode,name in [('history','firing only'),('mechanics','mechanics only')]:
            delta_rows.append(paired_row(f'{label} vs {name}',f'{family}_combined_vs_{mode}','mean' if family=='transformer' else 'fixed'))
    delta_rows.append(paired_row('Transformer vs Poisson, both combined','transformer_vs_glm_joint','mean'))
    tables['INCREMENTS']=table('Table 3. Exploratory fits. Combined minus comparator, across three held fibres.',
             ['Comparison','Lower deviance','Fibre deviance differences','Mean deviance difference','Mean MAE difference'],delta_rows)
    seed_span = span([score('transformer_all',seed)['deviance'] for seed in SEEDS])
    primary_aux=score('glm_afferent'); draws=score('glm_sampled')
    prose['SEEDS'] = (f'Across three separately trained combined Transformers, the macro deviance range was {seed_span}. '
        f'In this single prefix the equally weighted fibre regression reproduces the primary regression ({f(primary_aux["deviance"])} deviance). A separate regression '
        f'used the exact windows sampled for each Transformer ({f(draws["deviance"])} deviance, {f(draws["mae"])} MAE).')
    common = data['support']['common_lag']['macro']['all']
    prose['TIMING_SUPPORT'] = f'That left {short(common)} matched cutoffs and excluded {short(windows-common)}.'
    timerows = [paired_row(label,fam+'_current_vs_stale_mechanics','mean' if fam=='transformer' else 'fixed') for fam,label in FAMILIES]
    tables['TIME_TABLE']=table('Table 4. Exploratory timing test. Current minus earlier mechanics. Negative favours current.',
             ['Combined fit','Lower deviance','Fibre deviance differences','Mean deviance difference','Mean MAE difference'],timerows)
    prose['TIMING_FINDING'] = (f'Poisson regression {yesno(gates["glm_timing"]["pass_all"])} the timing criterion. '
         f'The Transformer {yesno(gates["transformer_timing"]["pass_all"])} the same exploratory criterion, including its per-seed check. '
         'This comparison tests one lag in the existing stretches.')
    prose['CALIBRATION_RULE'] = ('The table shows the fixed regression and the first registered Transformer seed (1641). '
        'Each uses its own forecast bands. Means retain the study weights, and n counts actual windows.')
    def bins(model,seed):
        bins=[x for x in data['calibration'] if x['support']=='full' and x['model']==model and x['seed']==seed and x['prefix']=='all']
        assert len(bins)==5
        return sorted(bins,key=lambda b:b['left'])
    calibration_rows=[]
    def band(b):
        return '—' if b['forecast'] is None else f'{f(b["forecast"])} / {f(b["observed"])}'
    for i,(a,b) in enumerate(zip(bins('glm_all','fixed'),bins('transformer_all','1641'),strict=True)):
        calibration_rows.append([BANDS[i],short(a['n_windows']),band(a),short(b['n_windows']),band(b)])
    tables['CALIBRATION']=table('Table 5. Exploratory combined fits. Calibration in spikes per 20 ms.',
        ['Forecast band','Poisson n','Forecast / observed','Transformer n','Forecast / observed '],calibration_rows)
    prose['CALIBRATION_FINDING']=(f'Across all bands, the weighted observed count was {f(joint["observed"])}. '
        f'Poisson regression forecast {f(count["forecast"])} on average (signed error {signed(count["bias"])}, observed/forecast {f(count["observed_over_forecast"])}). '
        f'The mean across separately scored Transformer fits was {f(joint["forecast"])} (signed error {signed(joint["bias"])}, ratio {f(joint["observed_over_forecast"])}). '
        f'Its mean forecast fell below the mean count in all {data["residual"]["transformer_combined_underpredicted_fibres"]} held fibres.')
    tg=paired['transformer_current_vs_stale_mechanics']['mean']['deviance'];pg=paired['glm_current_vs_stale_mechanics']['fixed']['deviance']
    prose['HETEROGENEITY']=(f'The correctly timed mechanics produced lower deviance in '
        f'{pg["lower"]} of {pg["n"]} fibres for regression and {tg["lower"]} of {tg["n"]} for the Transformer.')
    reverse_modes=[('zero','Zero change'),('velocity','Extend last-bin rate'),('repeat','Repeat previous change'),('spikes','Firing alone'),
                   ('mechanics','Mechanics alone'),('combined','Mechanics + firing')]
    rev_rows = [[label,*[native(v) for v in reverse['overall']['methods'][key]['mae']]] for key,label in reverse_modes]
    tables['REVERSE_MODELS']=table('Table 6. Exploratory held-fibre forecasts. Error in the next 20 ms change.',
                         ['Forecast','Force MAE (native units)','Position MAE (native units)'],rev_rows)
    def diffs(group,first,second):
        return [group['methods'][first]['mae'][i]-group['methods'][second]['mae'][i] for i in range(2)]
    signed_native=lambda x:f'{x:+.7f}'.replace('-','−')
    rev_deltas=[]
    for j,target in enumerate(['Tendon force','Actuator position']):
        d=reverse['conditional_by_output'][j]
        rev_deltas.append([target,f"{d['lower']} / {d['n']}",signed_native(d['minimum'])+' to '+signed_native(d['maximum']),signed_native(d['mean'])])
    tables['REVERSE_DELTA']=table('Table 7. Exploratory combined minus mechanics-only MAE, in each signal’s native units.',
        ['Output','Lower in fibres','Range of paired differences','Mean difference'],rev_deltas)
    prose['REVERSE_FINDING']=(f'Adding firing raised average force error and lowered average position error. Neither output improved across all three fibres. Extending the last measured rate gave a lower mean error than either fitted mechanics model on both outputs. '
       f'The secondary analysis retained all {short(reverse["overall"]["windows"])} eligible windows.')
    timing_stat=lagged['combined_beats_wrong_everywhere']
    tm=diffs(lagged['overall'],'combined','wrong_spikes')
    prose['REVERSE_TIMING']=(f'Across {short(lagged["overall"]["windows"])} matched cutoffs the MAE differences (correct minus earlier) were '
        f'{signed_native(tm[0])} native force units and {signed_native(tm[1])} native position units. '
        f'The all-fibre criterion was {yesno(timing_stat["force"])} for force and {yesno(timing_stat["position"])} for position.')
    prose['DISCUSSION'] = (f'Timing mattered to the fitted combined Transformer. A 100 ms shift of the mechanics worsened '
        'its spike-count deviance for every held fibre. Yet omitting the mechanics and training on the true firing histories '
        f'alone reduced mean absolute error by {f(joint["mae"]-hist["mae"])} spikes per 20 ms. Moving an input away from its '
        'proper time tests how an existing model uses it. Fitting a model without that input tests how much the other signals '
        'can already predict. Those experiments answer different questions.')
    return dict(prose=prose,tables=tables)
