# What can a stretch tell us about the next sensory spikes?

This is the complete editable source for the NeuroTranslation research note
about passive rat calf muscle stretches. To build the paper offline after
installing Python 3.10+, pypdf and Chromium, run:

    python build.py --out output

The resulting index.html, PDF and source ZIP can all be opened locally.
Use --html-only for the HTML and archive without a browser or pypdf.
The HTML carries its own typefaces. External reference links require
internet access. A working-tree-relative link to the forecast viewer is
for the published site; the paper also gives the absolute URL.

Edit paper.html.in for prose and style.css for layout. The build reads
group results in aggregate.json. The group values come from the score
tables and mechanical forecast outputs named by SHA-256 in the same file.
A change to the fitted models or source admission requires fresh scoring.
The ZIP contains aggregate results only. It rebuilds the manuscript, not
the archived physiological recordings. The linked companion supplies the
forecast model and its own documentation.

All three editions use the same manuscript. Publications, data and
software rights are listed in DATA-LICENCE.txt and the enclosed notices.
