"""Recreate the two figures from the attributed Ruhr example coordinates."""
import csv
import os
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import gridspec
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator

ROOT = Path(__file__).resolve().parent
plt.rcParams.update({"font.family":"Liberation Sans","font.size":11,"svg.fonttype":"none","svg.hashsalt":"ruhr-target-2026","axes.spines.top":False,"axes.spines.right":False,"axes.edgecolor":"#728a90","axes.labelcolor":"#294950","xtick.color":"#395559","ytick.color":"#395559","text.color":"#1a3539"})
COLORS = {1:"#11665e",5:"#b45026",9:"#28589a"}
data = {k:[] for k in COLORS}
with (ROOT / "ruhr-examples.csv").open() as f:
    for row in csv.DictReader(f):
        data[int(row["target"])].append([float(row[k]) if row[k] else np.nan for k in ("time_s","crossing_s","X_mm","Y_mm","Z_mm")])
data = {k:np.array(v) for k,v in data.items()}

def save(fig,name):
    fig.savefig(ROOT / name,format="svg",metadata={"Date":None},bbox_inches="tight",pad_inches=.13)
    plt.close(fig)

def paths(stacked=False):
    fig = plt.figure(figsize=(3.6,5.45) if stacked else (8.0,2.90))
    spec = (gridspec.GridSpec(2,1,height_ratios=[1.30,1],hspace=.43) if stacked
            else gridspec.GridSpec(1,2,width_ratios=[1.26,1],wspace=.40))
    left = fig.add_subplot(spec[0],projection="3d",proj_type="ortho")
    right = fig.add_subplot(spec[1])
    styles = {1:"-",5:"--",9:"-."}
    for target, values in data.items():
        t,c,x,y,z=values.T
        left.plot(x,y,z,styles[target],linewidth=2,color=COLORS[target])
        left.scatter(x[-1],y[-1],z[-1],s=26,color=COLORS[target],depthshade=False)
        sel=t>=c
        right.plot(t[sel]-c[sel],z[sel],styles[target],linewidth=1.9,color=COLORS[target], label=f"Target {target}")
    left.set(xlim=(-220,220),ylim=(-220,220),zlim=(-10,90),xticks=[-200,0,200],yticks=[-200,0,200],zticks=[0,80])
    left.set_box_aspect((440,440,100),zoom=1.12)
    left.view_init(elev=33,azim=-55)
    left.set_xlabel("X (mm)",labelpad=5);left.set_ylabel("Y (mm)",labelpad=4);left.set_zlabel("")
    left.text2D(.92,.58,"Z (mm)",transform=left.transAxes,color="#294950",fontsize=9)
    left.tick_params(labelsize=9,pad=0)
    for axis in [left.xaxis,left.yaxis,left.zaxis]:
        axis.pane.set_facecolor("#f8faf9")
    left.set_title("Measured paths in 3D",fontsize=12,fontweight="bold",pad=-2)
    right.set(xlabel="Seconds after crossing",ylabel="Z displacement (mm)",xlim=(0,.8),xticks=[0,.2,.4,.6,.8])
    right.yaxis.set_major_locator(MaxNLocator(nbins=5))
    right.grid(axis="y",color="#d8e3e1");right.legend(loc="upper right",frameon=False,fontsize=9, handlelength=2)
    right.set_title("One coordinate through time",fontsize=12,fontweight="bold",pad=9)
    save(fig,"object-paths-mobile.svg" if stacked else "object-paths.svg")

def clocks():
    c=float(data[5][0,1]);fig, ax=plt.subplots(figsize=(7.5,2.18))
    colors=["#27756d","#bd552a"]
    for y,t0,name in [(1.06,0.,"Acquisition"),(.13,c,"Crossing")]:
        ax.text(-.02,y+.27,name,fontsize=11,weight="bold",ha="left")
        ax.plot([0,.8],[y,y],lw=1.2,color="#a4b9b7")
        for t in (0,.05,.10,.15,.20):
            ax.scatter(t,y,s=28,facecolor=colors[0],edgecolor="white",linewidth=.5,zorder=3)
        for t in (.4,.6,.8):
            ax.scatter(t,y,marker="D",s=32 if t!=.6 else 56,facecolor=colors[1],edgecolor="white",linewidth=.4,zorder=3)
        for t in (0,.2,.4,.6,.8):
            ax.text(t,y-.16,f"{t0+t:.3f}",ha="center",va="top",fontsize=9)
    ax.set(xlim=(-.045,.845),ylim=(-.42,1.55));ax.axis("off")
    legend=[Line2D([0],[0],color=colors[0],marker="o",linestyle="",label="Observed input"),Line2D([0],[0],color=colors[1],marker="D",linestyle="",label="Forecast evaluated")]
    ax.legend(handles=legend,loc="upper right",ncol=2,frameon=False,bbox_to_anchor=(1,1.1),fontsize=9)
    fig.text(.51,.02,"Nominal times in seconds from the first usable camera frame",ha="center",fontsize=10)
    save(fig,"recording-clocks.svg")

if __name__=="__main__":
    paths();paths(stacked=True);clocks()
