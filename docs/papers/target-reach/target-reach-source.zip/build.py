"""Render the self-contained manuscript and attach its exact source archive to the PDF."""
import argparse
import base64
import hashlib
import html
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parent
TITLE = "Does knowing the target improve a reach forecast?"
FILES = ("article.html","style.css","ruhr-results.json","ruhr-examples.csv","object-paths.svg","object-paths-mobile.svg","recording-clocks.svg","figure.py","build.py","README.md")
CLOCKS = ("acquisition","crossing")
METHODS = (
    ("transformer_full","Transformer, motion and target"),
    ("transformer_pose_only","Transformer, motion only"),
    ("transformer_goal_only","Transformer, target only"),
    ("transformer_wrong_target","Full Transformer, wrong target"),
    ("goal_hand_mean","Mean for this target and hand"),
    ("stationary","Stay at the last position"),
    ("velocity","Continue at the last velocity"),
    ("ridge_full","Linear fit, motion and target"),
    ("ridge_pose_only","Linear fit, motion only"),
    ("ridge_goal_only","Linear fit, target only"),
    ("ridge_wrong_target","Full linear fit, wrong target"),
)
CONTRASTS = (
    ("transformer_pose_only","Motion only"),
    ("transformer_wrong_target","Wrong target"),
    ("transformer_goal_only","Target only"),
    ("goal_hand_mean","Target and hand mean"),
    ("ridge_full","Full linear fit"),
)

def table(title, heads, rows):
    tr = lambda cells:"<tr>"+"".join(cells)+"</tr>"
    h = tr([f'<th scope="col">{html.escape(x)}</th>' for x in heads])
    rs = []
    for label,*cells in rows:
        rs.append(tr([f'<th scope="row">{html.escape(label)}</th>',*(f'<td>{html.escape(x)}</td>' for x in cells)]))
    return f'<table><caption>{html.escape(title)}</caption><thead>{h}</thead><tbody>{"".join(rs)}</tbody></table>'

def metric(metres, clock, signed=False):
    digits=4 if clock=="acquisition" else 2
    return format(metres*1000,("+" if signed else "")+f".{digits}f").replace("-","−")

def figure(name, alt):
    data=base64.b64encode((ROOT/name).read_bytes()).decode()
    return f'<img alt="{html.escape(alt)}" src="data:image/svg+xml;base64,{data}">'

def render():
    results = json.loads((ROOT/"ruhr-results.json").read_text())
    g={clock:results[clock]["groups"]["600/both"] for clock in CLOCKS}
    def score(c,key):return g[c]["scores"][key]["mean_m"]
    def paired(c,key):
        effect = g[c]["comparisons"][key]
        estimate = metric(effect["mean_m"],c,True)
        lo,hi = [metric(x,c,True) for x in effect["ci"]]
        return f"{estimate} [{lo}, {hi}]"
    assert not any(results[k]["incremental_gate"] for k in CLOCKS)
    assert all(g["crossing"]["comparisons"][k]["ci"][1]<0 for k in ("transformer_wrong_target","goal_hand_mean","transformer_goal_only"))
    assert g["crossing"]["comparisons"]["transformer_pose_only"]["ci"][1]>0
    summary = ('<p class="response">Between 200 and 600 ms on the acquisition clock the object shifted just 0.117 mm on average. The full model missed by 0.118 mm, and movement alone by 0.114 mm. Once the object had travelled at least 15 mm, the model using both movement and target missed by <strong>'
               f'{score("crossing","transformer_full")*1000:.1f} mm</strong>. Exchanging the target for a wrong one increased that error to {score("crossing","transformer_wrong_target")*1000:.1f} mm. Yet a separately trained model given the motion alone missed by {score("crossing","transformer_pose_only")*1000:.1f} mm. The observed movement carried most of what was needed for this forecast.</p>')
    mean = ('<p class="response">After the crossing, the average path for the assigned hand and target missed the measured position by '
            f'{score("crossing","goal_hand_mean")*1000:.1f} mm. Adding the five observed positions to the target reduced the error by about {abs(g["crossing"]["comparisons"]["goal_hand_mean"]["mean_m"])*1000:.1f} mm. Knowing the destination leaves room for considerable variation in how far a person has travelled by a given time.</p>')
    models=table("Table 1. Average 3D error at 600 ms (mm).",["Forecast","Acquisition","Crossing"],[[label,*(metric(score(c,key),c) for c in CLOCKS)] for key,label in METHODS])
    diffs=table("Table 2. Full Transformer minus comparison at 600 ms (mm).",["Comparison","Acquisition","Crossing"],[[label,*(paired(c,key) for c in CLOCKS)] for key,label in CONTRASTS])
    judgment='<p>The primary criterion failed. Motion alone did slightly better in the early acquisition window. After the crossing, a wrong target made the fitted model worse, yet the interval for full minus motion-only included zero. The data support using early motion when the goal is known. They leave the incremental benefit of giving the correct goal to a motion model unresolved.</p>'
    hands=[]
    for c in CLOCKS:
        for ms in ("400","600","800"):
            label=c.capitalize()+", "+ms
            scores=[metric(results[c]["groups"][ms+"/"+side]["scores"]["transformer_full"]["mean_m"],c) for side in ("left","right","both")]
            hands.append([label,*scores])
    hands=table("Table 3. Full-model error (mm) by clock and endpoint (ms).",["Clock, endpoint","Left","Right","Both"],hands)
    def seedtext(c):
        vals=g[c]["scores"]["transformer_full"]["by_fit_m"]
        return ", ".join(metric(x,c) for x in vals)
    seeds=(f'<p>Fitting the full model three times gave 600 ms acquisition errors of {seedtext("acquisition")} mm and crossing errors of {seedtext("crossing")} mm, in seed order 17, 41, 73. The seeds reproduce variation from how the model started training. They add no people to the sample.</p>')
    def ind(clock,key,person):
        return metric(g[clock]["comparisons"][key]["person"][person],clock,True)
    people=table("Table 4. Within-person differences at 600 ms (mm).",["Person","Acq. vs motion","Acq. vs wrong","Cross. vs motion","Cross. vs wrong"],[[s,*[ind(c,k,s) for c in CLOCKS for k in ("transformer_pose_only","transformer_wrong_target")]] for s in "ABCDEFG"])
    coverage=('<p>Of 864 selected development trials, 40 carried publisher optical exclusions and 824 supported all endpoints on both clocks. Of 252 selected test trials, 13 carried the same type of exclusion. All remaining 239 had a detected crossing and all supplied acquisition-clock endpoints (114 left, 125 right). After the crossing one left-hand trial lacked a complete input history. One further left-hand trial lacked all three endpoints, leaving 237 (112 left, 125 right) at each horizon. We made no substitutions. The seven people contributed to every reported hand and horizon.</p>')
    gesture=('<p>In NEMO-Lowlands, the prompt was a word and picture naming an object. People improvised how to depict it. In our separate Lowlands test, 100 first attempts across 22 archive groups covered 33 concepts. Using early pose and concept, the model missed subsequent wrist displacement relative to the same-side shoulder by 55.80 mm, averaged across wrists and groups. Motion alone missed by 56.01 mm. Their paired difference was −0.22 mm (95% interval −3.79 to +3.49). Swapping the concept gave a difference of +0.38 mm (−1.45 to +2.27, full minus swapped). Staying still did better at 41.35 mm. The recording-relative endpoint followed the last input by a median 0.842 s. Neither gesture comparison established a benefit from supplying the object label. The archive grouping cannot verify independent people, and the combined prompt cannot isolate an effect of words. Neither experiment tested sentences.</p>')
    paths = figure("object-paths.svg","Three measured paths diverge in the camera frame. A second plot shows the Z coordinate across the 0.8 seconds after the crossing for targets 1, 5 and 9.")
    mobile=base64.b64encode((ROOT/"object-paths-mobile.svg").read_bytes()).decode()
    paths=f'<picture><source media="screen and (max-width: 600px)" srcset="data:image/svg+xml;base64,{mobile}">{paths}</picture>'
    clock = figure("recording-clocks.svg","In one trial, five acquisition input samples end at 0.200 s and the middle endpoint falls at 0.600 s. The crossing clock starts at 4.548 s, its last input is at 4.748 s and its middle endpoint is at 5.148 s.")
    text=(ROOT/"article.html").read_text()
    for name,value in {"style":(ROOT/"style.css").read_text(),"paths":paths,"clock":clock,"summary":summary,"mean_explanation":mean,"models":models,"differences":diffs,"judgment":judgment,"hands":hands,"seeds":seeds,"individuals":people,"coverage":coverage,"gesture":gesture}.items():
        token="@@"+name+"@@"
        if text.count(token)!=1:raise ValueError(token)
        text=text.replace(token,value)
    return text

def build(out,html_only):
    out.mkdir(exist_ok=True,parents=True)
    manuscript=render()
    (out/"index.html").write_text(manuscript)
    archive=out/"target-reach-source.zip"
    with ZipFile(archive,"w") as z:
        for name in FILES:
            item=ZipInfo(name,date_time=(2026,11,21,0,0,0))
            item.create_system=3;item.external_attr=0o100644<<16
            z.writestr(item,(ROOT/name).read_bytes(),compress_type=ZIP_DEFLATED)
    if html_only:return
    from pypdf import PdfReader, PdfWriter
    from pypdf.generic import ArrayObject, ByteStringObject
    browser=shutil.which("chromium") or shutil.which("google-chrome")
    if not browser:raise RuntimeError("Install Chromium to build the PDF.")
    with tempfile.TemporaryDirectory() as temp:
        temp=Path(temp);page=temp/"manuscript.html";pdf=temp/"printed.pdf"
        page.write_text(manuscript)
        subprocess.run([browser,"--headless","--disable-gpu","--disable-background-networking","--no-pdf-header-footer",f'--user-data-dir={temp/"profile"}',f"--print-to-pdf={pdf}",page.as_uri()],capture_output=True,check=True,timeout=90)
        writer=PdfWriter(clone_from=PdfReader(pdf))
        writer.metadata={"/Title":TITLE,"/Author":"NeuroTranslation","/Subject":"Forecasts of the three-dimensional motion of a hand-held cylinder"}
        writer.add_attachment(archive.name,archive.read_bytes())
        identity=ByteStringObject(hashlib.sha256(archive.read_bytes()).digest()[:16])
        writer._ID=ArrayObject([identity,identity])
        writer.write(out/"target-reach.pdf")

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out",type=Path,default=ROOT/"output")
    parser.add_argument("--html-only",action="store_true")
    a=parser.parse_args();build(a.out,a.html_only)
