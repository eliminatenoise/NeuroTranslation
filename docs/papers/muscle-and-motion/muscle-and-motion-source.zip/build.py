"""Build the muscle-and-motion paper and its attached reproducible source."""
import argparse
import base64
import hashlib
from html import escape
import json
from pathlib import Path
import shutil
import subprocess
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

SOURCE = Path(__file__).resolve().parent
NOTICES = ('DATA-LICENCE.txt', 'CC0-1.0.txt', 'Liberation-font-LICENSE.txt')
FONTS = (('Regular', 'normal', 400), ('Bold', 'normal', 700), ('Italic', 'italic', 400))
MEMBERS = ('README.md', 'paper.html.in', 'style.css', 'scores.json', 'build.py',
           *NOTICES, *(f'LiberationSans-{name}.ttf' for name, _, _ in FONTS))


def typography():
    faces = []
    for name, style, weight in FONTS:
        font = (SOURCE / f'LiberationSans-{name}.ttf').read_bytes()
        encoded = base64.b64encode(font).decode('ascii')
        faces.append(f'@font-face{{font-family:PaperSans;src:url(data:font/ttf;base64,{encoded}) format("truetype");'
                     f'font-weight:{weight};font-style:{style};}}')
    return '\n'.join(faces) + (SOURCE / 'style.css').read_text()


def table(headings, rows, caption):
    heading = ''.join(f'<th scope="col">{escape(label)}</th>' for label in headings)
    body = []
    for label, values in rows:
        cells = ''.join(f'<td data-label="{escape(title)}">{escape(value)}</td>'
                        for title, value in zip(headings[1:], values, strict=True))
        body.append(f'<tr><th scope="row">{escape(label)}</th>{cells}</tr>')
    return (f'<table class="scores" aria-label="{escape(caption)}"><thead><tr>{heading}</tr></thead>'
            f'<tbody>{"".join(body)}</tbody></table>')


NEURAL_UNITS = ('muscle_mae_uv', 'path_mean_distance_mm', 'endpoint_distance_mm')
LINEAR_UNITS = ('emg_mae_uv', 'path_error_mm', 'endpoint_error_mm')


def format_scores(scores, keys):
    return [f'{scores[k]:.3f}' for k in keys]


def sign(value):
    return f'{value:+.3f}'.replace('-', '−')


def forest(comparison):
    panels = ((NEURAL_UNITS[0], 'Muscle amplitude (µV)', (-.1, .25), (-.1, 0, .1, .2)),
              (NEURAL_UNITS[1], 'Sacrum path (mm)', (-.02, .06), (-.02, 0, .02, .04, .06)))
    plot = ['<svg viewBox="0 0 620 132" role="img" aria-labelledby="forest-title forest-desc">',
            '<title id="forest-title">Shared model minus specialist error</title>',
            '<desc id="forest-desc">Paired means and 95% confidence intervals in separate physical units. The interval crosses zero for muscle amplitude and lies above zero for path error.</desc>']
    mobile = []
    for i, (key, title, limits, ticks) in enumerate(panels):
        result = comparison[key]
        start = 12 + 315*i
        x = lambda n: start + 8 + (n-limits[0])/(limits[1]-limits[0])*263
        plot.append(f'<text x="{start}" y="17" font-weight="700">{title}</text>')
        for tick in ticks:
            px = x(tick)
            col = '#37564e' if tick == 0 else '#d4dfdb'
            label = f'{tick:g}'.replace('-', '−')
            plot.append(f'<line x1="{px}" x2="{px}" y1="32" y2="82" stroke="{col}"/>'
                        f'<text x="{px}" y="103" text-anchor="middle">{label}</text>')
        lo, hi = result['ci95']
        plot.append(f'<path d="M{x(lo)} 50 v14 M{x(lo)} 57 H{x(hi)} M{x(hi)} 50 v14" fill="none" stroke="#15665c" stroke-width="3"/>'
                    f'<circle cx="{x(result["mean"])}" cy="57" r="5" fill="#114e45"/>')
        mobile.append(f'<li><strong>{title}</strong>{sign(result["mean"])} [{sign(lo)}, {sign(hi)}]</li>')
    plot.append('<text x="310" y="131" text-anchor="middle">Shared minus specialist error</text></svg>')
    return ''.join(plot) + '<ul class="plot-small">' + ''.join(mobile) + '</ul>'


def fields(data):
    coverage = []
    for split,label in [('development','Development'), ('assessment','Historical assessment')]:
        totals = data['coverage'][split]
        for key, posture in [('rotatestand','standing'),('rotatewalk','walking')]:
            c = totals['by_posture'][key]
            direction = c['retained_by_direction']
            coverage.append((f'{label} · {posture}', [str(c['qualifying_people']), f"{c['original_rotations']:,}",
                             f"{c['retained']:,}", f"{direction['-1']:,} / {direction['1']:,}"]))
    neural = data['transformer_and_controls']
    linear = data['core_assess']['primary']['methods']
    rows = []
    for k, label in [('context_mean','Mean by posture and tilt'), ('hold_position','Recent RMS · no movement'),
                     ('persistence','Recent RMS · repeat path'), ('velocity16','Recent RMS · continue velocity'),
                     ('pooled','Pooled linear model'), ('motion_signal','Linear · motion history¹')]:
        rows.append((label,format_scores(linear[k],LINEAR_UNITS)))
    rows.extend((name,format_scores(neural[k]['scores'],NEURAL_UNITS)) for k,name in
                [('joint','Joint Transformer'),('specialists','Two specialists')])
    standing = data['core_assess']['postures']['standing']['methods']
    stand_neural = data['standing_transfer']['scores']
    transfer = [(label,format_scores(standing[k], LINEAR_UNITS[:2])) for k,label in
                [('walk_only','Linear · walking only'),('stand_limited','Linear · early standing only'),
                 ('adapted_walk','Linear · walking + early standing'),('stand_only','Linear · all standing only')]]
    transfer.extend((label,format_scores(stand_neural[k]['scores'],NEURAL_UNITS[:2])) for k,label in
                    [('walk','Neural · walking only'),('adapt_heads','Neural · adapt output layers'),
                     ('adapt_full','Neural · adapt all weights'),('stand_640','Neural · standing only, 640 updates'),
                     ('stand_1280','Neural · standing only, 1,280 updates'),('mixed','Neural · mixed postures')])
    return {'STYLE': typography(), 'FOREST':forest(data['contrasts']['joint_minus_specialists']['differences']),
            'COVERAGE': table(('Group and task','People','Logged','Retained','CCW / CW retained'),coverage,'Rotations retained by task, split and direction'),
            'BENCHMARK': table(('Forecast','Muscle (µV)','Path (mm)','Final (mm)'),rows,'Historical assessment errors'),
            'STANDING':table(('Training data and method','Muscle (µV)','Path (mm)'),transfer,'Standing assessment errors')}


def build(out, browser):
    data = json.loads((SOURCE / 'scores.json').read_text())
    html = (SOURCE / 'paper.html.in').read_text()
    for page in range(1, 7):
        header = f'<header><span>NeuroTranslation · Muscle and motion</span><span>{page} / 6</span></header>'
        html = html.replace('@@FOLIO@@', header, 1)
    for key, value in fields(data).items():
        token = f'@@{key}@@'
        if html.count(token) != 1:
            raise ValueError(f'Missing or repeated manuscript field {key}')
        html = html.replace(token, value)
    if '@@' in html:
        raise ValueError('Unresolved manuscript field')
    out.mkdir(parents=True, exist_ok=True)
    page = out / 'index.html'
    page.write_text(html, encoding='utf-8')
    archive = out / 'muscle-and-motion-source.zip'
    with ZipFile(archive, 'w') as bundle:
        for name in MEMBERS:
            info = ZipInfo(name, (2026, 11, 21, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = ZIP_DEFLATED
            bundle.writestr(info, (SOURCE / name).read_bytes())
    if browser:
        print_pdf(page, archive, browser)


def print_pdf(page, archive, browser):
    from pypdf import PdfReader, PdfWriter
    from pypdf.generic import ArrayObject, ByteStringObject
    with TemporaryDirectory() as directory:
        temp = Path(directory)
        raw = temp / 'print.pdf'
        subprocess.run([browser, '--headless', '--disable-gpu', '--disable-background-networking',
                        '--no-first-run', '--no-default-browser-check', '--no-pdf-header-footer',
                        f'--user-data-dir={temp/"profile"}', f'--print-to-pdf={raw}', page.as_uri()],
                       check=True, capture_output=True, timeout=90)
        reader = PdfReader(raw)
        if len(reader.pages) != 6:
            raise ValueError(f'Expected six pages, found {len(reader.pages)}')
        writer = PdfWriter(clone_from=reader)
        writer.metadata = {'/Title': 'Can one model forecast leg-muscle activity and pelvic motion?',
                           '/Author': '@eliminatenoise', '/Subject': 'Paired lower-leg surface EMG amplitudes and a 32-sample sacrum trajectory during standing and walking'}
        for file in [archive, *(SOURCE / name for name in NOTICES)]:
            writer.add_attachment(file.name, file.read_bytes())
        identity = ByteStringObject(hashlib.sha256(archive.read_bytes()).digest()[:16])
        writer._ID = ArrayObject([identity, identity])
        writer.write(page.with_name('muscle-and-motion.pdf'))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=SOURCE / 'output')
    parser.add_argument('--browser', help='Path to Chrome or Chromium')
    parser.add_argument('--html-only', action='store_true')
    args = parser.parse_args()
    browser = None if args.html_only else args.browser or shutil.which('chromium') or shutil.which('google-chrome')
    if not args.html_only and browser is None:
        parser.error('Install Chromium or pass its path with --browser.')
    build(args.out.resolve(), browser)
