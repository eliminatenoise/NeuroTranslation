# Can one model forecast leg-muscle activity and pelvic motion?

The source rebuilds the six-page NeuroTranslation paper from its manuscript, styles, group results and original figure. The PDF embeds a copy of this archive and three rights notices. A separate download serves readers whose PDF viewers hide attachments. The [paper page](https://eliminatenoise.github.io/NeuroTranslation/papers/muscle-and-motion/) contains both downloads.

## Reproduce the manuscript

Extract every member to one directory. Install Python, Chromium or Google Chrome, and pypdf. From the extracted directory run

    python -m pip install pypdf==6.21.2
    python build.py --out output

Open output/index.html or output/muscle-and-motion.pdf. To specify a browser executable, pass its path with --browser. To build only the standalone HTML and ZIP with Python’s standard library, pass --html-only. The PDF build was tested on Linux with Python 3.14.8, pypdf 6.21.2 and Chromium 155.0.8059.84. Rebuilding needs no internet after the software is installed. Rendering engines can differ across versions.

## Reproduce the measurements and models

Start with [Peterson and Ferris’s versioned OpenNeuro recordings](https://doi.org/10.18112/openneuro.ds003739.v1.0.3). The [Transformer package](https://eliminatenoise.github.io/NeuroTranslation/muscle-and-motion/) and [linear controls](https://eliminatenoise.github.io/NeuroTranslation/muscle-motion-controls/) provide the model readers and corresponding reproduction materials. The [atlas](https://eliminatenoise.github.io/Interoceptomics/muscle-and-motion/) illustrates the two tasks with the first eligible recorded event from the standing and walking sessions of one development participant. The paper uses the full study’s aggregate scores. No individual measurements are necessary to rebuild it.

The coverage field in scores.json describes the original rotations, retained events, and overlapping quality flags. A separate count uses the first reason for each rejection. The exposure field counts the people, sessions and events seen by the linear fits. The development_neural, core_dev and core_assess fields contain the grouped neural development and linear development/assessment results. The transformer_and_controls, contrasts and wrong_event sections contain assessment errors and paired comparisons for the two-posture neural forecast. standing_transfer distinguishes the walking model, two adaptations and same-standing-data controls. cross_model contains secondary cross-family outcome contrasts. Positive joint-minus-specialist differences mean more error for the shared model. Each reported interval uses resamples of whole people.

## Attribution

Steven M. Peterson and Daniel P. Ferris recorded the dataset. See the [methods paper](https://doi.org/10.1016/j.dib.2021.107635) and [original balance paper](https://doi.org/10.1523/ENEURO.0207-18.2018). DATA-LICENCE.txt credits the authors. The original manuscript, figure, aggregate materials and build code use CC0 1.0 to the extent of NeuroTranslation’s rights. CC0-1.0.txt contains the terms. The unmodified Liberation Sans regular, bold and italic faces use SIL Open Font License 1.1, as detailed in Liberation-font-LICENSE.txt.
