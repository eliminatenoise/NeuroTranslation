# What can the shin tell us about the next pedal reading?

A NeuroTranslation research supplement on AnkleImage Task 1. The question is whether electrical activity measured over the tibialis anterior helps predict a signed change in a seated volunteer’s pedal load, once past loading and the apparatus setting are available. The study measured prediction error in the recorded channel’s native units.

## Read or rebuild offline

Extract the archive. From the extracted folder, run:

```sh
python build.py --html-only
```

Open `output/index.html` directly in a browser. It contains the complete manuscript, figures and tables. To build the matching A4 PDF, use Python 3.10 or newer with pypdf, Chromium or Chrome, and the Liberation Sans font:

```sh
python -m pip install pypdf
python build.py --browser /path/to/chromium
```

The PDF also carries the complete source ZIP and both licence texts as attachments. A web server, network connection and model weights are unnecessary for reading or building the paper. The full build tested on Linux used Python 3.14, pypdf 6.21.2, Chromium 155 and Liberation Sans. Exact binary reproduction depends on the browser, PDF library, compression library and fonts. Paper HTML and the archive use Python’s standard library. Each member has fixed order, permissions and date. The source comprises the manuscript template, style sheet, full-precision aggregate scores, figure and table generator, these instructions and the two legal texts. No participant time series accompanies it.

## Forecast

At zero-based cutoff i, take the last 201 successive values of each selected channel through i. The outcome is load[i+100] − load[i] on the qualified nominal 1 kHz series. Start at i=200 and advance 100 positions at a time. Require the 301 positions within one recording, finite histories and endpoint, and a regular elapsed index wherever supplied. For a file that omitted time, the nominal labels come from row / 1,000. This cannot independently verify the physical duration or continuity of those intervals. For a pair of trials used by the specialist, require a qualified other-trial donor at the same cutoff for the wrong-history comparison. Its other-trial control recomputes all EMG summaries and interaction terms with unchanged recipient loading. The shared model uses the donor’s eligible cutoff rank, rounded down after multiplying the recipient rank by the ratio of donor to recipient window counts. The offline controls use a second recording. Neither method fits to assessment participants.

## Model settings

**Specialist.** Ten inclusive 21-value bins summarize 20 intervals each. Their eight columns are endpoint load, within-bin load change, endpoint load relative to the start of the full window, binary pedal setting, raw EMG mean, EMG population standard deviation, root-mean-square successive EMG difference, and the product of EMG standard deviation with within-bin load change. All continuous columns are standardized by training-only weighted mean and population standard deviation and clipped to ±8. A scale below 10⁻¹² becomes one. Training also standardizes the target, and inference returns it to recorded units. Masked variants zero the unavailable standardized features. The Transformer has learned positions, width 12, two heads, one block, a 24-unit ReLU feedforward layer and a last-token scalar readout. Seed 6731, 96 full-batch AdamW updates, learning rate 0.002, weight decay 0.01 and smooth L1 loss with threshold one are held fixed. Ridge controls flatten the three standardized load columns per bin and can append the binary setting. Their slope penalty is 0.01 with unpenalized intercept. The typical-change controls use balanced training medians.

**Shared encoder.** The four bins each span 50 intervals and include both endpoints. Load features are the ending level, net change, and the difference between mean load and the midpoint of the endpoint readings. The three EMG features are the two ending exponential envelopes and the bin-average rectified EMG. The envelopes start at the first absolute EMG sample within the window. Each update moves 1 − exp(−1/τ) of the way from the previous value to the current absolute reading, for τ of 25 and 80 nominal intervals. Flat bins, the last 100-interval load change and the binary setting enter the readout. The shared model also includes the final 24-element representation of the pretrained frozen movement Transformer. Remove that vector for the direct linear comparator. The fitted correction to recent change uses balanced weighted ridge with slope penalty 0.05, an unpenalized intercept and training-only standardization. The control encoder uses the pretrained architecture with its fixed random-initialization rule. A separate setting-omission comparison uses a load-only history. No trial identity, future-assisted filter, full-trial baseline or peak scaling enters ordinary inference.

**First-order relaxation.** Write α=1−exp(−100/150). Fit an equilibrium level E by ridge to L[i]+y/α at training cutoffs, where y is the subsequent load change. Predict α×(E−L[i]). One fit uses binary setting alone. The other also uses the final fast and slow envelopes and the changes in each over the previous 100 intervals. These fitted equilibria have recorded load-channel units. The 150, 25 and 80 nominal intervals are engineering choices. No physiological time constant is estimated.

**Tests.** The two groups of two participants and both model families were chosen before fitting to reserved cases. The complete, equal-settings paired decision for the designated two-person assessment requires both trials and the specified controls in both conditions. Results from the complete participant, the second participant’s valid two-trial setting and that participant’s remaining qualified single trial are descriptive. See the manuscript for unqualified data and recorded counts. The specialist development score gives equal weight to each person and setting and pools the windows within that person–setting cell. The shared-model development score gives equal weight to trials within each cell before averaging their windows. Both families’ descriptive reserved groups average trials equally within a setting, then average settings equally when both exist. Trials within every complete reserved pair have equal counts. Mean absolute error is the average of absolute differences between predicted and observed signed change. Relative error reduction, when shown, equals (control MAE − matched MAE) / control MAE. A positive value favours the model receiving the matched muscle trace.

## Sources, attribution and rights

Qiang Zhang, Noor Hakam, Oluwasegun Akinniyi, Ashwin Iyer, Xuefeng Bao and Nitin Sharma (2024). *AnkleImage – An ultrafast ultrasound image dataset to understand the ankle joint muscle contractility.* Scientific Data 11, 1439. [Article and apparatus description](https://doi.org/10.1038/s41597-024-04285-x). The article uses [CC BY-NC-ND 4.0](https://creativecommons.org/licenses/by-nc-nd/4.0/).

The same authors deposited [AnkleImage, BioImage Archive S-BIAD1482](https://doi.org/10.6019/S-BIAD1482) under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). This study selected Task 1 records, calculated lagged changes, fitted forecasting models and summarized errors. Article figures were not copied or adapted. Project text, code and original diagrams use [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/).

[Pedal specialist](https://eliminatenoise.github.io/NeuroTranslation/pedal-load/) · [Shared forecasting model](https://eliminatenoise.github.io/NeuroTranslation/shared-pedal-load/) · [Interoceptomics pedal atlas](https://eliminatenoise.github.io/Interoceptomics/pedal-load/).
