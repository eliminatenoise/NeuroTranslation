"""Rebuild the paper, figures and deterministic source archive from aggregate errors."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parent
TITLE = "What can the shin tell us about the next pedal reading?"
SOURCE_FILES = ("README.md", "build.py", "paper.html.in", "style.css", "scores.json",
                "CC-BY-4.0.txt", "CC0-1.0.txt")
COHORTS = ("development", "four_trials", "angle5_pair", "neutral_single")
METHODS = {
    "specialist": (
        ("zero", "Assume zero change"), ("continue", "Repeat recent change"),
        ("typical", "Typical change in training"), ("typical_condition", "Typical change at setting"),
        ("ridge_load", "Linear ridge, load"), ("ridge_condition", "Linear ridge, load + setting"),
        ("load", "Transformer, load"), ("load_condition", "Transformer, load + setting"),
        ("emg_condition", "Transformer, EMG + setting"), ("full", "Transformer, all inputs"),
        ("wrong", "Same fit, other trial’s EMG")),
    "shared": (
        ("hold", "Assume zero change"), ("recent", "Repeat recent change"),
        ("setting_median", "Typical change at setting"), ("relaxation_setting", "Relaxation, setting"),
        ("relaxation_emg", "Relaxation, EMG + setting"), ("linear_load", "Direct linear, load + setting"),
        ("linear_both", "Direct linear, all inputs"), ("shared_load_no_setting", "Shared encoder, load"),
        ("shared_load", "Shared encoder, load + setting"), ("shared_both", "Shared encoder, all inputs"),
        ("wrong_both", "Same fit, other trial’s EMG"), ("random_both", "Random encoder, all inputs"))
}


def comparison_table(data, family):
    columns = [data[key] for key in COHORTS]
    heads = ("Dev.", "Complete<br>four trials", "Other person<br>angle5 pair", "Other person<br>neutral single")
    header = ''.join(f'<th scope="col">{label}<span class="count">{col["windows"]} windows</span></th>'
                     for label, col in zip(heads, columns))
    body = []
    for key, label in METHODS[family]:
        row = []
        for col in columns:
            value = col[family][key]
            row.append('<td aria-label="Unavailable">—</td>' if value is None else f'<td>{value:.4f}</td>')
        attr = ' class="full"' if key in ("full", "shared_both") else ''
        body.append(f'<tr{attr}><th scope="row">{label}</th>{"".join(row)}</tr>')
    return f'<table class="scores"><thead><tr><th scope="col">Forecast</th>{header}</tr></thead><tbody>{"".join(body)}</tbody></table>'


def chart(group):
    rows = (
        ("Repeat recent change", "specialist", "continue", "repeat"),
        ("Specialist · load + setting", "specialist", "load_condition", "load"),
        ("Matched muscle history", "specialist", "full", "matched"),
        ("Other trial’s muscle history", "specialist", "wrong", "swapped"),
        ("Shared · load + setting", "shared", "shared_load", "load"),
        ("Matched muscle history", "shared", "shared_both", "matched"),
        ("Other trial’s muscle history", "shared", "wrong_both", "swapped"))
    maximum = math.ceil(max(group[f][k] for _, f, k, _ in rows) * 50) / 50
    parts = []
    for label, family, key, shade in rows:
        value = group[family][key]
        parts.append(f'<div class="chartrow"><span>{label}</span><div class="track" aria-hidden="true">'
                     f'<div class="bar {shade}" style="width:{value/maximum*100:.8f}%"></div></div>'
                     f'<span class="value">{value:.4f}</span></div>')
    ticks = (f'<div class="chartrow scale"><span>Recorded units</span><div class="ticks">'
             f'<span>0</span><span>{maximum/2:.2f}</span><span>{maximum:.2f}</span></div><span></span></div>')
    return '<div class="chart">' + ''.join(parts) + ticks + '</div>'


def build(out):
    data = json.loads((ROOT / "scores.json").read_text(encoding="utf-8"))
    template = (ROOT / "paper.html.in").read_text(encoding="utf-8")
    for i in range(1, 7):
        header = f'<header class="folio"><span>NeuroTranslation / Fixed-pedal load</span><span>{i} / 6</span></header>'
        template = template.replace("@@FOLIO@@", header, 1)
    slots = {"STYLE": (ROOT / "style.css").read_text(encoding="utf-8"),
             "CHART": chart(data["four_trials"]), "SPECIAL_TABLE": comparison_table(data, "specialist"),
             "SHARED_TABLE": comparison_table(data, "shared")}
    for key, value in slots.items():
        marker = "@@" + key + "@@"
        if template.count(marker) != 1:
            raise ValueError(f"Expected one {marker}")
        template = template.replace(marker, value)
    if "@@" in template:
        raise ValueError("Unfilled manuscript slot")
    out.mkdir(parents=True, exist_ok=True)
    (out / "index.html").write_text(template, encoding="utf-8")
    archive = out / "pedal-load-source.zip"
    with ZipFile(archive, "w") as zipped:
        for name in SOURCE_FILES:
            info = ZipInfo(name, date_time=(2026, 11, 21, 0, 0, 0))
            info.create_system = 3
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            zipped.writestr(info, (ROOT / name).read_bytes())
    return archive


def print_pdf(out, archive, browser):
    from pypdf import PdfReader, PdfWriter
    from pypdf.generic import ArrayObject, ByteStringObject
    with TemporaryDirectory() as temp:
        work = Path(temp)
        raw = work/"pages.pdf"
        subprocess.run([browser, "--headless", "--disable-gpu", "--disable-background-networking",
                        "--no-first-run", "--no-default-browser-check", "--no-pdf-header-footer",
                        f"--user-data-dir={work/'profile'}", f"--print-to-pdf={raw}",
                        (out/"index.html").as_uri()], check=True, capture_output=True, timeout=90)
        reader = PdfReader(raw)
        if len(reader.pages) != 6:
            raise ValueError(f"Expected six A4 pages, got {len(reader.pages)}")
        writer = PdfWriter(clone_from=reader)
        writer.metadata = {"/Title": TITLE, "/Author": "@eliminatenoise",
                           "/Subject": "Forecasting the change in a fixed pedal’s load-cell reading over 100 positions on a nominal 1 kHz series"}
        for name in ("CC-BY-4.0.txt", "CC0-1.0.txt"):
            writer.add_attachment(name, (ROOT/name).read_bytes())
        writer.add_attachment(archive.name, archive.read_bytes())
        identity = ByteStringObject(hashlib.sha256(archive.read_bytes()).digest()[:16])
        writer._ID = ArrayObject([identity,identity])
        writer.write(out/"pedal-load.pdf")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT/"output")
    parser.add_argument("--browser", help="Path to Chrome or Chromium for the PDF")
    parser.add_argument("--html-only", action="store_true", help="Build only HTML and the source archive")
    args = parser.parse_args()
    out = args.out.resolve()
    archive = build(out)
    if not args.html_only:
        browser = args.browser or shutil.which("chromium") or shutil.which("google-chrome")
        if not browser:
            parser.error("Supply --browser with the path to a Chrome or Chromium executable.")
        print_pdf(out, archive, browser)
