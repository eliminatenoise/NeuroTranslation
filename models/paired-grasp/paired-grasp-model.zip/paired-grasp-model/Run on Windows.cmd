@echo off
setlocal
set OPENBLAS_NUM_THREADS=1
set OMP_NUM_THREADS=1
set MKL_NUM_THREADS=1
set VECLIB_MAXIMUM_THREADS=1
python -c "import numpy" >nul 2>nul
if not errorlevel 1 goto runPython
py -3 -c "import numpy" >nul 2>nul
if not errorlevel 1 goto runPy
echo Open this folder with a Python 3 environment that has NumPy installed.
set result=1
goto done
:runPython
python -B "%~dp0grasp.py" %*
set result=%errorlevel%
goto done
:runPy
py -3 -B "%~dp0grasp.py" %*
set result=%errorlevel%
:done
if "%~1"=="" pause
exit /b %result%
