# Forecast the next 20 milliseconds of a grasp

As a macaque grips a sliding object, sensors on the apparatus register the contact and the object's travel. A cortical array records electrical spikes on the same clock. This offline NeuroTranslate preview takes the previous 100 milliseconds from both instruments and makes two forecasts. How much will each of six sensor readings change? How many spikes will each of 93 sorted cortical units produce?

The example uses invented readings. The weights come from a fit to one recording of a rhesus macaque using her left hand, Brochier L session `l101210-001`. Each neural column belongs to a particular electrode and sorting label in that session. The model's evidence covers that recording and task. [Recording and credits](https://doi.gin.g-node.org/10.12751/g-node.f83565/)

## Run the example

Extract the complete ZIP. Use a Python 3 environment with NumPy installed. If you need the dependency, install NumPy in your chosen environment first with `python -m pip install numpy`. The forecast then runs offline from the extracted folder.

On Windows, open **Run on Windows.cmd**. On macOS, open **Run on macOS.command**. On Linux, run **Run on Linux.sh** from a terminal. If an archive extractor drops the executable bit, run the macOS or Linux launcher with `sh`. You can also call Python directly.

```sh
python grasp.py
python grasp.py --input synthetic-example.json --seed 431 --json
```

The short display gives the change in the moving object's sensor and the expected count for electrode 3, unit 1. A positive change means the forecast sensor reading exceeds its last observed value. An expected count can be fractional. The JSON output gives all six sensor changes and all 93 expected counts for each input window. It carries the input origin and column labels with the predictions.

## Compare the fits

Each checkpoint contains the same frozen, seven-task temporal Transformer and four sets of weights fitted to the grasp recording. Seeds 431 and 827 repeat the experiment with different starting weights and sampled trial windows. Either checkpoint can supply all three comparisons.

| Output | How the two forecasts were fitted |
| --- | --- |
| `equal` | One shared grasp adapter learned from both sensor change and spike count. Each task supplied half its update to the shared layers. |
| `balanced` | A second joint fit adjusted the task weights at each training step to bring the two updates closer in magnitude. |
| `separate` | One adapter learned to predict sensor change. Another learned to predict spike count. This row pairs their respective forecasts. |

The grasp fits used 4,310 windows from 59 original trials in the first 85 attempts. Evaluation used 1,100 windows from 15 later trials in the same recording, drawn from a previously used development archive. Each trial counted equally. Both seeds saw the same evaluation windows.

Balancing the updates gave a worse shuttle forecast in both seeds. The mean absolute errors were 127.06 and 124.81 ADC counts for the balanced fit, 118.01 and 119.17 for the equal fit, and 115.06 and 112.26 for the separately fitted sensor model. The balanced fit improved the mean spike-count score over equal weighting in both seeds. Its comparison with the separately fitted count model changed direction between seeds. The experiment required a gain on both outcomes in both seeds and fell short.

## Supply a history

Copy `synthetic-example.json` and replace its window readings and cue fields. Each window has ten rows, oldest first. Use `origin` equal to `recording-history` for measurements prepared from the specified L recording. Keep `synthetic` for invented cases. All windows in a file share one origin. The JSON schema gives the exact sensor IDs, all 93 electrode and unit pairs, cue codes, dimensions and value ranges. The program checks the declared layout. The preparation of your measurements determines whether the channel identities and timing are correct. [Input schema](input-schema.json)

| Input | Meaning |
| --- | --- |
| `sensor_adc` | Ten rows of six raw instrument readings. NS2 channels 137, 138, 139 and 140 are the top, left, bottom and right grip sensors. Channel 141 measures the counterweight spring. Channel 143 senses the shuttle's horizontal travel. |
| `spike_counts` | Ten rows of counts for the 93 author-designated single units. Each column uses the indicated electrode and its local offline sorting label. Keep silent units in place with zero counts. |
| `grip_cue` | Raw CUE-ON word 65349 for precision grip or 65354 for side grip. |
| `load_cue` | Raw GO-ON word 65353 for low nominal load or 65350 for high nominal load. |
| `phase` | Integer from 0 through 74. Step zero is the first 1 ms boundary on or after GO-ON. Each subsequent step advances the forecast time by 20 ms. |

Prepare one history entirely within its trial, with both cues known by the forecast time. On the 30 kHz acquisition clock, each 10 ms bin contains 300 ticks. The six recorded sensor readings come from the last complete 1 ms frame of each bin. The ten frame offsets from forecast time run from −2,730 to −30 ticks in steps of 300. The original preparation required all 100 source frames on the 30-tick grid and excluded inputs where any supplied endpoint reached either signed 16-bit rail.

For the neural inputs, a spike becomes available 48 ticks after the start of its recorded waveform. Count it in the bin containing that availability time. Each bin includes its left edge and excludes its right. Keep repeated events at the same tick and require that each waveform starts within the trial. The authors sorted units offline across the session.

The sensor output estimates the reading at +570 ticks minus the last input reading at −30 ticks. Both readings are in raw analogue-to-digital converter (ADC) counts. Conversion to newtons or millimetres would require a separate calibration. The neural output estimates the number of waveform **starts** from the forecast time up to, and excluding, +600 ticks. This gives one expected count per unit per 20 ms.

To forecast several windows, put them in the `windows` array. The first axis of every output follows their order. A Python caller can keep one checkpoint open across forecasts.

```python
import json
from pathlib import Path
from grasp import GraspModel

packet = json.loads(Path("synthetic-example.json").read_text(encoding="utf-8"))
model = GraspModel(827)
forecasts = model.predict(packet)
print(forecasts["balanced"]["sensor_delta_adc"][0, 5])
print(forecasts["separate"]["expected_spike_counts"][0, 0])
```

The checkpoint provenance gives the SHA-256 hashes of the original fitted parameters, the shared Transformer and both portable files. The short example illustrates the calculation. Prediction accuracy comes from comparisons with measured outcomes. [Checkpoint provenance](PROVENANCE.json) · [Recording, model and software credits](NOTICE.md)
