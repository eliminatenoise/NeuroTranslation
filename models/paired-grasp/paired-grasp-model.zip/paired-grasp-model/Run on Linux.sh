#!/bin/sh
script_dir=$(CDPATH= cd -P -- "$(dirname -- "$0")" && pwd -P) || exit 1
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
for interpreter in python3 python; do
    if command -v "$interpreter" >/dev/null 2>&1 && "$interpreter" -c 'import numpy' >/dev/null 2>&1; then
        "$interpreter" -B "$script_dir/grasp.py" "$@"
        result=$?
        break
    fi
done
if [ -z "${result+x}" ]; then
    echo "Open this folder with a Python 3 environment that has NumPy installed." >&2
    result=1
fi
if [ "$#" -eq 0 ] && [ -t 0 ]; then
    printf 'Press Return to close. '
    read -r answer
fi
exit "$result"
