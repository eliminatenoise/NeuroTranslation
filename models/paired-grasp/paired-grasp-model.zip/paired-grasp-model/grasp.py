"""Forecast a change in six grasp sensors and counts from 93 sorted cortical units."""

import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np


HERE = Path(__file__).resolve().parent
SEEDS = (431, 827)
METHODS = ("equal", "balanced", "separate")


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def integer(value):
    return type(value) is int or (type(value) is float and value.is_integer())


def same_layout(value, expected):
    if isinstance(expected, list):
        return (isinstance(value, list) and len(value) == len(expected)
                and all(same_layout(v, e) for v, e in zip(value, expected)))
    if type(expected) is int:
        return integer(value) and value == expected
    return value == expected


def checked_matrix(values, rows, columns, minimum, maximum, field):
    if (not isinstance(values, list) or len(values) != rows
            or any(not isinstance(row, list) or len(row) != columns for row in values)):
        raise ValueError(f"{field} needs {rows} rows of {columns} values")
    if any(not integer(v) or v < minimum or v > maximum for row in values for v in row):
        raise ValueError(f"{field} needs integer counts from {minimum} to {maximum}")
    return np.asarray(values, dtype=np.float32)


def read_history(packet):
    schema = read_json(HERE / "input-schema.json")
    if not isinstance(packet, dict) or set(packet) != set(schema["required"]):
        raise ValueError("Input fields must match input-schema.json")
    fields = schema["properties"]
    for name in ("schema", "recording", "sensor_channels", "sorted_units"):
        if not same_layout(packet[name], fields[name]["const"]):
            raise ValueError(f"{name} must match the recording and column order in input-schema.json")
    if packet["origin"] not in fields["origin"]["enum"]:
        raise ValueError("origin must be synthetic or recording-history")
    windows = packet["windows"]
    if not isinstance(windows, list) or not windows:
        raise ValueError("Supply at least one history window")
    window_schema = fields["windows"]["items"]
    n = len(windows)
    sensors = np.empty((n, 10, 6), dtype=np.float32)
    spikes = np.empty((n, 10, 93), dtype=np.float32)
    context = np.empty((n, 3), dtype=np.float32)
    for i, window in enumerate(windows):
        if not isinstance(window, dict) or set(window) != set(window_schema["required"]):
            raise ValueError(f"Window {i + 1} fields must match input-schema.json")
        phase, grip, load = (window[k] for k in ("phase", "grip_cue", "load_cue"))
        if not integer(phase) or not 0 <= phase <= 74:
            raise ValueError(f"Window {i + 1} phase must be an integer from 0 to 74")
        for name, value in (("grip_cue", grip), ("load_cue", load)):
            if not integer(value) or value not in window_schema["properties"][name]["enum"]:
                raise ValueError(f"Unknown {name} in window {i + 1}")
        sensors[i] = checked_matrix(window["sensor_adc"], 10, 6, -32767, 32766, f"Window {i + 1} sensors")
        spikes[i] = checked_matrix(window["spike_counts"], 10, 93, 0, 65535, f"Window {i + 1} spikes")
        context[i] = (2 * phase / 74 - 1, 1 if grip == 65349 else -1, 1 if load == 65350 else -1)
    return sensors, spikes, context


def linear(data, weights, name):
    return data @ weights[name + ".weight"].T + weights[name + ".bias"]


def layer_norm(data, weights, name):
    centered = data - data.mean(axis=-1, keepdims=True)
    normalized = centered / np.sqrt(np.square(centered).mean(axis=-1, keepdims=True) + np.float32(1e-5))
    return normalized * weights[name + ".weight"] + weights[name + ".bias"]


def shared_state(features, weights, fit):
    projected = linear(features, weights, fit + ".projection")
    n, bins, width = projected.shape
    frequencies = np.exp(np.arange(0, width, 2, dtype="f") * np.float32(-np.log(10000) / width))
    phases = np.arange(1 - bins, 1, dtype="f")[:, None] * frequencies
    memory = projected + np.stack((np.sin(phases), np.cos(phases)), axis=-1).reshape(bins, width)
    state = memory[:, -1]
    past = np.concatenate((np.broadcast_to(weights["trunk.null"], (n, 1, width)), memory), axis=1)
    query = linear(state, weights, "trunk.q").reshape(n, 4, 8)
    key = linear(past, weights, "trunk.k").reshape(n, bins + 1, 4, 8)
    value = linear(past, weights, "trunk.v").reshape(n, bins + 1, 4, 8)
    scores = (query[:, None] * key).sum(axis=-1) / np.float32(np.sqrt(8))
    exponent = np.exp(scores - scores.max(axis=1, keepdims=True))
    attention = exponent / exponent.sum(axis=1, keepdims=True)
    pooled = (attention[..., None] * value).sum(axis=1).reshape(n, width)
    state = layer_norm(state + linear(pooled, weights, "trunk.proj"), weights, "trunk.ln1")
    hidden = np.maximum(0, linear(state, weights, "trunk.ff1"))
    state = layer_norm(state + linear(hidden, weights, "trunk.ff2"), weights, "trunk.ln2")
    residual = linear(state, weights, fit + ".residual")
    z = residual / np.float32(np.sqrt(2))
    erf = np.fromiter(map(math.erf, z.ravel()), dtype=np.float32, count=z.size).reshape(z.shape)
    return state + residual * 0.5 * (1 + erf)


class GraspModel:
    """One seed's four fits, sharing the same frozen temporal Transformer."""

    def __init__(self, seed):
        if seed not in SEEDS:
            raise ValueError("The available seeds are 431 and 827")
        path = HERE / f"grasp-{seed}.npz"
        expected = read_json(HERE / "PROVENANCE.json")["checkpoints"][str(seed)]["sha256"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError(f"Checkpoint checksum failed for {path.name}")
        with np.load(path, allow_pickle=False) as source:
            self.weights = {key: source[key] for key in source.files}

    def predict(self, packet):
        """Return both arrays for each fit method in the order of the supplied windows."""
        sensors, spikes, context = read_history(packet)
        weights = self.weights
        n = len(sensors)
        results = {method: {"sensor_delta_adc": np.empty((n, 6), dtype="f"),
                            "expected_spike_counts": np.empty((n, 93), dtype="f")} for method in METHODS}
        for start in range(0, n, 256):
            rows = slice(start, min(start + 256, n))
            values = sensors[rows]
            features = np.empty((*values.shape[:2], 102), dtype="f")
            features[:, :, :6] = (values - weights["norm.mean_x"]) / weights["norm.scale_x"]
            features[:, :, 6:9] = context[rows, None, :]
            spike_z = (np.log1p(spikes[rows]) - weights["norm.mean_spikes"]) / weights["norm.scale_spikes"]
            features[:, :, 9:] = np.clip(spike_z, -8, 8)
            for fit, output, heads in (("equal", "equal", ("sensor", "count")),
                                       ("balanced", "balanced", ("sensor", "count")),
                                       ("sensor_single", "separate", ("sensor",)),
                                       ("count_single", "separate", ("count",))):
                state = shared_state(features, weights, fit)
                if "sensor" in heads:
                    change = linear(state, weights, fit + ".sensor")
                    results[output]["sensor_delta_adc"][rows] = change * weights["norm.scale_y"]
                if "count" in heads:
                    log_adjust = np.clip(linear(state, weights, fit + ".count"), -8, 8)
                    results[output]["expected_spike_counts"][rows] = weights["norm.count_mean"] * np.exp(log_adjust)
        return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", default=str(HERE / "synthetic-example.json"),
                        help="History JSON file, or - for standard input. Defaults to the synthetic example.")
    parser.add_argument("--seed", choices=("431", "827", "both"), default="both")
    parser.add_argument("--json", action="store_true", help="Print all six sensor and 93 neural values for every window.")
    args = parser.parse_args()
    try:
        packet = json.load(sys.stdin) if args.input == "-" else read_json(Path(args.input))
        seeds = SEEDS if args.seed == "both" else (int(args.seed),)
        predictions = {str(seed): GraspModel(seed).predict(packet) for seed in seeds}
        if args.json:
            encoded = {seed: {fit: {name: array.tolist() for name, array in outputs.items()}
                              for fit, outputs in models.items()} for seed, models in predictions.items()}
            result = {"origin": packet["origin"], "recording_layout": packet["recording"],
                      "sensor_channels": packet["sensor_channels"], "sorted_units": packet["sorted_units"],
                      "seeds": encoded}
            print(json.dumps(result, allow_nan=False))
        else:
            source = "Synthetic example" if packet["origin"] == "synthetic" else "Supplied recording history"
            print(f"{source} | 100 ms of history | 20 ms forecast | window 1 of {len(packet['windows'])}")
            print("Seed  Fit         Shuttle change (ADC counts)   Electrode 3, unit 1 (expected spikes)")
            for seed, fits in predictions.items():
                for fit, outputs in fits.items():
                    delta = outputs["sensor_delta_adc"][0, 5]
                    rate = outputs["expected_spike_counts"][0, 0]
                    print(f"{seed:4}  {fit:9}   {delta:24.3f}   {rate:36.5f}")
            print("Use --json for all six sensors and 93 units in recording order.")
    except (OSError, ValueError, KeyError) as error:
        parser.exit(2, f"Cannot forecast: {error}\n")


if __name__ == "__main__":
    main()
