#!/bin/sh
base=$(CDPATH= cd -P -- "$(dirname -- "$0")" && pwd) || exit 1
exec open "$base/index.html"
