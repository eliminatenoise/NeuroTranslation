# Fish01 tail-angle study

Extract the ZIP and keep the files together. Open `index.html` in a browser, or use `Windows.cmd`, `macOS.command`, or `sh Linux.sh` for your operating system. Both editions and the score data open locally.

[Start](index.html) · [Technical edition](technical.html) · [Simple edition](simple.html) · [Aggregate scores (JSON)](results.json)

Both editions describe the same ten forecasts over 635 later observations from one zebrafish. The package includes the text of each edition and the aggregate error tables.

Martin Haesemeyer and Kaarthik Balakrishnan deposited the source recording under CC BY 4.0. The analysis of later tail angles uses their published data. The repository licence covers the new reader materials. The source dataset retains its own licence. [Versioned DANDI dataset](https://doi.org/10.48324/dandi.000235/0.230316.1600) · [Original paper by Costabile and colleagues](https://doi.org/10.7554/eLife.83289) · [Dataset licence](https://creativecommons.org/licenses/by/4.0/)
