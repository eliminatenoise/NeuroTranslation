Five finger forecasts

Extract the whole folder. Open a launcher for your system or double-click docs/finger-signals/index.html. In the reader, change which finger was cued or vary the invented cortical signal. A clinical recording from one person supplied the model's learning examples. The reader uses invented inputs.

To run the fitted models with Python and NumPy, see models/cortical-glove/README.md. It explains the original scientific task, the published ethics statement, exact source, data terms and optional PyTorch installation. The reader also includes the source credits and software licence notices.
