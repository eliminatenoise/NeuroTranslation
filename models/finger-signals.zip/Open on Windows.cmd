@echo off
start "" "%~dp0docs\finger-signals\index.html"
