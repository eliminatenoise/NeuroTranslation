# Forecasting variation in a zebrafish’s tail angle

Extract the ZIP and open `index.html` in your browser. You can also use `Windows.cmd` on Windows, `macOS.command` on macOS or `sh Linux.sh` on Linux. Keep the extracted files together so the pages can find their links and scores offline.

[Start the study](index.html) · [Technical edition](technical.html) · [Simple edition](simple.html) · [Aggregate scores (JSON)](results.json)

Both editions compare four forecasts of how widely a fish’s tail angle varied in the next tenth of a second. The scores cover the same 2,268 windows in one recording. The JSON includes results for each of the 20 populated one-minute blocks. The Markdown files contain the text of both editions.

Ryosuke Tanaka and Ruben Portugues deposited *Algorithmic dissection of optic flow memory in larval zebrafish* on Zenodo under CC BY 4.0. The repository licence covers the newly authored reader materials. [Versioned dataset](https://doi.org/10.5281/zenodo.16085585) · [Original Current Biology study](https://doi.org/10.1016/j.cub.2025.08.047) · [Dataset licence](https://creativecommons.org/licenses/by/4.0/legalcode)
