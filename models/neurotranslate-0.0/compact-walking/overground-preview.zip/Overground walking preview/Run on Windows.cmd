@echo off
setlocal
pushd "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Install Node.js 18 or later and then run this launcher again.
  popd
  pause
  exit /b 1
)
node overground.mjs overground-example.json
set "preview_exit=%errorlevel%"
popd
pause
exit /b %preview_exit%
