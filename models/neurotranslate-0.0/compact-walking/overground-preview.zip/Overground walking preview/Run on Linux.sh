#!/bin/sh
set -eu
cd -P "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
    printf '%s
' 'Install Node.js 18 or later and then run this launcher again.' >&2
    exit 1
fi
exec node overground.mjs overground-example.json
