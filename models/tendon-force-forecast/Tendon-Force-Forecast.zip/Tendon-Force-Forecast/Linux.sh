#!/bin/sh
base=$(CDPATH= cd "$(dirname "$0")" && pwd) || exit 1
exec xdg-open "$base/index.html"
