#!/bin/sh
base=$(CDPATH= cd "$(dirname "$0")" && pwd) || exit 1
exec open "$base/index.html"
