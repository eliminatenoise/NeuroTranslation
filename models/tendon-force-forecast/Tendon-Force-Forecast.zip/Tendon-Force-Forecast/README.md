# NeuroTranslation tendon-force preview

Extract the ZIP and keep the files together. Run `Windows.cmd` on Windows, `macOS.command` on macOS, or `sh Linux.sh` on Linux. You can also open `index.html` directly in your browser. The calculator runs locally.

[Technical edition](technical.html) · [Simple edition](simple.html) · [Score data](results.json)

Choose a tendon. Enter ten electrical signal sizes in millivolts, from oldest to newest, or use the invented example. Select **Calculate** to see three estimates of tendon impulse for the next 100 milliseconds. Impulse adds up force over time. The results are in newton-seconds (N·s).

The predictors were fitted to guinea fowl recordings released by Monica A. Daley, Anne Koelewijn and Maria Eleni Athanasiadou. [Zenodo dataset, CC BY 4.0](https://doi.org/10.5281/zenodo.15968637)
