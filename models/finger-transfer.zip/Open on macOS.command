#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 1
exec open docs/finger-transfer/index.html
