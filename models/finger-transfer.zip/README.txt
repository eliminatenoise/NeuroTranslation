Can a finger model transfer to another person?

Extract the whole archive and open a launcher for your computer. You can also open docs/finger-transfer/index.html directly. Change the cue and the available cortical regions to try an invented example. The research tables explain what the fitted models did when each of five people was held out of weight training and supplied 80 seconds of calibration.

To run the fitted models in Python or reproduce the scientific analysis, use models/finger-transfer/README.md. It includes the source identification, required ethics statement, original authors and links to obtain the licensed source data. The download supplies derived fits and invented inputs. It contains no participant recording series or anatomical surfaces. Keep models/finger-transfer/RIGHTS.md and the original licences with the results.
