@echo off
start "" "%~dp0docs\finger-transfer\index.html"
