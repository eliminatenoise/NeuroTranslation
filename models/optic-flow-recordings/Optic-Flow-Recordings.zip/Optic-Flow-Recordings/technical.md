# Tail-variation forecasts across two zebrafish recording dates

A Transformer fitted to earlier camera measurements and logged visual commands gave the lowest mean absolute error on the 12 later recordings, 0.020223 radians. The camera-only Transformer scored 0.020686 and carrying forward recent movement scored 0.023516. Adding command history reduced the camera-only error by 0.000463 radians. The current-command model improved on each comparator in nine of 12 recordings. Carry-forward had the lowest aggregate error on the four earlier development recordings.

## Two dates define the comparison

Ryosuke Tanaka and Ruben Portugues describe the Figure 4 protocol as head-restrained larval zebrafish viewing a visual pattern whose direction was programmed externally. The archived `embedded` flag is a software setting and cannot establish physical restraint for an individual file. We used all 29 date-qualified Figure 4 recordings, assigning each whole recording to one role. The fitting group comprised 17 recordings from 13 April 2023, including the previously analysed engineering recording. The test group comprised 12 from 16 May 2023. Swimming frequency and forecast performance played no part in selection.

The date and local fish number identify a recording, with numbers 1 to 12 reused across dates. May recordings f7 and f8 have distinct files but share a session label. The archive does not resolve physical identity across dates or independence within a session. Age and sex for individual records, apparatus equivalence and the separate contributions of fish, preparation and date remain uncertain.

## Camera measurements and logged commands

The camera field `tail_sum` records signed cumulative tail bend in radians. The program field `LDPS_drift_direction` records the commanded pattern direction as −1 or +1. On a 320 ms grid starting at zero on the software clock, forecast the population standard deviation of signed camera tail angle over [t, t + 100 ms), where t is the issue time. The target has units of radians and describes dispersion about the window mean. A sustained bend can have a large angle and little dispersion.

We retained native temporal order. Duplicate timestamp groups were ineligible. For a historical input, a strictly later timestamp in the same stream had to close the selected group by t. Each of the four preceding 50 ms camera bins and the 100 ms target needed at least two eligible readings. Internal gaps and gaps to either edge of each interval could be at most twice that recording’s median positive camera sampling interval. The gap check applied within each earlier bin. At every command cutoff, we used the latest eligible value at or before the cutoff, with age at most twice the command log’s median positive interval. Feature and target camera rows were disjoint throughout each recording. These tests concern stored software times. Physical screen onset, camera exposure and live arrival time were unmeasured.

## Earlier recordings set the model

Carry-forward used the pooled standard deviation over the two most recent 50 ms bins. Three linear ridge models learned corrections to it. All used the four bin means and population standard deviations from the preceding 200 ms. The current-command model added the logged direction at 5, 4, 3, 2, 1, 0.5, 0.2, 0.1, 0.05 and 0 s before issue. The control shifted all ten cutoffs six seconds earlier, retaining real history potentially informative about later movement. Each fitting recording had equal total weight, divided equally among its usable windows. The ridge models disabled features that were constant in the fitting data. Each varying feature was centered at its fitting-only weighted mean and divided by its fitting-only weighted population standard deviation, using these recording weights. The response for regression was the measured future spread minus the recent-variation baseline. The objective minimized the weighted mean squared error of the fitted correction to that residual plus 0.1 times the sum of squared slopes, with an unpenalized intercept. At issue, each ridge model added its correction to the baseline and set a negative sum to zero.

Three matched Transformers represented camera summaries and, in the two command variants, direction readings and their observed ages as inputs to an attention model. Attention allows the influence of one reading to depend on the others. Each Transformer estimated a signed correction to the same recent-variation baseline. Its output layer began with zero weights and bias, so the initial correction was zero. During fitting, the squared error compared the **unclipped** sum of baseline and correction with the measured future spread, with the same equal total weight per recording. Each shuffled batch’s weighted sum of squared errors was multiplied by the number of batches in a full pass. Each variant was trained separately with the same Adam optimizer settings and Float64 arithmetic. At forecast issue, the frozen model added its correction to the baseline and applied a lower bound of zero to the sum.

The first 13 earlier recordings supplied 83,258 development-fit windows. The last four in numeric label order (f14, f15, f17 and f18) supplied 25,438 check windows. The width choice minimized the mean of the three Transformer variants’ equally recording-weighted check errors. Width 24 gave 0.037345 radians and width 32 gave 0.037672. An exact tie favored 24. The two candidates used four attention heads, two layers, respectively 48 and 64 feed-forward units, six epochs, batches of 128, seed 104729 and learning rate 0.001. The earlier check ranked the carry-forward baseline first at 0.023542 radians. The rule selected the Transformer architecture and preserved every comparator for the later test.

Of 191,233 earlier grid times, 109,005 passed the clock rules and 108,814 supplied finite inputs. A further 118 lacked a finite target, leaving 108,696 windows for the final fit on all 17 earlier recordings. No later inputs or outcomes entered selection or fitting.

## Error on the later date

Of 134,988 later grid times, 90,357 passed the clock rules. Insufficient finite input support removed 130 before issue. Independent review reopened all 631,589 nonnegative predictions across seven methods and 90,227 windows and verified 2,103,065 requested later tail-angle rows before their camera values were read. Zero of those native camera rows occurred among the earlier feature rows for the same recording. A further 78 windows had nonfinite targets. Every method was scored on the same 90,149 windows.

Within each recording, we averaged the absolute difference between forecast and measured spread over its scored windows. The cohort mean gives equal weight to each recording. For a paired comparison, subtract the reference method’s absolute error from the comparison method’s absolute error on each window, average within recordings, then across recordings. The columns below report the four earlier check recordings at the selected width and the 12 later recordings after refitting on all 17. Values are rounded to six decimals.

| Forecast | Four earlier check recordings (radians) | Twelve later test recordings (radians) |
| --- | ---: | ---: |
| Repeat recent variation | 0.023542 | 0.023516 |
| Linear, camera | 0.026869 | 0.029264 |
| Linear, camera and current command | 0.026924 | 0.029122 |
| Linear, camera and older command | 0.026856 | 0.029247 |
| Transformer, camera | 0.036179 | 0.020686 |
| Transformer, camera and current command | 0.030703 | 0.020223 |
| Transformer, camera and older command | 0.045153 | 0.025742 |

The current-command Transformer reduced error by 0.003293 radians relative to recent variation. The camera-only Transformer already reduced it by 0.002830. The incremental command improvement of 0.000463 was smaller. The three exceptions against carry-forward were f1, f4 and f8. The three exceptions against the camera-only Transformer were f2, f4 and f11. Neither comparison had ties.

The current-command Transformer scored 0.005519 radians lower than its six-second-earlier counterpart and 0.008898 lower than the current-command linear model. For the linear models, using current commands reduced error by 0.000142 relative to camera alone and by 0.000125 relative to older commands. The comparison measures predictive information at the sampled lags. It cannot identify a causal response to the display.

## Errors within each later recording

The May archive labels identify recordings on the same date. Each error below is a mean absolute error in radians, rounded to six decimal places. The issued and scored counts apply to all seven methods.

| May recording | Issued | Scored | Recent variation | Linear camera | Linear current command | Linear older command |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| f1 | 7,327 | 7,324 | 0.006307 | 0.015552 | 0.015456 | 0.015514 |
| f2 | 7,340 | 7,334 | 0.030532 | 0.033264 | 0.032877 | 0.033249 |
| f3 | 9,820 | 9,809 | 0.030196 | 0.033097 | 0.033143 | 0.033105 |
| f4 | 6,618 | 6,615 | 0.011829 | 0.018862 | 0.019065 | 0.018845 |
| f5 | 6,496 | 6,494 | 0.024127 | 0.028251 | 0.028371 | 0.028262 |
| f6 | 7,568 | 7,567 | 0.025578 | 0.030589 | 0.030815 | 0.030614 |
| f7 | 7,352 | 7,320 | 0.042368 | 0.046224 | 0.045168 | 0.046179 |
| f8 | 7,421 | 7,420 | 0.005711 | 0.015733 | 0.015911 | 0.015721 |
| f9 | 9,599 | 9,587 | 0.029981 | 0.032088 | 0.032312 | 0.032079 |
| f10 | 6,524 | 6,519 | 0.051436 | 0.053962 | 0.053153 | 0.053932 |
| f11 | 6,570 | 6,568 | 0.009557 | 0.019615 | 0.019703 | 0.019600 |
| f12 | 7,592 | 7,592 | 0.014575 | 0.023928 | 0.023486 | 0.023860 |

| May recording | Transformer camera | Transformer current command | Transformer older command |
| --- | ---: | ---: | ---: |
| f1 | 0.008352 | 0.007648 | 0.012612 |
| f2 | 0.025041 | 0.025275 | 0.030911 |
| f3 | 0.026219 | 0.026120 | 0.031093 |
| f4 | 0.011836 | 0.011977 | 0.017810 |
| f5 | 0.019364 | 0.018386 | 0.023589 |
| f6 | 0.020872 | 0.020327 | 0.027251 |
| f7 | 0.035204 | 0.034594 | 0.039089 |
| f8 | 0.007328 | 0.006839 | 0.012358 |
| f9 | 0.025432 | 0.025064 | 0.029676 |
| f10 | 0.048113 | 0.046129 | 0.051805 |
| f11 | 0.008712 | 0.008788 | 0.014772 |
| f12 | 0.011764 | 0.011534 | 0.017944 |

Across 720 populated one-minute blocks of stored time, the current-command Transformer improved on camera alone in 470, on carry-forward in 424 and on the older-command Transformer in 718. These are descriptive subdivisions of the same recordings. The recording-level means and win counts carry no population confidence interval.

An independent check compared 9,529 numerical fields using the frozen predictions and saved target spreads. The largest absolute discrepancy was 3.33 × 10⁻¹⁶ radians. That check covered case matching, finite masks and recording, minute and paired scores. It did not repeat extraction of angle values from the original camera files. The experiment tests transfer to the held date within this source. Sensory exposure, neural activity and transfer to another laboratory remain unmeasured.

Ryosuke Tanaka and Ruben Portugues published *Algorithmic dissection of optic flow memory in larval zebrafish* and deposited the Figure 4 recordings on Zenodo under CC BY 4.0. [Original study](https://doi.org/10.1016/j.cub.2025.08.047) · [Versioned data archive](https://doi.org/10.5281/zenodo.16085585)

## Running the model

The runnable example supplies one invented input row to seven methods. Each result is the predicted population standard deviation of signed tail bend, in radians, during the 100 ms starting at issue. Use **Calculate forecast** after changing the example or entering a row. **Restore example** restores the original input and recalculates.

The camera scale multiplies the four bin means, the four bin spreads and the recent spread. The two reversal controls multiply the signs of the ten display entries in the selected history. The controls preserve each sample and confirmation time. **Edit input JSON** shows the exact row. Once you edit this field, calculate the edited row or restore the example to use its controls again.

### Input fields

| Field | Required value |
| --- | --- |
| `valid` | A Boolean eligibility flag. A row marked `false` returns no forecast. |
| `case_id`, `issue_s` | A nonnegative safe JavaScript integer and its exact issue time in seconds, `case_id × 0.32`. |
| `camera_stats_rad`, `recent_spread_rad` | Four mean and population spread pairs in chronological bins and the pooled spread of the last two bins, in radians. |
| `camera_first_s`, `camera_last_s`, `camera_closed_s` | First, last and later confirming sample times in seconds for each camera bin. |
| `command_codes`, `command_sample_s`, `command_closed_s` | Ten direction entries, their sample times and later confirmations, in the lag order given in the study. Use −1 and +1 as recorded in the study. |
| `earlier_command_codes`, `earlier_command_sample_s`, `earlier_command_closed_s` | Ten direction entries and the two time lists at the same lags shifted six seconds earlier. |
| `command_max_age_s`, `clock_tolerance_s` | Positive age limit from the display log and the recorded arithmetic tolerance from 0 to 10⁻¹¹ seconds. |

Copy the example to match field names and array lengths. The browser checks the submitted numbers, shapes, issue grid, nonnegative spreads, sample and confirmation times, and display age. Prepare real rows from the original camera and display logs under the full study rules, including checks for duplicated times, sample support and gaps. Calculate the spread values from those accepted native samples before submitting a row.

### Opening the offline package

Extract the ZIP and keep its directory together. Open `index.html`, or run `Linux.sh`, `macOS.command`, or `Windows.cmd` on the matching system. Both editions open the same full double-precision weights in the browser. The command line uses the identical model when Node.js is installed. From the extracted folder, run `node model/cli.cjs model/example-input.json` and read the seven values in radians from the JSON output.
