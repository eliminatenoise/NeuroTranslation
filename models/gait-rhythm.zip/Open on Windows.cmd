@echo off
start "" "%~dp0docs\gait-rhythm\index.html"
