#!/bin/sh
script_dir=$(CDPATH= cd -P -- "$(dirname -- "$0")" && pwd -P) || exit 1
if [ "$#" -eq 0 ]; then
    if command -v open >/dev/null 2>&1; then
        exec open "$script_dir/Start here.html"
    fi
    echo "Open Start here.html in a browser, or pass --task all to run the models." >&2
    exit 1
fi
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
for interpreter in python3 python; do
    if command -v "$interpreter" >/dev/null 2>&1 && "$interpreter" -c 'import numpy' >/dev/null 2>&1; then
        "$interpreter" -B "$script_dir/forecast.py" "$@"
        result=$?
        break
    fi
done
if [ -z "${result+x}" ]; then
    echo "Open this folder with a Python 3 environment that has NumPy installed." >&2
    result=1
fi
exit "$result"
