"""Replay six source-specific NeuroTranslate forecasts with Python and NumPy."""
import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
from inference import JointModel

HERE = Path(__file__).resolve().parent
GUIDE = json.loads((HERE / 'guide.json').read_text(encoding='utf-8'))
WIDTHS = ('compact', 'wider')


def load_packet(path):
    text = sys.stdin.read() if str(path) == '-' else Path(path).read_text(encoding='utf-8-sig')
    return json.loads(text)


def validate_packet(packet, model):
    if not isinstance(packet, dict) or set(packet) != {'task', 'origin', 'channels', 'X'}:
        raise ValueError('Use the task, origin, channels and X fields from an example file.')
    task = packet['task']
    if not isinstance(task, str) or task not in GUIDE:
        raise ValueError('Choose one of the six task names shown by --list.')
    if packet['origin'] not in ('synthetic', 'user-provided'):
        raise ValueError('Label the input origin as synthetic or user-provided.')
    schema = model.tasks[task]
    if packet['channels'] != schema['channels']:
        raise ValueError('Keep the exact input channel names and order from this task’s example.')
    windows = packet['X']
    if not isinstance(windows, list) or not windows:
        raise ValueError('X needs one or more history windows.')
    units = schema['input_units']
    count_units = {'spikes/10 ms', 'waveforms per 10 ms'}
    signed_cue = {'-1 or +1', '-1 or 1'}
    for index, window in enumerate(windows, start=1):
        if not isinstance(window, list) or len(window) != schema['history_steps']:
            raise ValueError(f'Window {index} needs {schema["history_steps"]} rows, oldest first.')
        for row in window:
            if not isinstance(row, list) or len(row) != len(units):
                raise ValueError(f'Each row needs {len(units)} values in the declared channel order.')
            for value, unit, channel in zip(row, units, schema['channels']):
                if value is None:
                    continue
                if type(value) not in (int, float) or not math.isfinite(value):
                    raise ValueError(f'Use a finite number or null for {channel}.')
                if unit in count_units and (value < 0 or value != int(value)):
                    raise ValueError(f'{channel} needs a nonnegative integer count.')
                if unit == 'ADC counts' and (value != int(value) or not -32767 <= value <= 32766):
                    raise ValueError(f'{channel} needs an integer ADC reading between -32767 and 32766.')
                if ((unit == '0 or 1' and value not in (0, 1))
                        or (unit in signed_cue and value not in (-1, 1))):
                    raise ValueError(f'{channel} needs {unit}.')
                if unit == '-1 to 1' and not -1 <= value <= 1:
                    raise ValueError('The encoded trial phase must lie between -1 and 1.')
                if unit == 'log(1+RMS/uV)' and value < 0:
                    raise ValueError(f'{channel} needs a nonnegative log RMS voltage.')
    return task, windows


def predict(packet, models):
    first = next(iter(models.values()))
    task, windows = validate_packet(packet, first)
    schema = first.tasks[task]
    return {
        'task': task,
        'input_origin': packet['origin'],
        'outputs': schema['outputs'],
        'units': schema['output_units'],
        'predictions': {width: model.predict(task, windows).tolist() for width, model in models.items()},
    }


def example(task, case):
    return load_packet(HERE / 'examples' / f'{task}-{case}.json')


def display(results):
    for item in results:
        print(f'\n{GUIDE[item["task"]]["title"]}  |  {item["input_origin"]} input')
        models = list(item['predictions'])
        for index in range(len(item['predictions'][models[0]])):
            print(f'Window {index+1}   ' + '   '.join(models))
            for j, (name, unit) in enumerate(zip(item['outputs'], item['units'])):
                values = '   '.join(f'{item["predictions"][width][index][j]:.6g}' for width in models)
                print(f'  {name:<30} {values}   {unit}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group()
    source.add_argument('--list', action='store_true', help='list tasks and their prediction horizons')
    source.add_argument('--input', metavar='FILE', help='forecast a prepared JSON packet; use - for standard input')
    source.add_argument('--task', choices=tuple(GUIDE) + ('all',), help='run one task or all six')
    parser.add_argument('--case', choices=('a', 'b'), help='choose a packaged synthetic example (default a)')
    parser.add_argument('--model', choices=WIDTHS + ('both',), default='both', help='choose checkpoint width')
    parser.add_argument('--json', action='store_true', help='print all labeled outputs as JSON')
    args = parser.parse_args()
    if args.list:
        for task, guide in GUIDE.items():
            print(f'{task}  —  {guide["question"]}')
        return 0
    if args.input and args.case:
        parser.error('--case selects a built-in example. Omit it when giving an input file.')
    widths = WIDTHS if args.model == 'both' else (args.model,)
    try:
        models = {width: JointModel.load(HERE / 'models' / f'{width}.npz') for width in widths}
        tasks = GUIDE if args.task in ('all', None) else (args.task,)
        packets = [load_packet(args.input)] if args.input else [example(t, args.case or 'a') for t in tasks]
        results = [predict(packet, models) for packet in packets]
        if args.json:
            print(json.dumps({'forecasts': results}, allow_nan=False))
        else:
            display(results)
    except (ValueError, TypeError, OverflowError, OSError) as exc:
        parser.exit(2, f'Forecast could not run. {exc}\n')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
