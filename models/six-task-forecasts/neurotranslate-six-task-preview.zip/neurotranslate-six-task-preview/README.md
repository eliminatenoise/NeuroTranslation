# NeuroTranslate · six-task experimental preview

Experimental edition of 21 November 2026, first training seed 431.

A macaque closes a hand on a sliding object. One instrument records changes at the grip and shuttle while another counts spikes from the motor cortex. Can the last 100 milliseconds help forecast the next 20? The grasp example asks this twice, once for the instrument readings and once for the electrical activity. The same two model checkpoints also forecast movement and electrical activity from a human balance experiment and a separate macaque reaching experiment. Each task keeps its own clock, channel order and output units.

## Start with an example

Extract the whole ZIP into one folder and open **Start here.html**, or double-click the launcher for your computer. The reader works offline in a browser. Choose a task, switch between its two synthetic histories and select an output channel. Both numbers come from actual runs of the fitted checkpoints on the displayed invented input. **See all outputs** opens the complete table. Click **Open these input values** to see the numbers behind it.

| Computer | Launcher |
| --- | --- |
| Windows | Run on Windows.cmd |
| macOS | Run on macOS.command |
| Linux | Run on Linux.sh |

## Run the checkpoints

To recalculate an example or edit its input, use Python 3 with NumPy installed. If you need NumPy, install it in your chosen Python environment with `python -m pip install numpy`. Once it is available, forecasting runs entirely offline. In a terminal opened in the extracted folder, try

```sh
python forecast.py --list
python forecast.py --task brochier_grasp_sensors --case b --model both
python forecast.py --task all --case a --json
```

Copy a JSON file from `examples`, edit its readings and keep its input channel order. The following command runs only the task named inside that file and reports every output for every window.

```sh
python forecast.py --input "my example.json" --model wider --json
```

The platform launchers take the same arguments. On Linux or macOS you can run the launcher with `sh` if your extractor dropped its executable bit. A relative input path is resolved from the folder where you started the command. `--input -` reads JSON from standard input. `--model compact`, `--model wider` and `--model both` select the two packaged checkpoints. Ordinary terminal output prints each forecast with its unit. JSON keeps full numeric precision in `forecasts[].predictions`, with the column order in `outputs` and the units in `units`.

## Read a history

Each input packet has four fields. `task` picks the input and prediction layout. `origin` is `synthetic` for invented values or `user-provided` for values you supply from another source. This is your declaration of origin. `channels` gives the input column names in order. `X` is a list of windows, each containing the specified number of time rows, oldest first. Use `null` for a missing observation. A forecast needs at least one observed value in each window. [Exact feature and output layouts](layouts.json)

| Experiment | Prepared history | Forecast |
| --- | --- | --- |
| Human balance | Five 125 ms rows × 28 columns. Scalp voltage, leg muscle voltage, sacrum marker movement, posture and visual rotation direction. | Eight muscle RMS voltages (µV) for the next 125 ms, or three sacrum displacement coordinates (mm) at each of four points through 125 ms. |
| Macaque reaching | Twenty 10 ms rows × 45 columns. Eight hand, elbow and handle coordinates (mm) and spike counts at 37 contacts. | Eight changes in position (mm) 100 ms ahead, or 37 expected contact counts integrated over the next 100 ms. |
| Macaque grasp | Ten 10 ms rows × 102 columns. Six digital sensor readings, three trial descriptors and counts from 93 sorted units. | Six sensor changes (ADC counts) over 20 ms, or 93 expected waveform-start counts in that 20 ms bin. |

**Human balance.** The visual scene rotated while participants stood or walked. On the processed 256 Hz clock, the cutoff is 32 samples after the rotation onset rounded up to a sample. The five bins end at that cutoff and include 32 samples each. Three scalp sites supply a mean voltage and a log RMS; eight surface muscle channels supply log RMS. Log RMS here means the natural logarithm of one plus the RMS voltage expressed in microvolts. Four positions of the sacrum marker per bin are expressed relative to its position at the cutoff. The last two inputs encode standing (0) or walking (1) and the signed direction of rotation. Muscle voltage forecasts concern the strength of the electrical signal. The marker forecast uses the recorded axes at 31.25, 62.5, 93.75 and 125 ms. Anatomical positive-axis signs remain unverified.

**Macaque reaching.** The optical hand and elbow markers supply three coordinates each, and the handle supplies two. Each row pairs these with the counts at 37 specified contacts in somatosensory cortex. The counts combine the available local sorting labels on each contact, including sort zero. The eight displacement forecasts refer to the last observed position. The count forecasts sum expected spikes through the ten future bins. The fit used one workspace, one date and one macaque. The animals, instruments and unit identities differ between the reaching and grasp recordings.

**Macaque grasp.** Sensor IDs 137, 138, 139 and 140 cover the top, left, bottom and right of the object, 141 the counterweight spring and 143 the sliding shuttle. Each 10 ms bin contains 300 ticks on the 30 kHz hardware clock. Use the last complete 1 ms sensor frame in each bin and include spikes when their waveform becomes available, 48 ticks after its start. The recorded preparation requires complete sensor frames and excludes both signed 16-bit ADC rails. Spike outputs count waveform starts from the issue time through the next 600 ticks, excluding the right edge. Sensor outputs give the change from the last observed frame at −30 ticks to +570 ticks. A digitizer count measures a change in instrument reading. Converting that change into force or distance requires physical calibration.

The three grasp context columns repeat across the ten history rows. Encode phase as `2 * step / 74 - 1`, where step 0 is the first 1 ms boundary at or after the go cue. Steps 0–74 advance in 20 ms increments. Use +1 for precision grip or −1 for side grip, and +1 for high load or −1 for low load. The last 93 columns use the session's specified electrode and sorting-label pairs, with a zero for a recorded unit that was silent. The recorded grasp windows were complete. You can use `null` to explore the model’s response to a missing input. Preparation determines whether the declared clocks and channel identities are correct.

## What the wider model changed

Both models started from seed 431 and learned for 480 updates. The compact model has 36,580 parameters, a hidden width of 32 and one attention layer with four heads. The wider model has 376,740 parameters, a width of 128 and two layers with eight heads each. Both fit input and output weights for each task and one shared temporal Transformer. Each model was fitted from initialization on these six tasks. This edition accompanies the existing NeuroTranslate model as a separate experiment.

The comparison scored the same retrospective cases for both widths. Each width had six separately fitted, single-task controls with the same starting task parameters, per-task batch size and update count. At each update the shared model saw all six tasks and a control saw one, so the total examples and computation differ. The compact shared model scored better than its single-task control on reach displacement (0.5217 versus 0.5560). At the wider setting that direction reversed (0.5606 versus 0.5474). The wider shared model improved on its single-task control for reaching spike counts (2.3632 versus 2.5640 nats), yet the compact shared model had the lower count score (2.1014). Sharing increased error for human muscle voltage, pelvis motion and both grasp outputs at both widths. No width won across all six.

For continuous outcomes, the score averages absolute error divided by the fitted training spread of each output. For spike counts it averages the full negative Poisson log probability in nats per recorded count channel and prediction bin. The comparison groups were three people (761 balance events), 78 trials in one reaching session (199 windows) and ten trials in one grasp session (733 windows). Each person or trial counts equally within the relevant comparison. Previously used development material supplied all three comparisons. The paired intervals condition on these groups and a single training seed, with no correction across tasks. The records leave accuracy on new people, animals and sessions open. They contain no live experiment, calibrated grasp force measurement or biological control test. [All scores, paired intervals and interpretation](comparison.json) · [Training and checkpoint information](PROVENANCE.json) · [Recording credits and licence terms](NOTICE.md)
