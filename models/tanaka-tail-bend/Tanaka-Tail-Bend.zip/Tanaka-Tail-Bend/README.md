# Tanaka tail-bend forecast

Extract the ZIP and keep the folder together. Open `index.html` in your browser, or start `Windows.cmd` on Windows, `macOS.command` on macOS or `sh Linux.sh` on Linux. The reading pages and scores work offline.

[Start the study](index.html) · [Technical edition](technical.html) · [Simple edition](simple.html) · [Aggregate scores (JSON)](results.json)

The reports compare three forecasts of signed tail bend using camera readings and the logged display command in one recording. The two Markdown files contain the source text of the reading editions. Score data include the seven populated blocks on the one-minute grid.

Ryosuke Tanaka and Ruben Portugues deposited the source dataset under CC BY 4.0. The repository licence covers the newly authored reader materials. The dataset retains its own licence. [Zenodo dataset](https://doi.org/10.5281/zenodo.17233579) · [Original Nature study](https://www.nature.com/articles/s41586-025-09888-x) · [Dataset licence](https://creativecommons.org/licenses/by/4.0/legalcode)
