# Earlier camera measurements improve a tail-bend forecast

In phase 1 of the Tanaka zebrafish recording `main01/20230825_f1_p0`, five earlier camera measurements reduced mean absolute error over 1,242 later cases. Adding the logged display command gave the same result to numerical precision.

| Forecast | Mean absolute error (radians) |
| --- | ---: |
| Carry forward the latest camera reading | 0.013841 |
| Fit a correction from five earlier camera readings | 0.011660 |
| Fit a correction from those readings and five logged command values | 0.011660 |

## Measured inputs and target

The camera variable `tail_sum` is signed cumulative tail bend in radians. The display variable `cl2D_flow_vel` is a logged 64-bit integer. Conversion to 64-bit floating-point values was accepted only where conversion back returned the exact original integer. A conversion to physical display speed and the lag to on-screen changes remain unverified. For each forecast time, take the latest acceptable value at or before each of five cutoffs, 200, 150, 100, 50 and 0 ms earlier. Require the source value to be within twice its log’s median sample interval of that cutoff. The target is the first signed camera reading at least 100 ms later, within two median camera intervals of that point. Exclude windows that cross a gap above the respective log’s bound. The scored target times were 100.008–105.774 ms later on the shared software clock.

## Fitting and comparison

Use the prespecified 320 ms schedule and half-open phase intervals [88.011128, 688.020253) s and [688.020253, 1288.008899) s. The two-thirds point of the shared logged interval is 888.003524 s. A fitting target must precede that split. Both oldest input times of a later case must be at or after it. Of 3,716 scheduled cases, one crossed the phase boundary and one crossed the split. Across both phases, 2,463 of 2,471 fitting candidates had complete histories and a finite target. Phase 0 supplied 1,844 of these and the early part of phase 1 supplied 619. For the two fits, estimate the later bend minus the latest angle. Centre and scale input columns using fitting means and population standard deviations. Set constant columns to zero. Minimize the mean squared residual plus 0.1 times the sum of the squared weights. Leave the intercept unpenalized.

Issue and independently reopen all three forecasts on every one of the 1,243 later cases before extracting the later targets. Score all methods on the same cases after removing one with a nonfinite target. Use ordinary subtraction on the unwrapped signed angle scale, then take the absolute difference for each case. The primary contrast is the paired mean of those errors for camera plus command minus camera alone.

## Scope of the comparison

All five command columns were constant during fitting, so their weights were disabled. Each lag also had one distinct command value across all 1,243 later cases. The paired difference of −7.82 × 10⁻²⁰ radians is within floating-point rounding precision. The predictive value of a varying display signal remains open. The camera fit had lower error than carrying the latest reading forward in all seven populated blocks on the 60-second grid. The block results describe phase 1 of one recording. Three static angle snapshots printed during metadata inspection, and their related columns, were excluded from fitting and scoring.

[Original study and camera method](https://pmc.ncbi.nlm.nih.gov/articles/PMC12916487/) · [Versioned recording](https://doi.org/10.5281/zenodo.17233579)
