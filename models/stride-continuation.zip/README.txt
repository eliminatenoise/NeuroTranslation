Extract the whole ZIP, then open the launcher for your computer or open docs/stride/index.html in a browser. The viewer runs offline.

The fitted model, examples, source credit and instructions for Python are in models/stride-continuation/README.md.
