@echo off
start "" "%~dp0docs\stride\index.html"
