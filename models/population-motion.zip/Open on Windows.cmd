@echo off
start "" "%~dp0docs\population-motion\index.html"
