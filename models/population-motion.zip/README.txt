Extract the whole ZIP, then open the launcher for your computer or open docs/population-motion/index.html in a browser. The viewer runs offline.

The fitted model, examples, source credit and instructions for Python are in models/population-motion/README.md.
