@echo off
start "" "%~dp0docs\finger-motion\index.html"
