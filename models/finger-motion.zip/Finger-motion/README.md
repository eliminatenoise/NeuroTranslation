# Which fingers follow the cue?

Open the launcher for your operating system or open [the browser model](docs/finger-motion/index.html) directly. The reader works offline with the included models. Select the finger cued on screen and change the strength of an invented rhythm. The table shows how much each model expects each of the five glove sensors to change.

[Browser controls and results](docs/finger-motion/README.md) · [Study, seven saved models and Python examples](models/finger-motion/README.md) · [Source, licences and original study ethics](models/finger-motion/RIGHTS.md)

To rebuild the reader, run `python -B docs/finger-motion/build.py` from this folder with Python 3 and NumPy installed. The original physiological recordings are available from the [Stanford Digital Repository](https://purl.stanford.edu/zk881ps0522).
