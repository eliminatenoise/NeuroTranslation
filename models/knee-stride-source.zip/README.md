# Knee stride forecast source

Open **docs/knee-stride/index.html** in a browser. The three desktop launchers are beside it. The viewer's JS and CSS are under **docs/knee-stride/src**. The browser runs both sets of predictors offline.

From this folder, run `python3 docs/knee-stride/build.py` to rebuild the page. The build checks the hashes of the study, checkpoints and shared model export, then embeds the two fitted models into the single HTML file.

**models/knee-stride** contains the dedicated model, training and evaluation code, public file fingerprints and one explicitly invented input for its Python example. Read its reproduction guide for the source recordings and software requirements. The opening walk in the reader is generated from a different pair of invented curves.

**docs/knee-stride/src/shared-knee.js** and **shared-knee.json** contain the portable shared-model code, parameters, per-person results and controls. The published shared study supplies the Python refit and full NeuroTranslate checkpoint. [Shared knee model and protocol](https://github.com/eliminatenoise/NeuroTranslation/tree/main/models/neurotranslate-0.0/knee)

The archive contains no participant recordings. [Source credits](docs/knee-stride/NOTICE.md)

The independent ten-walker test and its reproducible score are in models/knee-stride/external-optical.
