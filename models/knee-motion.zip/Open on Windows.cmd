@echo off
start "" "%~dp0docs\knee-motion\index.html"
