# Walking forecast blends

Extract the ZIP. Start `index.html` or use `Windows.cmd`, `macOS.command` or `sh Linux.sh`. Both examples contain invented numbers. The calculator and both reports work offline. On a system with Node installed, run `node forecast.cjs compact-example.json` or `node forecast.cjs research-example.json`.

[Calculator](index.html) · [Technical edition](technical.html) · [Simple edition](simple.html) · [Aggregate scores and source credits](aggregate-results.json)

The Compact and Research Edition corrections accept their respective frozen walking forecasts and matching physical references. Their model identity records are in `compact.json` and `research.json`. The archive contains the projection, invented input examples and aggregate evidence. Original project code is covered by the repository’s CC0 licence to the extent of the authors’ rights. Data and derived aggregate results retain the source attribution and CC BY 4.0 terms documented in the editions.
