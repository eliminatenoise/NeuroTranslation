# Two fixed walking forecast blends

The Compact and Research Edition components take an existing physical forecast and the corresponding frozen walking model’s forecast. Each returns a heel displacement vector, vertical force impulse and probability of a new load for each foot. Select **Compact** for the frozen NeuroTranslate 0.0 expanded-history walking fit, or **Research Edition** for the corresponding NeuroTranslate 0.1 walking continuation with its matched dense, expert and parent components. The coefficient files identify the required source checkpoints. This package supplies the final blend. Obtaining those two input forecasts from sensors requires their original forecasting pipeline.

## Inputs and calculation

For each scalar apply `physical + weight * (learned - physical)` in binary64 (FP64). Both operands refer to the same issue, side, units and coordinate basis. The two fixed sets of learned fractions are:

| Correction | Heel | Impulse | New load |
| --- | ---: | ---: | ---: |
| Compact | 0.03 | 0.58 | 1.00 |
| Research Edition | 0.15 | 0.32 | 1.00 |

Supply one JSON object with `learned_model` set to `compact` or `research`, and `physical` and `learned` objects. Each forecast uses exactly three arrays. `heel_mm` has shape [2, 3]. The feet are ordered left, right. Each displacement is ordered leftward, backward, upward in millimetres, as in the Utah walking adapter. `impulse_ns` has two signed vertical force integrals in N·s, ordered left, right. `new_load_probability` has two final probabilities in [0, 1] in that order. Convert model logits to probabilities upstream if needed. The heel coefficient applies separately to all six coordinates before calculating any displacement error. Summed force, distance magnitudes and raw sensor histories have different meanings from these inputs.

The reference carries recent heel velocity forward, holds the latest mean force steady over the forecast interval and uses its fixed fitting-derived event probability. Both event weights are one, so the learned forecast supplies each event probability, subject to floating-point arithmetic. The operator rejects missing or extra fields, invalid shapes, nonfinite values, out-of-range probabilities and numerical overflow. Successful output uses the same three arrays. The model tag states which learned forecast the caller supplies. It cannot verify the provenance of numbers.

Open `index.html` after extraction or use the Windows, macOS or Linux launcher. Click **Load invented example**, edit the input and click **Calculate blend**. The optional command `node forecast.cjs compact-example.json` prints the same output. Substitute `research-example.json`, a local file, or `-` for standard input. The examples contain invented values.

## The earlier six-person checks selected the correction

In 72 calibration histories from six Kuopio walkers, the fit chose one coefficient per model and endpoint on a grid from 0 to 1 in steps of 0.01. It gave each contributing person equal weight and minimized Euclidean heel displacement error, absolute impulse error or squared probability error. Eight separate check histories per person gave 48 check times. The correction for each check came from the other five people’s calibration labels. The networks and event prior already had fitting exposure to all six. There were 96 observed heel and impulse outcomes per endpoint and 94 load outcomes, including 14 positives.

In that five-person-per-check comparison, the Research blend reduced heel error by 0.450 mm against the physical reference (paired 95% interval −0.670 to −0.226 mm). The change in impulse error was −0.176 N·s (−0.619 to +0.132). Allowing different coefficients below and above a past plate-force threshold of 20 N gave no clear improvement. The coefficients shipped here were fitted using all six people before the separate Utah test. The earlier check scores use their own five-person fits.

## Utah walking at 1.0 m/s

Of 17 people reserved for external testing, eight had a matching treadmill trial at 1.0 m/s. All walked with an above-knee prosthesis. A separate preparation walker was excluded. At 756 issue times the predictors used the past 200 ms to forecast the next 100 ms. Heel displacement was relative to the last camera sample. The force forecast began 10 ms later. Force scoring required separate foot placement and complete measured force over the target interval. Event scoring also required a confirmed outcome.

| Forecast | Heel error (mm) | Impulse error (N·s) | Load-start Brier score |
| --- | ---: | ---: | ---: |
| Physical reference | 54.271868 | 13.322950 | 0.108400 |
| Compact, unadjusted | 55.369061 | 13.232538 | 0.106115 |
| Compact blend | 54.238998 | 13.255966 | 0.106115 |
| Research Edition, unadjusted | 55.318941 | 13.384063 | 0.099603 |
| Research Edition blend | 53.939177 | 13.242439 | 0.099603 |

The table uses both feet and the original calibrated force. First average the errors within each walker, then across walkers with an available outcome. For heel movement, score the Euclidean distance between forecast and measured displacement. For impulse use absolute error. For new loading use the squared difference between probability and the 0-or-1 observation, the Brier score. There were 1,498 foot forecasts for heel motion and 1,200 for impulse across eight walkers. Seven contributed 925 event forecasts, with 104 distinct confirmed starts (63 prosthetic and 41 intact).

For the Research blend minus physical, heel error changed by −0.332691 mm (95% interval −0.449651 to −0.204934, seven of eight lower). The impulse change was −0.080511 N·s (−0.226461 to +0.054358, five of eight lower). The Brier change was −0.008798 (−0.013057 to −0.005271, seven of seven lower). Its probability score comes from the frozen model. For the Compact blend the corresponding changes were −0.032871 mm, −0.066984 N·s and −0.002285. The intervals used 20,000 whole-walker paired resamples per comparison, without multiple-comparison adjustment. Practical importance and live latency remain unmeasured.

The accompanying [aggregate results](aggregate-results.json) give full-precision errors, counts and paired intervals for original and exported force, both feet and each prosthetic/intact subset. The export represents the same plates. A separate 0.6 m/s comparison found about 0.161 mm lower heel error for the Research blend and a higher impulse-error estimate with an interval spanning zero. Its results are reported separately from the 1.0 m/s trial. [Utah results reader](https://eliminatenoise.github.io/NeuroTranslation/utah-walking/) · [0.6 m/s comparison](https://github.com/eliminatenoise/NeuroTranslation/tree/main/models/neurotranslate-0.0/compact-walking#comparison-on-recorded-walks)

Alexander Beattie, Matti Kortelainen, Paavo Vartiainen and Pasi Karjalainen published the Kuopio Full-Body Dataset. Sarah Hood and Tommaso Lenzi published the Utah walking recordings. The scores here are derived from these sources and the Utah force encodings refer to the same plates. The data and derived aggregates retain their CC BY 4.0 attribution. [Kuopio dataset](https://doi.org/10.5281/zenodo.24194741) · [Utah dataset](https://doi.org/10.6084/m9.figshare.c.4962305.v1) · [Utah methods, Hood et al.](https://doi.org/10.1038/s41597-020-0494-7) · [Data licence](https://creativecommons.org/licenses/by/4.0/)
