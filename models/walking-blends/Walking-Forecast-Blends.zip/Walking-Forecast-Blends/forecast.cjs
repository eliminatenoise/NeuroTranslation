"use strict";
const fs = require("node:fs");
const {project} = require("./blend.js");
if (process.argv.length !== 3) {
  console.error("Usage: node forecast.cjs <input.json or ->");
  process.exitCode = 2;
} else {
  try {
    const path = process.argv[2] === "-" ? 0 : process.argv[2];
    const input = JSON.parse(fs.readFileSync(path, "utf8"));
    process.stdout.write(JSON.stringify(project(input), null, 2) + "\n");
  } catch (err) {
    console.error(err.message);
    process.exitCode = 1;
  }
}
