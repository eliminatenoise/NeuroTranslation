#!/usr/bin/env bash
# Build the four paper PDFs from the TeX source beside this script.
#
#   ./build.sh                      build all four editions, one after another
#   ./build.sh brain2body-article   build one edition (any number may be named)
#
# Run it from anywhere; every path is taken from where this script sits:
#   source/                 TeX, bibliography, the figure, the seven font files and the tools
#   ledger.json             the ledger of results that the number check reads
#   results-public/         the small result files that the number check also reads
#   toolchain/tectonic      the TeX engine, Tectonic 0.17, as a static binary: you supply it (README.md)
#   toolchain/cache-seed/   the 415 package files that engine needs, already fetched: you supply them
#   toolchain/runtime/      a certificate bundle (ca-certificates.crt) the engine opens at start-up: you supply it
#   build/<edition>/        output and logs for that edition
#   build/<edition>.pdf     the finished PDF
#   build/BUILD.log         what was built, how long it took, pages and checksums
#
# Host programs used: bash, coreutils, find, awk, grep, bwrap (bubblewrap), prlimit, timeout, pdfinfo,
# pdffonts and python3. The engine runs inside a bubblewrap sandbox with no network, a read-only view of
# source/ and write access to build/<edition>/ only.
#
# Before it builds, the source tree is checked by its own three scripts (check_numbers.py,
# check_glossary.py, check_anchors.py); a finding stops the build. After each PDF is built its fonts are
# checked: every font must be embedded and must be Noto Sans, Noto Sans Mono or Fira Math.
#
# Settings (environment variables):
#   SOURCE_DIR          source tree to build (default: ./source). Must stay inside this folder.
#   BUILD_DIR           where to build (default: ./build). Must stay inside this folder.
#   TOOLCHAIN_DIR       where the engine and its package files are (default: ./toolchain).
#   KEEP_CACHE=1        keep build/<edition>/cache after a successful build (default: delete it).
#   FINAL=1             run the three checks in their strict form (no unwritten section, no missing number).
#   SOURCE_DATE_EPOCH   date stamped into the PDFs (default 1795132800, 20 November 2026 00:00 UTC, the date
#                       of the published PDFs; keep it to get byte-identical output).
#   OTHER_CACHE=1       build with a package cache that is not the 415-file seed. The PDFs may then differ
#                       from the published ones.
set -euo pipefail

LANE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
SOURCE_DIR="$(cd "${SOURCE_DIR:-$LANE/source}" && pwd -P)"
BUILD_DIR="${BUILD_DIR:-$LANE/build}"
TOOL="${TOOLCHAIN_DIR:-$LANE/toolchain}"
EPOCH="${SOURCE_DATE_EPOCH:-1795132800}"
ALL=(neurotranslation-technical neurotranslation-explained brain2body-article brain2body-simple-english)
ENGINE_SHA=a98aa59ad5c1df39a6c9e56cbfc5088f2b11d6c179c0130b97998e4bd46a46da
export LEDGER_JSON="${LEDGER_JSON:-$LANE/ledger.json}"
export RESULTS_PUBLIC="${RESULTS_PUBLIC:-$LANE/results-public}"

fail() { printf 'build.sh: %s\n' "$*" >&2; exit 1; }

mkdir -p "$BUILD_DIR"
BUILD_DIR="$(cd "$BUILD_DIR" && pwd -P)"
case "$BUILD_DIR/" in "$LANE"/?*/) ;; *) fail "BUILD_DIR must be a folder inside $LANE" ;; esac
case "$SOURCE_DIR/" in "$LANE"/?*/) ;; *) fail "SOURCE_DIR must be a folder inside $LANE" ;; esac
for program in bwrap prlimit timeout pdfinfo pdffonts sha256sum find python3; do
  command -v "$program" >/dev/null || fail "missing host program: $program"
done
[ -x "$TOOL/tectonic" ] || fail "engine not found at $TOOL/tectonic (README.md says where to get it)"
[ "$(sha256sum "$TOOL/tectonic" | cut -d' ' -f1)" = "$ENGINE_SHA" ] || fail "engine checksum differs: this is not the Tectonic 0.17 binary the PDFs were built with"
[ -f "$TOOL/runtime/ca-certificates.crt" ] || fail "no certificate bundle at $TOOL/runtime/ca-certificates.crt (any system bundle will do)"
if [ "${OTHER_CACHE:-0}" != 1 ]; then
  [ "$(find "$TOOL/cache-seed" -type f | wc -l)" -eq 415 ] || fail "package cache is not the 415-file seed listed in toolchain-files.json (OTHER_CACHE=1 builds anyway)"
fi
[ -f "$LEDGER_JSON" ] || fail "no ledger at $LEDGER_JSON"

editions=("$@"); [ ${#editions[@]} -gt 0 ] || editions=("${ALL[@]}")
LOG="$BUILD_DIR/BUILD.log"
say() { printf '%s\n' "$*" | tee -a "$LOG"; }

say "== $(date -u +%Y-%m-%dT%H:%M:%SZ) build of: ${editions[*]}"
say "source tree: ${SOURCE_DIR#"$LANE"/} ($(find "$SOURCE_DIR" -type f | wc -l) files); engine sha256 $ENGINE_SHA; epoch $EPOCH"

# The source tree's own checks run first and stop the build on any finding.
strict=(); [ "${FINAL:-0}" = 1 ] && strict=(--final)
for check in check_numbers check_glossary check_anchors; do
  [ -f "$SOURCE_DIR/tools/$check.py" ] || fail "the source tree has no tools/$check.py"
  extra=(); [ "$check" = check_numbers ] && extra=(--build "$BUILD_DIR")
  if ! PYTHONDONTWRITEBYTECODE=1 python3 "$SOURCE_DIR/tools/$check.py" "$SOURCE_DIR" "${extra[@]}" "${strict[@]}" 2>&1 | tee -a "$LOG"; then
    say "FAILED  $check.py: nothing was built. Fix the findings above."
    exit 1
  fi
done

font_allow='NotoSans|NotoSansMono|FiraMath'

status=0
for edition in "${editions[@]}"; do
  mapfile -t masters < <(find "$SOURCE_DIR" -type f -name "$edition.tex")
  [ ${#masters[@]} -eq 1 ] || fail "expected exactly one $edition.tex under the source tree, found ${#masters[@]}"
  master="${masters[0]}"
  inside="/source/${master#"$SOURCE_DIR"/}"

  case="$BUILD_DIR/$edition"
  [ -n "$edition" ] && [ "$case" != "$BUILD_DIR" ] || fail "empty edition name"
  rm -rf -- "$case"
  mkdir -p "$case"/{cache,config,tmp,output,log,runtime}
  cp -a "$TOOL/cache-seed/." "$case/cache/"
  chmod -R u+rwX "$case/cache"

  # Only the font folders inside the source tree are visible to the engine: no system fonts, no fallback.
  {
    printf '<?xml version="1.0"?>\n<!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd">\n<fontconfig>\n'
    find "$SOURCE_DIR" -type d -name fonts | LC_ALL=C sort | while read -r dir; do
      printf '  <dir>/source/%s</dir>\n' "${dir#"$SOURCE_DIR"/}"
    done
    printf '  <cachedir>/work/cache/fontconfig</cachedir>\n  <config><rescan><int>0</int></rescan></config>\n</fontconfig>\n'
  } > "$case/runtime/fonts.conf"
  printf 'builder:x:%s:%s::/work/config:/bin/false\n' "$(id -u)" "$(id -g)" > "$case/runtime/passwd"

  start=$(date +%s%N)
  set +e
  timeout --signal=KILL 180s prlimit --cpu=180:180 --as=4294967296:4294967296 --nofile=256:256 --core=0:0 -- \
    bwrap --unshare-all --unshare-user --unshare-net --die-with-parent --new-session --clearenv --cap-drop ALL \
      --proc /proc --remount-ro /proc --dir /dev \
      --ro-bind /dev/null /dev/null --ro-bind /dev/urandom /dev/urandom \
      --ro-bind "$SOURCE_DIR" /source \
      --ro-bind "$TOOL/tectonic" /engine/tectonic \
      --ro-bind "$case/runtime/fonts.conf" /etc/fonts/fonts.conf \
      --ro-bind "$case/runtime/passwd" /etc/passwd \
      --ro-bind "$TOOL/runtime/ca-certificates.crt" /etc/ssl/certs/ca-certificates.crt \
      --bind "$case/cache" /work/cache --bind "$case/config" /work/config --bind "$case/tmp" /work/tmp \
      --bind "$case/output" /work/output --bind "$case/log" /work/evidence \
      --symlink /work/tmp /tmp \
      --setenv FONTCONFIG_FILE /etc/fonts/fonts.conf --setenv FONTCONFIG_PATH /etc/fonts \
      --setenv LANG C.UTF-8 --setenv LC_ALL C.UTF-8 \
      --setenv MKL_NUM_THREADS 1 --setenv NUMEXPR_NUM_THREADS 1 --setenv OMP_NUM_THREADS 1 \
      --setenv OPENBLAS_NUM_THREADS 1 --setenv RAYON_NUM_THREADS 1 \
      --setenv PATH /usr/bin:/bin --setenv SOURCE_DATE_EPOCH "$EPOCH" \
      --setenv SSL_CERT_FILE /etc/ssl/certs/ca-certificates.crt \
      --setenv TMPDIR /work/tmp --setenv TZ UTC \
      --setenv XDG_CACHE_HOME /work/cache --setenv XDG_CONFIG_HOME /work/config \
      --setenv XDG_DATA_HOME /work/config/data --setenv XDG_STATE_HOME /work/config/state \
      --chdir "$(dirname "$inside")" --remount-ro / -- \
      /engine/tectonic --untrusted --only-cached --keep-logs --keep-intermediates --print --color never \
        --makefile-rules /work/evidence/dependencies.d --outdir /work/output "$edition.tex" \
      </dev/null >"$case/log/stdout.txt" 2>"$case/log/stderr.txt"
  code=$?
  set -e
  tenths=$(( ($(date +%s%N) - start) / 100000000 ))
  seconds="$((tenths / 10)).$((tenths % 10))"

  pdf="$case/output/$edition.pdf"
  if [ "$code" -ne 0 ] || [ ! -s "$pdf" ]; then
    say "FAILED  $edition (exit $code, ${seconds}s). See ${case#"$LANE"/}/log/stderr.txt"
    status=1
    continue
  fi
  # The private copy of the package cache is 47 MB per edition; drop it unless asked to keep it.
  [ "${KEEP_CACHE:-0}" = 1 ] || rm -rf -- "$case/cache" "$case/tmp" "$case/config"
  pages=$(pdfinfo "$pdf" | awk '/^Pages:/{print $2}')
  warnings=$(cat "$case/log/stderr.txt" "$case/output/$edition.log" 2>/dev/null |
             grep -c -i -E 'overfull|missing character|undefined (references|citations)|errors were issued by bibtex|Font Warning|multiply defined' || true)
  # Every font embedded, and sans-serif only: Noto Sans, Noto Sans Mono or Fira Math.
  fonts=$(pdffonts "$pdf" | awk 'NR>2')
  bad_font=$(printf '%s\n' "$fonts" | awk 'NF{n=$1; sub(/^[A-Z]{6}\+/,"",n); print n}' | grep -v -E "^($font_allow)(-|$)" | LC_ALL=C sort -u | tr '\n' ' ' || true)
  not_embedded=$(printf '%s\n' "$fonts" | awk 'NF && $(NF-4)!="yes"{print $1}' | tr '\n' ' ' || true)
  if [ -n "$bad_font" ] || [ -n "$not_embedded" ]; then
    say "FAILED  $edition (fonts). Not Noto Sans, Noto Sans Mono or Fira Math: ${bad_font:-none}. Not embedded: ${not_embedded:-none}"
    status=1
    continue
  fi
  cp -f "$pdf" "$BUILD_DIR/$edition.pdf"
  say "ok      $edition  ${pages} pages  ${seconds}s  warnings-of-concern ${warnings}  fonts ok  sha256 $(sha256sum "$pdf" | cut -d' ' -f1)"
done
say "== finished with status $status"
exit "$status"
