# Source of the two papers, each written twice

This folder builds the four PDFs of the edition of 20 November 2026:

| PDF | Paper | Pages |
| --- | --- | ---: |
| `neurotranslation-technical.pdf` | *NeuroTranslation: A New Paradigm In Brain-Body Mapping.* | 53 |
| `neurotranslation-explained.pdf` | the same paper, Simple English Edition | 63 |
| `brain2body-article.pdf` | *Brain2Body: The Next Generation In Body-Brain Interfacing.* | 29 |
| `brain2body-simple-english.pdf` | the same paper, Simple English Edition | 33 |

Built as below, all four come out byte for byte the same as the published PDFs. `EDITION.json` gives the SHA-256 of
each PDF and of every file under `source/`.

## What is here

- `source/`: the TeX of both papers (`neurotranslation/`, `brain2body/`, and `results/` for the passages they share),
  the bibliography and glossary (`shared/`), the one figure in its two label sets with the CSV it is drawn from
  (`figures/`), the seven font files (`fonts/`), and the tools that write the number macros and check the text
  (`tools/`, explained in `tools/README.md`).
- `build.sh`: the build. It checks the source, runs the TeX engine in a sandbox with no network, and checks the fonts
  of each PDF.
- `ledger.json` and `results-public/`: the results every printed number is taken from. The build's first check
  regenerates the number macros from them and stops if `source/shared/numbers.tex` differs.
- `toolchain-files.json`: the SHA-256 of the engine and of each of the 415 package files it needs.
- `NOTICE.md` and `third-party-notices/`: the credits and licences of the datasets, simulators and fonts.
- `LICENSE.txt`: CC0 1.0, for the project's own text and code.

## What you need

- **The engine: Tectonic 0.17**, the static Linux x86-64 binary, SHA-256
  `a98aa59ad5c1df39a6c9e56cbfc5088f2b11d6c179c0130b97998e4bd46a46da`. Put it at `toolchain/tectonic`.
- **Its package files:** the 415 files of Tectonic's default bundle, version 33, that these papers use, already
  fetched. Put them under `toolchain/cache-seed/`, laid out as `toolchain-files.json` lists them. One way to get them:
  run that Tectonic once with network access on these sources, with `XDG_CACHE_HOME` set to an empty
  `toolchain/cache-seed/`, then compare the files with the list. A cache that differs builds with `OTHER_CACHE=1`,
  but the PDFs may then differ from the published ones.
- **A certificate bundle** at `toolchain/runtime/ca-certificates.crt`. The engine opens it at start-up and never uses
  the network; your system's bundle will do.
- **The fonts:** nothing to install. Noto Sans, Noto Sans Mono and Fira Math are in `source/fonts/`, and the engine
  sees no other font.
- **On the host:** Linux with bash, coreutils, find, awk, grep, bubblewrap (`bwrap`), `prlimit`, `timeout`, Python 3,
  and `pdfinfo` and `pdffonts` from Poppler.

## The command

```
FINAL=1 ./build.sh
```

It builds all four into `build/` and prints one line per PDF with its pages, `warnings-of-concern` (0 for all four)
and its SHA-256. Name an edition to build only that one: `./build.sh brain2body-article`. The date stamped into the
PDFs is `SOURCE_DATE_EPOCH=1795132800`, the default.

To change a number, change the result it comes from, then run `python3 source/tools/make_numbers.py` with
`LEDGER_JSON=ledger.json`. Redrawing the figure needs Python with matplotlib (`source/tools/make_figure.py`).
