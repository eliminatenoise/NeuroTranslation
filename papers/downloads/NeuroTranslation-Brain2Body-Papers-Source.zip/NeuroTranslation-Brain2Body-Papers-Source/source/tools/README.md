# The tools of this source tree

Everything here is plain Python 3 with the standard library, except `make_figure.py`, which needs matplotlib.
Paths below are relative to the folder that holds this source tree (`papers/`).

## Building

```
SOURCE_DIR=source-new BUILD_DIR=build-new/<folder> ./build.sh <edition>
```

Editions: `neurotranslation-technical`, `neurotranslation-explained`, `brain2body-article`,
`brain2body-simple-english`; name none to build all four. Two builds running at once need two `BUILD_DIR`s,
so that neither overwrites the other. A PDF takes between about ten seconds and a minute. `FINAL=1` runs the checks in their strict form (no unwritten section, no missing number, glossary and
anchors complete).

The build first runs the three checks below and stops on any finding. It then builds, and fails a PDF whose
fonts are not all embedded Noto Sans, Noto Sans Mono or Fira Math. The line it prints for each PDF ends with
`warnings-of-concern N`: N must be 0 (overfull boxes, missing characters, undefined references or citations,
font warnings, labels defined twice). The log is `<BUILD_DIR>/<edition>/log/stderr.txt`.

The engine runs in the master file's own folder. A section file therefore writes `\input{../results/eeg.tex}`
and `\includegraphics{../figures/signal-change.pdf}` whichever folder it sits in.

## Number macros: `make_numbers.py`, `shared/numbers.tex`, `shared/NUMBERS.md`

No result number is typed. `make_numbers.py` writes one macro per number from the ledger of measured results
and from the small result files in `results-public/`; `shared/NUMBERS.md` lists every macro with what it is,
what it prints and the file and field it came from. Look a macro up there, open the file it names, then use it.

```
python3 source-new/tools/make_numbers.py            regenerate the two files
python3 source-new/tools/make_numbers.py --verify   also re-read every ledger number at its result file
```

A name is a study tag plus a slot, letters only:

| Slot | Prints |
| --- | --- |
| `Tested`, `TestedText`, `TestedTitle` | people tested: 3, three, Three |
| `Fitted`, `FittedText`, `FittedTitle` | people the model was fitted on, where the ledger says |
| `Unit`, `UnitCol` | the unit to follow a number; the bare symbol for a table column |
| `PrimaryRef`, `PrimaryCand` | the study's main comparison: reference score, candidate score |
| `PrimaryDiff`, `PrimaryDiffAbs` | candidate minus reference, with its sign (a true minus or a plus); the size alone |
| `PrimaryLo`, `PrimaryHi` | the published range of that change, signed |
| `PrimaryBetter`, `PrimaryBetterOf` | people who did better, out of how many |
| `BaseA`, `BaseB`, … and `ModelA`, … | the baselines and the models, in ledger order |
| `CarryA…` + `Rule`, `Fitted` | "repeat the last value" against a fitted model |
| `CueRuleA…` + `Rule`, `Fitted` | "current reading plus the scheduled change" against a fitted model |
| `EegA…`, `EmgA…`, `EegAloneA`, `EmgAloneA` + `Without`, `With`, `Control` | a signal added to a model; the same model fed the signal from the wrong trial |
| `PersonalA…` + `Before`, `After` | an adjustment to a person, a day or a group |
| any comparison + `Diff`, `DiffAbs`, `Better`, `BetterOf` | its change, and people who did better |

Example: `\WristEegEegAWith` is study `WristEeg`, its first EEG comparison, the score with EEG.

Every value also has a `Short` form (`\WristEegPrimaryRefShort`): three significant figures for a score, two
for a change. The abstracts and the introductions use the short forms; tables use the full ones.

Counts come in three forms: `\CountEegRaisedNum` (5), `\CountEegRaisedText` (five), `\CountEegRaisedTitle`
(Five). A heading that carries a count uses the `Title` form; it prints correctly in the contents and in the
PDF bookmarks.

Writing with them:

- A macro swallows the space after it. Write `\WristEegPrimaryRef{}` before a space.
- Unit macros bring their own spacing and go straight after the number: `\WristEegPrimaryRef{}\UnitDeg{}`,
  `\PalmPrimaryRef{}\UnitMm{}`, `\UnitN`, `\UnitMv`, `\UnitMvc` ("% of maximum squeeze"), `\UnitMvcShort`
  ("% of MVC", only after MVC has been explained). `\<Study>Unit` is the right one for that study.
- Every score is an error: lower is better. A change is "with" minus "without".
- A number the ledger gives only inside a sentence has no macro. `NUMBERS.md` lists those sentences under
  "In text only" in each study's block. To give one a macro, add it to the hand table in `make_numbers.py`,
  with the file and field, after opening the file to check the value.

## Small result files: `results-public/<study>.json`

For a study with no public result file. One file per study, holding exactly the aggregate numbers the papers
print, each with its source:

```
{ "study": "…", "what": "one sentence", "numbers": [
    { "macro": "ReplayRight", "value": 41, "print": "41", "unit": "presses",
      "what": "attempted right-finger presses that produced the intended key contact",
      "source": { "file": "artifacts/…/study_acceptance.json", "pointer": "/muscle_body/aggregate_controls/learned/source_intention_to_contact_successes" } } ],
  "limits": ["…"], "credit": "…" }
```

- `macro`: letters only, and not a name that already exists. It becomes `\ReplayRight`.
- `value`: the number as the result file has it. `print`: exactly what the paper prints; it must be `value`
  rounded to the places shown, or the generator stops. `unit` is optional.
- `source.file` is relative to the private workspace, never a full path: these files are published.
  `source.pointer` is the path of the field inside that file. An entry without both stops the generator.
- `"value": null` is allowed for a number not yet verified: its macro prints a bold **??**.
- A name listed in `tools/pending-macros.txt` prints a bold **??** until a file here defines it. Four are listed
  now, used by the Brain2Body abstracts: `ReplayCommandsIssued`, `ReplayCommandsDone`, `ReplayAttempted`,
  `ReplayRight`. The file for the hand replay should define these four names.
- After adding or changing a file, run `make_numbers.py`; the build refuses a `numbers.tex` that is out of date.

## The checks

Each takes the source folder, prints findings as `file:line: message` and exits 1 on any finding.

- `check_numbers.py <tree> [--build <folder>] [--final]`. (a) `numbers.tex` and `NUMBERS.md` are up to date.
  (b) No file under `results/` types a ledger or results-public number by hand: every value is searched for
  as it could be printed (two to six significant figures, and its study's decimal places). A line may carry
  `% number-ok: <reason>` to pass. (c) The same search over every other `.tex` file is written to
  `NUMBERS-TYPED.txt` in the build folder, with every other typed numeral: a report, read by the fact checker.
- `check_glossary.py <tree> [--final] [--notes]`. A term a master prints in its glossary is used in that
  edition's text, and a term of `shared/glossary-terms.tex` used in the text is printed. While an edition
  still has an unwritten section, a mismatch is a note and does not fail; `--notes` lists them.
- `check_anchors.py <tree> [--final] [--notes]`. Each of the 28 anchors (the 24 of the first ledger, studies 26 and 28, and rows 27 and 29, which are not tests) is placed exactly once in each
  NeuroTranslation edition (a missing one is a note while appendix B is unwritten); no heading ends in a
  question mark; no `\paragraph` or `\subsubsection`; no `\usepackage` outside `shared/preamble.tex`; no
  `\nocite`; none of the project's working words; no private string. A `.tex` line may carry
  `% words-ok: <reason>` where a working word is ordinary English ("the fitted model was a candidate…" is
  not; "a gate in the fence" would be).

## What the preamble gives the text

- `\section{…}` and `\subsection{…}`: bold, ragged, never hyphenated, two levels only. The heading of a section
  lives in the section's own file.
- `\ForEdition{technical wording}{Simple English wording}` where a shared file needs both.
- `\StudyAnchor{name}`: an invisible named destination, once per study, in appendix B. `\hyperlink{name}{text}`
  links to it.
- Tables. There is no `longtable`: a table longer than a page is two tabulars.

  ```
  \TableCaption{What the table shows.}
  \begin{PaperTable}{p{50mm}p{12mm}p{38mm}p{12mm}p{13mm}p{13mm}}
  \toprule
  Study & People & What was forecast & Unit & Without & With \\
  \midrule
  \GroupRow{6}{Wrist angle}
  \RR A long cell that may wrap & \WristEegTested & … \\
  \TableContinues{6}
  \end{PaperTable}
  \begin{PaperTable}{…same columns…}
  \TableContinued{6}
  …
  \bottomrule
  \end{PaperTable}
  ```

  The text is 157 mm wide. The column widths plus 2.8 mm for each gap between columns must stay under that.
  `\RR` at the start of a `p{}` cell sets it ragged without hyphenation.
- `\FigureCaption{…}` under a picture; `\TableCaption{…}` above a table. Neither floats.
- `\PrintGlossary{keys}` and `\CreditsFor{n|b}` are for the master files.
- `\Unwritten{name}` marks a section not yet written: delete it when the section is written.

Packages: only those the preamble loads. Any other `\usepackage` stops the build.

## The figure

`figures/signal-change.pdf` and `figures/signal-change.csv` (the rows it draws) are made by `make_figure.py`
from the ledger: the fourteen comparisons that were a study's main question, six with EEG and eight with EMG;
the change in error as a percentage of the error without the signal; the published range where there is one.
The axis stops at 40% either way: the range of the paced-grip EEG row runs past both ends, is drawn with
arrowheads, and is printed in full beside the row. The kinds of range differ from row to row and are in the
CSV's last column, for the caption.

This machine's `python3` has no plotting library. Run the script with a Python that has matplotlib:

```
MPLBACKEND=Agg MPLCONFIGDIR=build-new/mpl PYTHONDONTWRITEBYTECODE=1 SOURCE_DATE_EPOCH=1794664896 <python with matplotlib> source-new/tools/make_figure.py
```

With the same inputs it writes the same bytes.

## Bibliography: `shared/refs.bib`

One file, keys as in the published edition. A master prints cited works only. Several works have two keys,
one from each paper's old list. Use the key in your paper's column, so that no work is printed twice:

| Work | In NeuroTranslation | In Brain2Body |
| --- | --- | --- |
| AlphaFold 3 (Abramson and others, 2024) | `alphafold32024` | `abramson2024` |
| MyoSuite (Caggiano and others, 2022) | `myosuite2022` | `caggiano2022` |
| Specification gaming (DeepMind, 2020) | `specgaming2020` | `deepmind2020` |
| DoomFly threat input | `doomfly` | `doomFlyPinned` |
| Fly-chess trainer | `flychess` | `flyChessPinned` |
| Fly wiring diagram (Dorkenwald and others, 2024) | `flywire2024` | `dorkenwald2024` |
| The Surprising Creativity of Digital Evolution (Lehman and others) | `surprises2018` | `lehman2018` |
| NeuroMechFly v2 (Wang-Chen and others, 2024) | `neuromechfly2024` | `wangchen2024` |
| NIST guidelines on measurement uncertainty | `nist1297` | `nistTerminology` |
| Methods for Determining Structure (RCSB PDB-101) | `pdbmethods` | `rcsbMethods` |
| Measuring and Manipulating Individual Quantum Systems (Royal Swedish Academy of Sciences) | `quantum2012` | `royal2012` |
| MyoSim | `myosim2026` | `myohandMyoSimPinned2026` |
| The companion paper | `brain2bodyworking` (cites Brain2Body) | `neurotranslation_companion_draft` (cites NeuroTranslation) |

Datasets: `wristmotionV3`, `kinmusujiV1`, `lucchetti2025` (+ `lucchetti2025hs01`, `lucchetti2025hs02`),
`cai2026openneuro` and `cai2026iackd`, `luciw2014way`, `ortega2020hygrip` and `ortega2020hygripdata`,
`jiang2023hyser` and `jiang2021hyser` (+ `pollard2026physionet`, `jianghysertoolbox`), `cemhseyGraspV2`,
`linkarchive`, `reachGraspV1`.

### Every inline link of the published Brain2Body text, and its key

The published article and its Simple English edition cite by inline link. Each link below is in both
editions; the lines are those of the two published body files. `research-evidence.json` is a file beside the
PDFs, not a source to cite.

| Link text | Key | Article line | Simple line |
| --- | --- | --- | --- |
| Todorov and Jordan, 2002 | `todorov2002` | 33 | 34 |
| NIST measurement terminology | `nistTerminology` | 35 | 46 |
| NHGRI, Beyond Genes | `nhgri2003` | 44 | 58 |
| MICrONS Consortium, 2025 | `microns2025` | 46 | 60 |
| Logothetis et al., 2001 | `logothetis2001` | 48 | 68 |
| Tang et al., 2023 | `tang2023` | 48 | 70 |
| Royal Swedish Academy, quantum measurement background | `royal2012` | 50 | 78 |
| Bouton et al., 2016 | `bouton2016` | 54 | 84 |
| Lorach et al., 2023 | `lorach2023` | 56 | 86 |
| Flesher et al., 2021 | `flesher2021` | 58 | 88 |
| Dorkenwald et al., 2024 | `dorkenwald2024` | 68 | 101 |
| Pospisil et al., 2024 | `pospisil2024` | 68 | 103 |
| Shiu et al., 2024 | `shiu2024` | 70 | 105 |
| Wang-Chen et al., 2024 | `wangchen2024` | 72 | 113 |
| Vaxenburg et al., 2025 | `vaxenburg2025` | 72 | 119 |
| Eon Systems, 10 March 2026 | `eon2026` | 74 | 123 |
| Fly-chess trainer | `flyChessPinned` | 76 | 125 |
| DoomFly threat input | `doomFlyPinned` | 76 | 127 |
| DoomFly, methods and limitations | `doomflyMethodsPinned` | 76 | 127 |
| Lehman et al., first-hand accounts | `lehman2018` | 86 | 140 |
| Google DeepMind, specification gaming | `deepmind2020` | 86 | 138 |
| Abramson et al., 2024 | `abramson2024` | 88 | 148 |
| Jumper et al., 2021 | `jumper2021` | 88 | 154 |
| RCSB structure methods | `rcsbMethods` | 88 | 152 |
| Nierula et al., 2024 | `nierula2024` | 96 | 191 |
| Caggiano et al., 2022 | `caggiano2022` | 102 | 204 |
| Marlow, 1961 | `marlow1961antechinus` | 182 | 373 |
| Cook et al., 2021 | `cook2021` | 183 | 374 |
| Armstrong and Ferguson, 1995 | `armstrong1995` | 193 | 385 |
| Kumar et al., 2022 | `kumar2022opossum` (new entry) | 194 | 386 |
| Green et al., 1980 | `green1980tammar` | 206 | 397 |
| Nicholas, 1988 | `nicholas1988dual` | 207 | 398 |
| Waite et al., 2005 | `waite2005tammar` (new entry) | 208 | 399 |
| Fehrenkamp et al., 2019 | `fehrenkamp2019opossum` (new entry) | 209 | 400 |
| Revah et al., 2022 (the organoid paper) | `revah2022` | 213 | 416 |
| its author correction, 2026 | `revah2026correction` | 213 | 420 |
| Pais-Vieira et al., 2013 | `paisvieira2013` | 231 | 436 |
