#!/usr/bin/env python3
"""Guard against result numbers typed by hand.

    python3 tools/check_numbers.py <source folder> [--build <folder for temporary files and the report>] [--final]

(a) shared/numbers.tex and shared/NUMBERS.md are up to date: they are regenerated into the build folder and
    compared. A difference is a finding.
(b) No file under results/ types a result number by hand. Every value of the ledger and of results-public/ is
    turned into the strings it could be printed as (rounded to 2, 3, 4, 5 and 6 significant figures and to
    its study's decimal places, with and without trailing zeros); any of those strings found as a literal in a
    results/*.tex file is a finding. Macro names, labels, references, citations, links, file names, lengths
    and comments are not searched. A line that carries "% number-ok: <reason>" is passed.
(c) The same search over every other .tex file, and a list of every other numeral typed there, written to
    NUMBERS-TYPED.txt in the build folder. This part is a report and never fails the build.
With --final: a macro that still prints "??" and is used anywhere is a finding.

Findings are printed as file:line: message. Exit status 1 on any finding. Standard library only.
"""
import filecmp
import json
import os
import re
import subprocess
import sys
from decimal import Decimal, ROUND_HALF_UP

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.dont_write_bytecode = True
import make_numbers as gen  # noqa: E402  (the generator's own paths and rounding)

NUMERAL = re.compile(r"(?<![\w.,])\d+(?:[.,]\d+)*(?![\w])")


def strip_tex(line):
    """The part of a line a reader could see as a number: no comment, macro name, label, link or length."""
    line = re.sub(r"(?<!\\)%.*", "", line)
    line = re.sub(r"\\(?:label|ref|pageref|eqref|cite[a-z]*|input|include|bibliography|hypertarget|hyperlink|StudyAnchor|url|nolinkurl|includegraphics(?:\[[^\]]*\])?)\s*\{[^{}]*\}", " ", line)
    line = re.sub(r"\\href\s*\{[^{}]*\}", " ", line)
    line = re.sub(r"\\[A-Za-z@]+", " ", line)
    line = re.sub(r"(?<=[{=\[,+\-])\s*\d+(?:\.\d+)?\s*(?:mm|cm|pt|em|ex|bp|in)\b", " ", line)
    line = re.sub(r"\[\s*-?\d+(?:\.\d+)?\s*(?:mm|cm|pt|em|ex|bp|in)\s*\]", " ", line)
    return line


def forms(d, dp=None):
    """Every way a value could be typed: 2 to 6 significant figures and its study's decimal places."""
    out = set()
    d = abs(d)
    texts = [gen.to_sig(d, n) for n in (2, 3, 4, 5, 6)]
    if dp is not None:
        texts.append(gen.to_dp(d, dp))
    for text in texts:
        out.add(text)
        if "." in text:
            out.add(text.rstrip("0").rstrip("."))
    return {t for t in out if "." in t}          # a bare whole number is too common to search for


def known_values(ledger):
    """string -> where it comes from, for every ledger and results-public value."""
    known = {}

    def note(strings, where):
        for s in strings:
            known.setdefault(s, where)

    def walk(node, where, dp):
        if isinstance(node, dict):
            if "value" in node and "file" in node and "field" in node:
                note(forms(gen.exact(node, where), dp), where)
                return
            for key, value in node.items():
                walk(value, "%s/%s" % (where, key), dp)
        elif isinstance(node, list):
            for i, value in enumerate(node):
                walk(value, "%s/%d" % (where, i), dp)

    for s in ledger["studies"]:
        tag = gen.TAGS.get(s["key"], s["key"])
        walk(s, "ledger row %d (%s)" % (s["n"], tag), s["dp"])
        pairs = []
        if s.get("primary"):
            pairs.append((s["primary"]["ref"], s["primary"]["cand"]))
        for c in s["comparisons"]:
            pairs.append((c.get("rule") or c.get("without"), c.get("fitted") or c.get("with_")))
        for a, b in pairs:
            diff = gen.exact(b, "diff") - gen.exact(a, "diff")
            if diff != 0:
                note(forms(diff, s["dp"]), "ledger row %d (%s), a difference of two scores" % (s["n"], tag))
        extra = s.get("extra_json")
        if extra and "coverage_overall" in extra:      # rows 26 to 29 carry other extra blocks
            for key in ("coverage_overall", "coverage_release"):
                for row in extra[key]:
                    note({str(row["covered"])} if row["covered"] >= 100 else set(), "ledger row %d (%s), a count" % (s["n"], tag))
                    note(forms(Decimal(repr(row["percent"])), 1), "ledger row %d (%s), a percentage" % (s["n"], tag))
    for key, slot, value, places, file, field, what in gen.HAND:
        note(forms(Decimal(repr(value)), places), "hand table (%s)" % slot)
    if os.path.isdir(gen.PUBLIC):
        for name in sorted(os.listdir(gen.PUBLIC)):
            if not name.endswith(".json"):
                continue
            with open(os.path.join(gen.PUBLIC, name), encoding="utf-8") as handle:
                data = json.load(handle)
            for entry in data.get("numbers", []):
                if entry.get("value") is None:
                    continue
                where = "results-public/%s (%s)" % (name, entry.get("macro"))
                d = Decimal(repr(entry["value"]))
                note(forms(d), where)
                printed = re.sub(r"[^\d.]", "", str(entry.get("print", "")))
                if printed and (("." in printed) or int(printed) >= 10):
                    note({printed}, where)
    return known


def scan(path, rel, known):
    """(findings that match a known value, other numerals) for one file."""
    hits, others = [], []
    with open(path, encoding="utf-8") as handle:
        for number, line in enumerate(handle, 1):
            ok = re.search(r"%\s*number-ok:\s*\S", line)
            visible = strip_tex(line)
            for m in NUMERAL.finditer(visible):
                literal = m.group(0)
                plain = literal.replace(",", "") if re.fullmatch(r"\d{1,3}(?:,\d{3})+", literal) else literal
                if plain in known and not ok:
                    hits.append((rel, number, literal, known[plain]))
                elif plain not in known:
                    others.append((rel, number, literal, ok.group(0) if ok else ""))
    return hits, others


def main():
    args = sys.argv[1:]
    final = "--final" in args
    build = None
    if "--build" in args:
        build = args[args.index("--build") + 1]
    positional = [a for i, a in enumerate(args) if not a.startswith("--") and (i == 0 or args[i - 1] != "--build")]
    if not positional:
        sys.exit(__doc__)
    tree = os.path.abspath(positional[0])
    build = os.path.abspath(build or os.path.join(os.path.dirname(tree), "build-new", "checks"))
    os.makedirs(build, exist_ok=True)
    findings = []

    # (a) the generated files are up to date
    fresh = os.path.join(build, "numbers-fresh")
    run = subprocess.run([sys.executable, os.path.join(HERE, "make_numbers.py"), "--out", fresh, "--quiet"],
                         capture_output=True, text=True)
    if run.returncode != 0:
        findings.append("shared/numbers.tex:1: the generator failed: %s" % run.stderr.strip())
    else:
        for name in ("numbers.tex", "NUMBERS.md"):
            current = os.path.join(tree, "shared", name)
            if not os.path.exists(current) or not filecmp.cmp(current, os.path.join(fresh, name), shallow=False):
                findings.append("shared/%s:1: not up to date with the ledger and results-public/: run tools/make_numbers.py" % name)

    # (b) and (c)
    with open(gen.LEDGER, encoding="utf-8") as handle:
        ledger = json.load(handle)
    known = known_values(ledger)
    report_hits, report_others = [], []
    for folder, _, names in sorted(os.walk(tree)):
        for name in sorted(names):
            if not name.endswith(".tex"):
                continue
            path = os.path.join(folder, name)
            rel = os.path.relpath(path, tree)
            if rel in (os.path.join("shared", "numbers.tex"), os.path.join("shared", "preamble.tex")):
                continue
            hits, others = scan(path, rel, known)
            if rel.split(os.sep)[0] == "results":
                for rel_, number, literal, where in hits:
                    findings.append("%s:%d: the number %s is typed by hand; it is a value of %s. Use its macro (shared/NUMBERS.md), "
                                    "or mark the line \"%% number-ok: <reason>\"" % (rel_, number, literal, where))
            else:
                report_hits += hits
            report_others += others
    with open(os.path.join(build, "NUMBERS-TYPED.txt"), "w", encoding="utf-8") as handle:
        handle.write("Numerals typed in .tex files outside shared/numbers.tex and shared/preamble.tex. A report: it fails nothing.\n")
        handle.write("Files under results/ are held to the stricter rule by the build itself.\n\n")
        handle.write("== Typed numerals that equal a ledger or results-public value (replace each by its macro, or give a reason) ==\n")
        for rel, number, literal, where in report_hits:
            handle.write("%s:%d: %s  (%s)\n" % (rel, number, literal, where))
        handle.write("\n== Every other typed numeral (dates, versions, list numbers, identifiers) ==\n")
        for rel, number, literal, ok in report_others:
            handle.write("%s:%d: %s%s\n" % (rel, number, literal, "  [%s]" % ok.strip("% ") if ok else ""))

    if final:
        missing = set(re.findall(r"\\newcommand\{\\([A-Za-z]+)\}\{\\MissingNumber\}",
                                 open(os.path.join(tree, "shared", "numbers.tex"), encoding="utf-8").read()))
        for folder, _, names in sorted(os.walk(tree)):
            for name in sorted(names):
                rel = os.path.relpath(os.path.join(folder, name), tree)
                if name.endswith(".tex") and rel != os.path.join("shared", "numbers.tex"):
                    for number, line in enumerate(open(os.path.join(folder, name), encoding="utf-8"), 1):
                        for macro in re.findall(r"\\([A-Za-z]+)", re.sub(r"(?<!\\)%.*", "", line)):
                            if macro in missing:
                                findings.append("%s:%d: \\%s still prints ??: its results-public file is missing" % (rel, number, macro))

    for finding in findings:
        print(finding)
    print("check_numbers.py: %d finding(s); %d typed numerals equal a known value outside results/ (see %s)"
          % (len(findings), len(report_hits), os.path.relpath(os.path.join(build, "NUMBERS-TYPED.txt"), os.path.dirname(tree))))
    sys.exit(1 if findings else 0)


if __name__ == "__main__":
    main()
