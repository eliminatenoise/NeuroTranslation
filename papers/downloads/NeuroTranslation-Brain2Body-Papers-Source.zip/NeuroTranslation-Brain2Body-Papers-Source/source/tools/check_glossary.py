#!/usr/bin/env python3
"""Each edition's glossary and its text agree, both ways.

    python3 tools/check_glossary.py <source folder> [--final] [--notes]

For each of the four master files: every term the master prints in its glossary is used in that edition's
text, and every term of shared/glossary-terms.tex that the text uses is in the master's glossary list.
The text of an edition is every file its master inputs, except the files under shared/.

A term is found by the forms on its "% match: key = form | form" line in glossary-terms.tex (a form with a
capital letter is matched exactly; any other form in either case), or by the term as printed.

While an edition still has an unwritten section (a \\LaneStub line) the two lists cannot agree yet, so a
mismatch is counted as a note (listed with --notes) and does not fail. Once no section is unwritten, or
with --final, a mismatch fails. A key that is unknown or listed twice always fails. The five fixed names
are printed in every glossary whether or not the edition uses each one. A used term that is not printed
always fails. Findings are printed as file:line: message; exit status 1 on any finding. Standard library only.
"""
import os
import re
import sys

# The fixed names are printed in all four glossaries whether or not an edition happens to use each one.
FIXED = {"neurotranslation", "neurotranslate", "neurotranslatezero", "neurotranslator", "brain2body"}
MASTERS = ["neurotranslation-technical", "neurotranslation-explained", "brain2body-article", "brain2body-simple-english"]


def no_comments(text):
    return re.sub(r"(?<!\\)%.*", "", text)


def group(text, start):
    """The brace group that opens at text[start] == '{': (content, index after the closing brace)."""
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "{" and (i == 0 or text[i - 1] != "\\"):
            depth += 1
        elif text[i] == "}" and text[i - 1] != "\\":
            depth -= 1
            if depth == 0:
                return text[start + 1:i], i + 1
    raise ValueError("unbalanced braces")


def read_terms(path):
    raw = open(path, encoding="utf-8").read()
    matches = {}
    for m in re.finditer(r"^%\s*match:\s*([a-z0-9]+)\s*=\s*(.+)$", raw, re.M):
        matches[m.group(1)] = [f.strip() for f in m.group(2).split("|") if f.strip()]
    text = no_comments(raw)
    terms = {}
    for m in re.finditer(r"\\GlossEntry\s*", text):
        i, parts = m.end(), []
        for _ in range(4):
            while text[i] in " \n\t":
                i += 1
            content, i = group(text, i)
            parts.append(content)
        key, printed = parts[0].strip(), parts[1].strip()
        terms[key] = {"printed": printed, "forms": matches.get(key, [printed]), "line": raw[:raw.find("\\GlossEntry{%s}" % key)].count("\n") + 1}
    return terms


def files_of(master):
    out, queue, base = [], [master], os.path.dirname(master)
    while queue:
        current = queue.pop(0)
        text = no_comments(open(current, encoding="utf-8").read())
        for m in re.finditer(r"\\input\s*\{([^{}]+)\}", text):
            path = os.path.normpath(os.path.join(base, m.group(1)))       # the engine runs in the master's folder
            if os.path.exists(path) and path not in out:
                out.append(path)
                queue.append(path)
    return out


def uses(form, text):
    flags = 0 if re.search(r"[A-Z]", form) else re.I
    pattern = r"(?<![A-Za-z0-9])" + re.escape(form).replace(r"\ ", r"\s+") + r"(?![A-Za-z0-9])"
    return re.search(pattern, text, flags)


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    final = "--final" in sys.argv
    if not args:
        sys.exit(__doc__)
    tree = os.path.abspath(args[0])
    terms = read_terms(os.path.join(tree, "shared", "glossary-terms.tex"))
    findings, notes = [], []
    for edition in MASTERS:
        found = [os.path.join(d, f) for d, _, fs in os.walk(tree) for f in fs if f == edition + ".tex"]
        if len(found) != 1:
            findings.append("%s.tex:1: expected exactly one master of this name, found %d" % (edition, len(found)))
            continue
        master = found[0]
        rel = os.path.relpath(master, tree)
        mtext = no_comments(open(master, encoding="utf-8").read())
        m = re.search(r"\\PrintGlossary\s*\{([^{}]*)\}", mtext)
        if not m:
            findings.append("%s:1: the master prints no glossary (\\PrintGlossary)" % rel)
            continue
        line = open(master, encoding="utf-8").read()[:open(master, encoding="utf-8").read().find("\\PrintGlossary")].count("\n") + 1
        listed = [k.strip() for k in m.group(1).split(",") if k.strip()]
        for key in listed:
            if key not in terms:
                findings.append("%s:%d: glossary key \"%s\" is not in shared/glossary-terms.tex" % (rel, line, key))
        for key in sorted(set(k for k in listed if listed.count(k) > 1)):
            findings.append("%s:%d: glossary key \"%s\" is listed twice" % (rel, line, key))
        body_files = [p for p in files_of(master) if os.path.relpath(p, tree).split(os.sep)[0] != "shared"]
        body, stubs = "", False
        for path in body_files:
            text = no_comments(open(path, encoding="utf-8").read())
            stubs = stubs or "\\LaneStub" in text
            body += "\n" + re.sub(r"\\[A-Za-z@]+", " ", text)
        for key, term in sorted(terms.items()):
            used = any(uses(form, body) for form in term["forms"])
            if key in listed and not used and key not in FIXED:
                message = "%s:%d: the glossary prints \"%s\" but the text of this edition does not use it" % (rel, line, term["printed"])
                (notes if stubs and not final else findings).append(message)
            if used and key not in listed:
                message = ("%s:%d: the text of this edition uses \"%s\" but its glossary does not print it (the key \"%s\" "
                           "has to be added to the master's list)" % (rel, line, term["printed"], key))
                (notes if stubs and not final else findings).append(message)
    if "--notes" in sys.argv:
        for note in notes:
            print("note: " + note)
    for finding in findings:
        print(finding)
    print("check_glossary.py: %d finding(s), %d note(s)" % (len(findings), len(notes)))
    sys.exit(1 if findings else 0)


if __name__ == "__main__":
    main()
