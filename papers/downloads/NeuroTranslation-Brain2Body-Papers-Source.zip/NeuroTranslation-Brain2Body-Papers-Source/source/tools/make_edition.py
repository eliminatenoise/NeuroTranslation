#!/usr/bin/env python3
"""Put one built edition of the four papers into a folder ready for the repository.

    python3 source-new/tools/make_edition.py <build folder> <edition folder> <epoch> [<notices folder>]

Run from the folder that holds the source tree (papers/). Reads only:
    <build folder>/<edition>.pdf and <build folder>/<edition>/output/<edition>.aux   (from build.sh)
    shared/credits.tex and tools/check_anchors.py of this source tree
    results-public/*.json beside the source tree
    <notices folder>/Noto-OFL.txt and FiraMath-LICENSE.txt, if given (the font licence texts)
Writes into <edition folder>: the four PDFs, NOTICE.md (from the credits table and the font licences),
results-public/, third-party-notices/ (if a notices folder was given), anchors.json (each study anchor and
the page it lands on in each NeuroTranslation edition), EDITION.json (date, epoch, page counts, fingerprints)
and SHA256SUMS. Standard library only.
"""
import datetime
import hashlib
import json
import os
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TREE = os.path.dirname(HERE)
PAPERS = os.path.dirname(TREE)
EDITIONS = ["neurotranslation-technical", "neurotranslation-explained", "brain2body-article", "brain2body-simple-english"]
TITLES = {"neurotranslation-technical": "NeuroTranslation: A New Paradigm In Brain-Body Mapping.",
          "neurotranslation-explained": "NeuroTranslation: A New Paradigm In Brain-Body Mapping. Simple English Edition",
          "brain2body-article": "Brain2Body: The Next Generation In Body-Brain Interfacing.",
          "brain2body-simple-english": "Brain2Body: The Next Generation In Body-Brain Interfacing. Simple English Edition"}


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1 << 16), b""):
            h.update(block)
    return h.hexdigest()


def groups(text, start, count):
    """The next `count` brace groups after position start: (list of contents, end position)."""
    out, i = [], start
    while len(out) < count:
        while text[i] in " \t\n%":
            if text[i] == "%":
                i = text.index("\n", i)
            i += 1
        assert text[i] == "{", text[i:i + 40]
        depth, j = 0, i
        while True:
            if text[j] == "{" and text[j - 1] != "\\":
                depth += 1
            elif text[j] == "}" and text[j - 1] != "\\":
                depth -= 1
                if depth == 0:
                    break
            j += 1
        out.append(text[i + 1:j])
        i = j + 1
    return out, i


def plain(tex):
    """The credits' LaTeX as Markdown."""
    s = re.sub(r"\s*\\cite\{[^}]*\}", "", tex)
    s = re.sub(r"\\url\{([^}]*)\}", r"<\1>", s)
    s = re.sub(r"\\ForEdition\{([^}]*)\}\{([^}]*)\}", r"\1 (Simple English Edition: \2)", s)
    s = s.replace("\\&", "&").replace("\\%", "%").replace("\\_", "_").replace("~", " ").replace("--", "–")
    s = re.sub(r"\\textit\{([^}]*)\}", r"*\1*", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def credits():
    text = open(os.path.join(TREE, "shared", "credits.tex"), encoding="utf-8").read()
    body = "\n".join(l for l in text.split("\n") if not l.lstrip().startswith("%"))
    items, i = [], 0
    while True:
        m = re.search(r"\\Credit(Row|Group)", body[i:])
        if not m:
            break
        start = i + m.end()
        if m.group(1) == "Row":
            g, i = groups(body, start, 6)
            items.append(("row", g))
        else:
            g, i = groups(body, start, 2)
            items.append(("group", g))
    tail = body[i:]
    closing = plain(tail.split("\\addvspace{12pt}", 1)[-1])
    intro = plain(body[:body.index("\\CreditGroup")])
    return intro, items, closing


def anchors(build):
    names = re.search(r"ANCHORS = \[(.*?)\]", open(os.path.join(HERE, "check_anchors.py"), encoding="utf-8").read(), re.S).group(1)
    names = re.findall(r'"([^"]+)"', names)
    out = {}
    for edition in EDITIONS[:2]:
        aux = open(os.path.join(build, edition, "output", edition + ".aux"), encoding="utf-8").read()
        for name in names:
            m = re.search(r"\\newlabel\{%s\}\{\{[^{}]*\}\{(\d+)\}" % re.escape(name), aux)
            if not m:
                sys.exit("make_edition.py: anchor %s not found in %s" % (name, edition))
            out.setdefault(name, {})[edition] = int(m.group(1))
    return names, out


def main():
    if len(sys.argv) < 4:
        sys.exit(__doc__)
    build, dest, epoch = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2]), int(sys.argv[3])
    notices = os.path.abspath(sys.argv[4]) if len(sys.argv) > 4 else None
    os.makedirs(dest, exist_ok=True)
    pages = {}
    for edition in EDITIONS:
        src = os.path.join(build, edition + ".pdf")
        shutil.copyfile(src, os.path.join(dest, edition + ".pdf"))
        log = open(os.path.join(build, edition, "output", edition + ".log"), encoding="utf-8", errors="replace").read()
        m = re.search(r"Output written on .*?\((\d+) pages", log, re.S)
        pages[edition] = int(m.group(1)) if m else None

    # results-public
    rp_src, rp_dst = os.path.join(PAPERS, "results-public"), os.path.join(dest, "results-public")
    os.makedirs(rp_dst, exist_ok=True)
    for name in sorted(os.listdir(rp_src)):
        if name.endswith(".json"):
            shutil.copyfile(os.path.join(rp_src, name), os.path.join(rp_dst, name))

    # third-party notices: the two font licences (no DejaVu Sans: no figure of this edition carries it)
    fonts = [("Noto Sans and Noto Sans Mono", "Noto-OFL.txt", "SIL Open Font License 1.1", "<https://github.com/notofonts/latin-greek-cyrillic>", "all four papers"),
             ("Fira Math", "FiraMath-LICENSE.txt", "SIL Open Font License 1.1", "<https://github.com/firamath/firamath>", "the two NeuroTranslation editions (mathematics)")]
    if notices:
        os.makedirs(os.path.join(dest, "third-party-notices"), exist_ok=True)
        for _, name, _, _, _ in fonts:
            shutil.copyfile(os.path.join(notices, name), os.path.join(dest, "third-party-notices", name))

    # NOTICE.md
    intro, items, closing = credits()
    lines = ["# Credits, licences and notices for this edition of the papers", "",
             "This file is generated from the papers' own credits table (`shared/credits.tex`), so it says what the papers",
             "say. Each paper prints the rows it relies on; the letter after each heading says which: NeuroTranslation (N),",
             "Brain2Body (B), or both.", "", intro, ""]
    for kind, g in items:
        if kind == "group":
            lines += ["## %s" % plain(g[1]), ""]
        else:
            flags, what, who, where, licence, used = g
            papers = {"n": "N", "b": "B", "nb": "N, B"}[flags]
            lines += ["### %s (%s)" % (plain(what), papers), "",
                      "- Made by: %s" % plain(who), "- Version and where: %s" % plain(where),
                      "- Licence: %s" % plain(licence), "- Used for: %s" % plain(used), ""]
    lines += ["## Fonts embedded in the PDFs", "",
              "| Family | Licence | Licence text | Source | Embedded in |", "| --- | --- | --- | --- | --- |"]
    for family, name, licence, source, where in fonts:
        link = "[%s](third-party-notices/%s)" % (name, name) if notices else name
        lines.append("| %s | %s | %s | %s | %s |" % (family, licence, link, source, where))
    lines += ["", "No other typeface is embedded: every PDF of this edition was checked to carry only Noto Sans, Noto Sans Mono",
              "and Fira Math, all embedded.", "", "## The papers' own text", "", closing, ""]
    open(os.path.join(dest, "NOTICE.md"), "w", encoding="utf-8").write("\n".join(lines))

    # anchors.json
    names, where = anchors(build)
    json.dump({"what": "Each study's named destination in the two NeuroTranslation PDFs and the page it lands on. Link to "
                       "<edition>.pdf#nameddest=<anchor> (or #<anchor>); the page is given for readers that ignore named destinations.",
               "not_tests": ["daily-sports-limbs", "wrist-forearm-correction"],
               "anchors": [{"anchor": n, "pages": where[n]} for n in names]},
              open(os.path.join(dest, "anchors.json"), "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    with open(os.path.join(dest, "anchors.json"), "a", encoding="utf-8") as handle:
        handle.write("\n")

    # EDITION.json
    date = datetime.datetime.fromtimestamp(epoch, datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    json.dump({"source_date_epoch": epoch, "date_stamped_in_the_pdfs": date,
               "build": "SOURCE_DATE_EPOCH=%d FINAL=1 SOURCE_DIR=source-new BUILD_DIR=<folder> ./build.sh" % epoch,
               "papers": [{"file": e + ".pdf", "title": TITLES[e], "pages": pages[e],
                           "sha256": sha(os.path.join(dest, e + ".pdf"))} for e in EDITIONS],
               "to_rebuild": {
                   "what_the_source_archive_must_hold": [
                       "the whole source tree below (TeX, bibliography, the figure in its two label sets with its CSV, the seven font files, the tools)",
                       "build.sh, which sits beside the source tree",
                       "the TeX engine Tectonic 0.17 as a static binary (build.sh checks its SHA-256) and the 415 package "
                       "files it needs, already fetched, or instructions to fetch exactly those; the engine runs with no network",
                       "for regenerating the numbers (not for building the PDFs): the ledger of results (ledger.json), the "
                       "results-public/ files and the repository's benchmark result files that the ledger names",
                       "for regenerating the figure (not for building the PDFs): a Python with matplotlib"],
                   "host_programs": ["bash", "coreutils", "find", "awk", "grep", "bwrap", "prlimit", "timeout", "pdfinfo",
                                     "pdffonts", "python3"],
                   "source_tree_files": [
                       {"path": os.path.relpath(os.path.join(f, x), TREE).replace(os.sep, "/"), "sha256": sha(os.path.join(f, x))}
                       for f, _, xs in sorted(os.walk(TREE)) for x in sorted(xs) if "__pycache__" not in f]}},
              open(os.path.join(dest, "EDITION.json"), "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    with open(os.path.join(dest, "EDITION.json"), "a", encoding="utf-8") as handle:
        handle.write("\n")

    # SHA256SUMS over everything else in the folder
    files = []
    for folder, _, names_ in os.walk(dest):
        for name in names_:
            rel = os.path.relpath(os.path.join(folder, name), dest)
            if rel != "SHA256SUMS":
                files.append(rel)
    with open(os.path.join(dest, "SHA256SUMS"), "w", encoding="utf-8") as handle:
        for rel in sorted(files):
            handle.write("%s  %s\n" % (sha(os.path.join(dest, rel)), rel))
    print("make_edition.py: %d files in %s" % (len(files) + 1, os.path.relpath(dest, PAPERS)))


if __name__ == "__main__":
    main()
