#!/usr/bin/env python3
"""Write shared/numbers.tex and shared/NUMBERS.md: one TeX macro per reported number.

    python3 tools/make_numbers.py                 write into <tree>/shared/
    python3 tools/make_numbers.py --out DIR       write the two files into DIR instead (used by check_numbers.py)
    python3 tools/make_numbers.py --verify        also re-read every number at its result file and compare

Inputs (nothing else is read):
    the ledger of measured results          LEDGER_JSON, default <papers>/../neuro/ledger.json
    small result files for other studies    RESULTS_PUBLIC, default <papers>/results-public/*.json
    names promised but not yet delivered    tools/pending-macros.txt
    the hand table below                    numbers the ledger gives only inside a sentence
    (only with --verify) the result files   RESULTS_ROOT, default <papers>/../../repos/NeuroTranslation

<papers> is the folder that holds this source tree. Standard library only.

Exit status 1, with a message naming the entry, when: a ledger number has no file and field; two entries
would get the same macro name; a results-public entry has no source; a printed form disagrees with its value.
"""
import json
import os
import re
import sys
from decimal import Decimal, ROUND_HALF_UP

HERE = os.path.dirname(os.path.abspath(__file__))
TREE = os.path.dirname(HERE)
PAPERS = os.path.dirname(TREE)
LEDGER = os.environ.get("LEDGER_JSON") or os.path.join(PAPERS, "..", "neuro", "ledger.json")  # integrator, pass 2: the current ledger (rows 1 to 29), the edition's cut-off
PUBLIC = os.environ.get("RESULTS_PUBLIC") or os.path.join(PAPERS, "results-public")
ROOT = os.environ.get("RESULTS_ROOT") or os.path.join(PAPERS, "..", "..", "repos", "NeuroTranslation")  # integrator, pass 2: the working clone (the reference checkout lacks rows 26 to 29)
PENDING = os.path.join(HERE, "pending-macros.txt")

# Ledger key -> macro tag (letters only: TeX allows nothing else in a macro name).
TAGS = {
    "wrist-pointing-temporal": "WristEeg",
    "wrist-pointing-muscle": "WristEmg",
    "wrist-forearm-transfer": "WristForearm",
    "uji-wrist-emg": "Everyday",
    "surface-emg-elbow": "Elbow",
    "scalp-eeg-hand": "PalmPilot",
    "scalp-eeg-palm-history": "Palm",
    "scalp-eeg-personal-calibration": "PalmCal",
    "way-grip-force": "LiftCue",
    "way-contact-force": "LiftSqueeze",
    "hygrip-force": "Grip",
    "hygrip-force/forearm-results": "GripEmg",
    "hygrip-force/cue-phase": "GripPhase",
    "hyser-index": "Finger",
    "hyser-index/crossday": "FingerDay",
    "hyser-index/whole-hand": "FingerFive",
    "hyser-index/prescribed": "FingerTask",
    "cemhsey-pinch": "Pinch",
    "cemhsey-arrays": "PinchGrids",
    "cemhsey-intervals": "PinchBand",
    "cemhsey-transfer": "PinchTarget",
    "cemhsey-carry": "PinchNextDay",
    "cemhsey-phase": "PinchGroup",
    "LINK": "Macaque",
    "first-general-learner-run": "LongRun",
    # integrator, pass 2: rows 26 to 29 of the current ledger
    "daily-sports-arm": "Walk",                 # study 26: arm sensor while walking (a study)
    "daily-sports-limbs": "WalkFive",           # row 27: the general model's five-sensor fit (not a test)
    "paired-wrist-forecast": "GeneralWrist",    # study 28: the general model at the wrist (a study)
    "wrist-forearm-correction": "WristInFit",   # row 29: the EMG correction within the fitting group (not a test)
}

# Ledger unit -> (unit macro used after a number, bare symbol for a table column).
UNITS = {
    "°": ("\\UnitDeg", "°"),
    "mm": ("\\UnitMm", "mm"),
    "N": ("\\UnitN", "N"),
    "mV": ("\\UnitMv", "mV"),
    "% of MVC": ("\\UnitMvc", "\\% of MVC"),
    "% of readings; widths in % of MVC": ("\\UnitMvc", "\\% of MVC"),
    "(normalised units)²": ("", "normalised"),
    "(normalised)": ("", "normalised"),
    "sensor units": ("", "sensor units"),       # rows 26 and 27: the accelerometer's stored values, no physical unit
}

KINDS = {"carry": "Carry", "eeg": "Eeg", "emg": "Emg", "eeg-alone": "EegAlone", "emg-alone": "EmgAlone",
         "personal": "Personal", "cue-rule": "CueRule"}

# Numbers the ledger gives only inside a sentence ("others", "happened", a range text). One entry is added
# for each number a writer asks for, after the result file has been opened. The value is read here as typed
# and, with --verify, compared with the result file.
#   (study key, slot, value, decimal places or None for the study's, file, field, what it is)
HAND = [
    ("first-general-learner-run", "TenAheadEmgModel", 0.5550961369599728, None,
     "papers/experimental/cemhsey-pinch-carry-2026-11-19/training-diagnostic-summary.json",
     "metrics/emg_rms/all_selected_original_TRAIN_windows/10/normalized_MSE/continued_final990",
     "the network after 990 updates, muscle stream, ten rows ahead"),
    ("first-general-learner-run", "TenAheadEmgCarry", 0.7344783633436713, None,
     "papers/experimental/cemhsey-pinch-carry-2026-11-19/training-diagnostic-summary.json",
     "metrics/emg_rms/all_selected_original_TRAIN_windows/10/normalized_MSE/past_featurewise_persistence",
     "past value carried forward, muscle stream, ten rows ahead"),
    ("wrist-pointing-temporal", "SeedRiseA", 0.4499960975154895, None, "benchmarks/wrist-pointing-temporal/DEVELOPMENT-AGGREGATE.json", "primary/seeds_delta_rmse_deg/17", "rise in error with EEG in the first of the network's three trainings"),
    ("wrist-pointing-temporal", "SeedRiseB", 0.5348716495725316, None, "benchmarks/wrist-pointing-temporal/DEVELOPMENT-AGGREGATE.json", "primary/seeds_delta_rmse_deg/43", "rise in error with EEG in the second of the network's three trainings (in order of size)"),
    ("wrist-pointing-temporal", "SeedRiseC", 0.7928907075310487, None, "benchmarks/wrist-pointing-temporal/DEVELOPMENT-AGGREGATE.json", "primary/seeds_delta_rmse_deg/29", "rise in error with EEG in the third of the network's three trainings (in order of size)"),
    ("scalp-eeg-palm-history", "RiseA", 0.17011764747469438, None, "benchmarks/scalp-eeg-palm-history/RESULT.json", "dev_comparisons/primary/per_participant_delta_rmse_mm/sub-10", "rise in one tested person's error with EEG (the largest of the three)"),
    ("scalp-eeg-palm-history", "RiseB", 0.02985379315866732, None, "benchmarks/scalp-eeg-palm-history/RESULT.json", "dev_comparisons/primary/per_participant_delta_rmse_mm/sub-11", "rise in one tested person's error with EEG (the smallest of the three)"),
    ("scalp-eeg-palm-history", "RiseC", 0.16590402381155944, None, "benchmarks/scalp-eeg-palm-history/RESULT.json", "dev_comparisons/primary/per_participant_delta_rmse_mm/sub-12", "rise in one tested person's error with EEG (the third person)"),
    ("scalp-eeg-palm-history", "TrialsEegLower", 72, 0, "benchmarks/scalp-eeg-palm-history/RESULT.json", "cohorts/DEV/paired_trials/primary/candidate", "test trials on which EEG lowered the squared error"),
    ("scalp-eeg-palm-history", "TrialsAll", 173, 0, "benchmarks/scalp-eeg-palm-history/RESULT.json", "cohorts/DEV/trials", "test trials in all"),
    ("way-grip-force", "StrongForceWithout", 0.77496, None, "benchmarks/way-grip-force/DEVELOPMENT-AGGREGATE.json", "dev_target_force_strata/target_force_above_0p5_n/strong/rmse_n", "error without EEG on the forecasts whose target force was above 0.5 N"),
    ("way-grip-force", "StrongForceWith", 0.7758, None, "benchmarks/way-grip-force/DEVELOPMENT-AGGREGATE.json", "dev_target_force_strata/target_force_above_0p5_n/eeg/rmse_n", "error with EEG on the forecasts whose target force was above 0.5 N"),
    ("way-grip-force", "EmgMaeWithout", 0.271851, None, "benchmarks/way-grip-force/DEVELOPMENT-AGGREGATE.json", "dev_full/strong/mae_n", "mean absolute error without EMG (the study's second measure)"),
    ("way-grip-force", "EmgMaeWith", 0.264594, None, "benchmarks/way-grip-force/DEVELOPMENT-AGGREGATE.json", "dev_full/emg/mae_n", "mean absolute error with EMG (the study's second measure)"),
    ("uji-wrist-emg", "FlexWithout", 48.78570275874003, None, "benchmarks/uji-wrist-emg/DEVELOPMENT-AGGREGATE.json", "primary/primary/models/task_time/axis_rmse_deg/extension_deg", "error on the bend-and-straighten axis without EMG"),
    ("uji-wrist-emg", "FlexWith", 46.36478902062879, None, "benchmarks/uji-wrist-emg/DEVELOPMENT-AGGREGATE.json", "primary/primary/models/task_time_emg/axis_rmse_deg/extension_deg", "error on the bend-and-straighten axis with EMG"),
    ("uji-wrist-emg", "SideWithout", 15.45678957687409, None, "benchmarks/uji-wrist-emg/DEVELOPMENT-AGGREGATE.json", "primary/primary/models/task_time/axis_rmse_deg/radial_deviation_deg", "error on the side-to-side axis (towards thumb or little finger) without EMG"),
    ("uji-wrist-emg", "SideWith", 16.15649714687339, None, "benchmarks/uji-wrist-emg/DEVELOPMENT-AGGREGATE.json", "primary/primary/models/task_time_emg/axis_rmse_deg/radial_deviation_deg", "error on the side-to-side axis (towards thumb or little finger) with EMG"),
    ("first-general-learner-run", "FortyEmg", 1.065703117562344, None, "papers/experimental/cemhsey-pinch-carry-2026-11-19/training-diagnostic-summary.json", "metrics/emg_rms/all_selected_original_TRAIN_windows/all/normalized_MSE/frozen_parent40", "the network after its first 40 updates, muscle stream, both horizons together"),
    ("first-general-learner-run", "FortyGlove", 1.1992171367822229, None, "papers/experimental/cemhsey-pinch-carry-2026-11-19/training-diagnostic-summary.json", "metrics/glove_angles/all_selected_original_TRAIN_windows/all/normalized_MSE/frozen_parent40", "the network after its first 40 updates, glove stream, both horizons together"),
    ("first-general-learner-run", "OneAheadEmgModel", 0.41254365424001344, None, "papers/experimental/cemhsey-pinch-carry-2026-11-19/training-diagnostic-summary.json", "metrics/emg_rms/all_selected_original_TRAIN_windows/1/normalized_MSE/continued_final990", "the network after 990 updates, muscle stream, one row ahead"),
    ("first-general-learner-run", "OneAheadEmgCarry", 0.14465972419162815, None, "papers/experimental/cemhsey-pinch-carry-2026-11-19/training-diagnostic-summary.json", "metrics/emg_rms/all_selected_original_TRAIN_windows/1/normalized_MSE/past_featurewise_persistence", "past value carried forward, muscle stream, one row ahead"),
    ("first-general-learner-run", "OneAheadGloveModel", 0.34938925569254925, None, "papers/experimental/cemhsey-pinch-carry-2026-11-19/training-diagnostic-summary.json", "metrics/glove_angles/all_selected_original_TRAIN_windows/1/normalized_MSE/continued_final990", "the network after 990 updates, glove stream, one row ahead"),
    ("first-general-learner-run", "OneAheadGloveCarry", 0.0004908467144512168, None, "papers/experimental/cemhsey-pinch-carry-2026-11-19/training-diagnostic-summary.json", "metrics/glove_angles/all_selected_original_TRAIN_windows/1/normalized_MSE/past_featurewise_persistence", "past value carried forward, glove stream, one row ahead"),
    ("first-general-learner-run", "TenAheadGloveModel", 0.3950666659142399, None, "papers/experimental/cemhsey-pinch-carry-2026-11-19/training-diagnostic-summary.json", "metrics/glove_angles/all_selected_original_TRAIN_windows/10/normalized_MSE/continued_final990", "the network after 990 updates, glove stream, ten rows ahead"),
    ("first-general-learner-run", "TenAheadGloveCarry", 0.048663762301765986, None, "papers/experimental/cemhsey-pinch-carry-2026-11-19/training-diagnostic-summary.json", "metrics/glove_angles/all_selected_original_TRAIN_windows/10/normalized_MSE/past_featurewise_persistence", "past value carried forward, glove stream, ten rows ahead"),
    ("scalp-eeg-personal-calibration", "OffsetsOnly", 1.8482454885198918, None, "benchmarks/scalp-eeg-personal-calibration/RESULT.json", "metrics/equal_person/time_palm_eeg_timing/rmse_mm", "the EEG model given only an offset at each of the nine forecast times from the person's first recording, its weights unchanged (the study's control for the full adjustment)"),
]

WORDS = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven",
         "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"]
TENS = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]
MINUS = "\u2212"


def fail(message):
    sys.stderr.write("make_numbers.py: %s\n" % message)
    sys.exit(1)


def word(n):
    if n < 0 or n > 99:
        return str(n)
    if n < 20:
        return WORDS[n]
    tens, ones = divmod(n, 10)
    return TENS[tens] if ones == 0 else "%s-%s" % (TENS[tens], WORDS[ones])


def whole(n):
    """A whole number as the papers print it: 4,736 (a comma from 1,000), as results-public/ and the prose do."""
    return format(int(n), ",")


def letters(index):
    """0 -> A, 25 -> Z, 26 -> AA."""
    out = ""
    index += 1
    while index:
        index, rem = divmod(index - 1, 26)
        out = chr(65 + rem) + out
    return out


def exact(obj, where):
    """The value of a ledger number as an exact decimal, from its raw value and scale."""
    if not obj.get("file") or not obj.get("field"):
        fail("ledger entry has no file and field: %s" % where)
    value = obj["value"]
    if obj.get("scale"):
        d = Decimal(repr(obj["raw"])) * Decimal(repr(obj["scale"]))
        if abs(float(d) - value) > 1e-9 * max(1.0, abs(value)):
            d = -d
        if abs(float(d) - value) > 1e-9 * max(1.0, abs(value)):
            fail("ledger entry's value is not its raw value times its scale: %s" % where)
        return d
    return Decimal(repr(value))


def to_dp(d, dp):
    q = d.quantize(Decimal(1).scaleb(-dp), rounding=ROUND_HALF_UP)
    if q == 0:
        q = abs(q)
    return format(q, "f")


def to_sig(d, sig):
    if d == 0:
        return "0"
    exponent = d.adjusted() - sig + 1
    q = d.quantize(Decimal(1).scaleb(exponent), rounding=ROUND_HALF_UP)
    if q.adjusted() != d.adjusted():          # 9.996 -> 10.0: one digit too many
        q = q.quantize(Decimal(1).scaleb(exponent + 1), rounding=ROUND_HALF_UP)
    if exponent > 0:
        q = q.quantize(Decimal(1))
    return format(q, "f")


def shorter(full, short):
    """The short form is never longer than the full one (a change of 0.009 stays 0.009, not 0.0085)."""
    places = lambda text: len(text.split(".")[1]) if "." in text else 0
    return full if places(short) > places(full) else short


def signed(text):
    """'-0.469' -> true minus; a positive value gets a plus; zero stays bare."""
    if text.startswith("-"):
        body = text[1:]
        return body if Decimal(body) == 0 else MINUS + body
    return text if Decimal(text) == 0 else "+" + text


class Book:
    """All macros, in order, with what each prints and where it came from."""

    def __init__(self):
        self.names = {}
        self.sections = []          # (title, intro lines, rows, text-only sentences)
        self.current = None

    def section(self, title, intro):
        self.current = {"title": title, "intro": intro, "rows": [], "text": []}
        self.sections.append(self.current)

    def add(self, name, prints, what, source, short=None):
        if not re.fullmatch(r"[A-Za-z]+", name):
            fail("macro name is not letters only: %s (%s)" % (name, what))
        for n in [name] + ([name + "Short"] if short is not None else []):
            if n in self.names:
                fail("two entries would get the macro name \\%s: (%s) and (%s)" % (n, self.names[n], what))
            self.names[n] = what
        self.current["rows"].append((name, prints, short, what, source))

    def value(self, name, obj, dp, what, where, diff=False):
        d = exact(obj, where)
        source = "`%s` → `%s`" % (obj["file"], obj["field"])
        if obj.get("note"):
            source += " (%s)" % obj["note"]
        full = to_dp(d, dp)
        short = shorter(full, to_sig(d, 2 if diff else 3))
        if diff:
            full, short = signed(full), signed(short)
        self.add(name, full, what, source, short=short)
        return d

    def count(self, stem, n, what, source, bare=False):
        self.add(stem if bare else stem + "Num", str(n), what, source)
        self.add(stem + "Text", word(n), what + " (in words)", source)
        self.add(stem + "Title", word(n).capitalize() if n <= 99 else str(n), what + " (capitalised, for a heading)", source)


def better(book, name, pair, what, source):
    if not pair:
        return
    book.add(name + "Better", str(pair[0]), "people who did better: " + what, source)
    book.add(name + "BetterOf", str(pair[1]), "of this many people: " + what, source)


def study_macros(book, s):
    tag = TAGS.get(s["key"])
    if tag is None:
        fail("ledger study has no macro tag: %s" % s["key"])
    dp = s["dp"]
    unit_macro, unit_col = UNITS.get(s["unit"], (None, None))
    if unit_macro is None:
        fail("ledger unit has no unit macro: %r (study %s)" % (s["unit"], s["key"]))
    tested = s.get("n_tested_text") or "%d" % s["n_tested"]
    book.section("%d. `%s`: %s" % (s["n"], tag, s["name"]),
                 ["Ledger key `%s`. People tested: %s. Unit: %s. Printed to %d decimal places."
                  % (s["key"], tested, s["unit"], dp), "People: %s." % s["people"].rstrip(".")])
    led = "ledger row %d" % s["n"]
    book.count(tag + "Tested", s["n_tested"], "people tested", "%s → `n_tested`" % led, bare=True)
    m = re.match(r"(?:corrections )?fitted on (?:the )?(?:same )?(\d+) ", s["people"])
    if m:
        book.count(tag + "Fitted", int(m.group(1)), "people the model was fitted on", "%s → `people` (text)" % led, bare=True)
    book.add(tag + "Unit", unit_macro, "the unit, to follow a number", "%s → `unit`" % led)
    book.add(tag + "UnitCol", unit_col, "the unit as a bare symbol, for a table column", "%s → `unit`" % led)

    p = s.get("primary")
    if p:
        w = "%s/primary" % s["key"]
        ref = book.value(tag + "PrimaryRef", p["ref"], dp, "main comparison, reference: " + p["ref_label"], w + "/ref")
        cand = book.value(tag + "PrimaryCand", p["cand"], dp, "main comparison, candidate: " + p["cand_label"], w + "/cand")
        diff = cand - ref
        if abs(float(diff) - p["diff"]) > 1e-9:
            fail("ledger diff is not candidate minus reference: %s" % w)
        src = "computed: `PrimaryCand` minus `PrimaryRef`"
        book.add(tag + "PrimaryDiff", signed(to_dp(diff, dp)), "main comparison, change in error with its sign", src,
                 short=signed(shorter(to_dp(diff, dp), to_sig(diff, 2))))
        book.add(tag + "PrimaryDiffAbs", to_dp(abs(diff), dp), "main comparison, size of the change, no sign", src,
                 short=shorter(to_dp(abs(diff), dp), to_sig(abs(diff), 2)))
        if p.get("range"):
            kind = p["range"]["kind"]
            book.value(tag + "PrimaryLo", p["range"]["lo"], dp, "main comparison, low end of the published range (%s)" % kind,
                       w + "/range/lo", diff=True)
            book.value(tag + "PrimaryHi", p["range"]["hi"], dp, "main comparison, high end of the published range (%s)" % kind,
                       w + "/range/hi", diff=True)
        elif p.get("range_text"):
            book.current["text"].append("range: " + p["range_text"])
        if p.get("better"):
            better(book, tag + "Primary", p["better"], "main comparison", "`%s`" % p["better"][2] if len(p["better"]) > 2 else led)
        elif p.get("better_text"):
            book.current["text"].append("people better: " + p["better_text"])
    elif s.get("primary_text"):
        book.current["text"].append("main comparison: " + s["primary_text"])

    for group, slot in (("baselines", "Base"), ("models", "Model")):
        for i, (label, obj) in enumerate(s[group]):
            book.value(tag + slot + letters(i), obj, dp, "%s: %s" % ("baseline" if slot == "Base" else "model", label),
                       "%s/%s/%d" % (s["key"], group, i))

    seen = {}
    for c in s["comparisons"]:
        kind = KINDS.get(c["kind"])
        if kind is None:
            fail("unknown comparison kind %r in study %s" % (c["kind"], s["key"]))
        i = seen.get(kind, 0)
        seen[kind] = i + 1
        stem = tag + kind + letters(i)
        w = "%s/comparisons/%s %s" % (s["key"], c["kind"], letters(i))
        if c["kind"] in ("carry", "cue-rule"):
            where = c.get("shift") or c.get("setting") or ""
            rule_label = c.get("rule_label") or "current reading plus the scheduled change"
            fitted_label = c.get("fitted_label") or "best fitted model"
            lead = ("repeat-the-last-value" if c["kind"] == "carry" else "scheduled-change rule") + (" (%s)" % where if where else "")
            a = book.value(stem + "Rule", c["rule"], dp, "%s, the rule: %s" % (lead, rule_label), w + "/rule")
            b = book.value(stem + "Fitted", c["fitted"], dp, "%s, the fitted model: %s" % (lead, fitted_label), w + "/fitted")
            first, second = "Fitted", "Rule"
        else:
            if c["kind"] == "personal":
                lead, first_slot, second_slot = "adjustment (%s)" % c["what"], "Before", "After"
            else:
                signal = "EEG" if c["kind"].startswith("eeg") else "EMG"
                lead = "%s %s (%s)%s" % (signal, "alone against" if c["kind"].endswith("alone") else "added to", c["into"],
                                         ", the study's main question" if c.get("primary") else "")
                first_slot, second_slot = "Without", "With"
            a = book.value(stem + first_slot, c["without"], dp, "%s: %s" % (lead, first_slot.lower()), w + "/without")
            b = book.value(stem + second_slot, c["with_"], dp, "%s: %s" % (lead, second_slot.lower()), w + "/with_")
            if c.get("control"):
                book.value(stem + "Control", c["control"][1], dp, "%s: the same model fed %s" % (lead, c["control"][0]),
                           w + "/control")
            first, second = second_slot, first_slot
        diff = b - a
        src = "computed: `%s` minus `%s`" % (first, second)
        book.add(stem + "Diff", signed(to_dp(diff, dp)), lead + ": change in error with its sign", src,
                 short=signed(shorter(to_dp(diff, dp), to_sig(diff, 2))))
        book.add(stem + "DiffAbs", to_dp(abs(diff), dp), lead + ": size of the change, no sign", src,
                 short=shorter(to_dp(abs(diff), dp), to_sig(abs(diff), 2)))
        better(book, stem, c.get("better"), lead, led + " → `comparisons`")

    extra = s.get("extra_json")
    if extra and "coverage_overall" in extra:     # only row 20's extra block has macros; rows 26 to 29 carry other notes
        order = [x.strip() for x in extra["order"].split(",")]
        for key, slot, what in (("coverage_overall", "Cover", "readings inside the band, whole pinch"),
                                ("coverage_release", "Release", "readings inside the band, during release")):
            for i, row in enumerate(extra[key]):
                src = "`%s` → `%s`" % (extra["file"], extra["fields"])
                stem = tag + slot + letters(i)
                label = "%s: %s" % (what, order[i])
                book.add(stem, whole(row["covered"]), label + " (count)", src)
                book.add(stem + "Of", whole(row["of"]), label + " (out of)", src)
                book.add(stem + "Percent", to_dp(Decimal(repr(row["percent"])), 1), label + " (percent)", "computed from the two counts")

    for key, slot, value, places, file, field, what in HAND:
        if key == s["key"]:
            obj = {"value": value, "raw": value, "file": file, "field": field}
            book.value(tag + slot, obj, dp if places is None else places, "from the text of the ledger: " + what,
                       "hand table/%s" % slot)

    for sentence in [s["happened"]] + list(s["others"]):
        if re.search(r"\d", sentence):
            book.current["text"].append(sentence)


def count_macros(book, ledger):
    c = ledger["counts"]
    book.section("Counts", ["From `ledger.json` → `counts`. Each count has three forms: `Num` (5), `Text` (five), "
                            "`Title` (Five). Headings that carry a count use the `Title` form."])

    def put(stem, n, what, source):
        book.count("Count" + stem, n, what, "`counts` → " + source)

    e, m = c["eeg"], c["emg"]
    put("EegAsked", e["primary_n"], "studies whose main question was scalp EEG", "`eeg/primary_n`")
    put("EegRaised", e["primary_n"] - e["primary_lower"], "of those, studies where EEG raised the error",
        "`eeg/primary_n` minus `eeg/primary_lower`")
    put("EegAll", e["n"], "all comparisons that added EEG to a model with the target's history", "`eeg/n`")
    put("EegAllLower", e["lower"], "of those, comparisons where EEG lowered the error", "`eeg/lower`")
    put("EegControls", e["with_control"], "EEG comparisons that also had a wrong-trial control", "`eeg/with_control`")
    put("EegBeatControl", e["beat_control"], "of those, properly timed EEG did better than the control", "`eeg/beat_control`")
    put("EmgAsked", m["primary_n"], "studies whose main question was forearm EMG", "`emg/primary_n`")
    put("EmgLowered", m["primary_lower"], "of those, studies where EMG lowered the error", "`emg/primary_lower`")
    put("EmgAll", m["n"], "all comparisons that added EMG", "`emg/n`")
    put("EmgAllLower", m["lower"], "of those, comparisons where EMG lowered the error", "`emg/lower`")
    put("EmgControls", m["with_control"], "EMG comparisons that also had a mistimed control", "`emg/with_control`")
    put("EmgBeatControl", m["beat_control"], "of those, properly timed EMG did better than the control", "`emg/beat_control`")
    p = c["personal"]
    put("AdjustAll", p["n"], "comparisons that adjusted a model to a person, a day or a group", "`personal/n`")
    put("AdjustLowered", p["lower"], "of those, the adjustment lowered the error", "`personal/lower`")
    put("AdjustMattered", p["lower_by_more_than_1_percent_of_error"], "of those, by more than 1% of the error",
        "`personal/lower_by_more_than_1_percent_of_error`")
    sh = c["shifted_settings"]
    put("ShiftAll", sh["n"], "settings with a new task or a new target", "`shifted_settings/n`")
    put("ShiftLost", sh["best_fitted_beaten_by_a_one_line_rule"], "of those, the best fitted model lost to a one-line rule",
        "`shifted_settings/best_fitted_beaten_by_a_one_line_rule`")
    put("ShiftAheadOfCarry", c["carry_shifted"]["fitted_lower"], "new settings where the fitted model stayed ahead of plain repeat-the-last-value",
        "`carry_shifted/fitted_lower`")
    put("CueRuleAll", c["cue_rule"]["n"], "new settings scored against the scheduled-change rule", "`cue_rule/n`")
    put("CueRuleAhead", c["cue_rule"]["fitted_lower"], "of those, the fitted model was ahead", "`cue_rule/fitted_lower`")
    put("HomeAll", c["carry_home"]["n"], "studies that scored a history model against repeat-the-last-value on its own task", "`carry_home/n`")
    put("HomeWon", c["carry_home"]["fitted_lower"], "of those, the history model won", "`carry_home/fitted_lower`")
    put("FittedLevelAll", c["carry_fitted_level"]["n"], "settings back at the level the model was fitted for", "`carry_fitted_level/n`")
    put("FittedLevelWon", c["cue_rule_fitted_level"]["fitted_lower"], "of those, the fitted model beat both rules",
        "`cue_rule_fitted_level/fitted_lower` (and `carry_fitted_level/fitted_lower`, the same number)")
    r = c["preset_rule"]
    put("RuleSet", r["stated"], "studies that set a rule in advance", "`preset_rule/stated`")
    put("RuleFailed", r["not_met"], "of those, the rule was failed", "`preset_rule/not_met`")
    put("RuleSplit", r["mixed"], "of those, a split answer", "`preset_rule/mixed`")
    put("RuleNone", r["none_stated"], "studies that set no rule", "`preset_rule/none_stated`")
    # integrator, pass 2: rows marked "not_a_test" (27 and 29, fits scored on the people they were fitted on) are
    # not studies and enter none of these three counts.
    studies = [s for s in ledger["studies"] if not s.get("not_a_test")]
    bench = [s for s in studies if s["folder"].startswith("benchmarks/")]
    book.count("CountDatasets", len({s["dataset"]["id"] for s in bench}), "open human datasets behind the benchmark studies",
               "the ledger: distinct `dataset/id` among the studies with a `benchmarks/` folder (rows marked `not_a_test` left out)")
    book.count("CountBenchRows", len(bench), "studies with a public result folder",
               "the ledger: studies with a `benchmarks/` folder (rows marked `not_a_test` left out)")
    book.count("CountRows", len(studies), "studies in all, the rows of the opening table of section 4",
               "the ledger: `studies`, rows marked `not_a_test` left out")
    book.count("CountNotTests", sum(1 for s in ledger["studies"] if s.get("not_a_test")),
               "ledger rows that are fits scored on the people they were fitted on (not tests)",
               "the ledger: rows marked `not_a_test`")
    book.count("CountMaxTested", max(s["n_tested"] for s in studies), "largest number of people in any test group",
               "the ledger: largest `n_tested`")


# integrator, pass 2: the names the writers asked for in tools/pending-macros.txt for the general model's fits,
# defined from the current ledger. Each is either another macro's number under the writer's name ("same"), or
# the size of a difference of two ledger scores printed to stated places ("gap": first minus second).
#   (name, study key, kind, ledger paths or macro, places, what it is)
NAMED = [
    ("GeneralWristMotion", "paired-wrist-forecast", "same", "GeneralWristPrimaryRef", None,
     "the general model fitted on six people's wrist recordings, wrist angles alone, on the three already-scored people"),
    ("GeneralWristEmg", "paired-wrist-forecast", "same", "GeneralWristPrimaryCand", None,
     "the general model with forearm EMG added, same people"),
    ("GeneralWristEegGain", "paired-wrist-forecast", "same", "GeneralWristEegADiffAbs", None,
     "how much adding scalp EEG on top of EMG lowered the general model's error, size only"),
    ("GeneralWristEegWrongGap", "paired-wrist-forecast", "gap", ("comparisons/1/control/1", "comparisons/1/with_"), 4,
     "how much better the general model did with the right trial's EEG than with another trial's, size only"),
    ("GeneralWristEmgWrongGap", "paired-wrist-forecast", "gap", ("comparisons/0/control/1", "comparisons/0/with_"), 4,
     "how much better the general model did with the right trial's EMG than with the next trial's, size only"),
    ("GeneralWristEarlierNet", "paired-wrist-forecast", "same", "GeneralWristBaseI", None,
     "the earlier small network of the first wrist study, which reads only the wrist, re-scored on the same 959 trials"),
    ("GeneralArmLearner", "daily-sports-arm", "same", "WalkModelE", None,
     "the general model fitted to the right-arm sensor on four walkers, on the two already-scored people"),
    ("GeneralArmTransformer", "daily-sports-arm", "same", "WalkPrimaryCand", None,
     "the small transformer fitted to the right arm alone, same people (the walking study's transformer)"),
    ("GeneralArmRidge", "daily-sports-arm", "same", "WalkPrimaryRef", None,
     "the straight-line (ridge) fit, same people (the walking study's linear fit)"),
    ("GeneralArmRepeat", "daily-sports-arm", "same", "WalkBaseA", None,
     "repeat the last reading, same people (the walking study's carry-forward)"),
]


def ledger_node(study, path):
    node = study
    for part in path.split("/"):
        node = node[int(part)] if isinstance(node, list) else node[part]
    return node


def named_macros(book, ledger):
    by_key = {s["key"]: s for s in ledger["studies"]}
    printed = {}
    for sec in book.sections:
        for name, prints, short, what, source in sec["rows"]:
            printed[name] = (prints, short, source)
    book.section("The general model's fits, under the names the writers used",
                 ["Each is a number of a ledger row above, under the name a writer asked for in `tools/pending-macros.txt`."])
    for name, key, kind, arg, places, what in NAMED:
        s = by_key[key]
        if kind == "same":
            if arg not in printed:
                fail("%s: no macro \\%s to take its number from" % (name, arg))
            prints, short, source = printed[arg]
            book.add(name, prints, what, "same number as `\\%s` (%s)" % (arg, source), short=short)
        else:
            a, b = (ledger_node(s, p) for p in arg)
            d = exact(b, "%s/%s" % (key, arg[1])) - exact(a, "%s/%s" % (key, arg[0]))
            src = "computed: `%s` → `%s` minus `%s` (ledger row %d)" % (a["file"], a["field"], b["field"], s["n"])
            book.add(name, to_dp(abs(d), places), what, src, short=shorter(to_dp(abs(d), places), to_sig(abs(d), 2)))


def public_macros(book):
    """results-public/*.json: studies with no public result file."""
    defined = []
    if not os.path.isdir(PUBLIC):
        return defined
    for name in sorted(os.listdir(PUBLIC)):
        if not name.endswith(".json"):
            continue
        path = os.path.join(PUBLIC, name)
        try:
            with open(path, encoding="utf-8") as handle:
                data = json.load(handle)
        except ValueError as error:
            fail("results-public/%s is not valid JSON: %s" % (name, error))
        for key in ("study", "what", "numbers"):
            if key not in data:
                fail("results-public/%s has no \"%s\"" % (name, key))
        book.section("results-public/%s: %s" % (name, data["study"]), [data["what"]])
        for i, entry in enumerate(data["numbers"]):
            where = "results-public/%s, numbers[%d] (%s)" % (name, i, entry.get("macro", "no macro name"))
            for key in ("macro", "value", "print", "what", "source"):
                if key not in entry:
                    fail("%s has no \"%s\"" % (where, key))
            source = entry["source"]
            if not isinstance(source, dict) or not source.get("file") or not source.get("pointer"):
                fail("%s lacks its source (file and pointer)" % where)
            if re.search(r"^/|^~|^[A-Za-z]:|\\\\", source["file"]):
                fail("%s: source.file must be relative to the private workspace, not a full path" % where)
            if entry["value"] is None:
                prints = "\\MissingNumber"
            else:
                prints = str(entry["print"])
                digits = re.sub(r"[,\s\u202f\u2009]", "", prints.replace(MINUS, "-").replace("+", ""))
                try:
                    shown = Decimal(digits)
                except Exception:
                    fail("%s: \"print\" is not a number: %r" % (where, prints))
                places = max(0, -shown.as_tuple().exponent)
                if Decimal(repr(entry["value"])).quantize(Decimal(1).scaleb(-places), rounding=ROUND_HALF_UP) != shown:
                    fail("%s: \"print\" (%s) is not \"value\" (%r) rounded to %d places" % (where, prints, entry["value"], places))
                prints = prints.replace("-", MINUS) if prints.startswith("-") else prints
            unit = " [%s]" % entry["unit"] if entry.get("unit") else ""
            book.add(entry["macro"], prints, entry["what"] + unit, "`%s` → `%s`" % (source["file"], source["pointer"]))
            defined.append(entry["macro"])
    return defined


def pending_macros(book):
    if not os.path.exists(PENDING):
        return
    rows = []
    with open(PENDING, encoding="utf-8") as handle:
        for line in handle:
            line = line.split("#", 1)[0].strip()
            if line:
                parts = line.split(None, 1)
                rows.append((parts[0], parts[1] if len(parts) > 1 else "promised by a results-public file that is not there yet"))
    rows = [(n, w) for n, w in rows if n not in book.names]
    if not rows:
        return
    book.section("Promised, not delivered yet", [
        "Each of these prints a bold ?? until a file under `results-public/` defines it. Listed in `tools/pending-macros.txt`."])
    for name, what in rows:
        book.add(name, "\\MissingNumber", what, "none yet")


def tex_escape(text):
    return text.replace("%", "\\%") if "\\" not in text else text


def render_tex(book):
    out = ["% GENERATED by tools/make_numbers.py from the ledger of results and results-public/. Do not edit:",
           "% change the source and run the script. NUMBERS.md beside this file lists every macro with its source.",
           "\\newcommand{\\UnitDeg}{\\textdegree}",
           "\\newcommand{\\UnitMm}{~mm}",
           "\\newcommand{\\UnitN}{~N}",
           "\\newcommand{\\UnitMv}{~mV}",
           "\\newcommand{\\UnitMvc}{\\%~of maximum squeeze}",
           "\\newcommand{\\UnitMvcShort}{\\%~of MVC}"]
    for sec in book.sections:
        out.append("")
        out.append("% " + sec["title"])
        for name, prints, short, what, source in sec["rows"]:
            out.append("\\newcommand{\\%s}{%s}" % (name, tex_escape(prints)))
            if short is not None:
                out.append("\\newcommand{\\%sShort}{%s}" % (name, tex_escape(short)))
    return "\n".join(out) + "\n"


def md(text):
    return text.replace("|", "\\|").replace("\n", " ")


def render_md(book):
    out = ["# Every number macro", "",
           "GENERATED by `tools/make_numbers.py`. Do not edit. One block per study in ledger order, then the counts,",
           "then the studies whose numbers come from `results-public/`.", "",
           "How to use one: write `\\WristEegPrimaryRef{}\\UnitDeg` (the `{}` keeps the space after a macro; a unit macro",
           "brings its own spacing). A macro with a `Short` column also exists as `\\<name>Short`: three significant",
           "figures for a score, two for a change. `Diff`, `Lo` and `Hi` print with their sign (a true minus or a plus);",
           "`DiffAbs` prints the size alone. Every score is an error: lower is better, and a change is \"with\" minus",
           "\"without\" (or candidate minus reference).", "",
           "Unit macros: `\\UnitDeg` (°), `\\UnitMm`, `\\UnitN`, `\\UnitMv`, `\\UnitMvc` (\"% of maximum squeeze\"),",
           "`\\UnitMvcShort` (\"% of MVC\", only after MVC has been explained). `\\<Study>Unit` is the right one for a study.", ""]
    total = 0
    for sec in book.sections:
        out.append("## " + sec["title"])
        out.append("")
        for line in sec["intro"]:
            out.append(line)
            out.append("")
        out.append("| Macro | Prints | Short | What it is | File and field |")
        out.append("| --- | --- | --- | --- | --- |")
        for name, prints, short, what, source in sec["rows"]:
            total += 1 + (short is not None)
            shown = "?? (bold)" if prints == "\\MissingNumber" else prints
            out.append("| `\\%s` | %s | %s | %s | %s |" % (name, md(shown) or "(nothing)", short if short is not None else "", md(what), md(source)))
        out.append("")
        if sec["text"]:
            out.append("In text only (the ledger gives these numbers inside a sentence; no macro exists until one is asked for):")
            out.append("")
            for sentence in sec["text"]:
                out.append("- " + sentence)
            out.append("")
    out.append("%d macros in all." % total)
    return "\n".join(out) + "\n"


def lookup(data, field):
    node = data
    for part in field.split("/"):
        if isinstance(node, list):
            node = node[int(part)]
        else:
            node = node[part]
    return node


def verify(ledger):
    """Re-read every ledger number at its result file. Prints a summary; returns the number of mismatches."""
    cache, checked, skipped, bad = {}, 0, {}, 0

    def walk(node, where):
        nonlocal checked, bad
        if isinstance(node, dict):
            if "value" in node and "file" in node and "field" in node:
                path = os.path.join(ROOT, node["file"])
                if not node["file"].endswith(".json") or not os.path.exists(path):
                    skipped[node["file"]] = skipped.get(node["file"], 0) + 1
                    return
                if path not in cache:
                    with open(path, encoding="utf-8") as handle:
                        cache[path] = json.load(handle)
                try:
                    found = lookup(cache[path], node["field"])
                except (KeyError, IndexError, ValueError, TypeError):
                    print("NOT FOUND  %s → %s (%s)" % (node["file"], node["field"], where))
                    bad += 1
                    return
                checked += 1
                if not isinstance(found, (int, float)) or abs(found - node["raw"]) > 1e-12 * max(1.0, abs(node["raw"])):
                    print("DIFFERENT  %s → %s: file has %r, ledger has %r (%s)" % (node["file"], node["field"], found, node["raw"], where))
                    bad += 1
                return
            for key, value in node.items():
                walk(value, "%s/%s" % (where, key))
        elif isinstance(node, list):
            for i, value in enumerate(node):
                walk(value, "%s/%d" % (where, i))

    for s in ledger["studies"]:
        walk(s, s["key"])
    for key, slot, value, places, file, field, what in HAND:
        walk({"value": value, "raw": value, "file": file, "field": field}, "hand table/%s" % slot)
    print("verify: %d numbers re-read at their result files, %d differ or are missing" % (checked, bad))
    for file, n in sorted(skipped.items()):
        print("verify: not a readable JSON result file, %d numbers not re-read: %s" % (n, file))
    return bad


def main():
    args = sys.argv[1:]
    out_dir = os.path.join(TREE, "shared")
    if "--out" in args:
        out_dir = args[args.index("--out") + 1]
    with open(LEDGER, encoding="utf-8") as handle:
        ledger = json.load(handle)
    book = Book()
    for s in ledger["studies"]:
        study_macros(book, s)
    count_macros(book, ledger)
    named_macros(book, ledger)
    public_macros(book)
    pending_macros(book)
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "numbers.tex"), "w", encoding="utf-8") as handle:
        handle.write(render_tex(book))
    with open(os.path.join(out_dir, "NUMBERS.md"), "w", encoding="utf-8") as handle:
        handle.write(render_md(book))
    if "--quiet" not in args:
        print("make_numbers.py: %d macros written to %s" % (len(book.names), os.path.relpath(out_dir, PAPERS)))
    if "--verify" in args:
        sys.exit(1 if verify(ledger) else 0)


if __name__ == "__main__":
    main()
