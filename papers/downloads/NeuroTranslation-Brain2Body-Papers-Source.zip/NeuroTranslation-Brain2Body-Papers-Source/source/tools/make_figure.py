#!/usr/bin/env python3
"""Draw figures/signal-change.pdf (technical editions) and figures/signal-change-simple.pdf (Simple English
editions), and write figures/signal-change.csv (exactly the rows drawn, with both labels).

Each row is one study whose main question was "does this signal lower the forecast's error?": the ledger's
comparisons marked primary, kind eeg or emg. The value is the change in error as a percentage of the error
without the signal, 100 x (with - without) / without, because the units differ from study to study. Where the
ledger publishes a range for that same comparison it is drawn, scaled the same way.

Needs a Python with matplotlib (this machine's python3 has none; tools/README.md gives the command).
Reads the ledger (LEDGER_JSON, default <papers>/../neuro/ledger.json) and the paper's own font files.
"""
import csv
import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
from matplotlib import font_manager
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
TREE = os.path.dirname(HERE)
PAPERS = os.path.dirname(TREE)
LEDGER = os.environ.get("LEDGER_JSON") or os.path.join(PAPERS, "..", "neuro", "ledger.json")  # the current ledger (rows 1 to 29), the edition's cut-off
OUT = os.path.join(TREE, "figures")

# The study in plain words. No number is typed here: people tested and every value come from the ledger.
LABELS = {
    "wrist-pointing-temporal": "Wrist angle, small network",
    "scalp-eeg-palm-history": "Palm position",
    "scalp-eeg-personal-calibration": "Palm position, adjusted model",
    "way-grip-force": "Lift grip force, from the cue",
    "way-contact-force": "Lift grip force, from the squeeze",
    "hygrip-force": "Grip sensor, paced squeezes",
    "wrist-pointing-muscle": "Wrist angle, linear fit",
    "wrist-forearm-transfer": "Wrist angle, corrected network",
    "uji-wrist-emg": "Wrist angle, everyday tasks",
    "hygrip-force/forearm-results": "Grip sensor, paced squeezes",
    "hyser-index": "Index-finger sensor, free presses",
    "cemhsey-pinch": "Pinch force",
    "cemhsey-arrays": "Pinch force, grids kept apart",
    "paired-wrist-forecast": "Wrist angle, general model",      # study 28
}
# Labels in the words the text uses, and a second set for the Simple English
# editions, which print their own copy of the figure (voice check M6).
SIMPLE_LABELS = {
    "wrist-pointing-temporal": "Wrist angle, small network",
    "scalp-eeg-palm-history": "Palm position",
    "scalp-eeg-personal-calibration": "Palm position, tuned guess",
    "way-grip-force": "Lift grip, from the signal to go",
    "way-contact-force": "Lift grip, from the squeeze",
    "hygrip-force": "Grip sensor, paced squeezes",
    "wrist-pointing-muscle": "Wrist angle, weighted sum",
    "wrist-forearm-transfer": "Wrist angle, corrected network",
    "uji-wrist-emg": "Wrist angle, everyday tasks",
    "hygrip-force/forearm-results": "Grip sensor, paced squeezes",
    "hyser-index": "Index-finger sensor, free presses",
    "cemhsey-pinch": "Pinch force",
    "cemhsey-arrays": "Pinch force, grids kept apart",
    "paired-wrist-forecast": "Wrist angle, general model",
}
SIGNALS = {"eeg": ("Scalp EEG added", "#d1602a", "o"), "emg": ("Forearm EMG added", "#2a78b5", "s")}
SIMPLE_SIGNALS = {"eeg": "Brain recording (EEG) added", "emg": "Muscle recording (EMG) added"}
WORDS = {"technical": {"axis": "Change in error, as a percentage of the error without the signal",
                       "left": "lowered the error", "right": "raised the error", "file": "signal-change.pdf",
                       "title": "Change in error when a signal is added"},
         "simple": {"axis": "Change in the miss, as a percentage of the miss without the recording",
                    "left": "made the miss smaller", "right": "made the miss bigger", "file": "signal-change-simple.pdf",
                    "title": "Change in the miss when a recording is added"}}
INK, MUTED, RULE = "#0b0b0b", "#52514e", "#b9b8b2"
LIMIT = 40.0            # the axis runs from -LIMIT to +LIMIT percent; a range beyond it is cut and marked


def rows_from_ledger():
    with open(LEDGER, encoding="utf-8") as handle:
        ledger = json.load(handle)
    rows = []
    for s in ledger["studies"]:
        for c in s["comparisons"]:
            if c["kind"] not in SIGNALS or not c.get("primary"):
                continue
            if s["key"] not in LABELS or s["key"] not in SIMPLE_LABELS:
                sys.exit("make_figure.py: no plain label for study %s" % s["key"])
            without, with_ = c["without"]["value"], c["with_"]["value"]
            row = {"ledger_row": s["n"], "study": s["key"], "signal": c["kind"], "label": LABELS[s["key"]],
                   "label_simple": SIMPLE_LABELS[s["key"]],
                   "people_tested": s["n_tested"], "unit": s["unit"], "error_without": without, "error_with": with_,
                   "change_percent": 100.0 * (with_ - without) / without, "range_low_percent": "",
                   "range_high_percent": "", "range_kind": ""}
            p = s.get("primary")
            same = p and p["ref"]["field"] == c["without"]["field"] and p["cand"]["field"] == c["with_"]["field"] \
                and p["ref"]["file"] == c["without"]["file"]
            if same and p.get("range"):
                row["range_low_percent"] = 100.0 * p["range"]["lo"]["value"] / without
                row["range_high_percent"] = 100.0 * p["range"]["hi"]["value"] / without
                row["range_kind"] = p["range"]["kind"]
            rows.append(row)
    order = {"eeg": 0, "emg": 1}
    rows.sort(key=lambda r: (order[r["signal"]], r["ledger_row"]))
    return rows


def signed(value, places=1):
    text = "%.*f" % (places, abs(value))
    if float(text) == 0:
        return text
    return ("+" if value > 0 else "−") + text


def main():
    rows = rows_from_ledger()
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, "signal-change.csv"), "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()), lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: ("%.6g" % v if isinstance(v, float) else v) for k, v in row.items()})

    for name in ("NotoSans-Regular.ttf", "NotoSans-Bold.ttf"):
        font_manager.fontManager.addfont(os.path.join(TREE, "fonts", name))
    plt.rcParams.update({"font.family": "Noto Sans", "font.size": 8.5, "pdf.fonttype": 42, "axes.unicode_minus": False,
                         "text.usetex": False, "svg.fonttype": "none"})
    for register in ("technical", "simple"):
        draw(rows, register)
    print("make_figure.py: %d rows drawn (%d EEG, %d EMG), in two label sets" % (len(rows), sum(r["signal"] == "eeg" for r in rows),
                                                              sum(r["signal"] == "emg" for r in rows)))


def draw(rows, register):
    words = WORDS[register]

    # Rows from the top: a group title, then its studies.
    y, positions, titles = 0.0, [], []
    for signal in ("eeg", "emg"):
        titles.append((y, signal))
        y += 1.0
        for row in rows:
            if row["signal"] == signal:
                positions.append((y, row))
                y += 1.0
        y += 0.55
    height_mm = 9.0 + 5.6 * y + 12.0
    fig = plt.figure(figsize=(160 / 25.4, height_mm / 25.4))
    ax = fig.add_axes([0.385, 12.0 / height_mm, 0.405, 1 - (12.0 + 9.0) / height_mm])
    ax.set_xlim(-LIMIT, LIMIT)
    ax.set_ylim(y - 0.6, -0.9)
    ax.axvline(0, color=INK, linewidth=0.8, zorder=1)
    for spine in ("top", "right", "left"):
        ax.spines[spine].set_visible(False)
    ax.spines["bottom"].set_color(RULE)
    ax.tick_params(axis="x", colors=MUTED, length=2.5, width=0.6, labelsize=8)
    ax.set_yticks([])
    ax.set_xticks([-40, -20, 0, 20, 40])
    ax.set_xticklabels([signed(t, 0) + "%" if t else "0" for t in (-40, -20, 0, 20, 40)])
    ax.set_xlabel(words["axis"], color=MUTED, fontsize=8)
    ax.text(-1.5, -0.75, words["left"], ha="right", va="center", color=MUTED, fontsize=8)
    ax.text(1.5, -0.75, words["right"], ha="left", va="center", color=MUTED, fontsize=8)

    trans = ax.get_yaxis_transform()        # x in axes fraction, y in data
    for ty, signal in titles:
        title, colour, marker = SIGNALS[signal]
        if register == "simple":
            title = SIMPLE_SIGNALS[signal]
        ax.plot([-0.925], [ty], marker=marker, markersize=5.5, color=colour, transform=trans, clip_on=False,
                markeredgecolor="white", markeredgewidth=0.6)
        ax.text(-0.895, ty, title, transform=trans, ha="left", va="center", fontweight="bold", color=INK, fontsize=8.5)
    for py, row in positions:
        title, colour, marker = SIGNALS[row["signal"]]
        people = "%d people" % row["people_tested"] if row["people_tested"] != 1 else "1 person"
        label = row["label_simple"] if register == "simple" else row["label"]
        ax.text(-0.895, py, "%s, %s" % (label, people), transform=trans, ha="left", va="center", color=INK, fontsize=8.2)
        ax.plot([-LIMIT, LIMIT], [py, py], color=RULE, linewidth=0.35, zorder=0)
        value = row["change_percent"]
        shown = [value] + ([row["range_low_percent"], row["range_high_percent"]] if row["range_kind"] else [])
        places = 2 if any(0 < abs(v) < 0.05 for v in shown) else 1      # a value just off zero must not print as zero
        note = signed(value, places) + "%"
        if row["range_kind"]:
            lo, hi = row["range_low_percent"], row["range_high_percent"]
            ax.plot([max(lo, -LIMIT), min(hi, LIMIT)], [py, py], color=colour, linewidth=1.6, solid_capstyle="butt", zorder=2)
            for end, edge, arrow in ((lo, -LIMIT, "<"), (hi, LIMIT, ">")):
                if abs(end) > LIMIT:
                    ax.plot([edge], [py], marker=arrow, markersize=4.5, color=colour, clip_on=False, zorder=3)
                else:
                    ax.plot([end, end], [py - 0.16, py + 0.16], color=colour, linewidth=1.0, zorder=2)
            note += "  (%s to %s)" % (signed(lo, places), signed(hi, places))
        ax.plot([value], [py], marker=marker, markersize=6.2, color=colour, markeredgecolor="white", markeredgewidth=0.8,
                zorder=4, clip_on=False)
        ax.text(1.03, py, note, transform=trans, ha="left", va="center", color=MUTED, fontsize=7.4)

    fig.savefig(os.path.join(OUT, words["file"]), metadata={"CreationDate": None, "ModDate": None, "Producer": None,
                                                            "Creator": None, "Title": words["title"]})
    plt.close(fig)


if __name__ == "__main__":
    main()
