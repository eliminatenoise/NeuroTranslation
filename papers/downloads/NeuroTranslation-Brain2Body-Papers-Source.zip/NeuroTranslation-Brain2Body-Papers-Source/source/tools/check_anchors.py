#!/usr/bin/env python3
"""Structure and wording rules for the whole source tree.

    python3 tools/check_anchors.py <source folder> [--final]

- Every study anchor exists exactly once in each NeuroTranslation edition (\\StudyAnchor{name}); no anchor
  outside the list. While the appendix that holds them is unwritten, a missing anchor is a note; with
  --final it fails. A duplicate or unknown anchor always fails.
- No heading ends in a question mark. No \\paragraph, \\subparagraph or \\subsubsection. No \\usepackage
  outside shared/preamble.tex. No \\nocite.
- None of the project's internal working words and none of the private strings (paths, accounts, names of
  tools) in any .tex or .bib file. A .tex line may carry "% words-ok: <reason>" to pass an internal word
  that is ordinary English there; private strings cannot be passed.
- With --final: no unwritten section (\\Unwritten) is left.

Findings are printed as file:line: message; exit status 1 on any finding. Standard library only.
"""
import os
import re
import sys

ANCHORS = [
    "sec:wrist-forecast-evidence", "sec:forearm-correction", "sec:uji-wrist", "sec:surface-emg-elbow",
    "sec:scalp-eeg-pilot", "sec:scalp-eeg-palm-history", "sec:way-grip", "sec:hygrip-primary", "sec:hygrip-forearm",
    "sec:hyser-index", "hyser-next-day", "hyser-whole-hand", "cemhsey-pinch", "cemhsey-five-grid",
    "cemhsey-pinch-intervals", "cemhsey-transfer", "cemhsey-carry", "sec:self-forecast",
    "sec:earlier-recorded-signals",
    "palm-calibration", "way-contact", "hygrip-cue-phase", "hyser-prescribed", "cemhsey-phase",
    # studies 26 and 28, and rows 27 and 29 (not tests), named as their folders are
    "daily-sports-arm", "paired-wrist-forecast", "daily-sports-limbs", "wrist-forearm-correction",
]
NT_MASTERS = ["neurotranslation-technical", "neurotranslation-explained"]

# Working words of the project that a reader must never meet (in either case, as whole words).
INTERNAL = ["admission", "lease", "candidate", "promoted", "unpromoted", "adopted", "registry revision",
            "source-bound", "accepted", "gate", "lane", "denominator"]
INTERNAL_RE = re.compile(r"(?<![A-Za-z])(" + "|".join(re.escape(w) for w in INTERNAL) + r")(?![A-Za-z])", re.I)
# Capitals used as names of data splits, round and revision numbers used as names, checksums.
CAPITALS_CASE = re.compile(r"(?<![A-Za-z])(DEV|TEST|FINAL|TRAIN)(?![A-Za-z])|(?<![A-Za-z0-9])R\d{2,}(?![A-Za-z0-9])|"
                           r"\b(?:[Ss][Hh][Aa]-?256|[Ss][Hh][Aa]-?1|[Mm][Dd]5|[Cc]hecksums?)\b")
# Private strings: paths, account names, names of tools and working sessions. Written in pieces so that this
# file does not contain them itself.
PIECES = [("/ho", "me/"), ("oma", "rchy"), ("/t", "mp/"), ("sess", "ion_"), ("cla", "ude"), ("fa", "ble"), ("op", "us"),
          ("son", "net"), ("anth", "ropic"), ("ope", "nai"), ("g", "pt"), ("@p", "m\\.me"), ("tri-s", "ubset"), ("cod", "ex"),
          ("thur", "sday"), ("tues", "day")]
PRIVATE_RE = re.compile("|".join(r"(?<![A-Za-z])" + a + b + r"(?![A-Za-z])" if (a + b).isalpha() else a + b
                                 for a, b in PIECES), re.I)
# Cited works whose own titles contain such a string (file name, pattern of the line, why it is allowed).
PRIVATE_OK = [("refs.bib", re.compile(r"Neuro-G" + "PT"), "title of a cited paper")]


def no_comment(line):
    return re.sub(r"(?<!\\)%.*", "", line)


def headings(text):
    """(line, text of heading) for every \\section and \\subsection."""
    out = []
    for m in re.finditer(r"\\(?:sub)*section\*?\s*\{", text):
        depth, i = 0, m.end() - 1
        while i < len(text):
            if text[i] == "{":
                depth += 1
            elif text[i] == "}":
                depth -= 1
                if depth == 0:
                    break
            i += 1
        out.append((text[:m.start()].count("\n") + 1, text[m.end():i]))
    return out


def files_of(master):
    out, queue, base = [], [master], os.path.dirname(master)
    while queue:
        current = queue.pop(0)
        text = "\n".join(no_comment(l) for l in open(current, encoding="utf-8").read().split("\n"))
        for m in re.finditer(r"\\input\s*\{([^{}]+)\}", text):
            path = os.path.normpath(os.path.join(base, m.group(1)))
            if os.path.exists(path) and path not in out:
                out.append(path)
                queue.append(path)
    return out


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    final = "--final" in sys.argv
    if not args:
        sys.exit(__doc__)
    tree = os.path.abspath(args[0])
    findings, notes = [], []
    sources = []
    for folder, _, names in sorted(os.walk(tree)):
        for name in sorted(names):
            if name.endswith((".tex", ".bib")):
                sources.append(os.path.join(folder, name))

    for path in sources:
        rel = os.path.relpath(path, tree)
        raw = open(path, encoding="utf-8").read()
        lines = raw.split("\n")
        is_tex = path.endswith(".tex")
        for number, line in enumerate(lines, 1):
            for m in PRIVATE_RE.finditer(line):
                if not any(rel.endswith(name) and pattern.search(line) for name, pattern, _ in PRIVATE_OK):
                    findings.append("%s:%d: private string \"%s\" (a path, an account or the name of a tool)" % (rel, number, m.group(0)))
            if re.search(r"%\s*words-ok:\s*\S", line):
                continue
            seen = no_comment(line) if is_tex else line
            if is_tex:
                seen = re.sub(r"\\[A-Za-z@]+", " ", re.sub(r"\\(?:input|label|ref|cite[a-z]*|url|href|includegraphics(?:\[[^\]]*\])?)\s*\{[^{}]*\}", " ", seen))
            else:
                seen = re.sub(r"\b(?:url|doi|eprint)\s*=\s*[{\"][^}\"]*[}\"]", " ", seen)
                seen = re.sub(r"^\s*@\w+\{[^,]*,", " ", seen)
            for m in INTERNAL_RE.finditer(seen):
                findings.append("%s:%d: internal working word \"%s\"; say it in a reader's words, or mark the line \"%% words-ok: <reason>\""
                                % (rel, number, m.group(0)))
            for m in CAPITALS_CASE.finditer(seen):
                findings.append("%s:%d: \"%s\" (a data split in capitals, a round or revision number used as a name, or a checksum)"
                                % (rel, number, m.group(0)))
        if not is_tex:
            continue
        code = "\n".join(no_comment(l) for l in lines)
        for number, title in headings(code):
            if re.sub(r"[\s{}]+$", "", title).endswith("?"):
                findings.append("%s:%d: a heading ends in a question mark: \"%s\"" % (rel, number, " ".join(title.split())))
        for number, line in enumerate(code.split("\n"), 1):
            if re.search(r"\\(?:sub)?paragraph\b|\\subsubsection\b", line) and rel != os.path.join("shared", "preamble.tex"):
                findings.append("%s:%d: no third heading level and no run-in heading: use \\section and \\subsection only" % (rel, number))
            if re.search(r"\\usepackage\b|\\RequirePackage\b", line) and rel != os.path.join("shared", "preamble.tex"):
                findings.append("%s:%d: \\usepackage outside shared/preamble.tex (the engine has only the packages listed there)" % (rel, number))
            if re.search(r"\\nocite\b", line):
                findings.append("%s:%d: \\nocite: the reference list prints cited works only" % (rel, number))
            if final and "\\Unwritten" in line and rel != os.path.join("shared", "preamble.tex"):
                findings.append("%s:%d: a section is still unwritten (\\Unwritten)" % (rel, number))

    for edition in NT_MASTERS:
        found = [p for p in sources if os.path.basename(p) == edition + ".tex"]
        if len(found) != 1:
            findings.append("%s.tex:1: expected exactly one master of this name, found %d" % (edition, len(found)))
            continue
        places, unwritten = {}, False
        for path in files_of(found[0]):
            rel = os.path.relpath(path, tree)
            for number, line in enumerate(open(path, encoding="utf-8").read().split("\n"), 1):
                line = no_comment(line)
                if "\\Unwritten" in line and os.path.basename(path).startswith("appendix-studies"):
                    unwritten = True
                for m in re.finditer(r"\\StudyAnchor\s*\{([^{}]*)\}", line):
                    if rel != os.path.join("shared", "preamble.tex"):
                        places.setdefault(m.group(1), []).append("%s:%d" % (rel, number))
        rel_master = os.path.relpath(found[0], tree)
        for name, where in sorted(places.items()):
            if name not in ANCHORS:
                findings.append("%s: study anchor \"%s\" is not one of the %d fixed names" % (where[0], name, len(ANCHORS)))
            if len(where) > 1:
                findings.append("%s: study anchor \"%s\" is placed %d times in %s (%s)" % (where[1], name, len(where), edition, ", ".join(where)))
        for name in ANCHORS:
            if name not in places:
                message = "%s:1: study anchor \"%s\" is not placed in this edition" % (rel_master, name)
                (notes if unwritten and not final else findings).append(message)

    if "--notes" in sys.argv:
        for note in notes:
            print("note: " + note + " (allowed while appendix B is unwritten)")
    for finding in findings:
        print(finding)
    print("check_anchors.py: %d finding(s), %d note(s)" % (len(findings), len(notes)))
    sys.exit(1 if findings else 0)


if __name__ == "__main__":
    main()
