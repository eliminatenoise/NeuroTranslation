# NeuroTranslation and Brain2Body paper previews

19 November 2026 · Experimental candidate

Open [the paper index](index.html) to read the four PDFs or jump to their revised passages. Keep these files together when you extract them so the PDFs can find their evidence companions.

Two cameras can give us a grip the person never made. The four editions now use that example to explain why a proposed movement comparison needs a common clock, a common physical frame and independent checks of the joined view. NeuroTranslation technical also clarifies what its completed temporal-order comparison can establish. The experiment results are the same.

| Paper | Technical edition | Accessible edition |
| --- | --- | --- |
| NeuroTranslation | [Technical paper](neurotranslation-technical.pdf) | [Explained edition](neurotranslation-explained.pdf) |
| Brain2Body | [Research article](brain2body-article.pdf) | [Simple English edition](brain2body-simple-english.pdf) |

The [reading aid](research-evidence-reading-aid.md) follows the numerical comparisons and their limits. The [scientific evidence summary](research-evidence.json) and [training diagnostic](training-diagnostic-summary.json) give the corresponding records. The candidate was checked at the revised passages and on pages with visible reflow. Independent review and reader-platform testing remain open.

The [content manifest](manifest.json) identifies the candidate, its four PDF hashes and the comparison with the prior edition. See the [notices](NOTICE.md) and [font provenance](font-provenance.json) for rights and dependencies.
