# Reuse and third-party material

CC0 1.0 applies to project-owned paper contributions to the extent the project holds those rights. It does not relicense third-party fonts, figures, cited publications, datasets, software or trademarks. Their original terms remain.

The four candidate NeuroTranslation and Brain2Body paper PDFs embed Noto Sans, Noto Sans Mono, Fira Math and DejaVu Sans. Their notices travel with this edition:

| Font family | Preserved notice | Source |
| --- | --- | --- |
| Noto Sans and Noto Sans Mono | [SIL Open Font License 1.1](third-party-notices/Noto-OFL.txt) | [The Noto Project](https://github.com/notofonts/latin-greek-cyrillic/blob/ffaec0a756877220dbf718ce08b8479a0be82479/OFL.txt) |
| Fira Math | [SIL Open Font License 1.1](third-party-notices/FiraMath-LICENSE.txt) | [Fira Math](https://github.com/firamath/firamath/blob/8f1423fbfcc659c44772d2523be82073eb26ad3a/LICENSE) |
| DejaVu Sans, including Bold | [Bitstream Vera and Arev notices](third-party-notices/DejaVu-LICENSE.txt) | [DejaVu Fonts](https://github.com/dejavu-fonts/dejavu-fonts/blob/0eda8a319c08835009849583cd090bb5b141ce25/LICENSE) |

The Noto and Fira Math notices are preserved from the selected manuscript sources. The DejaVu notice is an unmodified copy supplied with installed Matplotlib. The font tables identify the embedded families; they do not establish the exact font version in every older figure. [Font provenance](font-provenance.json) records that limit and the candidate PDF fingerprints. No separate font binaries are supplied by this notice package.

Existing figures keep their source and attribution requirements. Citation alone grants no redistribution rights. This notice adds the font texts; review of every figure, dataset, participant permission and combined use remains open. The papers are experimental drafts, and this notice makes no claim that their scientific or finished-product criteria have passed.
