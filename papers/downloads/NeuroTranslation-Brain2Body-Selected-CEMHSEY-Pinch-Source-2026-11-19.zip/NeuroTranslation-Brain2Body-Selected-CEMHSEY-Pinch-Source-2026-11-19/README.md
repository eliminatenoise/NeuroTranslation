# NeuroTranslation and Brain2Body manuscript source

The CEMHSEY GRASP dynamometer measures one squeeze between two finger pads. The papers compare a forecast of that normalized force against the last reading, the cue, force history and muscle readings from the other repeat. Paired muscle readings lowered average absolute error by 0.05% against force history and the cue, and 0.17% against muscle readings from the other repeat. Both descriptive ranges crossed zero. The smallest average absolute error on the four-person development panel was 0.004631948 (add muscle readings from this trial). The horizon is 120 ms on the released force record.

Contains information from the [Hyser database, PhysioNet 2.0.0](https://doi.org/10.13026/hxan-pe94), by Xinyu Jiang, Chenyun Dai, Xiangyu Liu and Jiahao Fan, made available under the [ODC Attribution License 1.0](https://opendatacommons.org/licenses/by/1-0/).

This archive contains 77 LaTeX and BibTeX files. Each manuscript file has
the exact bytes used for the corresponding experimental PDF. Open a main file
below to follow its section includes and citations. The [manifest](manifest.json)
lists the source files and the SHA-256 of each separate reader PDF.

| Edition | LaTeX entry point | Omitted figures | Omitted manuscript inputs |
| --- | --- | --- | --- |
| NeuroTranslation technical | [Open TeX](manuscripts/neurotranslation/neurotranslation/neurotranslation-technical.tex) | `architecture.pdf`, `length_fit.pdf`, `recorded_replay.pdf`, `transfer_comparison.pdf` | `paired-study-protocol.tex`, `reference-comparison-protocol.tex` |
| NeuroTranslation explained | [Open TeX](manuscripts/neurotranslation/neurotranslation/neurotranslation-explained.tex) | `architecture.pdf`, `length_fit.pdf`, `recorded_replay.pdf`, `transfer_comparison.pdf` | `paired-study-protocol.tex`, `reference-comparison-protocol.tex` |
| Brain2Body research article | [Open TeX](manuscripts/brain2body-technical/brain2body/brain2body-article.tex) | `historical-brain2body-framework.pdf` | `reference-comparison-protocol.tex` |
| Brain2Body Simple English | [Open TeX](manuscripts/brain2body-simple-english/brain2body/brain2body-simple-english.tex) | `historical-brain2body-framework.pdf` | `reference-comparison-protocol.tex` |

## Rebuilding and using the evidence

An exact rebuild also requires the excluded manuscript inputs and standalone
figures above, the pinned TeX engine and bibliography tooling, and the seven
Noto Sans, Noto Sans Mono and Fira Math font files named in the manifest.
Use the separate PDF edition to see the finished typesetting at this source
cut. The evidence JSON links in the papers point to files in the reader package.
The canonical glossary binding is recorded in the manifest. Its raw registry
and projections stay outside this archive, along with recordings, model
weights and build products.

The [grip methods and aggregate scores](https://github.com/eliminatenoise/NeuroTranslation/tree/3af280cdb164a35e35c50cded35dcbdc199f6a19/benchmarks/way-grip-force)
can be read beside the [acquisition paper](https://doi.org/10.1038/sdata.2014.47)
and the [WAY-EEG-GAL deposit](https://doi.org/10.6084/m9.figshare.c.988376.v2).
The four drafts report development results and keep the reserved tests and
live-control questions open.

## Reuse

[CC0 1.0](LICENSE.txt) applies to project-owned prose and LaTeX to the extent
the project holds those rights. Cited papers, datasets, fonts, figures and
software keep their own terms. The bibliographies identify the sources.
