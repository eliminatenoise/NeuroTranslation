# Source and scope

Matthew D. Luciw, Ewa Jarocka and Benoni B. Edin recorded the force, movement,
scalp EEG and surface EMG for these trials. This package applies aggregate ridge
models to those kinds of signals. The primary input path uses 400 ms of
synchronized history. Its future target is the average compressive normal
force measured by two physical fingertip plates. Training used paired windowed
records, with the reported force sign changed once to make compression
positive. [Scientific Data 1, 140047 (2014)](https://doi.org/10.1038/sdata.2014.47).

The version 2 collection links to the official article records. Their v1 file
records carry CC0 1.0. The descriptor separately credits the data and scripts
under CC BY 4.0. We preserve both notices and name the transformations in
`INFERENCE.md` and the study design. This package contains our inference code
and fitted model parameters, with no copied author scripts. [Figshare
collection v2](https://doi.org/10.6084/m9.figshare.c.988376.v2), [CC0
1.0](https://creativecommons.org/publicdomain/zero/1.0/), [CC BY
4.0](https://creativecommons.org/licenses/by/4.0/).

The included models share a single set of weights per branch. The feature
means, scales and nonzero weights were independently checked for support
across all six training participants. The package contains no source
waveforms, per-person results, identifiers, calibration histories or
individual predictions. Shared feature support is an empirical check and
does not supply a formal privacy guarantee.
