"""Forecast grip force 120 ms ahead from synchronized past sensor windows."""

import argparse
import json
from pathlib import Path
import sys

try:
    import numpy as np
except ModuleNotFoundError as exc:
    if exc.name != "numpy":
        raise
    sys.exit(
        "NumPy is required in the selected Python environment. Install it there with "
        "'python -m pip install numpy', or use a Python interpreter with NumPy already installed. "
        "On Linux or macOS set WAY_PYTHON to that interpreter's absolute path before launching."
    )

from way_model import EEG_HZ, EMG_HZ, EMG_HISTORY, HISTORY, SERIES_TYPES, predict_windows, read_models

HERE = Path(__file__).resolve().parent
INPUT_FIELDS = ("issue_offsets", "grip_n", "load_n", "position", "eeg", "emg")


def synthetic_windows():
    """One invented input with declared sampling and no participant data."""
    past = (np.arange(HISTORY) - HISTORY + 1) / EEG_HZ
    past_emg = (np.arange(EMG_HISTORY) - EMG_HISTORY + 1) / EMG_HZ
    grip = (1.2 + 0.6 * (past - past.min()))[None, :]
    load = (0.8 + 0.2 * (past - past.min()))[None, :]
    motion = np.zeros((1, HISTORY, 4, 3))
    motion[0, :, 1, 0] = 0.7
    motion[0, :, 2, 0] = -0.7
    motion[0, :, :, 2] = (past - past.min())[:, None] * 0.3
    amplitudes = np.linspace(-0.3, 0.3, 32)
    eeg = (np.sin(2 * np.pi * 10 * past[:, None]) * amplitudes)[None, :]
    emg = np.repeat(np.sin(2 * np.pi * 41 * past_emg[:, None]), 5, axis=1)[None, :]
    return np.array([420]), grip, load, motion, eeg, emg


def read_windows(path):
    with np.load(path, allow_pickle=False) as arrays:
        if set(arrays.files) != set(INPUT_FIELDS):
            raise ValueError("Expected only the six input arrays described in INFERENCE.md")
        return tuple(arrays[name] for name in INPUT_FIELDS)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--models", type=Path, default=HERE / "train-freeze" / "models.json")
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--synthetic-example", action="store_true")
    source.add_argument("--input", type=Path, help="Local NPZ of aligned past windows")
    parser.add_argument("--series-type", choices=SERIES_TYPES)
    parser.add_argument("--trial-number", type=int)
    args = parser.parse_args()
    if args.input and (args.series_type is None or args.trial_number is None):
        parser.error("--input requires --series-type and --trial-number from the recording schedule")
    try:
        if args.synthetic_example:
            issues, *windows = synthetic_windows()
            series_type, trial_number = "weight", 2
        else:
            issues, *windows = read_windows(args.input)
            series_type, trial_number = args.series_type, args.trial_number
        scores = predict_windows(read_models(args.models), issues, series_type, trial_number, *windows)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        parser.exit(2, f"{exc}\n")
    print(json.dumps({
        "input": "synthetic example" if args.synthetic_example else "locally supplied sensor windows",
        "study_status": "experimental TRAIN-only fit",
        "recorded_horizon_ms": 120,
        "grip_force_at_horizon_n": {name: values.tolist() for name, values in scores.items()},
    }, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
