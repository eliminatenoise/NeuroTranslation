@echo off
setlocal
pushd "%~dp0" || exit /b 1
if "%~1"=="" goto example
py -3 -B run_forecast.py --models models.json %*
set "WAY_EXIT=%ERRORLEVEL%"
goto finish
:example
py -3 -B run_forecast.py --models models.json --synthetic-example
set "WAY_EXIT=%ERRORLEVEL%"
pause
:finish
popd
exit /b %WAY_EXIT%
