# How the comparison works

Each trial contributes up to 29 issues on a grid from 240 to 1360 ms after the
LED turns on. The 500 Hz inputs cover 200 stored samples up to and including
issue. The target is one force measurement 60 samples later. We kept
the force plate measurements in newtons, reversed the archived grip sign to
make compression positive and kept the sign of lift-axis force. The same
complete finite windows and target support feed every main comparison.

The context model sees the LED-relative time, series type and trial ordinal.
The force-and-motion model also sees present and past grip and load force,
backward slopes, the distance between the fingertips and recent movement of
the object and hand. Past positions are in the native source scale. This
mechanical model forecasts the change from the last measured grip force. We
add that measured force to its predicted change to recover a prediction in N.

The EEG branch adds four chronological mean offsets per channel and three
band powers at 7.5–12.5, >12.5–25, and >25–35 Hz. The model subtracts the average across channels at
each sample before either calculation. For the power calculation it removes
each channel's fitted linear trend within the captured window, applies a
200-sample Hann taper and takes a one-sided spectrum. All features come from
the captured window. Surface EMG uses the last 1,600 samples through the issue
time on the 4 kHz clock. Four bins record each channel's root mean square after
removing its mean over that captured interval.

The reference for a useful EEG increment is an EEG model that gets the next
trial's EEG at the same cue-relative time. Trials rotate within the same
participant, series and assigned object mass and surface. Groups must contain
at least three eligible trials. The force, motion, cue context and measured
target stay with the original trial. Both EEG models and the mechanical
comparator score on the same eligible phase-control rows.

We fitted a regression with an unpenalized intercept and a penalty on the
sum of squared slope coefficients. Every training person received equal total
weight. Means and scales used only the people in the current training fold.
Penalties from 0.001 to 10 were selected from five fixed options using
leave-one-training-person-out RMSE, with ties going to the larger penalty.
We froze the parameters before seeing the three development participants.
Development scores use those same weights and scales.
