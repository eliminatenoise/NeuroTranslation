# How hard will the fingers squeeze?

Take a lift cue and the last 400 milliseconds of motion and force. Then add
scalp EEG or muscle electrical activity and see what changes. Each branch forecasts
how hard the fingers will be pressing 120 milliseconds later on the recording
clock. During the WAY-EEG-GAL experiment, plates under the thumb and index
finger measured that force directly. The target is the mean normal
compression in newtons. [Luciw, Jarocka and Edin, Scientific Data](https://doi.org/10.1038/sdata.2014.47).

The experiment asked whether past EEG could improve a forecast built from
past force and motion. The dev comparison used locked weights on three
people whose recordings took no part in training. Each person's root-mean-square
error (RMSE) contributes equal weight to the reported mean.

| Input | TRAIN selection folds | Frozen development |
|---|---:|---:|
| Cue and schedule | 1.274285 N | 1.425756 N |
| Last measured force | 0.506302 N | 0.787831 N |
| Backward-slope extrapolation | 0.391540 N | 0.673026 N |
| Cue, force and motion | 0.326722 N | 0.444181 N |
| Plus scalp EEG | 0.357878 N | 0.440183 N |
| Plus phase-matched EEG from the next trial | 0.356362 N | 0.438801 N |

Adding past scalp EEG shaved 0.004 N off mean development RMSE across
25,578 scheduled examples. The next-trial EEG control improved on that EEG
forecast. On the 5,140 examples with measured target force above 0.5 N,
the force-and-motion model scored 0.774960 N and the EEG model scored
0.775800 N. The planned comparison required aligned EEG to beat that
phase-matched control. It failed. Three other people remain reserved for
final testing within this experiment.

## Run a forecast

The model runs on a CPU with Python 3.10 or later and NumPy. The code was checked on Linux with Python 3.14.8 and NumPy 2.4.5. The
package includes `Run-Linux.sh`, `Run-macOS.command` and `Run-Windows.cmd`.
The launchers use Python and NumPy already installed on your machine. Linux
was exercised locally. The Windows launcher uses the Python Launcher `py`.
Open the matching launcher or run the command below for one invented input.

```sh
python run_forecast.py --models models.json --synthetic-example
```

The example prints model outputs in newtons. Its sensor values are synthetic.
It illustrates the input and output format. The error figures above come from
actual WAY-EEG-GAL recordings.

Check that the Python interpreter you intend to use can import NumPy with
`python -c "import numpy"`. If NumPy is absent, install it in your chosen
Python environment with `python -m pip install numpy`. Use `py -3` on Windows
or `python3` on macOS and Linux where those are the installed commands.
Set `WAY_PYTHON` on macOS or Linux to the absolute path of an interpreter
that already has NumPy, for example your virtual environment's `bin/python`.

For compatible local recordings, prepare a NumPy NPZ with one batch axis
`n` and the six arrays below. Each row represents an issue time within the
same trial. Include the most recent sample at the end of each window.
Use the acquisition's source scales and the order in `channel-order.json`.

| Input | Shape | Meaning |
|---|---|---|
| `issue_offsets` | `(n,)` | 500 Hz sample offsets 120, 140, …, 680 after the LED go cue |
| `grip_n` | `(n, 200)` | Measured normal compression in N, positive under compression |
| `load_n` | `(n, 200)` | Measured signed lift-axis force in N |
| `position` | `(n, 200, 4, 3)` | Object, index, thumb and wrist positions in native XYZ coordinates |
| `eeg` | `(n, 200, 32)` | Past scalp EEG at 500 Hz in released channel order |
| `emg` | `(n, 1600, 5)` | Past surface EMG at 4 kHz in released channel order, ending on or just before issue |

```sh
python run_forecast.py --models models.json --input windows.npz --series-type weight --trial-number 2
```

Use the actual scheduled series type, `weight`, `friction` or `mixed`, and
the observed ordinal of the trial within that series. The historical archive
lets the source reader reconstruct series type from the assigned block design.
A fresh acquisition needs this context at issue time. The API is also
available as `way_model.predict_windows`. It assumes the supplied histories
have already been aligned to the declared clock. Predictions with a different
instrument, task or cohort need fresh validation.

Each forecast reads past array indices only. Unmeasured instrument-filter
delay and clock drift limit what the archived 120 ms interval says about
online timing. Surface EMG measures muscle electrical activity. Scalp EEG
may also carry motion or muscle artifact, so an EEG score by itself cannot
identify a neural origin.

The source uses instrumented right-hand pinch lifts from healthy volunteers.
The exact model fit, data rights and wider acceptance remain with the study
review. The published data record contains the authors' measurements and
notices. [WAY-EEG-GAL collection v2](https://doi.org/10.6084/m9.figshare.c.988376.v2).
