#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ "$#" -eq 0 ]; then
    set -- --synthetic-example
fi
exec "${WAY_PYTHON:-python3}" -B run_forecast.py --models models.json "$@"
