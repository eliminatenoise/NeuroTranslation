"""CPU feature and prediction API for the WAY-EEG-GAL grip-force study."""

from dataclasses import dataclass
import json
from pathlib import Path

import numpy as np


ISSUES = np.arange(120, 681, 20)
HISTORY = 200
EMG_HISTORY = 1600
HORIZON = 60
EEG_HZ = 500
EMG_HZ = 4000
CLOCK_TOLERANCE = 1e-8
EMG_ALIGNMENT_TOLERANCE = 1e-10
SERIES_TYPES = ("weight", "friction", "mixed")
TRACKERS = ("object", "index", "thumb", "wrist")
MASSES = (165, 330, 660)
SURFACES = ("sandpaper", "suede", "silk")
TAPS_MS = (0, 20, 40, 80, 160, 320)
TAP_OFFSETS = np.array(TAPS_MS) // 2
BANDS = ("7p5_to_12p5", "gt12p5_to_25", "gt25_to_35")

CONTEXT_NAMES = (
    tuple(f"LED_sample_{offset}" for offset in ISSUES)
    + tuple(f"series_type_{kind}" for kind in SERIES_TYPES)
    + ("trial_number", "first_trial")
)
MECHANICAL_NAMES = (
    tuple(f"{force}_lag_{ms}ms" for force in ("GF", "LF") for ms in TAPS_MS)
    + tuple(f"{force}_slope_{ms}ms" for force in ("GF", "LF") for ms in TAPS_MS[1:])
    + ("aperture",)
    + tuple(f"{tracker}_displacement_{axis}_320ms" for tracker in ("object", "wrist") for axis in "xyz")
    + tuple(
        name
        for ms in (80, 160)
        for name in (
            *(f"{tracker}_velocity_{axis}_{ms}ms" for tracker in TRACKERS for axis in "xyz"),
            f"aperture_velocity_{ms}ms",
        )
    )
    + ("GF_squared", "LF_squared", "GF_slope_80ms_squared", "GF_by_LF", "GF_by_GF_slope_80ms", "LF_by_GF_slope_80ms")
)
EEG_NAMES = (
    tuple(f"EEG_channel_{channel:02d}_mean_bin_{block}_relative_to_first" for block in range(1, 5) for channel in range(1, 33))
    + tuple(f"EEG_channel_{channel:02d}_log_power_{band}_Hz" for band in BANDS for channel in range(1, 33))
)
EMG_NAMES = tuple(f"EMG_channel_{channel}_RMS_bin_{block}" for block in range(1, 5) for channel in range(1, 6))
PREVIOUS_NAMES = tuple(f"previous_mass_{mass}_g" for mass in MASSES) + tuple(f"previous_surface_{surface}" for surface in SURFACES)
CURRENT_NAMES = tuple(f"current_mass_{mass}_g" for mass in MASSES) + tuple(f"current_surface_{surface}" for surface in SURFACES)
STRONG_NAMES = CONTEXT_NAMES + MECHANICAL_NAMES
EEG_TIME = np.arange(HISTORY, dtype=np.float64) - (HISTORY - 1) / 2
EEG_HANN = np.hanning(HISTORY)
PERIODOGRAM_FREQUENCIES = np.fft.rfftfreq(HISTORY, d=1 / EEG_HZ)
BAND_MASKS = (
    (PERIODOGRAM_FREQUENCIES >= 7.5) & (PERIODOGRAM_FREQUENCIES <= 12.5),
    (PERIODOGRAM_FREQUENCIES > 12.5) & (PERIODOGRAM_FREQUENCIES <= 25),
    (PERIODOGRAM_FREQUENCIES > 25) & (PERIODOGRAM_FREQUENCIES <= 35),
)
BRANCH_NAMES = {
    "context": CONTEXT_NAMES,
    "strong": STRONG_NAMES,
    "eeg": STRONG_NAMES + EEG_NAMES,
    "emg": STRONG_NAMES + EMG_NAMES,
    "emg_eeg": STRONG_NAMES + EMG_NAMES + EEG_NAMES,
    "matched_strong": STRONG_NAMES,
    "matched_eeg": STRONG_NAMES + EEG_NAMES,
    "matched_rotated_eeg": STRONG_NAMES + EEG_NAMES,
    "matched_context": CONTEXT_NAMES,
    "previous_context": CONTEXT_NAMES + PREVIOUS_NAMES,
    "oracle_context": CONTEXT_NAMES + PREVIOUS_NAMES + CURRENT_NAMES,
}
ABSOLUTE_BRANCHES = {"context", "matched_context", "previous_context", "oracle_context"}
INFERENCE_BRANCHES = ("context", "strong", "eeg", "emg", "emg_eeg")


def context_features(issue_offsets, series_type, trial_number):
    """Use the known cue offset and schedule, without object labels."""
    issues = np.asarray(issue_offsets)
    if not np.isin(issues, ISSUES).all() or series_type not in SERIES_TYPES or trial_number < 1:
        raise ValueError("Context is outside the registered cue grid or series schedule")
    cue = issues[:, None] == ISSUES
    series = np.repeat((np.array(SERIES_TYPES) == series_type)[None, :], len(issues), axis=0)
    ordinal = np.full((len(issues), 1), trial_number, dtype=np.float64)
    return np.column_stack((cue, series, ordinal, ordinal == 1))


def mechanical_features(grip, load, position):
    """Build the mechanical features from batches of 200 past samples."""
    lag_indices = HISTORY - 1 - TAP_OFFSETS
    grip_taps = grip[:, lag_indices]
    load_taps = load[:, lag_indices]
    durations = np.array(TAPS_MS[1:]) / 1000
    grip_slopes = (grip_taps[:, :1] - grip_taps[:, 1:]) / durations
    load_slopes = (load_taps[:, :1] - load_taps[:, 1:]) / durations
    aperture = np.linalg.norm(position[:, :, 1, :] - position[:, :, 2, :], axis=2)
    displacement = position[:, -1, (0, 3), :] - position[:, -161, (0, 3), :]
    velocities = []
    for samples in (40, 80):
        duration = samples / EEG_HZ
        delta_position = position[:, -1, :, :] - position[:, -1 - samples, :, :]
        velocities.append(delta_position.reshape(len(position), 12) / duration)
        velocities.append((aperture[:, -1] - aperture[:, -1 - samples]) / duration)
    gf = grip_taps[:, 0]
    lf = load_taps[:, 0]
    slope = grip_slopes[:, 2]
    return np.column_stack((
        grip_taps, load_taps, grip_slopes, load_slopes, aperture[:, -1],
        displacement.reshape(len(position), 6), *velocities,
        gf**2, lf**2, slope**2, gf * lf, gf * slope, lf * slope,
    ))


def eeg_features(eeg):
    """Construct causal, within-window common-reference EEG features."""
    common_reference = eeg - eeg.mean(axis=2, keepdims=True)
    means = common_reference.reshape(len(eeg), 4, 50, 32).mean(axis=2)
    centred = common_reference - common_reference.mean(axis=1, keepdims=True)
    slope = np.einsum("t,btc->bc", EEG_TIME, centred) / np.dot(EEG_TIME, EEG_TIME)
    detrended = centred - EEG_TIME[None, :, None] * slope[:, None, :]
    spectrum = np.fft.rfft(detrended * EEG_HANN[None, :, None], axis=1)
    power = np.abs(spectrum)**2 / (EEG_HZ * np.dot(EEG_HANN, EEG_HANN))
    power[:, 1:-1, :] *= 2
    band_power = np.stack([power[:, mask, :].sum(axis=1) * (EEG_HZ / HISTORY) for mask in BAND_MASKS], axis=1)
    return np.column_stack((
        (means - means[:, :1, :]).reshape(len(eeg), 128),
        np.log(band_power + 1e-24).reshape(len(eeg), 96),
    ))


def emg_features(emg):
    """Within-window demeaning removes the constant source EMG offset."""
    centred = emg - emg.mean(axis=1, keepdims=True)
    return np.sqrt((centred.reshape(len(emg), 4, 400, 5)**2).mean(axis=2)).reshape(len(emg), 20)


def label_features(mass, surface):
    """Diagnostic one-hot labels. The deployable API never calls this."""
    return [float(mass == level) for level in MASSES] + [float(surface == level) for level in SURFACES]


def validate_clock(clock, shape, hz):
    """Require the admitted sample count and strictly increasing native cadence."""
    if clock.shape != shape or not np.isfinite(clock).all():
        raise ValueError(f"Invalid shape or nonfinite timestamps on {hz} Hz clock")
    delta = np.diff(clock)
    if not (delta > 0).all() or not np.allclose(delta, 1 / hz, rtol=0, atol=CLOCK_TOLERANCE):
        raise ValueError(f"Non-monotonic or irregular cadence on {hz} Hz clock")


def build_blocks(issues, series_type, trial_number, grip, load, position, eeg, emg):
    """Build common predictors. The caller supplies exact time-aligned past windows."""
    num_issues = len(issues)
    expected_shapes = (
        (num_issues, HISTORY), (num_issues, HISTORY), (num_issues, HISTORY, 4, 3),
        (num_issues, HISTORY, 32), (num_issues, EMG_HISTORY, 5),
    )
    inputs = tuple(np.asarray(array, dtype=np.float64) for array in (grip, load, position, eeg, emg))
    if [array.shape for array in inputs] != list(expected_shapes):
        raise ValueError("Each input must use the registered sample count and source channel order")
    if not all(np.isfinite(array).all() for array in inputs):
        raise ValueError("Predictors require complete finite raw histories")
    with np.errstate(over="ignore", invalid="ignore"):
        return (
            context_features(issues, series_type, trial_number),
            mechanical_features(*inputs[:3]),
            eeg_features(inputs[3]),
            emg_features(inputs[4]),
        )


@dataclass(frozen=True)
class TrialFeatures:
    key: tuple[int, int, int]
    member_sha256: str
    series_type: str
    mass_g: int
    surface: str
    previous_mass_g: int | None
    previous_surface: str | None
    audit: dict
    issues: np.ndarray
    context: np.ndarray
    mechanical: np.ndarray
    eeg: np.ndarray
    emg: np.ndarray
    current_grip: np.ndarray
    target_grip: np.ndarray
    linear_extrapolate: np.ndarray


def trial_features(trial):
    """Materialize the registered inputs and separately read the score target."""
    grip = np.asarray(trial.grip_n, dtype=np.float64)
    load = np.asarray(trial.load_n, dtype=np.float64)
    position = np.asarray(trial.position, dtype=np.float64)
    eeg = np.asarray(trial.eeg, dtype=np.float64)
    emg = np.asarray(trial.emg, dtype=np.float64)
    eeg_time = np.asarray(trial.eeg_t, dtype=np.float64)
    emg_time = np.asarray(trial.emg_t, dtype=np.float64)
    count = len(grip)
    if not (
        grip.shape == (count,) and load.shape == (count,) and position.shape == (count, 4, 3)
        and eeg.shape == (count, 32) and emg.ndim == 2 and emg.shape[1] == 5
        and 0 <= trial.issue_origin < count
    ):
        raise ValueError("Trial does not match the admitted EEG/EMG/kinematic schema")
    validate_clock(eeg_time, (count,), EEG_HZ)
    validate_clock(emg_time, (len(emg),), EMG_HZ)
    scheduled = trial.issue_origin + ISSUES
    issue_grid_ok = (scheduled >= 0) & (scheduled < count)
    emg_ends = np.full(len(ISSUES), -1, dtype=int)
    emg_ends[issue_grid_ok] = np.searchsorted(
        emg_time, eeg_time[scheduled[issue_grid_ok]] + EMG_ALIGNMENT_TOLERANCE, side="right"
    ) - 1
    primary_support = (scheduled >= HISTORY - 1) & (scheduled + HORIZON < count)
    emg_support = (emg_ends >= EMG_HISTORY - 1) & (emg_ends < len(emg))
    keep = np.flatnonzero(primary_support & emg_support)
    feature_audit = {
        "past_500Hz_support_missing": ISSUES[scheduled < HISTORY - 1].tolist(),
        "future_force_support_missing": ISSUES[scheduled + HORIZON >= count].tolist(),
        "past_emg_support_missing": ISSUES[~emg_support].tolist(),
        "float_nonfinite": {},
        "start_slack_s": float(eeg_time[trial.issue_origin] - eeg_time[0] + (ISSUES[0] - HISTORY + 1) / EEG_HZ),
        "end_slack_s": float(eeg_time[-1] - eeg_time[trial.issue_origin] - (ISSUES[-1] + HORIZON) / EEG_HZ),
    }
    cue_time = getattr(trial, "led_on_s", None)
    if cue_time is not None:
        cue_slack = abs(float(cue_time) - eeg_time[trial.issue_origin])
        if cue_slack > 0.5 / EEG_HZ + EMG_ALIGNMENT_TOLERANCE:
            raise ValueError("Supplied cue is outside the half-sample LED anchoring tolerance")
        feature_audit["cue_absolute_slack_s"] = float(cue_slack)
    led_off = getattr(trial, "led_off_s", None)
    if cue_time is not None and led_off is not None:
        feature_audit["cue_on_off_s"] = [float(cue_time), float(led_off)]
        feature_audit["post_offset_recorded_s"] = float(eeg_time[-1] - led_off)
    if keep.size:
        whole_issue = scheduled[keep]
        past_indices = whole_issue[:, None] + np.arange(-HISTORY + 1, 1)
        emg_indices = emg_ends[keep, None] + np.arange(-EMG_HISTORY + 1, 1)
        raw = (grip[past_indices], load[past_indices], position[past_indices], eeg[past_indices], emg[emg_indices])
        target = grip[whole_issue + HORIZON]
        name_to_values = dict(zip(("past_grip", "past_load", "past_position", "past_eeg", "past_emg", "target"), (*raw, target), strict=True))
        flags = []
        for name, values in name_to_values.items():
            finite = np.isfinite(values.reshape(len(keep), -1)).all(axis=1)
            flags.append(finite)
            if not finite.all():
                feature_audit["float_nonfinite"][name] = ISSUES[keep[~finite]].tolist()
        keep = keep[np.logical_and.reduce(flags)]
        if keep.size:
            latest_emg_slack = eeg_time[scheduled[keep]] - emg_time[emg_ends[keep]]
            feature_audit["emg_issue_slack_s"] = [float(latest_emg_slack.min()), float(latest_emg_slack.max())]
    whole_issue = scheduled[keep]
    if keep.size:
        past_indices = whole_issue[:, None] + np.arange(-HISTORY + 1, 1)
        emg_indices = emg_ends[keep, None] + np.arange(-EMG_HISTORY + 1, 1)
        blocks = build_blocks(
            ISSUES[keep], trial.series_type, trial.trial, grip[past_indices], load[past_indices],
            position[past_indices], eeg[past_indices], emg[emg_indices],
        )
        present = grip[whole_issue]
        target = grip[whole_issue + HORIZON]
        extrapolate = present + 0.120 * blocks[1][:, len(TAP_OFFSETS) * 2 + 2]
        finite = np.isfinite(extrapolate) & np.logical_and.reduce([np.isfinite(block).all(axis=1) for block in blocks])
        if not finite.all():
            feature_audit["float_nonfinite"]["derived_features_or_extrapolate"] = ISSUES[keep[~finite]].tolist()
        keep = keep[finite]
        blocks = tuple(block[finite] for block in blocks)
        present, target, extrapolate = present[finite], target[finite], extrapolate[finite]
    else:
        blocks = tuple(np.empty((0, len(names))) for names in (CONTEXT_NAMES, MECHANICAL_NAMES, EEG_NAMES, EMG_NAMES))
        present = target = extrapolate = np.empty(0)

    feature_audit["scheduled"] = int(len(ISSUES))
    feature_audit["retained"] = int(len(keep))
    if keep.size:
        retained = scheduled[keep]
        horizons = eeg_time[retained + HORIZON] - eeg_time[retained]
        feature_audit["recorded_target_horizon_s"] = [float(horizons.min()), float(horizons.max())]
    return TrialFeatures(
        key=(trial.participant, trial.series, trial.trial), member_sha256=trial.member_sha256,
        series_type=trial.series_type, mass_g=trial.mass_g, surface=trial.surface,
        previous_mass_g=trial.previous_mass_g, previous_surface=trial.previous_surface,
        audit=feature_audit, issues=ISSUES[keep], context=blocks[0], mechanical=blocks[1],
        eeg=blocks[2], emg=blocks[3], current_grip=present, target_grip=target,
        linear_extrapolate=extrapolate,
    )


@dataclass(frozen=True)
class RidgeModel:
    branch: str
    penalty: float
    mean: np.ndarray
    scale: np.ndarray
    coefficient: np.ndarray
    intercept: float

    def predict(self, features, current_grip=None):
        features = np.asarray(features, dtype=np.float64)
        if features.ndim != 2 or features.shape[1] != len(self.mean) or not np.isfinite(features).all():
            raise ValueError("Prediction inputs do not match the frozen finite feature vector")
        estimate = self.intercept + ((features - self.mean) / self.scale) @ self.coefficient
        if self.branch not in ABSOLUTE_BRANCHES:
            current_grip = np.asarray(current_grip, dtype=np.float64)
            if current_grip.shape != estimate.shape or not np.isfinite(current_grip).all():
                raise ValueError("Residual prediction requires measured force at issue")
            estimate = estimate + current_grip
        if not np.isfinite(estimate).all():
            raise ValueError("Forecast is nonfinite")
        return estimate

    def as_dict(self):
        return {
            "feature_names": BRANCH_NAMES[self.branch],
            "response": "future_grip_n" if self.branch in ABSOLUTE_BRANCHES else "future_minus_present_grip_n",
            "penalty": self.penalty,
            "mean": self.mean.tolist(),
            "scale": self.scale.tolist(),
            "coefficient": self.coefficient.tolist(),
            "intercept": self.intercept,
        }


def read_models(path):
    """Load frozen numeric parameters using JSON, without executable serialization."""
    bundle = json.loads(Path(path).read_text())
    if bundle.get("format") != "way-grip-force-study-models-v1":
        raise ValueError("Unrecognized model bundle format")
    models = {}
    for branch, row in bundle["models"].items():
        if branch not in BRANCH_NAMES or tuple(row["feature_names"]) != BRANCH_NAMES[branch]:
            raise ValueError("Model feature schema mismatch")
        response = "future_grip_n" if branch in ABSOLUTE_BRANCHES else "future_minus_present_grip_n"
        if row["response"] != response:
            raise ValueError("Model response schema mismatch")
        arrays = tuple(np.array(row[name], dtype=np.float64) for name in ("mean", "scale", "coefficient"))
        if any(a.shape != (len(BRANCH_NAMES[branch]),) or not np.isfinite(a).all() for a in arrays):
            raise ValueError("Invalid model parameter array")
        if not (arrays[1] > 0).all() or not np.isfinite(row["intercept"]) or not np.isfinite(row["penalty"]) or row["penalty"] <= 0:
            raise ValueError("Invalid model parameters")
        models[branch] = RidgeModel(branch, row["penalty"], *arrays, row["intercept"])
    return models


def predict_windows(models, issue_offsets, series_type, trial_number, grip, load, position, eeg, emg):
    """Forecast +120 ms from batches of past windows without identifiers or future data."""
    context, mech, eeg_block, emg_block = build_blocks(
        issue_offsets, series_type, trial_number, grip, load, position, eeg, emg
    )
    strong = np.column_stack((context, mech))
    features = {
        "context": context,
        "strong": strong,
        "eeg": np.column_stack((strong, eeg_block)),
        "emg": np.column_stack((strong, emg_block)),
        "emg_eeg": np.column_stack((strong, emg_block, eeg_block)),
    }
    present = np.asarray(grip, dtype=np.float64)[:, -1]
    result = {
        "persistence": present,
        "linear_extrapolate": present + 0.120 * mech[:, len(TAP_OFFSETS) * 2 + 2],
    }
    if not all(np.isfinite(block).all() for block in (strong, eeg_block, emg_block, result["linear_extrapolate"])):
        raise ValueError("A common required history produced nonfinite features")
    result.update({
        branch: models[branch].predict(features[branch], present)
        for branch in INFERENCE_BRANCHES if branch in models
    })
    return result
