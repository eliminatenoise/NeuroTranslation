@echo off
start "" "%~dp0index.html"
exit /b %errorlevel%
