# Grip force, 120 milliseconds ahead

A pinch starts to register on the force plates. The forecast has the last 200 sensor readings to work with. What does it gain from the scalp electrodes once it already knows how the hand and object are moving?

On the previously explored development group, the temporal model's average error was 0.978 N with mechanical history and 0.994 N after it added aligned EEG. Substituting EEG from another lift at the same point in the task gave 0.987 N. This experiment gives us no reason to add scalp EEG to this grip forecast. The simplest strong forecast in this comparison was the ridge model with mechanical features, at 0.677 N on the same development rows.

| Forecast or control | TRAIN RMSE (N) | Explored DEV RMSE (N) |
| --- | ---: | ---: |
| Keep the current force | 1.744 | 1.717 |
| Extend the last 80 ms force slope | 1.165 | 1.348 |
| Temporal CNN with trial timing only | 2.647 | 2.400 |
| Temporal CNN with grip, load and position history | 1.000 | 0.978 |
| Same history with aligned EEG | 1.040 | 0.994 |
| Same history with another lift's EEG at the same contact-relative time | 0.990 | 0.987 |
| Same history with EEG ending 300 ms earlier | 1.034 | 0.983 |
| Separate ridge model with engineered mechanical features | 0.720 | 0.677 |

The training comparison used 8,815 forecasts from 1,763 eligible right-hand pinch lifts across six healthy volunteers. It left each person out of the fit in turn to choose a checkpoint. The development comparison applied three people's 4,410 forecasts from 882 eligible lifts to the frozen models. Each participant counted equally, with equal weight for their trials and their scored offsets within a trial. The development group had already been explored for a related forecasting question. Final test participants remained unopened.

Across the training folds, all six participants had higher error with aligned EEG than with another lift's EEG. On development, alignment increased average error over mechanics alone by 0.016 N, with a descriptive 95% interval from −0.136 to +0.167 N across the three people. The ridge model uses different input features and tuning. The comparison tells us how these fitted methods performed, with each design difference still in play.

## Run the synthetic example

Extract this folder and run `Run-Windows.cmd`, `Run-macOS.command`, or `Run-Linux.sh` with Python 3.10 or newer installed. You can also open a terminal here and run `python3 replay.py` or, on Windows, `py -3 replay.py`. The example prints forecasts in newtons from the three fitted models. Add `--json` for machine-readable output.

The example uses invented sensor readings to check that the released weights run. The error table uses measurements from the study. The folder contains aggregate fitted parameters, scalers and metrics. The included replay has been executed on Linux. The Windows and macOS launchers use the same Python code and await native checks.

### Use a locally prepared window

Run `python3 replay.py --branch mechanics --window-json window.json --json`. The file stays on your machine. The `aligned` branch and the default `all` also require the EEG array described below. The `phase` branch uses timing only, with the same accepted input format. These are offline examples. To use the forecast with measured data, first establish the same sample order, calibration, synchronization and force-confirmation timing as the source.

| JSON key | Value |
| --- | --- |
| `rate_hz` | 500 |
| `offset_from_confirmation_ms` | One of 0, 100, 200, 300, 400 |
| `elapsed_since_go_cue_s` | Seconds from the trial go cue to the last sample |
| `grip_n` | 200 finite mean normal force values in N, compression positive |
| `load_n` | 200 finite signed upward load values in N |
| `position` | 200 rows, each containing object, index, thumb and wrist XYZ coordinates in released source scale |
| `eeg` | 200 rows of 32 finite values in released source scale, using the ordered names in `MODEL.json` |

Give the samples in chronological order and end on the issue sample. The window carries only inputs available at that point. The evaluator accepts the window after preprocessing and synchronization by the caller and does not estimate an actual device's sensing delay.

## What the model saw

The plates confirmed a threshold when they recorded ten consecutive samples of at least 0.5 N after observing a lower post-cue sample. Models forecast at confirmation and 100, 200, 300 and 400 ms later. For each forecast, the measured target is the mean compression force from the two fingertip plates, 60 samples beyond issue at 500 Hz. The timing input consists of those five offsets and elapsed time since the go cue.

The model compresses the 200 readings into fifty consecutive four-sample averages. Its temporal convolution has access to each bin up to issue. Mechanical history contains grip and load, object and wrist displacement from the first sample, and index and thumb positions relative to the object. EEG is referenced to its concurrent channel mean. The EEG-free version zeroes those channels. Each branch allocates 2,873 parameters, and the mechanical branch cannot use the 1,536 first-layer weights linked to its masked inputs.

The cross-trial control keeps the original movement and force. It substitutes the scalp readings from the next confirmed lift within the same person, recorded series, mass and surface. The same-trial control moves the EEG window 300 ms earlier. Its 400 ms history still overlaps the aligned history by 100 ms. Task phase, movement artefacts and electronics could all affect the scalp signal. The 120 ms measures a gap in the released recordings. Prospective sensing and physical delay were outside this exercise.

Source data by Matthew D. Luciw, Ewa Jarocka and Benoni B. Edin. Figshare records identify the files as CC0 1.0 and the descriptor describes data and utilities as available under CC BY 4.0. This example supplies derived weights and aggregate measurements only. [Data descriptor](https://pmc.ncbi.nlm.nih.gov/articles/PMC4365902/), [Figshare collection](https://doi.org/10.6084/m9.figshare.c.988376.v2).
