@echo off
pushd "%~dp0"
where py.exe >nul 2>nul
if errorlevel 1 (
  python replay.py %*
) else (
  py -3 replay.py %*
)
set "replay_exit=%ERRORLEVEL%"
popd
exit /b %replay_exit%
