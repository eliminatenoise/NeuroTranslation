"""Replay fitted NeuroTranslation force forecasts from bounded offline windows."""

import argparse
import json
import math
from pathlib import Path


OFFSETS_MS = (0, 100, 200, 300, 400)


def silu(x):
    if x >= 0:
        return x / (1 + math.exp(-x))
    exp = math.exp(x)
    return x * exp / (1 + exp)


def convolution(signal, weights, bias, dilation):
    """Compute valid cross-correlation for one fixed-width temporal layer."""
    channels = len(weights[0])
    kernel = len(weights[0][0])
    outputs = len(signal[0]) - dilation * (kernel - 1)
    return [
        [
            silu(offset + sum(
                output_weights[c][k] * signal[c][t + k * dilation]
                for c in range(channels) for k in range(kernel)
            ))
            for t in range(outputs)
        ]
        for output_weights, offset in zip(weights, bias, strict=True)
    ]


def dense(values, weights, bias, activation):
    return [
        activation(offset + sum(w * x for w, x in zip(row, values, strict=True)))
        for row, offset in zip(weights, bias, strict=True)
    ]


def evaluate(branch, inputs, phase, current_grip_n):
    """Evaluate a frozen branch from binned force, kinematic and EEG channels."""
    if len(inputs) != 46 or any(len(channel) != 50 for channel in inputs):
        raise ValueError("Supply 46 channels of 50 bins each.")
    if len(phase) != 6:
        raise ValueError("Supply five contact-offset indicators and seconds since the go cue.")
    values = inputs
    if branch["mode"] == "mechanics":
        values = inputs[:14] + [[0.0] * 50 for _ in range(32)]
    elif branch["mode"] == "phase":
        values = [[0.0] * 50 for _ in range(46)]
    centers = branch["temporal_means"][0]
    scales = branch["temporal_scales"][0]
    normalized = [
        [(value - mean[0]) / scale[0] for value in channel]
        for channel, mean, scale in zip(values, centers, scales, strict=True)
    ]
    normalized_phase = [
        (value - mean) / scale
        for value, mean, scale in zip(
            phase, branch["phase_means"][0], branch["phase_scales"][0], strict=True
        )
    ]
    for layer, dilation in ((0, 1), (2, 4), (4, 9)):
        normalized = convolution(
            normalized, branch[f"tensor.history.{layer}.weight"],
            branch[f"tensor.history.{layer}.bias"], dilation
        )
    final_hidden = [channel[0] for channel in normalized] + normalized_phase
    activated = dense(final_hidden, branch["tensor.head.0.weight"],
                      branch["tensor.head.0.bias"], silu)
    result = dense(activated, branch["tensor.head.2.weight"],
                   branch["tensor.head.2.bias"], lambda x: x)[0]
    return result + (current_grip_n if branch["mode"] != "phase" else 0.0)


def finite_number(value):
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def vector(value, size):
    return isinstance(value, list) and len(value) == size and all(map(finite_number, value))


def prepare_raw_window(window, require_eeg):
    """Map 200 ready-to-read rows ending at issue to the registered temporal inputs."""
    if not isinstance(window, dict):
        raise ValueError("Supply a JSON object of offline sensor readings.")
    offset_ms = window.get("offset_from_confirmation_ms")
    if window.get("rate_hz") != 500 or not finite_number(offset_ms) or offset_ms not in OFFSETS_MS:
        raise ValueError("Supply rate_hz=500 and a registered force-confirmation offset.")
    elapsed = window.get("elapsed_since_go_cue_s")
    if not finite_number(elapsed) or elapsed < offset_ms / 1000:
        raise ValueError("Elapsed time since the go cue must cover the confirmation offset.")
    grip = window.get("grip_n")
    load = window.get("load_n")
    position = window.get("position")
    if not vector(grip, 200) or not vector(load, 200):
        raise ValueError("Supply 200 finite grip_n and 200 finite load_n samples.")
    if not isinstance(position, list) or len(position) != 200 or any(
        not isinstance(row, list) or len(row) != 4 or not all(vector(sensor, 3) for sensor in row)
        for row in position
    ):
        raise ValueError("Supply 200 rows of object, index, thumb and wrist XYZ positions.")
    scalp = window.get("eeg")
    if require_eeg and (not isinstance(scalp, list) or len(scalp) != 200
                        or not all(vector(row, 32) for row in scalp)):
        raise ValueError("Aligned EEG needs 200 finite samples in the recorded 32-channel order.")
    temporal = []
    for index, tracked in enumerate(position):
        object_xyz, index_xyz, thumb_xyz, wrist_xyz = tracked
        object_motion = [value - base for value, base in zip(object_xyz, position[0][0])]
        index_object = [value - base for value, base in zip(index_xyz, object_xyz)]
        thumb_object = [value - base for value, base in zip(thumb_xyz, object_xyz)]
        wrist_motion = [value - base for value, base in zip(wrist_xyz, position[0][3])]
        mechanics = [grip[index], load[index]] + object_motion + index_object + thumb_object + wrist_motion
        if require_eeg:
            reference = sum(scalp[index]) / 32
            scalp_referenced = [value - reference for value in scalp[index]]
        else:
            scalp_referenced = [0.0] * 32
        temporal.append(mechanics + scalp_referenced)
    bins = [
        [sum(temporal[t + j][channel] for j in range(4)) / 4 for t in range(0, 200, 4)]
        for channel in range(46)
    ]
    phase = [float(offset == offset_ms) for offset in OFFSETS_MS]
    return bins, phase + [elapsed], grip[-1]


def example():
    signals = [[0.0] * 50 for _ in range(46)]
    for tick in range(50):
        fraction = tick / 49
        signals[0][tick] = 0.1 + 1.0 * fraction
        signals[1][tick] = 0.2 * fraction
        for sensor in range(2, 14):
            signals[sensor][tick] = 0.04 * math.sin(fraction * (sensor + 1))
        eeg = [0.05 * math.sin(8 * fraction + channel / 5) for channel in range(32)]
        mean = sum(eeg) / len(eeg)
        for channel, value in enumerate(eeg, start=14):
            signals[channel][tick] = value - mean
    return signals, [0.0, 1.0, 0.0, 0.0, 0.0, 0.71], 1.1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", action="store_true", help="Write the forecasts as JSON.")
    parser.add_argument("--window-json", type=Path, help="Use a local offline window instead of the example.")
    parser.add_argument("--branch", choices=("phase", "mechanics", "aligned", "all"), default="all")
    args = parser.parse_args()
    package = json.loads(Path(__file__).with_name("MODEL.json").read_text(encoding="utf-8"))
    models = {name: branch for name, branch in package["models"].items()
              if args.branch in ("all", name)}
    if args.window_json is None:
        captured = example()
        origin = "synthetic"
    else:
        window = json.loads(args.window_json.read_text(encoding="utf-8"))
        captured = prepare_raw_window(window, require_eeg="aligned" in models)
        origin = "user-supplied offline window"
    outputs = {label: evaluate(model, *captured) for label, model in models.items()}
    if not all(map(math.isfinite, outputs.values())):
        raise ValueError("An out-of-range input produced a non-finite forecast.")
    if args.json:
        print(json.dumps({"input": origin, "force_forecast_n": outputs}, indent=2))
    else:
        print(f"Input: {origin}. Force forecast 120 ms after issue.")
        for label, value in outputs.items():
            print(f"{label}: {value:.4f} N")


if __name__ == "__main__":
    main()
