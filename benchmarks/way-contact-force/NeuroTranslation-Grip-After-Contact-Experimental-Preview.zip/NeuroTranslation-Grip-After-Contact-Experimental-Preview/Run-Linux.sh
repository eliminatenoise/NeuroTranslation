#!/bin/sh
set -eu
way_contact_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec "${WAY_CONTACT_PYTHON:-python3}" -B "$way_contact_dir/run_contact.py" "$@"
