"""Source-free contact detection and pairing for the sealed WAY study."""

from collections import defaultdict
from dataclasses import dataclass

import numpy as np

HISTORY = 200
HORIZON = 60
OFFSETS = (0, 50, 100, 150, 200)
THRESHOLD_N = 0.5
DWELL_ROWS = 10


@dataclass(frozen=True)
class Event:
    reason: str
    go_index: int
    confirmation: int | None = None


def detect_contact(grip_n, clock, led_on_s):
    """Use the acquired prefix through confirmation, without author events."""
    go = int(np.searchsorted(clock, led_on_s, side="left"))
    if go >= len(grip_n):
        return Event("no_post_go_samples", go)
    if not np.isfinite(grip_n[go]):
        return Event("missing_before_confirmation", go)
    if grip_n[go] >= THRESHOLD_N:
        return Event("left_censored", go)
    above = 0
    for index in range(go + 1, len(grip_n)):
        value = grip_n[index]
        if not np.isfinite(value):
            return Event("missing_before_confirmation", go)
        above = above + 1 if value >= THRESHOLD_N else 0
        if above == DWELL_ROWS:
            return Event("confirmed", go, index)
    reason = "right_censored_incomplete_run" if above else "right_censored_below_at_end"
    return Event(reason, go)


def history_bounds(issue, length):
    if issue >= length:
        return "issue_outside_recording", None
    start = issue - HISTORY + 1
    if start < 0:
        return "short_history", None
    return "ok", slice(start, issue + 1)


def rotation(confirmed_trials):
    """Pair all confirmed trial keys irrespective of target/feature availability."""
    groups = defaultdict(list)
    for participant, series, trial, mass_g, surface in confirmed_trials:
        groups[participant, series, mass_g, surface].append(trial)
    donors = {}
    sizes = {}
    for (participant, series, mass_g, surface), trials in sorted(groups.items()):
        ordered = sorted(trials)
        if len(ordered) != len(set(ordered)):
            raise ValueError("Repeated confirmed trial identity within a control stratum.")
        sizes[participant, series, mass_g, surface] = len(ordered)
        if len(ordered) >= 3:
            for index, trial in enumerate(ordered):
                donors[participant, series, trial] = (
                    participant, series, ordered[(index + 1) % len(ordered)]
                )
    return donors, sizes
