@echo off
setlocal
if defined WAY_CONTACT_PYTHON goto custom
where py >nul 2>&1
if errorlevel 1 goto python
py -3 -B "%~dp0run_contact.py" %*
goto finish
:python
python -B "%~dp0run_contact.py" %*
goto finish
:custom
"%WAY_CONTACT_PYTHON%" -B "%~dp0run_contact.py" %*
:finish
set "WAY_CONTACT_EXIT=%ERRORLEVEL%"
if "%~1"=="" pause
exit /b %WAY_CONTACT_EXIT%
