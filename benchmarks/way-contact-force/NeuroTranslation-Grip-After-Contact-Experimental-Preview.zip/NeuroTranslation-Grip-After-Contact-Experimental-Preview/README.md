# Grip after contact

The plates register a squeeze. How hard will the hand be squeezing 120 milliseconds later? In this recorded pinch-lift task, the past 400 ms of force and motion gave a better answer than the same measurements plus scalp EEG on the three people used for development. The model forecasts the average normal force on two plates, in newtons. [WAY-EEG-GAL data descriptor](https://www.nature.com/articles/sdata201447.pdf).

## Run the preview

Extract the whole ZIP. You need Python 3.10 or later and NumPy, installed in the Python environment you use. The launchers run locally and read no network resources.

- **Windows** — double-click `Run-Windows.cmd`. From a terminal use `Run-Windows.cmd --help`.
- **macOS** — open `Run-macOS.command` or run `sh ./Run-macOS.command` in Terminal.
- **Linux** — run `./Run-Linux.sh` in a terminal, or run `sh ./Run-Linux.sh` if extraction strips executable permission.

Each launcher starts with an invented pinch lift and displays forecast values as JSON. It uses the bundled fitted weights. Use `--offset 100` to ask for just one issue time at 100 ms after force confirmation. Save JSON with `--output forecasts.json`. To use a different Python environment, set `WAY_CONTACT_PYTHON` to its executable path. The Linux launch was checked in this extracted package. Windows and macOS launcher files are supplied with static validation.

## Supply captured signals

Use `--input /path/to/capture.npz` with the history from before the LED go cue through each requested issue. The file needs object and hand signals in the layout below. Include the optional channels to compare their forecasts on identical input windows. Use NumPy arrays stored without Python object serialization. All clocks are seconds on the same timeline. The program calculates from the input file on your computer.

| Key | Shape | Meaning |
|---|---|---|
| `clock_s` | `(n,)` | Aligned 500 Hz timestamps |
| `led_on_s` | scalar | The captured LED go timestamp |
| `grip_n` | `(n,)` | Average normal fingertip force, positive for compression, in N |
| `load_n` | `(n,)` | Combined vertical load force, positive upward, in N |
| `position` | `(n,4,3)` | X, Y and Z for the object, index finger, thumb and wrist, in the released source scale |
| `eeg` | `(n,32)`, optional | Scalp EEG in released channel order and amplitude scale |
| `emg_clock_s` | `(m,)`, optional | Aligned 4 kHz timestamps for surface EMG |
| `emg` | `(m,5)`, optional | Surface EMG in released channel order and amplitude scale |

`channel-order.json` lists those scalp and muscle channels. `SOURCE-DATA.md` gives the force signs and model inputs. If there are too few captured samples, the output gives the reason and omits the affected forecast. A `forecast_n` key names each available model or formula. The nominal target timestamp is calculated from the issue time plus 120 ms. No observed future target is required to run a forecast.

## Read the result

The six training participants supplied 8,815 scored windows from 1,763 confirmed lifts. The frozen models were compared on 4,410 windows from 882 trials in three previously explored development participants. The figures below are the means of the three separate participant RMSEs, in N. Each represented trial contributes equal weight within its participant.

| Inputs | RMSE (N) |
|---|---:|
| Past force and movement | 0.677 |
| Past force and movement with aligned scalp EEG | 0.695 |
| Past force and movement with another lift's phase-matched EEG | 0.692 |
| Past force and movement with surface EMG | 0.717 |
| Past force and movement with surface EMG and aligned scalp EEG | 0.722 |

Adding aligned EEG increased RMSE for all three development participants. The mean increase was 0.018 N. The descriptive paired interval was −0.003 to +0.040 N. The aligned mean was also 0.004 N higher than when EEG came from another lift at the same scheduled time after its own force confirmation. Between these tiny effects, a sample of three people leaves considerable uncertainty. `AGGREGATE-RESULTS.json` contains the exact errors, signed bias, comparison counts, and results from each scheduled offset. It includes training diagnostics separately.

The forecast runs on the recorded clock. Its contact proxy is the tenth consecutive sample at or above 0.5 N after an observation below that threshold. This proxy cannot locate first anatomical touch. Acquisition and live inference delays remain unknown, and the EEG may include movement or muscle activity. Measurements came from healthy adults performing one task. The final test participants remain reserved.
