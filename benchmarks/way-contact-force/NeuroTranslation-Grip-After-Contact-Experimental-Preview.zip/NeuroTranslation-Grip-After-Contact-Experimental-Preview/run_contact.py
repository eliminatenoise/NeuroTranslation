"""Forecast grip force from supplied past signals or an invented example."""

import argparse
import hashlib
import json
from pathlib import Path

try:
    import numpy as np
except ModuleNotFoundError as error:
    raise SystemExit("This preview requires NumPy in the selected Python environment. See README.md.") from error

from contact import HORIZON, OFFSETS, detect_contact, history_bounds
from contact_features import EEG_NAMES, EMG_NAMES, MECHANICAL_NAMES, TIME_NAMES, eeg_features, emg_features, mechanical_features

HERE = Path(__file__).resolve().parent
REQUIRED = ("clock_s", "led_on_s", "grip_n", "load_n", "position")
OPTIONAL = ("eeg", "emg_clock_s", "emg")
SCHEMA = {
    "time_only": TIME_NAMES,
    "mechanics": MECHANICAL_NAMES,
    "aligned_eeg": MECHANICAL_NAMES + EEG_NAMES,
    "emg": MECHANICAL_NAMES + EMG_NAMES,
    "emg_aligned_eeg": MECHANICAL_NAMES + EEG_NAMES + EMG_NAMES,
}


def clock(values, step):
    return (
        values.ndim == 1 and 0 < len(values)
        and np.isfinite(values).all()
        and np.allclose(np.diff(values), step, rtol=0, atol=1e-6)
    )


def receive(path):
    with np.load(path, allow_pickle=False) as archive:
        names = set(archive.files)
        if not set(REQUIRED).issubset(names) or names - set(REQUIRED) - set(OPTIONAL):
            raise ValueError("NPZ must contain the required arrays and only documented optional arrays.")
        return {key: np.asarray(archive[key], dtype=np.float64) for key in archive.files}


def validate(capture):
    timeline = capture["clock_s"]
    led = capture["led_on_s"]
    if not clock(timeline, 0.002) or led.shape != () or not np.isfinite(led):
        raise ValueError("Provide a finite native 500 Hz clock and one scalar LED onset time.")
    if not timeline[0] <= led <= timeline[-1]:
        raise ValueError("Supply the captured recording from before the LED onset through the issue timestamp.")
    count = len(timeline)
    for name, shape in (("grip_n", ()), ("load_n", ()), ("position", (4, 3)), ("eeg", (32,))):
        if name in capture and capture[name].shape != (count, *shape):
            raise ValueError(f"Unexpected 500 Hz array shape for {name}.")
    if ("emg_clock_s" in capture) != ("emg" in capture):
        raise ValueError("Provide both EMG clock and EMG signal, or omit both.")
    if "emg" in capture:
        emg_clock = capture["emg_clock_s"]
        if not clock(emg_clock, 0.00025) or capture["emg"].shape != (len(emg_clock), 5):
            raise ValueError("Provide an aligned 4 kHz EMG clock and five matching channels.")


def load_parameters(path):
    manifest = json.loads((path.parent / "MANIFEST.json").read_text())
    if hashlib.sha256(path.read_bytes()).hexdigest() != manifest["file_sha256"][path.name]:
        raise ValueError("Saved parameters failed the archive's integrity check.")
    data = json.loads(path.read_text())
    models = {}
    if set(data["models"]) != set(SCHEMA):
        raise ValueError("Saved forecast variants differ from the contact inference schema.")
    for key, expected in SCHEMA.items():
        entry = data["models"][key]
        mean, scale, coeff = (np.asarray(entry[field]) for field in ("means", "scales", "coefficients_n"))
        if (
            tuple(entry["feature_names"]) != expected or entry["add_present_grip_n"] != (key != "time_only")
            or any(values.shape != (len(expected),) or not np.isfinite(values).all() for values in (mean, scale, coeff))
            or not (scale > 0).all() or not np.isfinite(entry["intercept_n"])
        ):
            raise ValueError(f"Saved parameter schema mismatch in {key}.")
        models[key] = mean, scale, coeff, entry["intercept_n"]
    return models


def apply_model(model, design, anchor):
    mean, scale, coeff, intercept = model
    return float(anchor + intercept + ((design - mean) / scale) @ coeff)


def forecast(capture, models, offsets):
    validate(capture)
    timeline = capture["clock_s"]
    led_on = float(capture["led_on_s"])
    grip = capture["grip_n"]
    event = detect_contact(grip, timeline, led_on)
    predictions = []
    if event.confirmation is None:
        return {"contact_force_confirmation": event.reason, "forecasts": predictions}
    for ms in offsets:
        issue = event.confirmation + ms // 2
        status, window = history_bounds(issue, len(timeline))
        record = {"offset_after_confirmation_ms": ms, "status": status, "forecast_n": {}}
        predictions.append(record)
        if window is None:
            continue
        issue_s = float(timeline[issue])
        record["issue_time_s"] = issue_s
        record["nominal_target_time_s"] = issue_s + HORIZON / 500
        gf, lf, pos = grip[window], capture["load_n"][window], capture["position"][window]
        if not all(np.isfinite(values).all() for values in (gf, lf, pos)):
            record["status"] = "mechanical_history_nonfinite"
            continue
        time = np.concatenate((np.equal(ms // 2, OFFSETS), [issue_s - led_on]))
        mechanics, slope = mechanical_features(gf, lf, pos, time)
        present = float(gf[-1])
        future_grip = {
            "persistence": present, "backward_slope": slope,
            "time_only": apply_model(models["time_only"], time, 0),
            "mechanics": apply_model(models["mechanics"], mechanics, present),
        }
        eeg = capture.get("eeg")
        eeg_input = eeg_features(eeg[window]) if eeg is not None and np.isfinite(eeg[window]).all() else None
        if eeg_input is not None:
            future_grip["aligned_eeg"] = apply_model(models["aligned_eeg"], np.concatenate((mechanics, eeg_input)), present)
        if "emg" in capture:
            end = int(np.searchsorted(capture["emg_clock_s"], issue_s, side="right"))
            if end >= 1600:
                muscle = capture["emg"][end - 1600:end]
                if np.isfinite(muscle).all():
                    emg_input = emg_features(muscle)
                    future_grip["emg"] = apply_model(models["emg"], np.concatenate((mechanics, emg_input)), present)
                    if eeg_input is not None:
                        future_grip["emg_aligned_eeg"] = apply_model(models["emg_aligned_eeg"],
                            np.concatenate((mechanics, eeg_input, emg_input)), present)
        record["forecast_n"] = future_grip
    return {
        "contact_force_confirmation": event.reason, "contact_confirmation_clock_s": float(timeline[event.confirmation]),
        "nominal_horizon_ms": HORIZON * 2, "forecasts": predictions,
    }


def example():
    time = np.arange(700) * 0.002
    emg_time = np.arange(5600) * 0.00025
    rise = np.maximum(time - 0.600, 0)
    compression = 5 * (-np.expm1(-rise / 0.120))
    load = 3 * (-np.expm1(-np.maximum(time - 0.680, 0) / 0.150))
    position = np.zeros((len(time), 4, 3))
    position[:, :, 2] = 1.5 * load[:, None]
    position[:, 1, 0] = 1.0
    position[:, 2, 0] = -1.0
    wave = 3 * np.sin(2 * np.pi * 10 * time[:, None] + np.arange(32)[None, :] / 6)
    muscle = 50 * np.sin(2 * np.pi * 45 * emg_time[:, None] + np.arange(5)[None, :])
    return {"clock_s": time, "led_on_s": np.asarray(0.200), "grip_n": compression, "load_n": load,
            "position": position, "eeg": wave, "emg_clock_s": emg_time, "emg": muscle}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, help="An optional local NPZ of captured signals. Omit for invented example.")
    parser.add_argument("--offset", type=int, choices=[2 * index for index in OFFSETS], help="Score just one scheduled offset in ms.")
    parser.add_argument("--output", type=Path, help="Write new JSON output to this file. Default is standard output.")
    args = parser.parse_args()
    try:
        capture = receive(args.input) if args.input else example()
        result = forecast(capture, load_parameters(HERE / "parameters.json"),
                          (args.offset,) if args.offset is not None else tuple(2 * offset for offset in OFFSETS))
        result["input"] = "user-supplied arrays; provenance unverified by this program" if args.input else "invented example"
        report = json.dumps(result, indent=2, allow_nan=False) + "\n"
        if args.output:
            with args.output.open("x", encoding="utf-8") as output:
                output.write(report)
        else:
            print(report, end="")
    except (OSError, ValueError) as error:
        parser.error(str(error))


if __name__ == "__main__":
    main()
