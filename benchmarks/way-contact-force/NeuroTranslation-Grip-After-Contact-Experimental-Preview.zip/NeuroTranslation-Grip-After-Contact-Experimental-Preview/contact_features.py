"""Build forecast inputs exclusively from the exposed prefix at issue time."""

from collections import Counter, defaultdict
from dataclasses import dataclass
import hashlib

import numpy as np

from contact import HISTORY, HORIZON, OFFSETS, detect_contact, history_bounds, rotation

EEG_HZ = 500
TAPS_MS = (0, 20, 40, 80, 160, 320)
EEG_TIME = np.arange(HISTORY, dtype=np.float64) - (HISTORY - 1) / 2
EEG_HANN = np.hanning(HISTORY)
EEG_FREQ = np.fft.rfftfreq(HISTORY, d=1 / EEG_HZ)
BANDS = (
    ("7.5-12.5", (7.5 <= EEG_FREQ) & (EEG_FREQ <= 12.5)),
    ("12.5-25", (12.5 < EEG_FREQ) & (EEG_FREQ <= 25)),
    ("25-35", (25 < EEG_FREQ) & (EEG_FREQ <= 35)),
)
TRACKERS = ("object", "index", "thumb", "wrist")
TIME_NAMES = tuple(f"offset_{2 * offset}_ms" for offset in OFFSETS) + ("seconds_since_LED_go",)
QUADRATIC = ("grip_squared", "load_squared", "grip80_squared", "grip_by_load", "grip_by_grip80", "load_by_grip80")
MECHANICAL_NAMES = (
    TIME_NAMES
    + tuple(f"{signal}_lag_{ms}_ms" for signal in ("grip", "load") for ms in TAPS_MS)
    + tuple(f"{signal}_rate_{ms}_ms" for signal in ("grip", "load") for ms in (20, 80))
    + ("finger_aperture",)
    + tuple(f"{tracker}_delta_{axis}_320_ms" for tracker in ("object", "wrist") for axis in "xyz")
    + tuple(f"{tracker}_rate_{axis}_{ms}_ms" for ms in (80, 160) for tracker in TRACKERS for axis in "xyz")
    + QUADRATIC
    + tuple(f"offset_{2 * offset}_ms_by_{signal}" for offset in OFFSETS for signal in ("grip", "load", "grip80"))
)
EEG_NAMES = (
    tuple(f"eeg_{channel:02d}_bin_{block}_mean_relative_to_first" for block in range(1, 5) for channel in range(1, 33))
    + tuple(f"eeg_{channel:02d}_log_bandpower_{band}_Hz" for band, _ in BANDS for channel in range(1, 33))
)
EMG_NAMES = tuple(f"emg_{channel}_bin_{block}_rms" for block in range(1, 5) for channel in range(1, 6))


@dataclass(frozen=True)
class Row:
    key: tuple[int, int, int, int]
    series_type: str
    mass_g: int
    surface: str
    issue_s: float | None = None
    history_s: float | None = None
    horizon_s: float | None = None
    emg_slack_s: float | None = None
    timing: np.ndarray | None = None
    mechanical: np.ndarray | None = None
    eeg: np.ndarray | None = None
    emg: np.ndarray | None = None
    target: float | None = None
    present: float | None = None
    extrapolate: float | None = None


class Census:
    def __init__(self):
        self.count = Counter()
        self.by_person = defaultdict(Counter)
        self.by_offset = defaultdict(Counter)
        self.by_person_offset = defaultdict(Counter)
        self.confirmation_delay_ms = defaultdict(list)

    def record(self, participant, reason, offset=None):
        if offset is None:
            self.count[reason] += 1
            self.by_person[participant][reason] += 1
        else:
            self.by_offset[offset][reason] += 1
            self.by_person_offset[f"{participant}:{offset}"][reason] += 1

    def report(self):
        return {
            "trial_events": dict(self.count),
            "trial_events_by_participant": self.by_person,
            "issue_events_by_offset_ms": self.by_offset,
            "issue_events_by_participant_and_offset_ms": self.by_person_offset,
            "confirmation_delay_after_go_ms_by_participant": {
                str(person): {
                    "min": float(np.min(delays)), "median": float(np.median(delays)), "max": float(np.max(delays))
                }
                for person, delays in sorted(self.confirmation_delay_ms.items())
            },
        }


def mechanical_features(grip, load, motion, timing):
    lags = -1 - np.asarray(TAPS_MS) // 2
    last_gf = grip[-1]
    last_lf = load[-1]
    g20, g80 = (last_gf - grip[lags[1]]) / 0.020, (last_gf - grip[lags[3]]) / 0.080
    l20, l80 = (last_lf - load[lags[1]]) / 0.020, (last_lf - load[lags[3]]) / 0.080
    last = motion[-1]
    aperture = np.linalg.norm(last[1] - last[2])
    delta = (last - motion[lags[-1]])[[0, 3]].ravel()
    rates = [(last - motion[-1 - ms // 2]).ravel() / (ms / 1000) for ms in (80, 160)]
    quadratic = [last_gf**2, last_lf**2, g80**2, last_gf * last_lf, last_gf * g80, last_lf * g80]
    interactions = np.outer(timing[:len(OFFSETS)], [last_gf, last_lf, g80]).ravel()
    features = np.concatenate((timing, grip[lags], load[lags], [g20, g80, l20, l80], [aperture], delta,
                               *rates, quadratic, interactions))
    return features, float(last_gf + 0.120 * g80)


def eeg_features(eeg):
    # C-order keeps the reference's sample-wise, contiguous 32-channel reduction.
    eeg = np.asarray(eeg, dtype=np.float64, order="C")
    reference = eeg - eeg.mean(axis=1, keepdims=True)
    means = reference.reshape(4, 50, 32).mean(axis=1)
    centred = reference - reference.mean(axis=0, keepdims=True)
    slope = np.einsum("t,tc->c", EEG_TIME, centred) / np.dot(EEG_TIME, EEG_TIME)
    detrended = centred - EEG_TIME[:, None] * slope
    spectrum = np.fft.rfft(detrended * EEG_HANN[:, None], axis=0)
    power = np.abs(spectrum)**2 / (EEG_HZ * np.dot(EEG_HANN, EEG_HANN))
    power[1:-1] *= 2
    band_power = np.stack([power[mask].sum(axis=0) * (EEG_HZ / HISTORY) for _, mask in BANDS])
    return np.concatenate(((means - means[:1]).ravel(), np.log(np.maximum(band_power, 1e-12)).ravel()))


def emg_features(emg):
    centred = emg - emg.mean(axis=0, keepdims=True)
    return np.sqrt((centred.reshape(4, 400, 5)**2).mean(axis=1)).ravel()


def extract_row(trial, event, offset, census):
    index = event.confirmation + offset
    offset_ms = 2 * offset
    key = (trial.participant, trial.series, trial.trial, offset_ms)
    identity = dict(key=key, series_type=trial.series_type, mass_g=trial.mass_g, surface=trial.surface)
    record = lambda event_name: census.record(trial.participant, event_name, offset_ms)
    record("scheduled_after_confirmation")
    status, history = history_bounds(index, len(trial.eeg_t))
    if status == "issue_outside_recording":
        record(status)
        record("target_outside_recording")
        return Row(**identity)

    issue_s = float(trial.eeg_t[index])
    record("issue_observed")
    timing = np.concatenate((np.equal(offset, OFFSETS), [issue_s - trial.led_on_s]))
    mechanical = eeg = emg = present = extrapolate = history_s = emg_slack_s = None
    if history is None:
        record(status)
    else:
        history_s = issue_s - float(trial.eeg_t[history.start])
        grip, load, position = (np.asarray(channel[history], dtype=np.float64) for channel in
                                (trial.grip_n, trial.load_n, trial.position))
        if all(np.isfinite(channel).all() for channel in (grip, load, position)):
            mechanical, extrapolate = mechanical_features(grip, load, position, timing)
            present = float(grip[-1])
            record("mechanics_input_ready")
        else:
            record("mechanics_input_nonfinite")
        eeg_history = trial.eeg[history]
        if np.isfinite(eeg_history).all():
            eeg = eeg_features(eeg_history)
            record("eeg_input_ready")
        else:
            record("eeg_input_nonfinite")
        emg_end = int(np.searchsorted(trial.emg_t, issue_s, side="right"))
        if emg_end >= 1600:
            emg_history = np.asarray(trial.emg[emg_end - 1600:emg_end], dtype=np.float64)
            emg_slack_s = issue_s - float(trial.emg_t[emg_end - 1])
            if np.isfinite(emg_history).all():
                emg = emg_features(emg_history)
                record("emg_input_ready")
            else:
                record("emg_input_nonfinite")
        else:
            record("emg_short_history")
    if mechanical is not None and eeg is not None:
        record("common_input_ready_before_label_read")

    target = horizon_s = None
    target_index = index + HORIZON
    if target_index >= len(trial.grip_n):
        record("target_outside_recording")
    elif not np.isfinite(trial.grip_n[target_index]):
        record("target_nonfinite")
    else:
        target = float(trial.grip_n[target_index])
        horizon_s = float(trial.eeg_t[target_index]) - issue_s
        record("target_observed")
    return Row(**identity, issue_s=issue_s, history_s=history_s, horizon_s=horizon_s, emg_slack_s=emg_slack_s,
               timing=timing, mechanical=mechanical, eeg=eeg, emg=emg, target=target, present=present,
               extrapolate=extrapolate)


def assemble(trials, people):
    """Create common scoring sets. Rotation is independent of donor labels."""
    census = Census()
    confirmed = []
    rows = {}
    event_identities = []
    for trial in trials:
        if trial.participant not in people:
            raise ValueError("Adapter yielded a participant outside the admitted role.")
        event = detect_contact(trial.grip_n, trial.eeg_t, trial.led_on_s)
        event_identities.append((trial.participant, trial.series, trial.trial, event.confirmation))
        census.record(trial.participant, "scheduled_trials")
        census.record(trial.participant, event.reason)
        if event.confirmation is None:
            continue
        delay_ms = 1000 * (trial.eeg_t[event.confirmation] - trial.led_on_s)
        census.confirmation_delay_ms[trial.participant].append(delay_ms)
        confirmed.append((trial.participant, trial.series, trial.trial, trial.mass_g, trial.surface))
        for offset in OFFSETS:
            row = extract_row(trial, event, offset, census)
            if row.key in rows:
                raise ValueError("Repeated issue identity from source.")
            rows[row.key] = row
    if set(census.by_person) != set(people) or any(c["scheduled_trials"] != 294 for c in census.by_person.values()):
        raise ValueError("Admitted role is missing trials or participants.")
    if len({identity[:3] for identity in event_identities}) != len(event_identities):
        raise ValueError("Repeated trial identity from source.")

    donors, sizes = rotation(confirmed)
    primary = []
    matched = []
    muscle = []
    for key, row in sorted(rows.items()):
        if row.mechanical is None or row.eeg is None or row.target is None:
            continue
        primary.append(row)
        census.record(key[0], "primary_scored", key[-1])
        trial_donor = donors.get(key[:3])
        if trial_donor is None:
            census.record(key[0], "rotation_sparse_stratum", key[-1])
            continue
        donor = rows[(*trial_donor, key[-1])]
        if donor.eeg is None:
            census.record(key[0], "rotation_donor_eeg_unavailable", key[-1])
            continue
        matched.append((row, donor))
        census.record(key[0], "rotation_scored", key[-1])
        if row.emg is not None:
            muscle.append((row, donor))
            census.record(key[0], "rotation_with_emg_scored", key[-1])
    return primary, matched, muscle, census, sizes, event_identities


def digest(values):
    value = "".join(",".join(str(field) for field in row) + "\n" for row in values)
    return hashlib.sha256(value.encode("ascii")).hexdigest()
