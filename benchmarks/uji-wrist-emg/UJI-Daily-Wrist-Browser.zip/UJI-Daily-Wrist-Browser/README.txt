Wrist estimates during daily activities

Extract the whole folder and open index.html or your system launcher.
Linux: sh Launch-Linux.sh. macOS: open Launch-macOS.command or run it in
Terminal. Windows: open Launch-Windows.cmd. Linux Chromium and its launcher
were tested. Native Windows and macOS execution remains unverified.

Choose a task and an invented muscle-activity example to explore the models.
For a compatible recording, open a local JSON window. The raw form has seven
spots at integer millisecond positions within the preceding half second, or
supply sixteen RMS bins with seven values each. The source scale, spot order,
task label and timing matter. example-window.json contains invented values.
The input can be inspected in the heatmap and the numerical table. Your
data remain in this tab. Return to invented inputs clears the selected data.

The two frozen estimators were trained on fourteen people in the KIN-MUS UJI
study. The second uses forearm EMG alongside task and elapsed time. A third
estimate combines the other two using separate TRAIN-learned weights per axis.
These are estimates of archived glove angle at the nominal 250 ms target.
The source filtered the angles both forwards and backwards. In the four-person
development comparison the weighted estimate had higher overall error than
using the full muscle signal, and lower radial error. Final test data remain
sealed. The reader carries fitted parameters and invented examples.

Source: KIN-MUS UJI v1.0 by Néstor J. Jarque-Bou, Margarita Vergara,
Joaquín L. Sancho-Bru, Verónica Gracia-Ibáñez and Alba Roda-Sales.
https://doi.org/10.5281/zenodo.3469380
CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
Scientific Data descriptor: https://doi.org/10.1038/s41597-019-0285-1
NeuroTranslation derived seven-channel historical RMS features, fitted the
models and prepared this interface and the invented examples. See LICENSE.txt
for project-owned code. Study, method ZIPs and reproducible sources:
https://github.com/eliminatenoise/NeuroTranslation/tree/main/benchmarks/uji-wrist-emg
