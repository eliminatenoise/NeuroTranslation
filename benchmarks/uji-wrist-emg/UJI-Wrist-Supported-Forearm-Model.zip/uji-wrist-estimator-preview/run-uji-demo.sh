#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
exec "${UJI_PYTHON:-python3}" -B infer_uji.py MODEL-STATE.json SYNTHETIC-RMS.json
