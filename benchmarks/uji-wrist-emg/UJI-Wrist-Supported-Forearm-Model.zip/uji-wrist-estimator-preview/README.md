# How much does forearm EMG tell us about the wrist?

Imagine opening a jar. Give the first model the activity and time since the recorded segment began, and it estimates two angles from the training cohort’s wrist movements. Give the second model the same activity and clock, plus half a second of electrical activity from seven forearm sites. It can use that signal to revise its estimate. The useful question is whether the revision brings the estimate closer to the recorded wrist angles for people the models have never seen.

This NeuroTranslation preview contains two fitted ridge models for that question. Both learn from 65,821 windows in the KIN-MUS UJI archive, with equal total weight for each of 14 training participants. That keeps a person with a longer recording from counting more. Each of the 26 activity intercepts and 112 EMG terms has input support from at least seven training people. An activity’s time term can contribute only when its elapsed time or hinge value is positive for seven or more people. This leaves 176 of 260 time terms in both models. This screen reduces reliance on terms seen in very few people. It offers no formal privacy guarantee.

## What changed on development recordings?

Across 20,073 eligible windows from four development participants and 104 trials, giving everyone equal weight, the two-axis root mean squared error fell from **36.16° to 34.70°**. Extension error fell by 2.42°. Radial deviation error rose by 0.70°. Rotating the EMG windows within each of the same trials, so the model got the right task but the wrong moment, raised error by 0.68° relative to aligned EMG. The exploratory 95% interval for the two-axis change from adding EMG was [−2.936°, −0.005°], resampling the same four people as pairs. That is a small sample. The preassigned final test partition remains sealed.

These numbers apply to the two fitted heads in this folder. The primary study has a separate comparison, with its full registered set of time terms.

## Open the example

Unzip the folder. Open the launcher for your operating system or run the command below from the folder. Use Python 3.11 or later with NumPy installed in that environment. The study used Python 3.13.15 and NumPy 2.4.6. The launcher uses invented input values with the fitted models. It prints one prediction from each model in the terminal. The script reads local files and makes no network requests.

| System | Launcher |
| --- | --- |
| Windows | `Run-UJI-Demo.cmd` |
| macOS | `Run-UJI-Demo.command` |
| Linux | `./run-uji-demo.sh` |

```sh
python3 infer_uji.py MODEL-STATE.json SYNTHETIC-RMS.json
```

On Windows, use `py -3` in place of `python3` if needed.

Try `SYNTHETIC-ZERO-RMS.json` as a second example. The EMG features are zero, so the EMG terms contribute zero. The predictions can still differ because the models fitted their activity and time weights separately. Both examples show the calculation. Measuring accuracy takes a recorded angle and a held-out comparison.

The Linux launcher and the macOS shell wrapper were exercised on Linux. Windows and macOS still need native execution checks.

## Supply a compatible window

Copy `SYNTHETIC-RMS.json` and replace its values with inputs on the KIN-MUS UJI version 1.0 raw companion archive’s numerical scale. Pass your file as the second argument. The file uses the following fields.

| Field | Value |
| --- | --- |
| `task_id` | Integer activity ID from 1 through 26. Use the source’s ADL numbering and the recorded activity. |
| `elapsed_anchor_s` | Seconds from the published trimmed segment start to the EMG cutoff. The minimum is 0.5 seconds. The time basis clips the input at 30 seconds. |
| `amplitude_scale` | `kin-mus-uji-v1.0-native-amplitude`. This label declares the input convention. The archive’s amplitude has no verified conversion to volts for this model. |
| `rms_bins` | Sixteen chronological rows of seven finite, nonnegative numbers. Spots follow order 1 through 7. Each number is the square root of the mean squared native amplitude for that spot in that bin. |
| `input_provenance` | Optional description of your input source. Replace the example’s synthetic label when using a compatible recording. |

The bins are 31.25 ms wide and cover the half-second before and including the cutoff. Each bin excludes its left endpoint and includes its right endpoint. When deriving the bins, use the source’s actual timestamps and at least 25 finite samples in every bin on every spot. The largest raw gap within the window is 5 ms. The precomputed input contains no raw timestamps, so verify those conditions before supplying it. You can also replace `rms_bins` with two fields, `clock_ms_from_anchor` and `emg`. Supply strictly increasing integer millisecond positions in `(-500, 0]` and one row of seven native raw amplitudes per position. The runner then checks support and computes the RMS. Whole-record normalization, arbitrary device gains and processed archive amplitudes change the input scale.

Output fields `extension_deg` and `radial_deviation_deg` estimate the archive’s wrist angles 250 ms after the EMG cutoff. Positive values mean extension and radial deviation, respectively. The labels come from an individually calibrated glove, relative to a recorded reference posture and retrospectively filtered in both directions at 5 Hz. At inference the activity and trimmed start are supplied by the caller. The 250 ms describes the archive’s input cutoff. Real-time latency, wrist sensor accuracy, live control and transfer to other devices or activities require their own tests. Surface EMG measures muscle electrical activity.

## Source

Nestor Jarque-Bou, Margarita Vergara, Joaquín L. Sancho-Bru, Verónica Gracia-Ibáñez and Alba Roda-Sales, *A calibrated database of kinematics and EMG of the forearm and hand during activities of daily living*, version 1.0. The training adaptation uses the archive’s two wrist columns and seven raw forearm EMG spots, extracts matched historical windows and fits an aggregate ridge model. This folder contains fitted parameters and invented examples. [KIN-MUS UJI data release](https://doi.org/10.5281/zenodo.3469380), [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/), [Scientific Data descriptor](https://doi.org/10.1038/s41597-019-0285-1), [forearm electrode mapping study](https://doi.org/10.1186/s12984-018-0437-0).

Terminology follows the Brain2Body glossary, revision 36, SHA-256 `40b98695e6204bc9e305ecdea853756aec30f48a6ae67d29e92c8bb220b3e406`.
