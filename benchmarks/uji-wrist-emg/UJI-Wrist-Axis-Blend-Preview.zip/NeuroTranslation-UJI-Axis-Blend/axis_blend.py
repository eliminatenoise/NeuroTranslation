"""Estimate both wrist angles with the frozen axis-specific UJI blend."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


BASE = "task_time"
PAIR = "task_time_emg"
MIX = "axis_blend"
AXES = ("extension_deg", "radial_deviation_deg")
BASE_SHA256 = "a6b92d0897d2159b64eb519bf2010d6ccd1c9a79a6cfa8dc4742e1ebeecfae53"


def blend(baseline, augmented, alpha):
    """Keep exact endpoint values even when addition would round differently."""
    alpha = np.asarray(alpha, dtype=np.float64)
    result = baseline + alpha * (augmented - baseline)
    return np.where(alpha == 0, baseline, np.where(alpha == 1, augmented, result))


def read_blend(checkpoint, blend_file):
    base_bytes = checkpoint.read_bytes()
    config = json.loads(blend_file.read_bytes())
    if (type(config["schema_version"]) is not int or config["schema_version"] != 1
            or config["axes"] != list(AXES)
            or config["base_model_sha256"] != BASE_SHA256
            or hashlib.sha256(base_bytes).hexdigest() != BASE_SHA256):
        raise ValueError("Blend and endpoint weights must match the released UJI model")
    alpha = config["alpha"]
    if (type(alpha) is not list or len(alpha) != len(AXES)
            or any(type(value) not in (int, float) or not 0 <= value <= 1 for value in alpha)):
        raise ValueError("Supply two finite blend weights between zero and one")
    return json.loads(base_bytes), alpha


def main(args=None):
    from infer_uji import infer

    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("window", type=Path, help="UJI-format historical EMG window or RMS features")
    parser.add_argument("--checkpoint", type=Path, default=here / "MODEL-STATE.json")
    parser.add_argument("--blend", type=Path, default=here / "AXIS-BLEND.json")
    settings = parser.parse_args(args)
    try:
        bundle, alpha = read_blend(settings.checkpoint, settings.blend)
        result = infer(bundle, json.loads(settings.window.read_bytes()))
        estimates = result["predictions"]
        baseline = np.array([estimates[BASE][axis] for axis in AXES])
        augmented = np.array([estimates[PAIR][axis] for axis in AXES])
        mixed = blend(baseline, augmented, alpha)
        if not np.isfinite(mixed).all():
            raise ValueError("Nonfinite blended estimate")
        estimates[MIX] = dict(zip(AXES, mixed.tolist(), strict=True))
        result["estimator"] = "KIN-MUS UJI wrist angle with a separate EMG blend for each axis"
        result["emg_blend_weight_by_axis"] = dict(zip(AXES, alpha, strict=True))
        print(json.dumps(result, indent=2, allow_nan=False))
    except (KeyError, TypeError, ValueError, OverflowError, OSError) as error:
        parser.error(str(error))


if __name__ == "__main__":
    main()
