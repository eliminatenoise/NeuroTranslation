# How far should muscle activity move a wrist-angle estimate?

Suppose the task is opening a jar. The activity and the time tell one model how the training cohort tended to move at that point in the task. A second model also sees half a second of electrical activity from seven forearm sites. If the second estimate overshoots, how much of its adjustment should we keep? This NeuroTranslation preview lets the answer differ for wrist extension and radial deviation.

For each axis the estimate starts at the activity-and-time prediction and moves a learned fraction of the way toward the prediction that also uses surface electromyography (EMG). The final weights are **0.737345** for extension and **0.737570** for radial deviation. They're nearly the same. The fraction sets how far to move between two fitted estimates. It does not describe a muscle's contribution to wrist movement.

## What the recorded angles tell us

We held out one person at a time from the 14-person TRAIN cohort. Each time we fitted the two models on the other 13 people. To set the blend for that fold, we used predictions on those 13 people from models that also left each of them out in turn. Each fit recalculated its scales and equal-person weights and required at least seven people to support each retained term. This gave every one of the 65,821 eligible windows, across 359 recorded trials, three predictions from models that had not seen its person. The two heads bundled here use all 14 people. The paired predictions from holding out each person once supply the two final blend weights for those heads.

| Prediction | Extension RMSE | Radial deviation RMSE | Two-axis RMSE |
| --- | ---: | ---: | ---: |
| Activity and time | 26.372° | 13.982° | 21.106° |
| Activity, time and EMG | 25.721° | 13.494° | 20.538° |
| Separate blend for each axis | 25.641° | 13.433° | 20.468° |

Each person contributes equally to the root mean squared error (RMSE). The blend shaved **0.070°** off the two-axis error of always taking the EMG model's estimate. Resampling people in pairs gave an exploratory 95% interval of **−0.350° to +0.143°** for blend minus EMG, so the observed difference is small compared with its uncertainty. The interval uses the existing fold errors and does not rerun the fitting procedure.

We then ran the frozen weights on 20,073 windows over 104 trials from the same four people used in earlier development comparisons. Those earlier results motivated this experiment, so this is an exploratory check on a reused cohort. The four final UJI test people remain sealed.

| Prediction on reused development data | Extension RMSE | Radial deviation RMSE | Two-axis RMSE |
| --- | ---: | ---: | ---: |
| Activity and time | 48.762° | 15.427° | 36.165° |
| Activity, time and EMG | 46.346° | 16.130° | 34.700° |
| Separate blend for each axis | 46.858° | 15.818° | 34.971° |

The blend gave back **0.512°** of the EMG model's extension improvement and recovered **0.312°** on radial deviation. Its radial error remained **0.390°** above the activity-and-time model's. The two-axis error was **0.271°** higher than the EMG model's, with an exploratory paired-person interval of **−0.142° to +0.679°**. It was **1.194°** lower than the activity-and-time model's. Dropping activities 7 and 11, where the archive warns of a glove measurement artifact, kept the two-axis difference against the EMG model at **+0.264°**. Rotating EMG windows within trials increased the blend's two-axis error by **0.465°** on these same 104 trials. The older aligned and rotated model scores reproduce exactly. `RESULTS.json` records these comparisons by axis and phase, including the rotation and glove-warning checks.

## Open the example

Unzip the folder and open the launcher for your system. Use Python 3.11 or later with NumPy installed. The example supplies invented numbers to the fitted heads and prints all three angle estimates in the terminal.

| System | Launcher |
| --- | --- |
| Windows | `Run-UJI-Blend.cmd` |
| macOS | `Run-UJI-Blend.command` |
| Linux | `./run-uji-blend.sh` |

From the unzipped folder you can also run `python3 axis_blend.py SYNTHETIC-RMS.json`. On Windows, use `py -3` in place of `python3` if needed. The launcher and macOS shell wrapper were exercised on Linux. Native macOS and Windows execution remain unverified.

Try `SYNTHETIC-ZERO-RMS.json` to see what happens when all EMG inputs are zero. The two heads can still give different estimates because each fitted its own activity and time coefficients. Both examples show how the software computes an angle. Scoring an estimate takes a recorded reference.

## Use a compatible recording

Copy `SYNTHETIC-RMS.json`, substitute a compatible window and pass that file to `axis_blend.py`.

| Field | Meaning |
| --- | --- |
| `task_id` | Integer activity ID from 1 to 26 in the KIN-MUS UJI archive. |
| `elapsed_anchor_s` | Seconds from the published segment start to the EMG cutoff. The minimum is 0.5 seconds and the time features clip at 30 seconds. |
| `amplitude_scale` | `kin-mus-uji-v1.0-native-amplitude`. A conversion to volts is unverified. |
| `rms_bins` | Sixteen chronological rows of seven finite nonnegative values, in archive spot order 1 through 7. Each value is the square root of the mean squared raw amplitude for one spot in one bin. |
| `input_provenance` | Optional description of the input. Replace the synthetic label when using a recording. |

Each 31.25 ms bin excludes its left endpoint and includes its right endpoint. Together they cover the half-second through the EMG cutoff. Use the original source clock and at least 25 finite observations per spot in each bin, with no gap over 5 ms in the window. For raw input, replace `rms_bins` with `clock_ms_from_anchor` and `emg`. Supply strictly increasing integer millisecond positions in `(-500, 0]` and seven source amplitudes per position. The runner then checks the clock and derives the RMS values. Changing electrode positions, device gain or full-record normalization changes the inputs that the model sees.

The target is an archived wrist angle 250 ms after the latest allowed EMG sample. Positive output degrees indicate extension and radial deviation. The target angles came from a calibrated glove, relative to its recorded reference posture and filtered forward and backward at 5 Hz after acquisition. The archive's 250 ms cutoff specifies the input clock. Live latency, prospective control and transfer to other devices still require their own measurements. Surface EMG measures muscle electrical activity.

Néstor J. Jarque-Bou, Margarita Vergara, Joaquín L. Sancho-Bru, Verónica Gracia-Ibáñez and Alba Roda-Sales published the KIN-MUS UJI archive. This adaptation uses its paired wrist angles and raw EMG to derive features, fit two aggregate heads and learn the fractions between their estimates. [KIN-MUS UJI v1.0](https://doi.org/10.5281/zenodo.3469380), [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/), [Scientific Data article](https://doi.org/10.1038/s41597-019-0285-1), [forearm electrode mapping study](https://doi.org/10.1186/s12984-018-0437-0).

Terminology follows Brain2Body glossary revision 36, SHA-256 `40b98695e6204bc9e305ecdea853756aec30f48a6ae67d29e92c8bb220b3e406`.
