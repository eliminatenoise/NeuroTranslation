#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
exec ./run-uji-blend.sh
