@echo off
setlocal
cd /d "%~dp0"
set OPENBLAS_NUM_THREADS=1
set OMP_NUM_THREADS=1
set MKL_NUM_THREADS=1
if defined UJI_PYTHON (
  "%UJI_PYTHON%" -B axis_blend.py SYNTHETIC-RMS.json
) else (
  where py >nul 2>nul
  if errorlevel 1 (
    python -B axis_blend.py SYNTHETIC-RMS.json
  ) else (
    py -3 -B axis_blend.py SYNTHETIC-RMS.json
  )
)
set "UJI_EXIT=%ERRORLEVEL%"
if /i not "%~1"=="--no-pause" pause
exit /b %UJI_EXIT%
