"""Read one historical seven-spot EMG window and run two frozen angle estimators."""

import argparse
import json
from pathlib import Path

import numpy as np

from uji_model import (AXES, BINS, EMG_WIDTH, HORIZON, KNOTS_S, SPOTS, TASKS, TIME_WIDTH,
                       TICKS_PER_MS, clock_ticks, predict, require, rms_history, task_basis)


BASE = "task_time"
PAIR = "task_time_emg"
UJI_AMPLITUDE_SCALE = "kin-mus-uji-v1.0-native-amplitude"
SYNTHETIC_AMPLITUDE_SCALE = "synthetic-demo-native-amplitude"
MAX_SQUARE_SAFE_MAGNITUDE = np.sqrt(np.finfo(np.float64).max / 32)


def numeric_array(values):
    checked = np.asarray(values, dtype=object)
    require(all(type(item) in (int, float) for item in checked.flat),
            "samples must be JSON numbers")
    array = checked.astype(np.float64)
    require(np.isfinite(array).all(), "samples must be finite")
    return array


def paired_states(bundle):
    require(bundle["axes"] == list(AXES) and bundle["knots_seconds"] == KNOTS_S.tolist(),
            "checkpoint does not use the expected angle axes and time basis")
    states = {}
    for name in (BASE, PAIR):
        state = bundle["models"][name]
        require(state["name"] == name, "checkpoint head name does not match its slot")
        emg_scale_size = 0 if name == BASE and state["emg_scale"] == [] else EMG_WIDTH
        sizes = {"intercept": (TASKS, 2), "time_scale": (TASKS, TIME_WIDTH),
                 "time_beta": (TASKS * TIME_WIDTH, 2), "emg_scale": (emg_scale_size,),
                 "emg_beta": (EMG_WIDTH if name == PAIR else 0, 2)}
        arrays = {key: np.asarray(state[key], dtype=np.float64) for key in sizes}
        if not len(arrays["emg_beta"]):
            arrays["emg_beta"] = arrays["emg_beta"].reshape(0, 2)
        for key, shape in sizes.items():
            require(arrays[key].shape == shape and np.isfinite(arrays[key]).all(),
                    f"invalid checkpoint array {name}.{key}")
        for key in ("time_scale", "emg_scale"):
            require(np.all(arrays[key] >= 0), f"negative feature scale {name}.{key}")
        states[name] = {**arrays, "name": name}
    require(np.array_equal(states[BASE]["time_scale"], states[PAIR]["time_scale"]),
            "the two models do not share their task/time scalers")
    return states


def infer(bundle, window):
    states = paired_states(bundle)
    scale = bundle.get("input_amplitude_scale", UJI_AMPLITUDE_SCALE)
    require(scale in (UJI_AMPLITUDE_SCALE, SYNTHETIC_AMPLITUDE_SCALE), "unknown checkpoint amplitude scale")
    require(window["amplitude_scale"] == scale, f"window amplitude_scale must be {scale!r}")
    task = window["task_id"]
    elapsed = window["elapsed_anchor_s"]
    require(type(task) is int and 1 <= task <= TASKS, "task_id must be an integer from 1 to 26")
    require(type(elapsed) in (float, int) and np.isfinite(elapsed) and elapsed >= 0.5,
            "elapsed_anchor_s must be finite and at least 0.5 seconds after the declared segment start")
    if "rms_bins" in window:
        require("emg" not in window and "clock_ms_from_anchor" not in window,
                "supply raw history or RMS bins alone")
        rms = numeric_array(window["rms_bins"])
        require(rms.shape == (BINS, SPOTS), "rms_bins must have sixteen rows and seven spots per row")
        require(np.all((rms >= 0) & (rms <= MAX_SQUARE_SAFE_MAGNITUDE)),
                "RMS amplitude exceeds its nonnegative numerical range")
        emg = rms.reshape(1, EMG_WIDTH)
    else:
        require(1 <= len(window["clock_ms_from_anchor"]) <= 500,
                "one window accepts at most 500 distinct millisecond positions")
        clock = clock_ticks(numeric_array(window["clock_ms_from_anchor"]) / 1000)
        require(clock[0] > -500 * TICKS_PER_MS and clock[-1] <= 0,
                "timestamps must lie in the past half-second (-500 ms, 0 ms]")
        raw = numeric_array(window["emg"])
        require(raw.shape == (len(clock), SPOTS), "EMG needs one row per clock position and seven source spots")
        require(np.max(np.abs(raw)) <= MAX_SQUARE_SAFE_MAGNITUDE, "raw amplitude cannot be squared safely")
        emg, flags = rms_history(clock, raw, np.array([HORIZON]))
        require(not np.any(flags), "EMG history failed support checks (short bin, gap, nonfinite or overflow)")
    features = {"task": np.array([task]), "time": task_basis(np.array([elapsed])), "emg": emg}
    predictions = {name: predict(features, state)[0] for name, state in states.items()}
    require(all(np.isfinite(prediction).all() for prediction in predictions.values()), "nonfinite estimator output")
    return {"estimator": bundle.get("estimator", "locally supplied; check its provenance"),
            "output_offset_from_anchor_ms": 250,
            "reference": "offline archive-angle predictions in degree coordinates",
            "amplitude_scale": scale, "input_provenance": window.get("input_provenance", "unspecified"),
            "predictions": {name: dict(zip(AXES, prediction.tolist(), strict=True))
                            for name, prediction in predictions.items()}}


def run(args=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checkpoint", type=Path)
    parser.add_argument("window", type=Path)
    settings = parser.parse_args(args)
    try:
        bundle = json.loads(settings.checkpoint.read_text(encoding="utf-8"))
        window = json.loads(settings.window.read_text(encoding="utf-8"))
        print(json.dumps(infer(bundle, window), indent=2, allow_nan=False))
    except (KeyError, TypeError, ValueError, OverflowError, OSError) as error:
        parser.error(str(error))


if __name__ == "__main__":
    run()
