"""Fit two tiny synthetic heads and apply them to one generated input window."""

import json

import numpy as np

from infer_uji import BASE, PAIR, SYNTHETIC_AMPLITUDE_SCALE, infer
from replicate_uji import serialize_states
from synthetic_demo import make_trial
from uji_model import AXES, KNOTS_S, TASKS, fit_model, participant_weights, shared_scales, stack_trials


def demo():
    rng = np.random.Generator(np.random.PCG64(211))
    people = [1, 2, 3]
    trials = [make_trial(rng, person, task, 2700) for person in people for task in range(1, TASKS + 1)]
    train = stack_trials(trials)
    w = participant_weights(train["person"], people)
    scales = shared_scales(train, w)
    states = {name: fit_model(train, w, scales, name)[0] for name in (BASE, PAIR)}
    checkpoint = {"estimator": "synthetic worked example", "axes": list(AXES),
                  "input_amplitude_scale": SYNTHETIC_AMPLITUDE_SCALE,
                  "knots_seconds": KNOTS_S.tolist(), "models": serialize_states(states)}
    ms = np.arange(-499, 1)
    raw = (1.0 + 0.6 * np.sin(ms[:, None] / 180 + np.arange(7) / 5)) * rng.normal(size=(len(ms), 7))
    window = {"task_id": 4, "elapsed_anchor_s": 1.10, "amplitude_scale": SYNTHETIC_AMPLITUDE_SCALE,
              "input_provenance": "generated signals only",
              "clock_ms_from_anchor": ms.tolist(), "emg": raw.tolist()}
    return infer(checkpoint, window)


if __name__ == "__main__":
    print(json.dumps(demo(), indent=2, allow_nan=False))
