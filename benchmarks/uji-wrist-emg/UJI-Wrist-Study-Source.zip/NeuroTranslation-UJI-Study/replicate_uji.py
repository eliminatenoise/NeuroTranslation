"""Repeat the frozen fitting method on a user's own prepared TRAIN and DEV splits."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from portable_study import coverage, input_trials, score
from uji_model import (AXES, KNOTS_S, MODELS, PENALTY, TASKS, fit_model, participant_weights,
                       require, shared_scales, stack_trials)


def role_inventory(role):
    people = role["people"]
    require(isinstance(people, list) and people and
            all(type(key) is int and 1 <= key <= np.iinfo(np.int16).max for key in people) and
            people == sorted(set(people)), "each role needs ascending, unique positive local subject keys")
    require("missing_trials" in role and isinstance(role["missing_trials"], list),
            "each role must declare missing_trials; use [] when complete")
    missing = set()
    for pair in role["missing_trials"]:
        require(isinstance(pair, list) and len(pair) == 2 and all(type(x) is int for x in pair),
                "missing_trials entries must be [local subject key, activity ID] pairs")
        person, task = pair
        require(person in people and 1 <= task <= TASKS and (person, task) not in missing,
                "missing trial is outside the declared role or duplicates an earlier declaration")
        missing.add((person, task))
    return people, missing


def load_input(path, people, missing):
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    trials, rejected = input_trials(path, digest, people, missing)
    data = stack_trials(trials)
    w = participant_weights(data["person"], people)
    counts = coverage(trials, rejected, people, missing)
    return trials, data, w, counts


def serialize_states(states):
    return {name: {key: value.tolist() if isinstance(value, np.ndarray) else value
                   for key, value in state.items()}
            for name, state in states.items()}


def replicate(args):
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    train, develop = manifest["train"], manifest["development"]
    train_people, train_missing = role_inventory(train)
    dev_people, dev_missing = role_inventory(develop)
    require(not set(train_people).intersection(dev_people), "TRAIN and DEV overlap")
    require(not args.output.exists(), "use a new output path")
    _, data, weights, train_counts = load_input(args.manifest.parent / train["slice"], train_people, train_missing)
    scales = shared_scales(data, weights)
    states = {name: fit_model(data, weights, scales, name)[0] for name in MODELS}
    trials, dev_data, _, dev_counts = load_input(args.manifest.parent / develop["slice"], dev_people, dev_missing)
    scores, _ = score(trials, dev_data, states)
    rotation = scores["rotation"]
    rotation["whole_trials_with_valid_clock"] = rotation["whole_trials_original"]
    rotation["whole_trials_original"] = dev_counts["original_trials"]
    rotation["whole_trials_declared_missing"] = dev_counts["declared_missing_trials"]
    rotation["whole_trials_rejected_phase_boundary"] = sum(dev_counts["trials_rejected_by_phase_boundary"].values())
    result = {"estimator": "locally fitted independent replication from user-supplied slices",
              "axes": list(AXES), "knots_seconds": KNOTS_S.tolist(), "ridge_l2": PENALTY,
              "models": serialize_states(states),
              "counts": {"train": train_counts, "development": dev_counts}, "scores": scores}
    with args.output.open("x", encoding="utf-8") as file:
        json.dump(result, file, sort_keys=True, indent=2, allow_nan=False)
        file.write("\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("output", type=Path, help="create a new output JSON")
    args = parser.parse_args()
    try:
        replicate(args)
    except (KeyError, TypeError, ValueError, OSError) as error:
        parser.error(str(error))


if __name__ == "__main__":
    main()
