"""The predeclared KIN-MUS UJI wrist-angle study for already admitted slices."""

from dataclasses import dataclass

import numpy as np


TICKS_PER_MS = 16
WINDOW = 750 * TICKS_PER_MS
HORIZON = 250 * TICKS_PER_MS
BIN_WIDTH = 500
BINS = 16
SPOTS = 7
TASKS = 26
KNOTS_S = np.array([0.5, 1, 2, 3.5, 5, 8, 12, 18, 27])
TIME_WIDTH = 1 + len(KNOTS_S)
EMG_WIDTH = BINS * SPOTS
PENALTY = 0.01
BOOT_SEED = 20261119
BOOT_DRAWS = 20_000
AXES = ("extension_deg", "radial_deviation_deg")
MODELS = {"mean": (False, False), "task_time": (True, False),
          "emg_only": (False, True), "task_time_emg": (True, True)}
REASONS = ("before_full_elapsed", "after_common_end", "nonfinite_target",
           "angle_gap", "short_bin", "raw_gap", "nonfinite_raw", "nonfinite_rms")


def require(condition, message):
    if not condition:
        raise ValueError(message)


@dataclass(frozen=True)
class Trial:
    person: int
    task: int
    anchor: np.ndarray
    t0: int
    phase: np.ndarray
    y: np.ndarray
    emg: np.ndarray
    audit: dict


class InvalidPhaseBoundary(ValueError):
    def __init__(self, reason, next_phase, difference_ms):
        super().__init__(reason)
        self.reason = reason
        self.next_phase = next_phase
        self.difference_ms = difference_ms


def clock_ticks(seconds):
    ms = np.asarray(seconds, dtype=np.float64) * 1000
    require(ms.ndim == 1 and len(ms) and np.all(np.isfinite(ms)), "invalid clock")
    nearest = np.rint(ms)
    require(np.all(np.abs(ms - nearest) <= 1e-6) and np.all(np.abs(nearest) < 2**40),
            "clock is outside the qualified integer-ms representation")
    ticks = nearest.astype(np.int64) * TICKS_PER_MS
    require(np.all(np.diff(ticks) > 0), "duplicate or backward source clock")
    return ticks


def angle_stream(records):
    parts = []
    for phase, (seconds, values) in enumerate(records, start=1):
        ticks = clock_ticks(seconds)
        values = np.asarray(values, dtype=np.float64)
        require(values.shape == (len(ticks), 2), "expected two original wrist coordinates")
        if parts:
            last_ticks, last_values, _ = parts[-1]
            if ticks[0] < last_ticks[-1]:
                raise InvalidPhaseBoundary("backward angle phase boundary", phase,
                                           int(ticks[0] - last_ticks[-1]) // TICKS_PER_MS)
            if ticks[0] == last_ticks[-1]:
                if not np.array_equal(values[0], last_values[-1], equal_nan=True):
                    raise InvalidPhaseBoundary("same-time angle phase boundary has conflicting values",
                                               phase, 0)
                ticks, values = ticks[1:], values[1:]
        if len(ticks):
            parts.append((ticks, values, np.full(len(ticks), phase, dtype=np.int8)))
    time, angles, phases = (np.concatenate(columns) for columns in zip(*parts, strict=True))
    return time, angles * np.array([-1.0, 1.0]), phases


def rms_history(raw_ticks, raw, target):
    """Exact (left, right] windows with independent sums in each bin."""
    edges = target[:, None] - WINDOW + BIN_WIDTH * np.arange(BINS + 1)
    limit = np.searchsorted(raw_ticks, edges, side="right")
    counts = np.diff(limit, axis=1)
    short = np.any(counts < 25, axis=1)
    start, end = limit[:, 0], limit[:, -1]
    gap_prefix = np.r_[0, np.cumsum(np.diff(raw_ticks) > 5 * TICKS_PER_MS)]
    last_sample = len(raw_ticks) - 1
    gap = gap_prefix[(end - 1).clip(0, last_sample)] > gap_prefix[start.clip(max=last_sample)]

    finite = np.all(np.isfinite(raw), axis=1)
    bad = np.r_[0, np.cumsum(~finite)]
    nonfinite = bad[end] != bad[start]
    with np.errstate(over="ignore", invalid="ignore"):
        power = np.square(raw)
        max_count = (BIN_WIDTH + TICKS_PER_MS - 1) // TICKS_PER_MS
        offset = np.arange(max_count)
        totals = np.empty((len(target), BINS, SPOTS))
        for b in range(BINS):
            first, after = limit[:, b:b + 2].T
            position = first[:, None] + offset
            gather = np.minimum(position, np.maximum(after[:, None] - 1, 0))
            valid = position < after[:, None]
            totals[:, b] = np.where(valid[:, :, None], power[gather], 0.0).sum(axis=1)
        rms = np.sqrt(totals / np.maximum(counts[:, :, None], 1))
    flat = rms.reshape(len(target), EMG_WIDTH)
    return flat, (short, gap, nonfinite, ~np.isfinite(flat).all(axis=1))


def build_trial(person, task, raw_record, angle_records):
    raw_seconds, raw = raw_record
    ticks = clock_ticks(raw_seconds)
    raw = np.asarray(raw, dtype=np.float64)
    require(raw.shape == (len(ticks), SPOTS), "expected the seven original EMG spots")
    angle_ticks, y, phase = angle_stream(angle_records)
    t0 = int(angle_ticks[0])
    row = np.arange(75, len(angle_ticks), 5)
    target = angle_ticks[row]
    before = target < t0 + WINDOW
    after = target > min(ticks[-1], angle_ticks[-1])
    nonfinite = ~np.isfinite(y[row]).all(axis=1)
    left = (np.searchsorted(angle_ticks, target - WINDOW, side="right") - 1).clip(min=0)
    gap_prefix = np.r_[0, np.cumsum(np.diff(angle_ticks) > 15 * TICKS_PER_MS)]
    angle_gap = gap_prefix[row] > gap_prefix[left]
    emg, rms_flags = rms_history(ticks, raw, target)
    flags = (before, after, nonfinite, angle_gap, *rms_flags)
    rejected = np.select(flags, np.arange(1, len(REASONS) + 1), default=0)
    keep = rejected == 0
    audit = {
        "source_angle_rows_by_phase": [len(a[0]) for a in angle_records],
        "merged_angle_rows": len(angle_ticks),
        "raw_rows": len(ticks),
        "raw_start_minus_angle_start_ms": (int(ticks[0]) - t0) // TICKS_PER_MS,
        "raw_end_minus_angle_end_ms": int(ticks[-1] - angle_ticks[-1]) // TICKS_PER_MS,
        "nominal_target_jitter_max_ms": (
            int(np.max(np.abs(target - t0 - row * 10 * TICKS_PER_MS))) // TICKS_PER_MS
            if len(row) else None
        ),
        "candidates_by_phase": np.bincount(phase[row], minlength=4)[1:].tolist(),
        "eligible_by_phase": np.bincount(phase[row][keep], minlength=4)[1:].tolist(),
        "excluded_first_reason": {name: int(np.sum(rejected == i))
                                  for i, name in enumerate(REASONS, start=1)},
        "flags_independent_counts": {name: int(flag.sum())
                                     for name, flag in zip(REASONS, flags, strict=True)},
    }
    return Trial(person, task, target[keep] - HORIZON, t0, phase[row][keep],
                 y[row][keep], emg[keep], audit)


def task_basis(elapsed_s):
    seconds = np.clip(elapsed_s, 0, 30)
    return np.column_stack((seconds, np.maximum(seconds[:, None] - KNOTS_S, 0)))


def stack_trials(trials):
    supported = [trial for trial in trials if len(trial.y)]
    require(bool(supported), "no eligible rows")
    values = [(np.full(len(trial.y), trial.person, dtype=np.int16),
               np.full(len(trial.y), trial.task, dtype=np.int8),
               trial.phase, trial.y, trial.emg,
               task_basis((trial.anchor - trial.t0) / (1000 * TICKS_PER_MS)))
              for trial in supported]
    return dict(zip(("person", "task", "phase", "y", "emg", "time"),
                    (np.concatenate(columns) for columns in zip(*values, strict=True)), strict=True))


def participant_weights(person, people):
    ids, inverse, counts = np.unique(person, return_inverse=True, return_counts=True)
    require(np.array_equal(ids, np.asarray(people)), "one or more admitted people lack eligible rows")
    return 1 / (len(people) * counts[inverse])


def population_scale(x, w):
    mu = w @ x
    scale = np.sqrt(w @ np.square(x - mu))
    # Exact constants can acquire epsilon-sized variance from the weighted sum.
    scale[x.max(axis=0) == x.min(axis=0)] = 0
    return scale


def shared_scales(data, weights):
    time = np.zeros((TASKS, TIME_WIDTH))
    for task in range(1, TASKS + 1):
        select = data["task"] == task
        if select.any():
            w, x = weights[select], data["time"][select]
            mu = w @ x
            variance = w @ np.square(x - mu) + weights[~select].sum() * mu**2
            time[task - 1] = np.sqrt(variance)
    return time, population_scale(data["emg"], weights)


def standardized(x, scale):
    return np.divide(x, scale, out=np.zeros_like(x), where=scale > 0)


def fit_model(data, w, scales, name):
    has_time, has_emg = MODELS[name]
    time_scale, emg_scale = scales
    n_time = TASKS * TIME_WIDTH if has_time else 0
    width = n_time + (EMG_WIDTH if has_emg else 0)
    normal = np.eye(width) * PENALTY
    cross = np.zeros((width, len(AXES)))
    groups = []
    emg_index = np.arange(n_time, width)
    for group in (range(1, TASKS + 1) if has_time else (0,)):
        use = data["task"] == group if has_time else np.ones(len(w), dtype=bool)
        require(use.any(), f"unidentified intercept for task {group}")
        y, weights = data["y"][use], w[use]
        mass = weights.sum()
        normalized = weights / mass
        cols = []
        indexes = []
        if has_time:
            cols.append(standardized(data["time"][use], time_scale[group - 1]))
            indexes.append(np.arange((group - 1) * TIME_WIDTH, group * TIME_WIDTH))
        if has_emg:
            cols.append(standardized(data["emg"][use], emg_scale))
            indexes.append(emg_index)
        index = np.concatenate(indexes) if indexes else np.empty(0, dtype=int)
        x = np.column_stack(cols) if cols else np.empty((len(y), 0))
        mx, my = normalized @ x, normalized @ y
        center = x - mx
        normal[np.ix_(index, index)] += center.T @ (weights[:, None] * center)
        cross[index] += center.T @ (weights[:, None] * (y - my))
        groups.append((index, mx, my))
    beta = np.linalg.solve(normal, cross) if width else cross
    intercept = np.array([my - mx @ beta[index] for index, mx, my in groups])
    model = {"name": name, "intercept": intercept, "time_scale": time_scale,
             "emg_scale": emg_scale, "time_beta": beta[:n_time], "emg_beta": beta[n_time:]}
    residual = predict(data, model) - data["y"]
    gradient_intercept = (np.array([w[data["task"] == i] @ residual[data["task"] == i]
                                    for i in range(1, TASKS + 1)]) if has_time else w @ residual)
    gradient_slopes = normal @ beta - cross
    audit = {"weighted_objective_by_axis": (w @ residual**2 + PENALTY * (beta**2).sum(axis=0)).tolist(),
             "max_abs_intercept_gradient_without_factor2": float(np.max(np.abs(gradient_intercept))),
             "max_abs_ridge_gradient_without_factor2": (float(np.max(np.abs(gradient_slopes)))
                                                        if width else 0.0),
             "normal_condition_number": float(np.linalg.cond(normal)) if width else None,
             "penalized_slope_slots": width,
             "nonzero_time_scales": int(np.count_nonzero(time_scale)) if has_time else 0,
             "nonzero_emg_scales": int(np.count_nonzero(emg_scale)) if has_emg else 0}
    require(all(np.isfinite(value).all() for value in (beta, intercept, gradient_intercept, gradient_slopes)),
            "nonfinite ridge solution")
    require(audit["max_abs_intercept_gradient_without_factor2"] <= 1e-9 and
            audit["max_abs_ridge_gradient_without_factor2"] <= 1e-9,
            "float64 solution fails the stationarity audit")
    return model, audit


def predict(data, state, emg=None):
    has_time, has_emg = MODELS[state["name"]]
    task = data["task"] - 1
    if has_time:
        time = standardized(data["time"], state["time_scale"][task])
        beta = state["time_beta"].reshape(TASKS, TIME_WIDTH, len(AXES))[task]
        pred = state["intercept"][task] + np.einsum("nk,nka->na", time, beta)
    else:
        pred = np.broadcast_to(state["intercept"], (len(task), len(AXES))).copy()
    if has_emg:
        if emg is None:
            emg = data["emg"]
        pred += standardized(emg, state["emg_scale"]) @ state["emg_beta"]
    return pred


def rotated_donors(supported_trials):
    donors = []
    offset = 0
    audit = []
    for trial in supported_trials:
        n = len(trial.anchor)
        row = np.arange(n)
        next_row = row + n // 2
        donor = next_row % n if n else next_row
        shift = (trial.anchor[donor] - trial.anchor) / TICKS_PER_MS
        eligible = n > 0 and np.all(np.abs(shift) >= 750)
        donors.append(donor + offset if eligible else np.full(n, -1))
        ranges = {}
        for key, mask in (("wrapped_ms", next_row >= n), ("unwrapped_ms", next_row < n)):
            ranges[key] = [float(shift[mask].min()), float(shift[mask].max())] if mask.any() else None
        audit.append({"person": trial.person, "task": trial.task, "eligible": bool(eligible),
                      "rows": n, **ranges})
        offset += n
    return np.concatenate(donors), audit


def summarize(e2, people):
    unique = np.unique(people)
    counts = [int(np.sum(people == p)) for p in unique]
    by_person = np.array([e2[people == p].mean(axis=0) for p in unique])
    by_axis = np.sqrt(by_person.mean(axis=0))
    return {"two_axis_rmse_deg": float(np.sqrt(by_person.mean())),
            "axis_rmse_deg": dict(zip(AXES, by_axis.tolist(), strict=True)),
            "mean_of_person_roots_deg": float(np.sqrt(by_person.mean(axis=1)).mean()),
            "pooled_two_axis_rmse_deg": float(np.sqrt(e2.mean())),
            "pooled_axis_rmse_deg": dict(zip(AXES, np.sqrt(e2.mean(axis=0)).tolist(), strict=True)),
            "people": len(unique), "rows": len(e2)}, by_person, unique, counts


def paired_scores(errors, people, left, right):
    if not len(people):
        return {"status": "no_eligible_rows", "people": 0, "rows": 0}, []
    results = {name: summarize(e2, people) for name, e2 in errors.items()}
    left_summary, a, identities, counts = results[left]
    right_summary, b, _, _ = results[right]
    rng = np.random.Generator(np.random.PCG64(BOOT_SEED))
    drawn = rng.integers(0, len(a), size=(BOOT_DRAWS, len(a)))
    sa, sb = a[drawn].mean(axis=1), b[drawn].mean(axis=1)
    both = np.sqrt(sa.mean(axis=1)) - np.sqrt(sb.mean(axis=1))
    axes = np.sqrt(sa) - np.sqrt(sb)
    q = np.quantile(np.column_stack((both, axes)), [0.025, 0.975], axis=0, method="linear")
    rows = [{"person": int(p), "rows": count,
             "mse_deg2": {name: result[1][i].tolist() for name, result in results.items()}}
            for i, (p, count) in enumerate(zip(identities, counts, strict=True))]
    axes_delta = {axis: left_summary["axis_rmse_deg"][axis] - right_summary["axis_rmse_deg"][axis]
                  for axis in AXES}
    return {"models": {name: result[0] for name, result in results.items()}, "left": left, "right": right,
            "two_axis_difference_deg": left_summary["two_axis_rmse_deg"] - right_summary["two_axis_rmse_deg"],
            "axis_difference_deg": axes_delta,
            "pooled_difference_deg": (left_summary["pooled_two_axis_rmse_deg"] -
                                      right_summary["pooled_two_axis_rmse_deg"]),
            "mean_of_person_roots_difference_deg": (left_summary["mean_of_person_roots_deg"] -
                                                     right_summary["mean_of_person_roots_deg"]),
            "exploratory_bootstrap_95_percent_deg": dict(zip(("two_axis", *AXES), q.T.tolist(), strict=True)),
            "people": len(a), "rows": len(people)}, rows
