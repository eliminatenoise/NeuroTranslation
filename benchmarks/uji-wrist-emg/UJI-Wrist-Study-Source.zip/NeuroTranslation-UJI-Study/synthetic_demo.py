"""Exercise the full fit and score on generated data with no source files."""

import json

import numpy as np

from portable_study import score
from uji_model import (MODELS, TASKS, build_trial, fit_model, participant_weights,
                       shared_scales, stack_trials)


def make_trial(rng, person, task, stop_ms):
    raw_ms = np.arange(-1, stop_ms)
    target_ms = np.arange(0, stop_ms + 1, 10)
    shifts = (person + np.arange(7)) / 5
    envelope = 1.0 + 0.8 * np.sin(raw_ms[:, None] / 180 + shifts)
    raw = envelope * rng.normal(size=(len(raw_ms), 7))
    slow = np.sin((target_ms - 500) / 180 + shifts[0])
    source_wrist = np.column_stack((-task - target_ms / 700 - 4 * slow,
                                    0.8 * task + target_ms / 500 + 2 * slow))
    a, b = len(target_ms) // 3, 2 * len(target_ms) // 3
    phases = [(target_ms[segment] / 1000, source_wrist[segment])
              for segment in (slice(None, a + 1), slice(a, b), slice(b, None))]
    return build_trial(person, task, (raw_ms / 1000, raw), phases)


def simulation(large=False):
    rng = np.random.Generator(np.random.PCG64(501))
    train = list(range(1, 15)) if large else [1, 2, 3]
    stop = 11_000 if large else 2700
    trials = [make_trial(rng, person, task, stop + 50 * person)
              for person in train for task in range(1, TASKS + 1)]
    data = stack_trials(trials)
    w = participant_weights(data["person"], train)
    scales = shared_scales(data, w)
    fit = {name: fit_model(data, w, scales, name)[0] for name in MODELS}
    unseen = [make_trial(rng, p, task, stop) for p in (15, 16) for task in range(1, TASKS + 1)]
    scores, _ = score(unseen, stack_trials(unseen), fit)
    return {"data": "synthetic example only; no human recordings or fitted human weights",
            "fit_rows": len(data["y"]), "score_rows": scores["primary"]["rows"],
            "primary": scores["primary"], "shift_control": scores["rotation"]}


if __name__ == "__main__":
    import argparse

    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--large", action="store_true", help="approximate the archive workload with generated data")
    sample = simulation(cli.parse_args().large)
    print(json.dumps(sample, sort_keys=True, indent=2, allow_nan=False))
