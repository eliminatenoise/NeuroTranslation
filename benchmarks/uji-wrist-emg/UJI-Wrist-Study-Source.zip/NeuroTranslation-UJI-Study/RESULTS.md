# Muscle activity helped predict extension

The wrist has two chances to prove the model wrong. Across four previously unseen development participants, historical forearm muscle activity lowered the combined error from 36.19° to 34.72°. That average hides a trade-off. Extension error fell by 2.42°, while radial-deviation error rose by 0.70°. Extension RMSE remained 46.36° in the paired model.

| Frozen primary models | Two-axis RMSE | Extension RMSE | Radial-deviation RMSE |
| --- | ---: | ---: | ---: |
| TRAIN mean | 37.56° | 50.33° | 16.97° |
| EMG alone | 35.03° | 46.61° | 16.81° |
| Task and elapsed time | 36.19° | 48.79° | 15.46° |
| Task, elapsed time and EMG | 34.72° | 46.36° | 16.16° |
| Task, elapsed time and EMG from the wrong time | 35.39° | 46.98° | 17.24° |

Both axes and all four people receive equal weight in the combined error. The paired model’s two-axis change was −1.468° (exploratory paired-person bootstrap interval −2.936° to −0.016°, 20,000 draws). The change was −1.368° when all rows received equal weight and −1.171° when we averaged each person’s RMSE. With four people, the apparent precision of a bootstrap endpoint can be misleading. Four separately reserved final-test participants remain sealed.

## What survives when the clock is wrong?

When we moved the EMG to a different time within each trial, the model’s two-axis error rose by 0.667° relative to aligned EMG. All 104 trials supported the rotation, with donor windows 1.20 to 13.50 s away. The rotated model still fell below the task/time error by 0.801°. That result keeps the interpretation narrow. Information present across a trial can help explain part of the gain, even with the local timing deliberately broken. Electrode or movement artifacts can contribute as well.

The source warns that its glove sensor can exaggerate extension in activities 7 and 11. Dropping both activities, with the same frozen predictions, changed the two-axis contrast to −1.455° across 18,438 windows. Extension again improved and radial deviation again worsened. The exploratory two-axis contrasts by archived movement phase were −3.311° for reaching (619 windows), −1.311° for manipulation (16,145) and −2.038° for release (3,309). All four development participants contributed to each phase. Phase labels describe results after fitting and never enter either model. [Source sensor notes](https://doi.org/10.1038/s41597-019-0285-1)

## What did the models see?

The training set had 14 people and 364 planned trials. One complete source trial was unavailable. We excluded four more from fitting when a phase timestamp ran backward. We kept 65,821 of 65,904 candidate timestamps from the other 359 trials. Of those candidates, 66 were outside the common record end, one lacked the initial 750 ms and 16 crossed a forward angle-clock gap greater than 15 ms. The development set had four different people and all 104 trials. Twenty-two of 20,095 candidate timestamps fell after the common record end, leaving 20,073 matched rows for every primary comparator. All models were frozen before these four people were scored.

This is an exploratory development result from a distinct Spanish cohort, separate from the earlier NeuroTranslation wrist-pointing studies. The error refers to archived, glove-derived angles with a participant-specific reference-posture zero and retrospective 5 Hz forward-backward filtering. A window that stops 250 ms early shows a cutoff in the archive clock. The offline comparison gives no live control or functional validation. Independent implementations matched the admitted rows and reproduced the reported metrics.

## The deployment estimator

The primary study’s exact weights and person-level records remain in custody. The separately fitted deployment estimator retained time terms supported by at least seven training participants. We fixed that rule before development scoring and evaluated it on the same 20,073 rows.

| Deployment models | Two-axis RMSE | Extension RMSE | Radial-deviation RMSE |
| --- | ---: | ---: | ---: |
| Task and elapsed time | 36.16° | 48.76° | 15.43° |
| Task, elapsed time and EMG | 34.70° | 46.35° | 16.13° |

The two-axis change was −1.465° (exploratory paired-person interval −2.936° to −0.005°). Dropping the two glove-warning activities gave −1.446°. The aligned model again beat its rotated counterpart by 0.678°. The same limits apply. Both versions were scored on these four people, so their agreement is a check on the feature-support decision within this sample. [Development aggregate](DEVELOPMENT-AGGREGATE.json)
