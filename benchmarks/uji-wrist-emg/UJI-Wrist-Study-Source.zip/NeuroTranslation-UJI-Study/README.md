# What does half a second of forearm activity tell us about the wrist?

Pick up a cup twice. The task name and the time since your hand started moving tell us where the wrist tends to be. They leave plenty of room for what your wrist actually does each time. The KIN-MUS UJI comparison asks whether seven recordings of muscle electrical activity from the forearm help close that gap for people the model has never seen.

Both models receive the archived task ID and time since the start of the published segment. The second also receives 500 ms of earlier muscle activity. The signals stop 250 ms before the target timestamp. The glove data were filtered forward and backward at 5 Hz, which means a target value can depend on motion after its own timestamp. The figures describe an offline comparison against those archived angles. They establish neither the latency of a live system nor the wrist angle a live controller would encounter. Surface EMG measures muscle electrical activity. It supplies no direct observation of nerve firing, and an association can include movement or electrical artifacts. [KIN-MUS UJI descriptor](https://doi.org/10.1038/s41597-019-0285-1)

Extension error fell. Radial-deviation error rose. See the [four-person development results](RESULTS.md) for the combined error, the deliberately mistimed EMG control and the separately fitted deployment estimator.

## Run one prediction

Install Python 3.11 or later and NumPy. The study ran on Python 3.13.15 and NumPy 2.4.6. Use `python -m pip install numpy` inside your own virtual environment. Open the launcher for your system, or run `python demo_inference.py`. The demo fits two small models to generated signals and predicts one window. It never opens any human recording or downloads a dependency.

| System | Launcher |
| --- | --- |
| Windows | `Run-UJI-Demo.cmd` |
| macOS | `Run-UJI-Demo.command` |
| Linux | `./run-uji-demo.sh` |

To apply a compatible checkpoint, run `python infer_uji.py model.json window.json`. Use `example-rms-window.json` to try a KIN-MUS UJI checkpoint with invented inputs. The examples exercise the calculation and carry no evidence of accuracy. Supply either precomputed RMS or raw samples in the window:

| Field | Required input |
| --- | --- |
| `task_id` | Integer 1 to 26, using the source's activity IDs |
| `elapsed_anchor_s` | Finite seconds from the start of the published segment to the history cutoff, at least 0.5. The calculated task/time basis caps this at 30 s. |
| `amplitude_scale` | Required `kin-mus-uji-v1.0-native-amplitude` for UJI checkpoints |
| `rms_bins` | In precomputed mode, 16 rows by 7 columns with finite nonnegative RMS values. Follow the exact order and history rules below. Precomputation must screen the original timestamp support. |
| `clock_ms_from_anchor` | In raw mode, strictly increasing integer milliseconds in `(−500, 0]`, with at least 25 points per bin and no observed gap above 5 ms |
| `emg` | In raw mode, one row per timestamp with seven raw amplitude values from the source spots in original order |

The runner checks transport format and numerical bounds. The amplitude-scale label is a declaration from the caller. The program has no way to identify a new device or verify how a precomputed feature was made. It runs locally and uploads no inputs or results.

The command emits the two estimated angle values for 250 ms after the cutoff. Positive values represent wrist extension and radial deviation, respectively, in degrees relative to the dataset’s individual reference posture. The source’s cited cross-person calibration validation excluded the two wrist sensors. It supplies no individual wrist-accuracy bound. The raw amplitude scale in the deposit has no verified voltage conversion, so a window in arbitrary device units or from a different electrode layout is outside the tested setting. [Source task IDs and recording procedure](https://doi.org/10.1038/s41597-019-0285-1)

Keep the study and deployable estimator separate when reading the results. The primary study retained all predeclared time terms. Some of those terms received data from only one or two training participants, so the primary weights remain in local custody. The separate deployment candidate used a training-only support rule of at least seven contributing people per included time term and was fitted before development scoring. Scores attributed to one estimator apply to that estimator alone.

## Repeat the method locally

Get the official 1.0 release at the source. Before fitting, use your own approved person split and assign one positive integer key to each person, unique across both roles. Keep all of a person’s tasks under that same key. Prepare one NPZ per role. The format uses `subject_XX_adl_YY_phase_P_time` for the one-dimensional seconds array and `subject_XX_adl_YY_phase_P_signal` for the matching observation rows. Here `XX` is your local subject key, padded to at least two digits, and `YY` is the source activity ID padded to two digits. Preserve each published timestamp and the sample order. Phase 0 comes from `RAW_EMG` and carries source spots 1 through 7. Phases 1–3 carry archived wrist columns 17 and 18 from `KIN_MUS_UJI`, in the original signs. The runner expects prepared NPZ files. Extraction from the original archive is a separate step. [KIN-MUS UJI v1.0 and deposit schema](https://doi.org/10.5281/zenodo.3469380)

Write a JSON manifest with `train` and `development` objects. Each object has `slice` (a path relative to the manifest), `people` (its ascending list of local keys between 1 and 32,767) and `missing_trials` (a list of `[local subject key, activity ID]` pairs). Use `[]` when the role has every planned trial. Declare genuinely unavailable whole trials before fitting and omit all eight arrays for each declared pair. The runner checks the actual array names against exactly the planned inventory minus those declarations. It rejects duplicates, undeclared omissions, partial trials and records supplied for a declared missing pair. The caller’s manifest records which source trials were unavailable. The runner verifies the inventory against that manifest and retains every planned trial in the denominator.

Run `python replicate_uji.py manifest.json local-result.json`. The output combines locally fitted states and aggregate DEV scores and reports the declared missing trial count per role. Treat the output as sensitive if it comes from human data. The original study’s participant mapping, recordings and primary checkpoints stay outside the package.

The implementation joins phases in their original order. It drops the second copy of an identical same-time boundary row and excludes a trial if the phase clock goes backward or if a same-time join has conflicting angles. A timestamp advances through the source timeline even when it jumps. A 15 ms gap criterion then applies to each candidate window independently. After joining, start with angle row 75 (zero-based) and advance five source rows at a time. Keep the actual timestamp `t`, check that it is at least 750 ms from the segment start and at or before both stream ends, then require finite targets and complete history. No interpolation or time warping occurs.

For each `t`, the EMG feature extractor computes the root mean square (RMS) in sixteen adjacent `(left, right]` bins across `(t−750 ms, t−250 ms]`. Each bin is 31.25 ms wide. For each spot, square the raw samples, average the squares, then take the square root. Order features by bin from oldest to newest and by spot within bin. The task/time model uses one unpenalized intercept per task, elapsed anchor time capped at 30 s, and elapsed-time hinges at 0.5, 1, 2, 3.5, 5, 8, 12, 18 and 27 s. A hinge contributes zero until its time and then increases linearly. The paired model uses the same task/time basis plus the 112 EMG features shared across tasks.

Each training participant gets the same total weight and each of their eligible rows gets an equal share. Divide a slope feature by its weighted training population standard deviation. Constant features contribute zero. Fit each wrist axis by minimizing weighted squared degree error plus `0.01 × sum(squared standardized slope coefficients)`. The strong comparison uses the same target rows for both models. Compute mean squared error per participant and axis, average over participants and axes, then take the square root. Subtract task/time RMSE from paired RMSE. A negative difference favors the paired model. The clock negative control rotates every eligible trial's EMG rows by half its row count, rounded down, and requires every donor timestamp to be at least 750 ms from its destination. It retains the original destination task, elapsed time and label.

## Source credit

Nestor Jarque-Bou, Margarita Vergara, Joaquín L. Sancho-Bru, Verónica Gracia-Ibáñez and Alba Roda-Sales, *A calibrated database of kinematics and EMG of the forearm and hand during activities of daily living*, KIN-MUS UJI v1.0, 2019. The original data deposit is licensed CC BY 4.0. NeuroTranslation selected the two wrist columns, changed the flexion angle sign, joined source times without resampling, derived historical EMG RMS features and fitted and evaluated paired ridge estimators. [Dataset](https://doi.org/10.5281/zenodo.3469380) · [Article](https://doi.org/10.1038/s41597-019-0285-1) · [License](https://creativecommons.org/licenses/by/4.0/)

The original NeuroTranslation project code uses CC0 1.0 Universal. [NeuroTranslation code license](https://github.com/eliminatenoise/NeuroTranslation/blob/51cb7a250c029af86c154b5c233c87fc69d1bc90/LICENSE)

Terminology follows Brain2Body glossary revision 36, SHA-256 `40b98695e6204bc9e305ecdea853756aec30f48a6ae67d29e92c8bb220b3e406`.
