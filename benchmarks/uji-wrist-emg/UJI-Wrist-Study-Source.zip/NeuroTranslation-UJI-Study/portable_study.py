"""The role-NPZ loading and scoring helpers from the frozen study.

Only independently prepared role slices are accepted by the public entrypoint.
"""

from collections import Counter
import hashlib

import numpy as np

from uji_model import (REASONS, TASKS, InvalidPhaseBoundary, build_trial, paired_scores,
                       predict, require, rotated_donors)

PHASES = {1: "reaching", 2: "manipulation", 3: "release"}


def input_trials(path, sha, people, missing_trials):
    trial_keys = [(person, task) for person in people for task in range(1, TASKS + 1)
                  if (person, task) not in missing_trials]
    keys = {f"subject_{person:02d}_adl_{task:02d}_phase_{phase}_{suffix}"
            for person, task in trial_keys for phase in range(4) for suffix in ("time", "signal")}
    with path.open("rb") as source:
        require(hashlib.file_digest(source, "sha256").hexdigest() == sha,
                "slice does not match the credited SHA-256")
        source.seek(0)
        with np.load(source, allow_pickle=False) as archive:
            observed = set(archive.files)
            require(len(archive.files) == len(observed), "NPZ contains duplicate array names")
            require(observed == keys, f"NPZ does not match the declared trial inventory "
                    f"({len(keys - observed)} required arrays absent, {len(observed - keys)} unexpected arrays)")
            trials = []
            rejected = []
            for person, task in trial_keys:
                name = f"subject_{person:02d}_adl_{task:02d}_phase_"
                records = [(archive[f"{name}{phase}_time"], archive[f"{name}{phase}_signal"])
                           for phase in range(4)]
                try:
                    trials.append(build_trial(person, task, records[0], records[1:]))
                except InvalidPhaseBoundary as error:
                    rejected.append({"person": person, "task": task, "reason": error.reason,
                                     "next_phase": error.next_phase, "difference_ms": error.difference_ms,
                                     "source_angle_rows_by_phase": [len(x[0]) for x in records[1:]],
                                     "raw_rows": len(records[0][0])})
                except ValueError as error:
                    raise ValueError(f"subject {person}, ADL {task}: {error}") from error
    return trials, rejected


def coverage(trials, rejected, people, missing_trials):
    supported = sum(bool(len(trial.y)) for trial in trials)
    result = {"assigned_people": len(people), "original_trials": len(people) * TASKS,
              "extracted_trials": len(trials) + len(rejected), "released_trials_used": len(trials),
              "trials_rejected_by_phase_boundary": dict(Counter(x["reason"] for x in rejected)),
              "trials_with_eligible_rows": supported,
              "declared_missing_trials": len(missing_trials),
              "original_phase_slots": len(people) * TASKS * len(PHASES),
              "candidates_by_phase": {}, "eligible_rows_by_phase": {},
              "trials_with_eligible_rows_by_phase": {}, "trials_with_phase_records": {},
              "excluded_first_reason": {name: 0 for name in REASONS},
              "flags_independent_counts": {name: 0 for name in REASONS}}
    require(result["original_trials"] == result["extracted_trials"] + result["declared_missing_trials"],
            "declared missing and observed trial counts do not reconcile")
    for phase, name in PHASES.items():
        i = phase - 1
        result["candidates_by_phase"][name] = sum(t.audit["candidates_by_phase"][i] for t in trials)
        result["eligible_rows_by_phase"][name] = sum(t.audit["eligible_by_phase"][i] for t in trials)
        result["trials_with_eligible_rows_by_phase"][name] = sum(
            bool(t.audit["eligible_by_phase"][i]) for t in trials)
        result["trials_with_phase_records"][name] = sum(
            bool(t.audit["source_angle_rows_by_phase"][i]) for t in trials) + sum(
            bool(t["source_angle_rows_by_phase"][i]) for t in rejected)
    for trial in trials:
        for key in ("excluded_first_reason", "flags_independent_counts"):
            for reason in REASONS:
                result[key][reason] += trial.audit[key][reason]
    for key in ("raw_start_minus_angle_start_ms", "raw_end_minus_angle_end_ms",
                "nominal_target_jitter_max_ms"):
        result[key] = dict(Counter(t.audit[key] for t in trials if t.audit[key] is not None))
    result["candidates"] = sum(result["candidates_by_phase"].values())
    result["eligible_rows"] = sum(result["eligible_rows_by_phase"].values())
    require(result["candidates"] == result["eligible_rows"] + sum(result["excluded_first_reason"].values()),
            "non-reconciling coverage counts")
    return result


def score(trials, data, states):
    left, right = "task_time_emg", "task_time"
    people, y = data["person"], data["y"]
    errors = {name: np.square(predict(data, state) - y) for name, state in states.items()}
    result, private = {}, {}

    def compare(name, mask):
        these = {key: e2[mask] for key, e2 in errors.items()}
        result[name], private[name] = paired_scores(these, people[mask], left, right)

    compare("primary", np.ones(len(y), dtype=bool))
    compare("glove_warning_drop_adl_7_11", ~np.isin(data["task"], [7, 11]))
    for phase, name in PHASES.items():
        compare(f"phase_{name}", data["phase"] == phase)

    donor, shifts = rotated_donors(trials)
    usable = donor >= 0
    selected = {key: value[usable] for key, value in data.items()}
    rotated = predict(selected, states[left], emg=data["emg"][donor[usable]])
    negative = "rotated_task_time_emg"
    common = {name: errors[name][usable] for name in (left, right)}
    common[negative] = np.square(rotated - y[usable])
    result["rotation"], private["rotation"] = paired_scores(common, people[usable], left, negative)
    keep = [entry for entry in shifts if entry["eligible"]]
    result["rotation"]["whole_trials_included"] = len(keep)
    result["rotation"]["whole_trials_original"] = len(trials)
    result["rotation"]["whole_trials_shift_too_short"] = sum(
        bool(entry["rows"]) and not entry["eligible"] for entry in shifts)
    result["rotation"]["whole_trials_without_eligible_rows"] = sum(not entry["rows"] for entry in shifts)
    for key in ("wrapped_ms", "unwrapped_ms"):
        bounds = [entry[key] for entry in keep if entry[key] is not None]
        result["rotation"][f"included_shift_range_{key}"] = (
            [min(lo for lo, _ in bounds), max(hi for _, hi in bounds)] if bounds else None)
    private["rotation_trials"] = shifts
    return result, private
