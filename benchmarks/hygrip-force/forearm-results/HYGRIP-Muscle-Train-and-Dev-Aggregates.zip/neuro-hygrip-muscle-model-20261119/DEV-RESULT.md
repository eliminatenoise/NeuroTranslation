# The EMG forecast improved on average. Shift the EMG and it improved again.

On the three previously studied HYGRIP development participants, adding aligned forearm EMG lowered mean participant error from **0.360 to 0.345 mV** for the 120 ms grip forecast. The model improved for one of the three people. Reassign the EMG to a different point in the same trial and mean error fell further, to **0.343 mV**. Aligned EMG lost that comparison for all three. The lower mean against the voltage-and-timing model therefore failed the prespecified test of an alignment-specific advantage. Adding aligned scalp EEG after EMG increased mean error to **0.474 mV**, with an increase for each participant. [Frozen method](FROZEN-SECONDARY-DESIGN.md), [DEV aggregate](DEV-RUN/AGGREGATES.json).

## A locked score on familiar participants

The thirteen ridge models were fitted on the seven eligible TRAIN participants. After locking the refits, we used the same three DEV participants previously scored in the primary EEG-only study. All 7,995 scheduled issues from 39 right-hand trials passed the full shared source and feature checks. Model settings stayed fixed. The reference measurements are signed released transducer voltages. Each person contributed equally to mean RMSE, each trial within that person equally, and each scored issue within that trial equally. [TRAIN result](TRAIN-RESULT.md), [prior primary development result](https://github.com/eliminatenoise/NeuroTranslation/tree/ba1171845af2245cd041188507c7c85cc0faed02/benchmarks/hygrip-force/results-2026-11-19).

| Forecast inputs | Mean participant RMSE (mV) |
| --- | ---: |
| Cue timing | 0.889869 |
| Last measured voltage | 0.516850 |
| Backward-slope forecast | 0.496622 |
| Recent voltage and cue timing | 0.360083 |
| Recent voltage, cue timing and aligned EEG | 0.461331 |
| Recent voltage, cue timing and aligned EMG | 0.345494 |
| Recent voltage, cue timing and phase-rotated EMG | 0.342696 |
| Recent voltage, cue timing, aligned EMG and aligned EEG | 0.473943 |

The fitted voltage-history comparisons share targets, recent voltage, cue timing, training rules and scored rows. Trial rotation uses the next matching right-hand trial at the same trial-relative time. Within-trial phase rotation uses the same trial's windows reindexed by ten scheduled steps, with wrap. Both rotations can use samples unavailable at the original issue. The earlier window ends 400 ms before the aligned end and does not overlap the aligned input. [Frozen method](FROZEN-SECONDARY-DESIGN.md).

| Candidate minus comparator | Mean change (mV) | Descriptive 95% interval (mV) | Improved / worsened |
| --- | ---: | ---: | ---: |
| Aligned EMG vs recent voltage and timing | −0.014589 | −0.120337 to +0.091160 | 1 / 2 |
| Aligned EMG vs trial-rotated EMG | −0.000076 | −0.004654 to +0.004501 | 2 / 1 |
| Aligned EMG vs phase-rotated EMG | +0.002798 | −0.001944 to +0.007541 | 0 / 3 |
| Aligned EMG vs earlier EMG | −0.000806 | −0.003472 to +0.001860 | 2 / 1 |
| Aligned EEG after EMG vs EMG alone | +0.128449 | −0.229092 to +0.485990 | 0 / 3 |
| Aligned EEG after EMG vs trial-rotated EEG after EMG | +0.028676 | −0.023509 to +0.080861 | 0 / 3 |
| Aligned EEG after EMG vs earlier EEG after EMG | +0.083155 | −0.339829 to +0.506138 | 2 / 1 |

All seven descriptive intervals cross zero. The exact two-sided sign test on three people cannot give a p-value below 0.25. The aggregate report includes every comparison, its raw and within-family adjusted sign-test values, and four task-phase strata. In the exploratory comparison, using four 100 ms EMG bins had nearly the same mean error as using one summary of the 400 ms window. [DEV aggregate](DEV-RUN/AGGREGATES.json).

## What carries forward

The model without EMG had the lower mean error in TRAIN. The opposite ordering in DEV did not survive the timing controls. EEG showed no consistent gain after EMG in either split. This experiment supplies no reliable directional evidence that the time-aligned electrophysiology improves a strong voltage-history and timing forecast in this paced right-hand task. The estimate is limited to the tested summaries and small observed samples, with three participants previously used in development and three FINAL participants reserved. It leaves open effects under other tasks and measurement conditions. [TRAIN result](TRAIN-RESULT.md), [DEV aggregate](DEV-RUN/AGGREGATES.json).

Forearm surface EMG records muscle electrical activity. The secondary benchmark uses released voltages, local device timestamps, and a fixed 20 ms guard. It measures no physical inter-device skew, filter phase or online lead time. Its four-channel analysis does not include a left-Go donor or compare the working arm with a nominally idle arm. The result establishes no calibrated newtons, specific peripheral nerve signals or cortical origin. [HYGRIP study](https://www.frontiersin.org/journals/neuroscience/articles/10.3389/fnins.2020.00919/full), [right-Go scope](RIGHT-GO-SCOPE.md).
