# Does forearm activity improve the grip forecast?

You can squeeze a transducer and read its voltage at this instant. Now hide the next 120 milliseconds. How much does the electrical activity recorded from your forearms tell a model that already has the cue schedule and the last 400 milliseconds of voltage? In the seven HYGRIP training folds, adding aligned surface EMG increased mean prediction error from **0.394 to 0.409 mV**. Adding aligned scalp EEG after EMG put it at **0.423 mV**. [HYGRIP study](https://www.frontiersin.org/journals/neuroscience/articles/10.3389/fnins.2020.00919/full), [frozen method](FROZEN-SECONDARY-DESIGN.md).

## Models on the same issues

All comparisons use 16,195 forecasts from 79 right-hand trials in seven previously qualified TRAIN participants. One of eight assigned participants remains excluded under the previously verified clock hold. That run accounted for 13 right-hand trials and 2,665 planned issues. On the eligible runs, every planned issue cleared the source and input-window checks and entered all branches. Participants contributed equally, as did trials within each participant and scored issues within each trial. We fit the original ridge model separately for each feature set, using the same five penalties and seven leave-one-participant-out folds to choose the penalty and calculate these errors. This gives a development estimate with selection optimism. [Aggregate record](TRAIN-RUN/AGGREGATES.json), [right-Go scope](RIGHT-GO-SCOPE.md).

| Forecast inputs | Mean participant RMSE (mV) |
| --- | ---: |
| Cue timing | 0.854152 |
| Last measured voltage | 0.531851 |
| Backward-slope forecast | 0.558423 |
| Recent voltage and cue timing | 0.393763 |
| Recent voltage, cue timing and aligned EEG | 0.417955 |
| Recent voltage, cue timing and aligned bilateral EMG | 0.409495 |
| Recent voltage, cue timing, aligned bilateral EMG and aligned EEG | 0.422863 |

The model with EMG saw all four release channels in four consecutive, past-only 100 ms bins. We compared it with EMG from the next same-hand trial at the same relative time in the cue schedule, EMG from the same trial reindexed to another scheduled issue, and an earlier nonoverlapping window. A second set of comparisons tested EEG with aligned EMG in every branch. The rotations test the use of concurrent information in this offline experiment. They can draw on later samples and would be unavailable to a live forecaster. [Frozen method](FROZEN-SECONDARY-DESIGN.md).

| Candidate minus comparator | Mean change (mV) | Descriptive 95% interval (mV) | Improved / worsened |
| --- | ---: | ---: | ---: |
| Aligned EMG vs recent voltage and timing | +0.015731 | −0.013073 to +0.044536 | 3 / 4 |
| Aligned EMG vs trial-rotated EMG | +0.000438 | −0.002314 to +0.003190 | 2 / 5 |
| Aligned EMG vs phase-rotated EMG | −0.000898 | −0.004614 to +0.002818 | 4 / 3 |
| Aligned EMG vs earlier EMG | +0.000250 | −0.001086 to +0.001586 | 4 / 3 |
| Aligned EEG after EMG vs EMG alone | +0.013369 | −0.029919 to +0.056656 | 2 / 5 |
| Aligned EEG after EMG vs trial-rotated EEG after EMG | +0.016816 | +0.003618 to +0.030014 | 1 / 6 |
| Aligned EEG after EMG vs earlier EEG after EMG | +0.001243 | −0.002838 to +0.005325 | 2 / 5 |

Both comparison families failed the frozen rule that all paired mean changes be negative. The exploratory whole-window EMG model had lower mean error than the four-bin EMG model by 0.000933 mV, with all seven signs in that direction. Its exact sign-test value was 0.015625 before and 0.0625 after within-family Holm adjustment. Overlapping training folds and selection limit the interpretation of the tests and intervals. The aggregate file includes all prespecified contrasts, signs, raw and adjusted sign-test values, phase counts and every tested penalty. [Aggregate record](TRAIN-RUN/AGGREGATES.json).

## What the experiment measures

During seated, cued grips, the transducer voltage already carries the movement's recent trajectory, while the cue supplies its schedule. With those two inputs, the tested surface EMG summaries supplied no consistent benefit at 120 ms in TRAIN. This estimate leaves room for participant-specific benefit and for other feature sets, horizons, tasks or recordings. The volunteer was instructed to grip with one hand. The nominal arm labels come from the publisher's analysis code, and assessing the same forearm during a left-hand trial needed a different data scope. This right-Go analysis yields no working-versus-nonworking-arm estimate. [HYGRIP study](https://www.frontiersin.org/journals/neuroscience/articles/10.3389/fnins.2020.00919/full), [right-Go scope](RIGHT-GO-SCOPE.md).

HYGRIP measures forearm electrical activity, scalp potentials and transducer voltage. The model uses device-local event alignment on released samples with a 20 ms guard before issue for EEG and EMG. Physical skew, release filter phase and live hardware latency were unmeasured. The results address offline voltage forecasting. They establish neither calibrated newtons nor causal or cortical attribution. The previously studied DEV positions and the reserved FINAL positions are outside this TRAIN outcome. [HYGRIP study](https://www.frontiersin.org/journals/neuroscience/articles/10.3389/fnins.2020.00919/full), [source qualification](../neuro-independent-force-census-20261119/SOURCE-QUALIFICATION.md).
