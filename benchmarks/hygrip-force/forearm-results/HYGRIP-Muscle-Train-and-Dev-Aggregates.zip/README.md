# HYGRIP muscle-activity forecast

This package records a secondary analysis of the healthy HYGRIP voltages. It tests whether forearm surface EMG improves on recent measured transducer voltage and scheduled cue timing when forecasting released voltage 120 ms ahead, then tests scalp EEG with aligned EMG already in the model. This is an offline ridge benchmark with two prespecified comparison families and separate exploratory comparisons. Read the report for each included split. [HYGRIP study](https://www.frontiersin.org/journals/neuroscience/articles/10.3389/fnins.2020.00919/full), [deposited study data](https://doi.org/10.6084/m9.figshare.12383639.v1).

Unzip this file to a directory you can read. Open the included `TRAIN-RESULT.md`, and `DEV-RESULT.md` if present, in the `neuro-hygrip-muscle-model-20261119` folder. Each links to the corresponding aggregate report. The JSON retains mean errors, confidence-interval calculations described in the study as descriptive, comparison signs, penalties where applicable, and person, trial and issue totals. Participant waveforms, participant-level scores, timestamps, and model coefficients remain in local custody. The original per-split aggregate digest binds the machine-local record.

From the unpacked package root, Python 3 can verify coverage arithmetic, model inventory, mean changes, interval consistency, sign-test calculations, within-family adjustment and penalty selection from the reported aggregates. Input source and independent numerical reproduction remain separate checks.

    python verify_aggregates.py neuro-hygrip-muscle-model-20261119/TRAIN-RUN/AGGREGATES.json

For a package that includes DEV, pass its `DEV-RUN/AGGREGATES.json` report as a second input. `SHA256SUMS` lists exact file content identities. The supporting method files preserve their original custody links, some of which require the original study workspace. The package is read-only. It requires no environment changes or connected account.

The original study is by Pablo Ortega, Tong Zhao and A. Aldo Faisal. The experimental aggregate package contains no original participant data and no publisher figures.
