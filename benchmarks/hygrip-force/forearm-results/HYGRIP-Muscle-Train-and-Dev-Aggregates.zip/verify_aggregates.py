"""Check a distributable report's coverage, branch arithmetic and multiplicity without source data."""

from math import comb, isclose, isfinite
import argparse
import json
from pathlib import Path


PHASES = {"00", "01", "10", "11"}
COUNTS = ("planned", "scored", "censored", "unscorable")
EXPECTED_FAMILIES = {
    "emg_increment": tuple(
        ("force_emg_aligned", baseline) for baseline in (
            "force_history", "force_emg_rotated", "force_emg_phase_rotated", "force_emg_earlier",
        )
    ),
    "eeg_after_emg": tuple(
        ("force_emg_eeg_aligned", baseline) for baseline in (
            "force_emg_aligned", "force_emg_eeg_rotated", "force_emg_eeg_earlier",
        )
    ),
    "exploratory": (
        ("force_eeg_aligned", "force_history"),
        ("force_eeg_aligned", "force_eeg_rotated"),
        ("force_eeg_aligned", "force_eeg_earlier"),
        ("force_emg_aligned", "force_emg_whole"),
    ),
}
EXPECTED_BRANCHES = {
    "persistence", "backward_slope", "timing", "force_history",
    "force_eeg_aligned", "force_eeg_rotated", "force_eeg_earlier",
    "force_emg_aligned", "force_emg_rotated", "force_emg_phase_rotated",
    "force_emg_earlier", "force_emg_whole",
    "force_emg_eeg_aligned", "force_emg_eeg_rotated", "force_emg_eeg_earlier",
}
ROW_KEYS = {"planned", "scored", "censored", "unscorable",
            "right_trials", "zero_scored_trials"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify_summary(report):
    require(report["target_units"] == "V" and report["forecast_horizon_ms"] == 120,
            "Result unit or horizon differs from the protocol")
    split = report["split"]
    expected = {"TRAIN": (7, 79, 16195), "DEV": (3, 39, 7995)}
    coverage = report["aggregate_coverage"]
    n = report["participant_count"]
    require((n, coverage["right_trials"], coverage["planned"]) == expected[split],
            "Unexpected people, trials or planned issues")
    require(set(coverage) == ROW_KEYS, "Out-of-scope row coverage fields")
    require(sum(coverage[key] for key in COUNTS[1:]) == coverage["planned"],
            "Coverage classes do not sum to planned")
    require(set(report["phase_coverage"]) == set(report["phase_error"]) == PHASES,
            "Wrong task-phase table keys")
    for key in COUNTS:
        require(sum(p[key] for p in report["phase_coverage"].values()) == coverage[key],
                "Task-phase counts do not reconcile with overall counts")
    for key, phase in report["phase_error"].items():
        require(phase["issues"] == report["phase_coverage"][key]["scored"]
                and phase["participants"] <= n and phase["trials"] <= coverage["right_trials"],
                "Phase denominator disagreement")
        require(set(phase["participant_mean_rmse_v"]) == EXPECTED_BRANCHES,
                "Phase branch inventory differs")

    metrics = report["participant_mean_rmse_v"]
    require(set(metrics) == EXPECTED_BRANCHES and all(isfinite(v) and v >= 0 for v in metrics.values()),
            "Unexpected score presence or RMSE")
    require(report["scope"]["arm_condition"] == "mapped_arm_comparisons_excluded",
            "Unexpected renamed or ineligible arm condition")
    require(set(report["comparison_families"]) == set(EXPECTED_FAMILIES),
            "Comparison family set differs")
    for name, expected_pairs in EXPECTED_FAMILIES.items():
        family = report["comparison_families"][name]
        comparisons = family["comparisons"]
        observed_pairs = tuple((row["candidate"], row["comparator"]) for row in comparisons)
        require(observed_pairs == expected_pairs, "Comparison pair inventory differs")
        count = len(expected_pairs)
        if name != "exploratory":
            require(family["directional_screen_cleared"] == all(row["mean_delta_v"] < 0 for row in comparisons),
                    "Directional screen does not match reported contrasts")
        for row in comparisons:
            expected_delta = metrics[row["candidate"]] - metrics[row["comparator"]]
            delta = row["mean_delta_v"]
            require(isclose(delta, expected_delta, rel_tol=1e-11, abs_tol=1e-16),
                    "Mean of paired differences disagrees with difference of means")
            observed = row["negative"] + row["positive"]
            require(observed == row["sign_test_n"] and observed + row["ties"] == n,
                    "Invalid participant signs or ties")
            smaller = min(row["negative"], row["positive"])
            p = min(1.0, 2 * sum(comb(observed, k) for k in range(smaller + 1)) / 2**observed) if observed else None
            require(p == row["sign_test_p"], "Incorrect raw sign test")
            lower, upper = row["descriptive_t95_v"]
            require(lower <= delta <= upper and isclose((upper + lower)/2, delta, abs_tol=1e-16),
                    "Descriptive interval is inconsistent with its mean")
        def raw(row):
            return row["sign_test_p"] if row["sign_test_p"] is not None else 1.0
        worst = 0
        for i, row in enumerate(sorted(comparisons, key=raw)):
            worst = max(worst, raw(row) * (count - i))
            require(min(1, worst) == row["sign_test_holm_within_family_p"],
                    "Incorrect within-family Holm adjustment")

    if split == "TRAIN":
        require(set(report["fit_grid"]) == EXPECTED_BRANCHES - {"persistence", "backward_slope"},
                "TRAIN refit branches differ")
        for fit in report["fit_grid"].values():
            alphas = {float(alpha): value for alpha, value in fit["grid_mean_participant_rmse_v"].items()}
            require(set(alphas) == {0.01, 0.1, 1.0, 10.0, 100.0}, "TRAIN alpha grid is different")
            require(fit["selected_alpha"] == min(alphas, key=lambda alpha: (alphas[alpha], -alpha)),
                    "TRAIN alpha selection did not minimize fold score with larger-penalty tie break")
    else:
        require("fit_grid" not in report, "DEV should have no model-selection table")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reports", type=Path, nargs="+")
    args = parser.parse_args()
    for path in args.reports:
        data = json.loads(path.read_bytes())
        verify_summary(data)
        print(path.name, data["split"], "aggregate checks passed")


if __name__ == "__main__":
    main()
