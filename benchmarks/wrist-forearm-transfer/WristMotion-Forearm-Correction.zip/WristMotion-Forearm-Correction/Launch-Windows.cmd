@echo off
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 (
  python portable.py %*
) else (
  py -3 portable.py %*
)
set "result=%errorlevel%"
if "%~1"=="" pause
exit /b %result%
