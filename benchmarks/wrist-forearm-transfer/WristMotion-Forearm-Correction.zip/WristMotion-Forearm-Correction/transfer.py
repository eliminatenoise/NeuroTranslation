"""Train and apply additive wrist-angle corrections in degree space."""

import numpy as np

METHODS = ("frozen_motion", "motion_correction", "motion_emg_correction", "rotated_emg_correction")
AXES = ("extension", "radial_deviation")
N_SLOTS = 6
PENALTY = 0.01
ARRAY_SHAPES = {
    "motion_center": (98,), "motion_scale": (98,), "emg_center": (64,), "emg_scale": (64,),
    "motion_coefficients": (104, 2), "emg_coefficients": (168, 2),
}
CONTRASTS = {
    "emg_minus_motion_correction": (METHODS[2], METHODS[1]),
    "motion_correction_minus_frozen": (METHODS[1], METHODS[0]),
    "emg_correction_minus_frozen": (METHODS[2], METHODS[0]),
    "aligned_minus_rotated_emg": (METHODS[2], METHODS[3]),
    "rotated_emg_minus_motion_correction": (METHODS[3], METHODS[1]),
}


def person_weights(people):
    _, indices, counts = np.unique(people, return_inverse=True, return_counts=True)
    return 1.0 / (len(counts) * counts[indices])


def standardizer(values):
    scale = values.std(axis=0)
    return values.mean(axis=0), np.where(scale == 0, 1.0, scale)


def matrices(motion, emg, slots, state):
    motion = (motion - state["motion_center"]) / state["motion_scale"]
    emg = (emg - state["emg_center"]) / state["emg_scale"]
    timing = np.eye(N_SLOTS)[slots]
    return np.column_stack((motion, timing)), np.column_stack((motion, emg, timing))


def solve(matrix, degrees, weights):
    weighted = weights[:, None] * matrix
    system = matrix.T @ weighted
    continuous = np.arange(matrix.shape[1] - N_SLOTS)
    system[continuous, continuous] += PENALTY
    rhs = weighted.T @ degrees
    factor = np.linalg.cholesky(system)
    coefficients = np.linalg.solve(factor.T, np.linalg.solve(factor, rhs))
    gradient = np.abs(system @ coefficients - rhs).max()
    if not np.isfinite(coefficients).all() or gradient > 1e-10:
        raise ValueError("The penalized least-squares stationarity check failed")
    return coefficients, float(gradient)


def validate_state(state):
    if set(state) != set(ARRAY_SHAPES):
        raise ValueError("Unexpected correction arrays")
    for name, shape in ARRAY_SHAPES.items():
        data = state[name]
        if data.shape != shape or data.dtype != np.float64 or not np.isfinite(data).all():
            raise ValueError(f"Invalid correction array: {name}")
        if name.endswith("_scale") and not (data > 0).all():
            raise ValueError(f"Invalid TRAIN standard deviation: {name}")


def fit(motion, emg, slots, people, base, target):
    motion_center, motion_scale = standardizer(motion)
    emg_center, emg_scale = standardizer(emg)
    state = {
        "motion_center": motion_center, "motion_scale": motion_scale,
        "emg_center": emg_center, "emg_scale": emg_scale,
    }
    weights, residual = person_weights(people), target - base
    motion_design, emg_design = matrices(motion, emg, slots, state)
    motion_beta, motion_gradient = solve(motion_design, residual, weights)
    emg_beta, emg_gradient = solve(emg_design, residual, weights)
    state.update(motion_coefficients=motion_beta, emg_coefficients=emg_beta)
    validate_state(state)
    return state, {"motion": motion_gradient, "motion_emg": emg_gradient}


def predict(motion, emg, slots, base, state, rotation=None):
    design_motion, design_emg = matrices(motion, emg, slots, state)
    result = {
        METHODS[0]: base,
        METHODS[1]: base + design_motion @ state["motion_coefficients"],
        METHODS[2]: base + design_emg @ state["emg_coefficients"],
    }
    if rotation is not None:
        rotated_design = design_emg.copy()
        emg_slice = slice(motion.shape[1], motion.shape[1] + emg.shape[1])
        rotated_design[:, emg_slice] = design_emg[rotation, emg_slice]
        result[METHODS[3]] = base + rotated_design @ state["emg_coefficients"]
    if not all(np.isfinite(value).all() for value in result.values()):
        raise ValueError("Nonfinite wrist predictions")
    return result
