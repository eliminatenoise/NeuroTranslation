# Can the forearm add to what the wrist already tells us?

The wrist was already moving. Our motion model had its last two angles, the half-second before them and the time since the pointing cue. It forecast the two angles a quarter of a second later on the archive clock with an error of 4.053°. We left that model frozen and asked whether electrical activity recorded at the skin of the forearm could help correct the forecast.

| Forecast | Two-axis RMSE | Extension RMSE | Radial deviation RMSE |
| --- | ---: | ---: | ---: |
| Frozen motion CNN ensemble | 4.053° | 5.098° | 2.622° |
| Motion correction | 3.957° | 4.947° | 2.615° |
| Motion and forearm EMG correction | 3.853° | 4.806° | 2.568° |
| Same correction with EMG moved to the next trial | 4.140° | 5.225° | 2.642° |

The matched addition of EMG lowered two-axis error by 0.104°. The reduction was 0.141° for extension and 0.047° for radial deviation, with lower error on both axes in each of the three development participants. Give the correction the forearm trace from the next trial in the same recording block, at the same time after the cue, and the advantage disappears. The motion input and the fitted coefficients stay fixed in that comparison. The aligned correction scored 0.287° lower than the rotated one.

The figures describe the same three healthy volunteers already evaluated in the earlier studies. Their 960 trials supplied 5,760 forecast rows with identical support across methods. Each person contributed equally to the root mean square error. Across the 27 ordered resamples of these same people, the descriptive 2.5th to 97.5th percentiles for the paired change were −0.142° to −0.057°. The three leave-one-person-out changes ranged from −0.125° to −0.072°. These ranges show what happens when we change the weight given to a few people. Six reserved test participants stayed sealed, and performance on other people or tasks remains open.

## Where the correction comes from

We froze three already trained motion CNNs and took the 32 activations just before each network’s output layer. One additive ridge regression saw those 96 numbers, the two latest measured angles and six timing indicators. The other saw all of that plus the amplitudes from four forearm electrode pairs in each of the 16 input bins. Both learned to predict the remaining angle error in degrees. Six other volunteers supplied 1,879 eligible training trials out of 1,880 recorded. A planned block lacked both source files and one recorded trial had invalid encoder support. We used only these training rows to centre and scale features and estimate the two correction matrices. The continuous predictor coefficients have a fixed ridge penalty of 0.01 on the participant-weighted squared error. Each timing coefficient is unpenalized.

For a target at archive row `t`, each head sees rows `t-383` through `t-128`, inclusive. Each motion feature is a 16-row mean encoder angle minus the corresponding angle at `t-128`. An EMG feature is the root mean square of the 16 row-by-row differences between the left and right signed channels within a pair. The pair order is M1, M2, M3, M4. The model uses no target direction or future input. Measured angles use positive extension and positive radial deviation.

Surface EMG tells us about electrical activity near the electrodes. Nearby muscles, motion and electrical contact can change what those electrodes pick up. The added predictive information is specific to the recorded task, timing and comparison above. The lead of 128 rows means 250 ms on the stored 512 Hz grid. The nominal encoder update rate was 100 Hz, and its repeated samples on the stored grid are retained. We did not measure acquisition latency, muscle force, a causal nerve pathway or closed-loop control. [Acquisition and ethics description](https://doi.org/10.1038/s41597-026-07287-z)

## Run the model offline

Extract the whole archive next to a local installation of Python 3.10 or newer. The runner uses only the Python standard library.

- Linux. Run `sh Launch-Linux.sh`.
- macOS. Run `sh Launch-macOS.command` in Terminal.
- Windows. Open `Launch-Windows.cmd` or run it in Command Prompt.

All three launch `portable.py` on 12 invented input windows. The runner checks all 72 output numbers against the original Python numerical runtime at an absolute tolerance of 0.00005°. Native Linux execution passed. macOS shell syntax and Windows script format were checked, with native execution on those two systems unverified.

`python3 portable.py --input input.json` accepts one JSON object. On Windows use `py -3 portable.py --input input.json`. Copy an `input` object from `SYNTHETIC-CASES.json` as a template. An input has four fields.

| Field | Shape and order |
| --- | --- |
| `target_offset_ticks` | One integer, 384, 512, 640, 768, 896 or 1024 ticks since the pointing cue |
| `anchor_deg` | Two angles in degrees at the last visible row, extension first |
| `motion_bins_deg_relative_to_anchor` | 16 earlier-to-later bins, two mean angles per bin relative to the last visible angles |
| `emg_differential_rms_uv` | 16 earlier-to-later bins, four differential RMS amplitudes in nominal archived microvolts, in M1–M4 order |

The three returned pairs are the frozen motion forecast, the forecast with the motion correction and the forecast with the motion and EMG correction. The rotated control requires a group of matched recorded trials, so the single-window runner shows the three unrotated predictions. Software checks on the invented examples do not measure forecast accuracy. Use the table above and `AGGREGATE.json` for measured errors.

## Inspect or reproduce the calculation

`MODEL.json` contains the three previously published motion CNNs and their original normalizers, the correction coefficients, and the training-only continuous-feature centres and scales. Its CNN states are little-endian float32, encoded as base64. Each layer's weight array precedes its bias. The two correction matrices are float64 in JSON and have shapes 104 × 2 and 168 × 2, with column order extension then radial deviation. Read `portable.py` for the full inference path from binned inputs. The scoring study used CPU PyTorch for the CNN layers. The portable implementation rounds layer outputs to float32 and can differ slightly in accumulation order.

`transfer.py` is the actual NumPy fitting and correction code. Its `fit` function takes the 98 continuous motion features (three 32-element activations in seed order 17, 29, 43, then two angles), 64 flattened EMG amplitudes (bin first, pair second), zero-based timing slots, participant group keys, the frozen forecasts and the measured targets in degrees. It returns the two coefficient matrices with their training-only scales. `DESIGN.json` records the analysis frozen before this attempt. `AGGREGATE.json` gives support, metrics and signed contrasts. The package runs from binned inputs and exposes the estimator. It does not contain participant recordings, row-level results or the task-local archive custody and score runner needed for an exact end-to-end replay. The original deposit is available separately under its own terms.

Data are from the EEG-EMG-WristMotion Dataset by Jorge German Perez Blanco and Javier Mauricio Anteliz Ortiz. This package derives forecasts and errors from the licensed recordings. [WristMotion v3 deposit](https://doi.org/10.6084/m9.figshare.29666735.v3) · [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) · [Scientific Data descriptor](https://doi.org/10.1038/s41597-026-07287-z)

Brain2Body glossary revision 36, SHA-256 `40b98695e6204bc9e305ecdea853756aec30f48a6ae67d29e92c8bb220b3e406`.
