Forecast a wrist turn

Extract the whole folder. Open index.html or the launcher for your computer.
Linux: sh Launch-Linux.sh. macOS: open Launch-macOS.command or run it in
Terminal. Windows: open Launch-Windows.cmd. Offline replay was verified
in Chromium on Linux; other browsers and native Windows/macOS launchers
have not been tested.

Choose an invented window set to explore three real trained models.
To see what a person's wrist actually did, select an original unmodified
development ZIP from the WristMotion v3 study. Keep the file zipped.
Choose a block (1–8), trial (1–40) and axis. Angle shows the recorded
value and the three forecasts. Forecast error shows forecast minus
measured angle. Use the table to read the exact plotted values.

The original file stays on your computer. The background reader checks it
against the study's source fingerprints. Clear recording or select an
invented set to erase it from the active view. Your browser needs a local
worker, Web Crypto and raw DEFLATE decompression for original ZIPs.
The desktop Python reader is available separately:
https://github.com/eliminatenoise/NeuroTranslation/tree/main/benchmarks/wrist-forearm-transfer

Jorge German Perez Blanco and Javier Mauricio Anteliz Ortiz, EEG-EMG-WristMotion
Dataset, version 3, https://doi.org/10.6084/m9.figshare.29666735.v3
CC BY 4.0, https://creativecommons.org/licenses/by/4.0/
NeuroTranslation derived the wrist angles and four differential EMG features,
fitted two output corrections and built this reader. The included licence
covers project-owned code. This download contains software and trained
parameters. You obtain the original measurements from the deposit.
