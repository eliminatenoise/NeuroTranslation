#!/bin/sh
set -eu
exec python3 -B "$(dirname "$0")/real_trial.py" "$@"
