@echo off
where py >nul 2>&1
if errorlevel 1 (
  python -B "%~dp0real_trial.py" %*
) else (
  py -3 -B "%~dp0real_trial.py" %*
)
set "result=%errorlevel%"
if "%~1"=="" pause
exit /b %result%
