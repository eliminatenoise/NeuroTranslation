"""Run the frozen WristMotion forecast and trained corrections without network access."""

import argparse
import base64
import json
import math
from pathlib import Path
import struct


DIRECTORY = Path(__file__).resolve().parent
TARGET_OFFSETS = (384, 512, 640, 768, 896, 1024)
METHODS = ("frozen_motion", "motion_correction", "motion_emg_correction")
SEEDS = ("17", "29", "43")


def read_json(filename):
    return json.loads(Path(filename).read_text(encoding="utf-8"))


def float32(value):
    return struct.unpack("<f", struct.pack("<f", value))[0]


def vector(values, expected_size):
    if not isinstance(values, list) or len(values) != expected_size:
        raise ValueError(f"Expected {expected_size} values")
    if any(type(value) not in (int, float) or not math.isfinite(value) for value in values):
        raise ValueError("Use finite numeric values")
    return values


def load_model():
    model = read_json(DIRECTORY / "MODEL.json")
    for seed in SEEDS:
        payload = base64.b64decode(model["models"][seed], validate=True)
        array = struct.unpack(f"<{len(payload) // 4}f", payload)
        if not all(math.isfinite(value) for value in array):
            raise ValueError("Invalid motion CNN state")
        start = 0
        layers = []
        for inputs, outputs, kernel in ((2, 16, 3), (16, 16, 3), (200, 32, 1), (32, 2, 1)):
            end = start + inputs * outputs * kernel
            stop = end + outputs
            layers.append((array[start:end], array[end:stop]))
            start = stop
        if start != len(array):
            raise ValueError("Unexpected motion CNN parameter count")
        model["models"][seed] = layers
    return model


def convolve_relu(signal, channels, size, layer):
    weights, biases = layer
    output_size = size - 2
    results = []
    for output, bias in enumerate(biases):
        for sample in range(output_size):
            value = float(bias)
            for channel in range(channels):
                start = channel * size + sample
                kernel = (output * channels + channel) * 3
                for tick in range(3):
                    value += signal[start + tick] * weights[kernel + tick]
            results.append(float32(max(value, 0.0)))
    return results


def affine(features, layer, relu=False):
    weights, biases = layer
    values = []
    for unit, bias in enumerate(biases):
        start = unit * len(features)
        value = bias + sum(x * y for x, y in zip(features, weights[start:start + len(features)]))
        values.append(float32(max(value, 0.0) if relu else value))
    return values


def standardize(values, center, scale):
    return [(value - origin) / width for value, origin, width in zip(values, center, scale, strict=True)]


def rms_emg(emg_uv):
    """Turn 256 rows of eight signed L/R surface-EMG values into a 16 x 4 RMS matrix."""
    if not isinstance(emg_uv, list) or len(emg_uv) != 256:
        raise ValueError("Use 256 EMG rows through the last visible input tick")
    rows = [vector(row, 8) for row in emg_uv]
    return [
        [
            math.sqrt(sum((float(row[2 * pair]) - float(row[2 * pair + 1])) ** 2
                          for row in rows[start:start + 16]) / 16)
            for pair in range(4)
        ]
        for start in range(0, 256, 16)
    ]


def predict(record, model):
    """Use one binned forecast window. Inputs are specified in README.md."""
    bins = record["motion_bins_deg_relative_to_anchor"]
    emg = record["emg_differential_rms_uv"]
    anchor = vector(record["anchor_deg"], 2)
    offset = record["target_offset_ticks"]
    if type(offset) is not int or offset not in TARGET_OFFSETS or len(bins) != 16 or len(emg) != 16:
        raise ValueError("Use 16 bins and one of the six supported cue offsets")
    bins = [vector(row, 2) for row in bins]
    emg = [value for row in emg for value in vector(row, 4)]
    if min(emg) < 0:
        raise ValueError("EMG root mean square values must be nonnegative")
    timing = [int(offset == target) for target in TARGET_OFFSETS]
    norm = model["frozen_normalization"]
    sequence = [
        float32((row[axis] - norm["bins_center"][axis]) / norm["bins_scale"][axis])
        for axis in range(2) for row in bins
    ]
    auxiliary = [float32(value) for value in standardize(anchor, norm["anchor_center"], norm["anchor_scale"])]
    auxiliary += timing

    latent, outputs = [], []
    for seed in SEEDS:
        conv1, conv2, dense, output = model["models"][seed]
        first = convolve_relu(sequence, 2, 16, conv1)
        second = convolve_relu(first, 16, 14, conv2)
        hidden = affine(second + auxiliary, dense, relu=True)
        standardized_residual = affine(hidden, output)
        degrees = [
            origin + z * scale + center
            for origin, z, scale, center in zip(anchor, standardized_residual, norm["residual_scale"],
                                                norm["residual_center"], strict=True)
        ]
        latent.extend(hidden)
        outputs.append(degrees)
    base = [sum(axis) / len(SEEDS) for axis in zip(*outputs)]
    parameters = model["correction_parameters"]
    shared = standardize(latent + anchor, parameters["motion_center"], parameters["motion_scale"])
    added = standardize(emg, parameters["emg_center"], parameters["emg_scale"])

    def correct(inputs, weights):
        return [
            base[axis] + math.fsum(value * row[axis] for value, row in zip(inputs, weights, strict=True))
            for axis in range(2)
        ]

    return {
        METHODS[0]: base,
        METHODS[1]: correct(shared + timing, parameters["motion_coefficients"]),
        METHODS[2]: correct(shared + added + timing, parameters["emg_coefficients"]),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, help="One JSON object having the binned-input schema in README.md")
    args = parser.parse_args()
    model = load_model()
    if args.input:
        print(json.dumps(predict(read_json(args.input), model), indent=2, allow_nan=False))
        return

    fixture = read_json(DIRECTORY / "SYNTHETIC-CASES.json")
    max_error = 0.0
    print("Synthetic examples. All inputs are invented.")
    print("Cue time     Frozen motion             Motion correction        Motion + EMG correction")
    print("                  Extension / radial deviation in degrees")
    for case in fixture["cases"]:
        inputs = case["input"]
        outputs = predict(inputs, model)
        for method in METHODS:
            for estimate, expected in zip(outputs[method], case["reference_deg"][method], strict=True):
                max_error = max(max_error, abs(estimate - expected))
        formatted = "      ".join(f"{a:8.3f} / {b:8.3f}" for a, b in outputs.values())
        print(f"{inputs['target_offset_ticks'] / 512:7.3f} s    {formatted}")
    if max_error > fixture["max_implementation_delta_deg"]:
        raise SystemExit(f"Synthetic reference mismatch: {max_error:.9g} degrees")
    print(f"Verified {len(fixture['cases'])} synthetic windows. Maximum implementation difference: {max_error:.3g} degrees.")
    print("These figures check the software. See AGGREGATE.json for errors against measured wrist angles.")


if __name__ == "__main__":
    main()
