# A wrist forecast has a measurement to answer to

Pick a recorded pointing trial. The right wrist turns on two encoder axes. At six times in that movement, you can compare what each model forecast with the angle the encoder recorded. Both models get the same earlier wrist readings and time after the cue. One also gets eight scalp EEG channels. The two forecasts and the measurement belong on the same plot.

This converter prepares one such trial for local playback in the NeuroTranslation wrist companion. Start with your own copy of an original version 3 development ZIP. The converter, format and fingerprints are included here. Get the recordings from the deposit and the weights from the [temporal wrist study](https://github.com/eliminatenoise/NeuroTranslation/tree/a95ae62ddcd51e87a3e97d4348a732ecb11dd052/benchmarks/wrist-pointing-temporal).

## Open the converter

Extract the entire ZIP. Use Python 3.11 or newer. Checking a packet against the supplied list uses standard Python. Creating a packet or regenerating it from source also needs NumPy 2, with 2.4.6 used for the reference build. Use your existing study environment if it already has NumPy.

- **Linux** · Run `./launch-linux.sh` in Terminal. Use `sh launch-linux.sh` if the ZIP extractor dropped executable permissions.
- **macOS** · Open `Launch-macOS.command` or run `sh Launch-macOS.command` in Terminal.
- **Windows** · Open `Launch-Windows.cmd` to see the commands, or run it with arguments from Command Prompt.

You can also run `python convert.py --help`. The launchers use the Python on your machine and perform all work offline. This edition was verified on Linux. The macOS and Windows launchers are supplied as source.

## Play a trial from the verified development study

Download one original ZIP from version 3 of the WristMotion deposit. For the first example, use [the official archive file 62570998](https://ndownloader.figshare.com/files/62570998) (38,005,702 bytes). Save the ZIP as it comes from Figshare. Pass its path as `--archive` and use an unused output name in a private folder.

```text
python convert.py make-archive --archive "downloaded.zip" --block 1 --trial 1 --output local-trial.json
python convert.py verify-archive --archive "downloaded.zip" --packet local-trial.json
python convert.py check --packet local-trial.json
```

Replace `downloaded.zip` with the saved filename. The converter verifies the ZIP’s bytes, locates the paired EEG and motion records for the selected task block and checks their hashes, clock and units. It decodes those two members locally and checks the completed packet against the fingerprint list. There is no download or extraction step in the converter.

The approved development ZIPs are the example above and Figshare files [62570821](https://ndownloader.figshare.com/files/62570821) and [62570890](https://ndownloader.figshare.com/files/62570890), all from [the v3 deposit](https://doi.org/10.6084/m9.figshare.29666735.v3). Task blocks 1 through 8 correspond to archive runs 03 through 10. Trial numbers 1 through 40 follow the movement cues in each block. Any trial without all six targets and their complete earlier input windows is rejected as a whole. The development release has 960 eligible trials across three people. Six other people’s test recordings remain sealed.

Open the local packet in the [wrist companion](https://eliminatenoise.github.io/NeuroTranslation/wrist-pointing/) to compare the two forecasts with the measured angles. The packet carries a compact set of actual derived EEG and encoder features and six measured angle pairs. It also carries a source-run fingerprint and clock positions that somebody with access to the source can link to the original run. Keep the packet and any recording-derived plot or screen capture private. The separate list contains only 960 SHA-256 commitments, with no participant labels or measurements. A holder of a matching packet can confirm that it belongs to the list.

### Use the original staged files

The study’s original staged `private/development/runs/MANIFEST.json` and its exact run NPZs support a second route. Check the manifest fingerprint in [SOURCE-PINS.json](SOURCE-PINS.json). If you have a locally restaged manifest with different bytes, use the official ZIP route above.

```text
python convert.py runs --manifest /path/to/private/development/runs/MANIFEST.json
python convert.py make --manifest /path/to/private/development/runs/MANIFEST.json --run 1 --trial 1 --output local-trial.json
python convert.py verify --manifest /path/to/private/development/runs/MANIFEST.json --packet local-trial.json
```

Run numbers 1 through 24 follow the fixed development manifest order. Trial numbers follow the same cues as the official ZIP route.

## What the comparison measures

The six targets are 0.75, 1.00, 1.25, 1.50, 1.75 and 2.00 seconds after the stored movement cue. The 512 Hz archive grid gives each forecast 256 earlier stored rows, with its last input 128 rows before the target. The two encoder axes report positive extension and positive radial deviation in degrees. The decoder retains the neutral midpoint and repeated encoder states. It excludes the raw-zero missing word and out-of-envelope values. No interpolation fills a rejected sample. EEG means retain the archive’s microvolt calibration.

The temporal models forecast two residual angles relative to the last observed two angles. Each uses the fixed training-only normalisation and the final checkpoints from seeds 17, 29 and 43. Reverse the residual normalisation and add the last measured angles before averaging the three predictions in degrees. For each of the resulting six angle pairs, the error is forecast minus measurement. Each axis’s RMSE is the square root of its mean squared error over six target times. The two-axis RMSE is the square root of the mean of all twelve squared errors. One packet’s error describes that movement. The published development statistic gives equal weight to people and trials within each person. The recorded trials favoured motion history and timing on the primary study contrast. [Frozen study and results](https://github.com/eliminatenoise/NeuroTranslation/tree/a95ae62ddcd51e87a3e97d4348a732ecb11dd052/benchmarks/wrist-pointing-temporal)

The encoder has a nominal 100 Hz update rate and repeated states are kept on the stored grid. The 250 ms input–target gap is on that grid. The physical acquisition lag, including the time between the encoder and the archive, is unbounded by this source. The angles come from one right-wrist pointing apparatus. The playback provides neither a third-axis trajectory nor live measurements. Scalp EEG can pick up movement, muscle and cue effects. A difference in forecast error under this protocol does not establish physiological lead, a clinical result or a unique brain signal for a movement.

## Source and format

Jorge German Perez Blanco and Javier Mauricio Anteliz Ortiz are credited on the [EEG-EMG-WristMotion Dataset v3](https://doi.org/10.6084/m9.figshare.29666735.v3), published under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). The original measurements and experimental setup are described in the [data descriptor](https://doi.org/10.1038/s41597-026-07287-z). The converter selects six times from one pointing trial, expresses the two device angles in degrees with positive extension and radial deviation, and averages the earlier readings into bins. The format records those transformations and pins the model inputs and checkpoints. [Packet format](FORMAT.md) · [Source fingerprints](SOURCE-PINS.json)

Brain2Body glossary revision 36, SHA-256 `40b98695e6204bc9e305ecdea853756aec30f48a6ae67d29e92c8bb220b3e406`.
