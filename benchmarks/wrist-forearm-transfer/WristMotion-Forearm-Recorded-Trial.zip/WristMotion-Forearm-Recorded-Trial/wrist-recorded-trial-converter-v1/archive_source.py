"""Read one frozen task block directly from a verified public WristMotion v3 ZIP."""

from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from zipfile import BadZipFile, ZipFile


RECIPE = Path(__file__).resolve().with_name("DEVELOPMENT-ARCHIVE-PINS.json")
RECIPE_SHA256 = "a0b4db26cd12926aa57a2797f766d0d7da27976cfa773168c56b6516755e1725"
BLOCKS_PER_ARCHIVE = 8


def verified_archive_bytes(path):
    recipe_raw = RECIPE.read_bytes()
    if sha256(recipe_raw).hexdigest() != RECIPE_SHA256:
        raise ValueError("The frozen public ZIP verification recipe changed")
    recipe = json.loads(recipe_raw)
    approved = {entry["bytes"]: entry for entry in recipe["archives"]}
    with path.open("rb") as stream:
        size = stream.seek(0, 2)
        entry = approved.get(size)
        if entry is None:
            raise ValueError("File size does not match an approved public development ZIP")
        stream.seek(0)
        raw = stream.read(size + 1)
    if len(raw) != size or sha256(raw).hexdigest() != entry["sha256"]:
        raise ValueError("ZIP bytes do not match an approved public development archive")
    return raw, entry["blocks"]


def select_block(blocks, block_number, expected_run_hash):
    if block_number is not None:
        if not 1 <= block_number <= BLOCKS_PER_ARCHIVE:
            raise ValueError("Task block number must be between 1 and 8")
        return block_number, blocks[block_number - 1]
    matched = [(ordinal, block) for ordinal, block in enumerate(blocks, 1)
               if block["sourceRunSha256"] == expected_run_hash]
    if len(matched) != 1:
        raise ValueError("The packet's source run does not belong to this verified public ZIP")
    return matched[0]


def read_block(path, *, block_number=None, expected_run_hash=None):
    raw, blocks = verified_archive_bytes(path)
    ordinal, pin = select_block(blocks, block_number, expected_run_hash)

    # Import only after authenticating the outer source file.
    from archive_features import (coordinate_data, decode_edf, read_dictionary,
                                  require_standard_header, trial_ticks, EEG, EMG, TASK_RUN_IDS)

    run_suffix = TASK_RUN_IDS[ordinal - 1]
    eeg_pattern = re.compile(rf"(sub-[0-9]{{2}})/eeg/\1_task-WristPointingTask_run-{run_suffix}_eeg\.edf")
    try:
        with ZipFile(BytesIO(raw)) as archive:
            names = archive.namelist()
            if len(names) != len(set(names)):
                raise ValueError("Duplicate ZIP member")
            matches = [match for name in names if (match := eeg_pattern.fullmatch(name))]
            if len(matches) != 1:
                raise ValueError("Expected one EDF for the selected task block")
            match = matches[0]
            alias = match.group(1)
            stem = f"{alias}_task-WristPointingTask"
            motion_stem = f"{alias}/motion/{stem}_tracksys-BiomechWrist"
            eeg_dict = read_dictionary(archive, f"{alias}/eeg/{stem}_channels.tsv")
            motion_dict = read_dictionary(archive, f"{motion_stem}_channels.tsv")
            verify_dictionaries(eeg_dict, motion_dict, EEG, EMG)
            edf = archive.read(match.group(0))
            tsv = archive.read(f"{motion_stem}_run-{run_suffix}_motion.tsv")
    except (BadZipFile, KeyError) as error:
        raise ValueError("The selected paired recording members cannot be read") from error

    if sha256(edf).hexdigest() != pin["edfSha256"] or sha256(tsv).hexdigest() != pin["tsvSha256"]:
        raise ValueError("Selected EEG or motion member changed")
    if require_standard_header(edf[:6144], len(edf)) != pin["edfHeaderSha256"]:
        raise ValueError("Selected EEG header changed")
    signal, _ = decode_edf(edf)
    markers = trial_ticks(signal)
    _, angle, valid = coordinate_data(tsv, signal)
    eeg = signal[:, :8].astype("float32")
    return eeg, angle, valid, markers, pin


def verify_dictionaries(eeg, motion, scalp_labels, emg_labels):
    received = [(row["name"], row["type"], row["units"]) for row in eeg]
    expected = [(label, "EEG", "microV") for label in scalp_labels]
    expected.extend((label, "EMG", "microV") for label in emg_labels)
    if received != expected:
        raise ValueError("Unexpected EEG channel labels, order or calibration units")

    coordinates = [(row["name"], row["tracked_point"], row["units"]) for row in motion]
    if coordinates != [("X", "RightWrist", "rad"), ("Y", "RightWrist", "rad")]:
        raise ValueError("Unexpected source motion channels or units")
