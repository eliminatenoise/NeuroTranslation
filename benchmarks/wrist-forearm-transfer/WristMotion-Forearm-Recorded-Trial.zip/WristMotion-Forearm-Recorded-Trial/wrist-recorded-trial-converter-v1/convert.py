"""Create and verify one wrist pointing trial from the frozen development archive staging."""

import argparse
import hashlib
import json
import os
from pathlib import Path
from math import isfinite
import re
import struct


HERE = Path(__file__).resolve().parent
SCHEMA = "wrist-recorded-trial.v1"
ROLE = "development"
DEPOSIT = "10.6084/m9.figshare.29666735.v3"
RATE = 512
OFFSETS = (384, 512, 640, 768, 896, 1024)
AXES = ("extension", "radial_deviation")
EEG_CHANNELS = ("C3", "C1", "Cz", "C2", "C4", "CP3", "CPz", "CP4")
CHANNELS = ("extension_relative_to_anchor", "radial_deviation_relative_to_anchor", *EEG_CHANNELS)
MANIFEST_SHA256 = "eb957afdefd86ede0072a327292ca7b51a123bf4c46d7ed295914d9d5097b92b"
ARCHIVES_SHA256 = "ca9193680afe9d0eabd578acbd1684f91699a6d2d94cef4e731cd9f767194862"
DESIGN_SHA256 = "69518d134127f762d7199f1fb64b28c471655f158d63bf8592199388af03ec35"
ROLE_FREEZE_SHA256 = "5ba02aa108cf9406dd48bcfa5576f50f3aae3d2ea033fda968a4de52c9fcea6b"
FIT_SEAL_SHA256 = "e888a96ddfa14e5ee3ec8788bdedede89da3b9646ca201ea9e99e21542788e8a"
CATALOGUE_FILENAME = "wrist-recorded-development-sha256.txt"
CATALOGUE_SHA256 = "2f6422705881398013b3245fb0d5fb4b0c5bb0528160c2325be8bdbc0286ff30"
RUN_COUNT = 24
TRIALS_PER_RUN = 40
PACKET_MAX_BYTES = 65536
RUN_FIELDS = ("eeg_uv", "angle_deg", "valid", "trial_start_tick", "cue_tick", "return_tick")
FIXED_SOURCE = {
    "depositDoi": DEPOSIT,
    "roleManifestSha256": MANIFEST_SHA256,
    "archiveManifestSha256": ARCHIVES_SHA256,
    "fitSealSha256": FIT_SEAL_SHA256,
    "designSha256": DESIGN_SHA256,
}
FIXED_PACKET = {
    "schema": SCHEMA,
    "role": ROLE,
    "sampleRateHz": RATE,
    "axisOrder": list(AXES),
    "channelOrder": list(CHANNELS),
}
SHA256_HEX = re.compile(r"[0-9a-f]{64}")


def read_digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def unique_keys(pairs):
    result = {}
    for name, value in pairs:
        if name in result:
            raise ValueError("Repeated JSON field")
        result[name] = value
    return result


def reject_constant(_value):
    raise ValueError("JSON numbers must be finite")


def read_json(raw):
    return json.loads(raw, object_pairs_hook=unique_keys, parse_constant=reject_constant)


def tick(value):
    return type(value) is int and 0 <= value < 2**32


def number(value):
    if type(value) not in (int, float):
        raise ValueError("A trial coordinate or feature is not numeric")
    value = float(value)
    if not isfinite(value):
        raise ValueError("A trial coordinate or feature is not finite")
    return value if value else 0.0


def vector(values, length):
    if not isinstance(values, list) or len(values) != length:
        raise ValueError("Invalid array dimensions in trial packet")
    return [number(value) for value in values]


def matrix(values, rows, columns):
    if not isinstance(values, list) or len(values) != rows:
        raise ValueError("Invalid array dimensions in trial packet")
    return [value for row in values for value in vector(row, columns)]


def content_digest(packet):
    """Validate every schema field and hash every measurement and provenance field."""
    expected = set(FIXED_PACKET) | {"source", "rows", "measuredDegrees", "contentSha256"}
    if not isinstance(packet, dict) or set(packet) != expected:
        raise ValueError("Wrong fields in trial packet")
    if any(packet[name] != value for name, value in FIXED_PACKET.items()):
        raise ValueError("Wrong packet schema, role, channel order, axis order or sample rate")
    if type(packet["sampleRateHz"]) is not int:
        raise ValueError("Sample rate must be an integer")

    source = packet["source"]
    source_fields = set(FIXED_SOURCE) | {"sourceRunSha256", "cueTick", "returnTick", "targetTicks"}
    if not isinstance(source, dict) or set(source) != source_fields:
        raise ValueError("Wrong fields in trial provenance")
    if any(source[name] != value for name, value in FIXED_SOURCE.items()):
        raise ValueError("Unknown archive, development role, study design or model seal")
    run_hash = source["sourceRunSha256"]
    if not isinstance(run_hash, str) or not SHA256_HEX.fullmatch(run_hash):
        raise ValueError("Invalid source run fingerprint")

    cue, returned, targets = source["cueTick"], source["returnTick"], source["targetTicks"]
    if not tick(cue) or not tick(returned) or not isinstance(targets, list):
        raise ValueError("Invalid archive clock")
    if targets != [cue + offset for offset in OFFSETS] or not all(map(tick, targets)) or returned <= targets[-1]:
        raise ValueError("Target times fall outside the frozen cue or return bounds")

    rows = packet["rows"]
    if not isinstance(rows, list) or len(rows) != len(OFFSETS):
        raise ValueError("Expected six complete forecast rows")
    values = []
    for offset, row in zip(OFFSETS, rows, strict=True):
        if not isinstance(row, dict) or set(row) != {"offsetSamples", "bins", "anchorDegrees"}:
            raise ValueError("Wrong fields in forecast row")
        if type(row["offsetSamples"]) is not int or row["offsetSamples"] != offset:
            raise ValueError("Invalid or reordered target offset")
        values.extend(vector(row["anchorDegrees"], len(AXES)))
        values.extend(matrix(row["bins"], 16, len(CHANNELS)))
    values.extend(matrix(packet["measuredDegrees"], len(OFFSETS), len(AXES)))

    prefix = "\n".join([
        SCHEMA, ROLE, str(RATE), ",".join(AXES), ",".join(CHANNELS),
        DEPOSIT, MANIFEST_SHA256, ARCHIVES_SHA256, run_hash, FIT_SEAL_SHA256, DESIGN_SHA256,
        str(cue), str(returned), ",".join(map(str, targets)), ",".join(map(str, OFFSETS)),
    ]) + "\n"
    return hashlib.sha256(prefix.encode("ascii") + struct.pack(f"<{len(values)}d", *values)).hexdigest()


def verify_integrity(packet):
    digest = content_digest(packet)
    if digest != packet["contentSha256"]:
        raise ValueError("Trial content does not match its stated fingerprint")
    return digest


def read_packet(path):
    with path.open("rb") as stream:
        raw = stream.read(PACKET_MAX_BYTES + 1)
    if len(raw) > PACKET_MAX_BYTES:
        raise ValueError("Trial packet exceeds 64 KiB")
    return read_json(raw.decode("utf-8"))


def verified_catalogue():
    contents = HERE.joinpath(CATALOGUE_FILENAME).read_bytes()
    if hashlib.sha256(contents).hexdigest() != CATALOGUE_SHA256:
        raise ValueError("Converter's reference fingerprint list changed")
    digests = contents.decode("ascii").splitlines()
    if len(digests) != RUN_COUNT * TRIALS_PER_RUN or digests != sorted(set(digests)):
        raise ValueError("Converter's reference list has an invalid denominator")
    return frozenset(digests)


def verified_development_manifest(path):
    # Bind the pathname and frozen bytes before exposing a run file to NumPy.
    suffix = ("private", ROLE, "runs", "MANIFEST.json")
    if path.is_symlink() or path.parts[-len(suffix):] != suffix:
        raise ValueError("Select the staged private/development/runs/MANIFEST.json")
    path = path.resolve(strict=True)
    if path.parts[-len(suffix):] != suffix:
        raise ValueError("The manifest path resolves outside the staged development role")
    with path.open("rb") as stream:
        raw = stream.read(65536)
        if stream.read(1):
            raise ValueError("Development manifest is larger than the frozen manifest")
    if hashlib.sha256(raw).hexdigest() != MANIFEST_SHA256:
        raise ValueError("Development manifest does not match the frozen source")
    manifest = read_json(raw)
    metadata = {
        "role": ROLE, "role_freeze_sha256": ROLE_FREEZE_SHA256, "deposit": DEPOSIT,
        "archive_manifest_sha256": ARCHIVES_SHA256, "sample_rate_hz": RATE,
        "eeg_order": list(EEG_CHANNELS), "eeg_units": "microvolts",
        "angle_columns_degrees": ["positive extension", "positive radial deviation"],
    }
    if any(manifest[name] != value for name, value in metadata.items()):
        raise ValueError("The frozen manifest clock, units or role do not match this converter")

    runs = [run for entry in manifest["participant_order"] for run in entry["runs"]]
    if len(runs) != RUN_COUNT or len({run["npz_sha256"] for run in runs}) != RUN_COUNT:
        raise ValueError("Frozen development run inventory is incomplete or ambiguous")
    return path.parent, runs


def load_verified_run(folder, run):
    # An immutable snapshot avoids validating one file version then parsing another.
    name = Path(run["npz"])
    if name.name != str(name):
        raise ValueError("Development manifest contains a path instead of a run filename")
    path = folder / name
    if path.is_symlink() or not path.is_file():
        raise ValueError("Selected frozen development run is missing locally")
    with path.open("rb") as stream:
        raw = stream.read(run["npz_bytes"] + 1)
    if len(raw) != run["npz_bytes"] or hashlib.sha256(raw).hexdigest() != run["npz_sha256"]:
        raise ValueError("Selected development run does not match the frozen source")

    limit_default_threads()
    from io import BytesIO
    import numpy as np

    with np.load(BytesIO(raw), allow_pickle=False) as data:
        eeg, angle, valid, starts, cues, returns = (data[field] for field in RUN_FIELDS)
    rows = feature_rows(eeg, angle, valid, starts, cues, returns, run["stored_rows"])
    return rows, cues, returns


def limit_default_threads():
    # The original CPU feature operations need no extra BLAS workers. Respect
    # explicit settings in the existing study environment.
    for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "BLIS_NUM_THREADS"):
        os.environ.setdefault(variable, "1")


def feature_rows(eeg, angle, valid, starts, cues, returns, stored_rows):
    from features import featurize, validate_run

    validate_run(eeg, angle, valid, starts, cues, returns, stored_rows)
    rows, _ = featurize(eeg, angle, valid, cues, returns, ROLE, 0)
    return rows


def packet_from_run(rows, cues, returns, run_hash, trial):
    match = rows.trial == trial - 1
    if not match.any():
        raise ValueError("That source trial lacks a complete set of six eligible target windows")
    cue = int(cues[trial - 1])
    source = FIXED_SOURCE | {
        "sourceRunSha256": run_hash,
        "cueTick": cue, "returnTick": int(returns[trial - 1]),
        "targetTicks": [cue + offset for offset in OFFSETS],
    }
    packet = FIXED_PACKET | {
        "source": source,
        "rows": [
            {"offsetSamples": offset, "bins": bins.tolist(), "anchorDegrees": anchor.tolist()}
            for offset, bins, anchor in zip(OFFSETS, rows.bins[match], rows.anchor[match], strict=True)
        ],
        "measuredDegrees": rows.target[match].tolist(),
        "contentSha256": None,
    }
    packet["contentSha256"] = content_digest(packet)
    return packet


def save_packet(path, packet):
    raw = (json.dumps(packet, allow_nan=False, separators=(",", ":")) + "\n").encode("utf-8")
    descriptor = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(raw)
    except BaseException:
        path.unlink(missing_ok=True)
        raise


def check_catalogue(digest):
    if digest not in verified_catalogue():
        raise ValueError("Trial is absent from the frozen development commitment list")


def matching_source_trial(folder, runs, packet):
    source = packet["source"]
    run = next((entry for entry in runs if entry["npz_sha256"] == source["sourceRunSha256"]), None)
    if run is None:
        raise ValueError("Packet run is absent from the frozen development manifest")
    rows, cues, returns = load_verified_run(folder, run)
    trial_index = trial_at_cue(cues, source["cueTick"])
    return packet_from_run(rows, cues, returns, run["npz_sha256"], trial_index)


def trial_at_cue(cues, cue_tick):
    trial_index = next((index for index, cue in enumerate(cues, 1) if cue == cue_tick), None)
    if trial_index is None:
        raise ValueError("Packet cue is absent from the selected source run")
    return trial_index


def packet_from_archive(path, block=None, trial=None, packet=None):
    limit_default_threads()
    from archive_source import read_block

    expected_run = packet["source"]["sourceRunSha256"] if packet is not None else None
    eeg, angle, valid, markers, pin = read_block(path, block_number=block, expected_run_hash=expected_run)
    starts, cues, returns = (values.astype("int64", copy=False) for values in markers)
    rows = feature_rows(eeg, angle, valid, starts, cues, returns, pin["storedRows"])
    if packet is not None:
        trial = trial_at_cue(cues, packet["source"]["cueTick"])
    return packet_from_run(rows, cues, returns, pin["sourceRunSha256"], trial)


def parser():
    cli = argparse.ArgumentParser(description=__doc__)
    actions = cli.add_subparsers(dest="action", required=True)
    runs = actions.add_parser("runs", help="show the numbered choices without participant aliases")
    make = actions.add_parser("make", help="create a private packet from one frozen development pointing trial")
    verify = actions.add_parser("verify", help="regenerate a packet from its original staged source and compare")
    check = actions.add_parser("check", help="verify packet membership against the bundled commitments")
    make_archive = actions.add_parser("make-archive", help="prepare one trial directly from an official public development ZIP")
    verify_archive = actions.add_parser("verify-archive", help="regenerate a packet from its official public ZIP and compare")
    for action in (runs, make, verify):
        action.add_argument("--manifest", required=True, type=Path)
    for action in (make_archive, verify_archive):
        action.add_argument("--archive", required=True, type=Path)
    for action in (check, verify, verify_archive):
        action.add_argument("--packet", required=True, type=Path)
    make.add_argument("--run", required=True, type=int, metavar="1..24")
    make_archive.add_argument("--block", required=True, type=int, metavar="1..8")
    for action in (make, make_archive):
        action.add_argument("--trial", required=True, type=int, metavar="1..40")
        action.add_argument("--output", required=True, type=Path)
    return cli


def run_action(args):
    if args.action == "check":
        check_catalogue(verify_integrity(read_packet(args.packet)))
        print("Matches a frozen development commitment.")
        return
    if args.action in ("make-archive", "verify-archive"):
        run_archive_action(args)
        return

    folder, runs = verified_development_manifest(args.manifest)
    if args.action == "runs":
        print("Development run numbers 1 to 24. Source trial numbers 1 to 40 per run.")
    elif args.action == "make":
        if not (1 <= args.run <= len(runs) and 1 <= args.trial <= TRIALS_PER_RUN):
            raise ValueError("Run or trial number falls outside the frozen source")
        run = runs[args.run - 1]
        rows, cues, returns = load_verified_run(folder, run)
        packet = packet_from_run(rows, cues, returns, run["npz_sha256"], args.trial)
        check_catalogue(packet["contentSha256"])
        save_packet(args.output, packet)
        print("Created one private packet checked against the frozen development source.")
    elif args.action == "verify":
        packet = read_packet(args.packet)
        digest = verify_integrity(packet)
        check_catalogue(digest)
        original = matching_source_trial(folder, runs, packet)
        if original["contentSha256"] != digest:
            raise ValueError("Packet differs from the trial regenerated from its frozen development source")
        print("Packet matches the original frozen development trial.")


def run_archive_action(args):
    if args.action == "make-archive":
        if not 1 <= args.block <= 8 or not 1 <= args.trial <= TRIALS_PER_RUN:
            raise ValueError("Task block or trial number falls outside the frozen source")
        packet = packet_from_archive(args.archive, block=args.block, trial=args.trial)
        check_catalogue(packet["contentSha256"])
        save_packet(args.output, packet)
        print("Created one private packet checked against the official development ZIP.")
    else:
        packet = read_packet(args.packet)
        digest = verify_integrity(packet)
        check_catalogue(digest)
        original = packet_from_archive(args.archive, packet=packet)
        if original["contentSha256"] != digest:
            raise ValueError("Packet differs from the trial regenerated from its official public ZIP")
        print("Packet matches the original trial in the official development ZIP.")


def main():
    cli = parser()
    try:
        run_action(cli.parse_args())
    except FileExistsError:
        cli.exit(1, "Choose an unused output filename. The existing file was preserved.\n")
    except ModuleNotFoundError as error:
        cli.exit(1, f"Missing {error.name}. See README.md for the local dependency.\n")
    except FileNotFoundError:
        cli.exit(1, "A required input path is missing. Check the selected manifest or packet.\n")
    except (KeyError, TypeError, OverflowError, RecursionError, OSError, ValueError) as error:
        # JSON syntax and semantic errors omit source aliases and local paths.
        message = str(error) if type(error) is ValueError else "Unreadable packet or frozen input"
        cli.exit(1, f"{message}\n")


if __name__ == "__main__":
    main()
