#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
if [ "$#" -eq 0 ]; then
    set -- --help
fi
exec "${WRIST_PYTHON:-python3}" -B convert.py "$@"
