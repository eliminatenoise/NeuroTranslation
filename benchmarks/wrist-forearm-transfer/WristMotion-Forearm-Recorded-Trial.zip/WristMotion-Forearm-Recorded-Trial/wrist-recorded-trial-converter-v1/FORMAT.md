# Wrist trial packet version 1

A UTF-8 JSON packet holds one complete trial from the fixed WristMotion v3 development split. Its maximum file size is 64 KiB. Property order and whitespace can change. The record has these fields.

| Field | Value |
| --- | --- |
| `schema` | `wrist-recorded-trial.v1` |
| `role` | `development` |
| `sampleRateHz` | Integer `512` |
| `axisOrder` | `["extension","radial_deviation"]` |
| `channelOrder` | `["extension_relative_to_anchor","radial_deviation_relative_to_anchor","C3","C1","Cz","C2","C4","CP3","CPz","CP4"]` |
| `source` | One object with the fields below |
| `rows` | Six ordered input objects with fields `offsetSamples`, `bins`, `anchorDegrees` |
| `measuredDegrees` | Six measured target rows, two angles each in axis order |
| `contentSha256` | Lowercase, 64-character fingerprint of the canonical bytes below |

`source` contains `depositDoi`, `roleManifestSha256`, `archiveManifestSha256`, `sourceRunSha256`, `fitSealSha256`, `designSha256`, `cueTick`, `returnTick` and `targetTicks`. The checksum fields are lowercase hexadecimal. Each index is a run-local unsigned 32-bit integer. The six target ticks equal the cue tick plus the six ordered offsets 384, 512, 640, 768, 896 and 1024. They precede the return tick. The source-run fingerprint identifies the verified staged NPZ. The deposit and all fixed edition fingerprints are in [SOURCE-PINS.json](SOURCE-PINS.json).

At target tick `t`, the 16 consecutive bins cover `t−383` through `t−128` inclusive, with 16 original rows per bin. Each bin has 10 columns. The first two are the mean encoder angles minus the absolute two-axis anchor at `t−128`. The other eight are mean EEG samples in the declared channel order, accumulated in float64 from the staged float32 microvolt samples. The input window marks and the target must all fall in the same movement segment `[cueTick, returnTick)`. Both the source mask and finite observations must qualify the entire trial. The packet does not carry raw windows, task direction or EMG. The same six elapsed-time flags and absolute anchors complement the bins in both models.

`anchorDegrees` has the two absolute angles in axis order. The motion head takes only the first two columns of the bins. The combined head takes all ten. Measured target angles stay in the separate `measuredDegrees` array for scoring. Reject shape changes, unfamiliar fields, repeated JSON keys, out-of-order offsets, mismatched clocks and nonfinite numeric values. Integer fields are written as decimal JSON integers.

## Canonical fingerprint

Append one LF byte to each of the following fields in order. Encode them as ASCII. For arrays in this prefix, join values with a comma and no spaces. Write integers in unsigned decimal without leading zeros.

```text
schema
role
sampleRateHz
axisOrder
channelOrder
source.depositDoi
source.roleManifestSha256
source.archiveManifestSha256
source.sourceRunSha256
source.fitSealSha256
source.designSha256
source.cueTick
source.returnTick
source.targetTicks
rows[*].offsetSamples
```

After the prefix, write 984 IEEE-754 binary64 values in little-endian order. Write each row’s two `anchorDegrees`, then its 16 × 10 bins in row-major order. Once all six input rows are written, append `measuredDegrees` in row-major order. Canonicalise negative zero to positive zero. The SHA-256 of the prefix and 7,872-byte numeric tail is `contentSha256`. File formatting and the stated `contentSha256` are outside the hash input.

Compute the digest and check it against the supplied value **and** against the separately pinned list. The list is exactly 960 sorted, distinct, lower-case hex digests with one LF after each digest, including the last. Its SHA-256 is in [SOURCE-PINS.json](SOURCE-PINS.json). A packet with a newly computed digest can pass a consistency check on its own bytes. It earns the development label only if the digest is also in the fixed list. Given the staged manifest and run, `verify` additionally regenerates the whole packet from source.
