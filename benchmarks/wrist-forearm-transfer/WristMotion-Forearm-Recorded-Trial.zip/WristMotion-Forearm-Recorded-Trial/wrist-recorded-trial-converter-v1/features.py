"""Exact wrist forecasting feature primitives extracted from the frozen forecast.py.

Original source SHA-256: 98ab07e87e626450e634b9aaadfbc9fe9ea3313793be1a033c97967843eb0198
"""

from dataclasses import dataclass

import numpy as np


OFFSETS = np.array([384, 512, 640, 768, 896, 1024])

CHANNELS = ("C3", "C1", "Cz", "C2", "C4", "CP3", "CPz", "CP4")

AXES = ("extension", "radial_deviation")

HISTORY_ROWS = np.arange(-383, -127)

ANCHOR_LEAD = 128

VELOCITY_INTERVAL = 64

NUM_BINS = 16

DENOMINATOR_TRIALS_PER_RUN = 40

@dataclass(frozen=True)
class Rows:
    bins: np.ndarray
    anchor: np.ndarray
    past: np.ndarray
    target: np.ndarray
    offset: np.ndarray
    subject: np.ndarray
    block: np.ndarray
    trial: np.ndarray

    @property
    def residual(self):
        return self.target - self.anchor

    @property
    def timing_flags(self):
        return np.eye(len(OFFSETS), dtype=np.float64)[self.offset]

    @classmethod
    def combine(cls, runs):
        return cls(**{
            name: np.concatenate([getattr(run, name) for run in runs])
            for name in cls.__dataclass_fields__
        })

def validate_run(eeg, angle, valid, starts, cues, returns, n_rows):
    if eeg.dtype != np.float32 or eeg.shape != (n_rows, len(CHANNELS)):
        raise ValueError("Invalid EEG array")
    if angle.dtype != np.float64 or angle.shape != (n_rows, len(AXES)):
        raise ValueError("Invalid encoder angle array")
    if valid.dtype != np.bool_ or valid.shape != angle.shape:
        raise ValueError("Invalid encoder eligibility mask")
    if not np.all(np.isfinite(angle[valid])) or not np.all(np.isnan(angle[~valid])):
        raise ValueError("Encoder validity mask disagrees with decoded data")
    for ticks in (starts, cues, returns):
        if ticks.dtype != np.int64 or ticks.shape != (DENOMINATOR_TRIALS_PER_RUN,):
            raise ValueError("Invalid marker dtype or source count")
        if not np.all((0 <= ticks) & (ticks < n_rows)) or np.any(np.diff(ticks) <= 0):
            raise ValueError("Out-of-range or non-monotonic run-local markers")
    if not np.all((starts < cues) & (cues < returns)) or not np.all(returns[:-1] < starts[1:]):
        raise ValueError("Nonsequential or overlapping source trials")

def featurize(eeg, angle, valid, cues, returns, subject, block):
    targets = cues[:, None] + OFFSETS
    support = targets[:, :, None] + HISTORY_ROWS
    bounded = ((support[:, :, 0] >= cues[:, None]) &
               (targets < returns[:, None]) & (targets < len(angle))).all(axis=1)
    bounded_ids = np.flatnonzero(bounded)
    t = targets[bounded_ids]
    support = support[bounded_ids]
    encoder_ok = valid[t].all(axis=(1, 2)) & valid[support].all(axis=(1, 2, 3))
    eeg_ok = np.isfinite(eeg[support]).all(axis=(1, 2, 3))
    keep = encoder_ok & eeg_ok
    t, support, trials = t[keep], support[keep], bounded_ids[keep]
    flattened = t.ravel()
    support = support.reshape(len(flattened), len(HISTORY_ROWS))
    anchor = angle[flattened - ANCHOR_LEAD]
    past = angle[flattened - ANCHOR_LEAD - VELOCITY_INTERVAL]
    motion_bins = angle[support].reshape(-1, NUM_BINS, 16, 2).mean(axis=2)
    eeg_bins = eeg[support].reshape(-1, NUM_BINS, 16, len(CHANNELS)).mean(axis=2, dtype=np.float64)
    bins = np.concatenate((motion_bins - anchor[:, None, :], eeg_bins), axis=2)
    rows = Rows(
        bins=bins, anchor=anchor, past=past, target=angle[flattened],
        offset=np.tile(np.arange(len(OFFSETS)), len(trials)),
        subject=np.full(len(flattened), subject),
        block=np.full(len(flattened), block),
        trial=np.repeat(trials, len(OFFSETS)),
    )
    exclusions = {
        "recorded_trials": len(cues),
        "eligible_trials": len(trials),
        "outside_movement": int((~bounded).sum()),
        "invalid_encoder_only": int((~encoder_ok & eeg_ok).sum()),
        "nonfinite_eeg_only": int((encoder_ok & ~eeg_ok).sum()),
        "invalid_encoder_and_nonfinite_eeg": int((~encoder_ok & ~eeg_ok).sum()),
    }
    return rows, exclusions
