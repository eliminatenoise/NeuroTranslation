@echo off
setlocal
pushd "%~dp0"
if "%~1"=="" goto help
where py >nul 2>nul
if errorlevel 1 (
    python -B "%~dp0convert.py" %*
) else (
    py -3 -B "%~dp0convert.py" %*
)
set "wrist_status=%errorlevel%"
popd
exit /b %wrist_status%

:help
where py >nul 2>nul
if errorlevel 1 (
    python -B convert.py --help
) else (
    py -3 -B convert.py --help
)
set "wrist_status=%errorlevel%"
if not "%wrist_status%"=="0" echo Install Python 3.11 or newer, then read README.md.
pause
popd
exit /b %wrist_status%
