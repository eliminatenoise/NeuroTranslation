# WristMotion · Forecast one recorded trial

Pick one wrist movement and put the forecasts next to what the encoders measured. At six times after the movement cue, the first model uses earlier wrist angles, the second adds a correction learned from motion, and the third adds a correction learned from motion and forearm surface electromyography (EMG). All three forecasts use the same recorded movement and the same time points.

## Run a trial

Extract this whole ZIP. Use Python 3.11 or newer with NumPy 2 already available in that Python environment. For the example below, save [original Figshare file 62570998](https://ndownloader.figshare.com/files/62570998) as `downloaded.zip` in the extracted folder. Leave it zipped. Open a terminal in that folder and run the line for your system.

| System | Command |
| --- | --- |
| Linux | `sh Launch-Real-Trial-Linux.sh --archive "downloaded.zip" --block 1 --trial 1` |
| macOS | `sh Launch-Real-Trial-macOS.command --archive "downloaded.zip" --block 1 --trial 1` |
| Windows | `Launch-Real-Trial-Windows.cmd --archive "downloaded.zip" --block 1 --trial 1` (Command Prompt) |

If you use a specific Python environment, run `python real_trial.py --archive "downloaded.zip" --block 1 --trial 1` from that environment. You can also pass a full path to the ZIP. The original bytes identify the recording, so the filename can change. The two other accepted archives are [62570821](https://ndownloader.figshare.com/files/62570821) and [62570890](https://ndownloader.figshare.com/files/62570890). Choose a task block from 1 to 8 and a trial in cue order from 1 to 40.

The four columns report measured angles, frozen motion forecasts, motion-corrected forecasts and motion-plus-EMG-corrected forecasts. Each pair gives extension first and radial deviation second, in degrees. Add `--format json` for full-precision values on standard output. Keep that output private, including anything you save from the terminal. The reader runs offline and writes no recording or feature files. The Linux command was tested on the original archives. Native macOS and Windows execution remains unverified.

## What goes into a forecast

The reader checks the original archive fingerprint, paired recording files, channel order and units, then checks the trial against the frozen development fingerprints. Each forecast sees 256 earlier stored rows, ending 128 rows before its target. They form 16 bins of 16 rows. For motion, each bin contributes its mean angle relative to the last visible angle. For EMG, we subtract the right electrode reading from the left on every row of each pair, square the differences and take the square root of their mean. That gives four amplitudes per bin in nominal archived microvolts, ordered M1 through M4. Scalp EEG enters the frozen trial eligibility check. The three forearm forecasts use motion and, where used, surface EMG.

`AGGREGATE.json` gives the errors on 960 eligible development trials from three people. The motion-plus-EMG correction reduced two-axis root mean square error from 3.957° to 3.853° compared with the motion correction. The study's rotated control took EMG from the next eligible trial in the same block. That cohort comparison is reported in the aggregate. The single-trial reader uses the selected trial's own signals.

The 128-row gap is 250 ms on the stored 512 Hz grid. Acquisition latency was unmeasured. These are forecasts of two encoder angles from voluntary pointing. Surface EMG measures electrical activity around the electrodes. What the forecasts gain from that signal in this reused development cohort leaves nerve activity, physical control and performance on other people or tasks open. Six reserved test participants stayed sealed. [Study design](DESIGN.json) · [Development results](AGGREGATE.json)

## Sources

Jorge German Perez Blanco and Javier Mauricio Anteliz Ortiz are credited for the EEG-EMG-WristMotion Dataset. The reader derives forecasts and two measured angle values per time point from that licensed recording. [WristMotion v3 deposit](https://doi.org/10.6084/m9.figshare.29666735.v3) · [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) · [Scientific Data descriptor](https://doi.org/10.1038/s41597-026-07287-z)

The package contains the frozen forearm predictor and the original NeuroTranslation converter used for source checks. `SOURCE-PINS.json` identifies their exact editions. [Original converter at 1e34214](https://github.com/eliminatenoise/NeuroTranslation/blob/1e342140b8d8f8d3039ecd5db7034f28d26c77df/benchmarks/wrist-pointing-temporal/WristMotion-Recorded-Trial-Converter.zip)

Study glossary revision 36, SHA-256 `40b98695e6204bc9e305ecdea853756aec30f48a6ae67d29e92c8bb220b3e406`.
