"""Compare six measured wrist angles with the three frozen study forecasts."""

import argparse
from hashlib import file_digest, sha256
from io import BytesIO
import json
import os
from pathlib import Path
import re
import sys
from zipfile import BadZipFile, ZipFile


HERE = Path(__file__).resolve().parent
CONVERTER = HERE / "wrist-recorded-trial-converter-v1"
COMPONENTS = {
    HERE: {
        "MODEL.json": "b3b9efef1ebdad42f4545747e90c6dee3170d774340590167446b312aba17d72",
        "portable.py": "5285dde41bd3b23c4627824d69a25a8aa1c0343aae5902fb5417c306a5b78914",
    },
    CONVERTER: {
        "DEVELOPMENT-ARCHIVE-PINS.json": "a0b4db26cd12926aa57a2797f766d0d7da27976cfa773168c56b6516755e1725",
        "archive_features.py": "cbc0632483b3de1c77d71a3720f02aab958fcf344813ecb3a6fe196d80cfb49b",
        "archive_source.py": "7fd3f60553ac4dcc8c1b7de987bc9ca2438d32c450932414ad0ec96c4ce6e6b8",
        "convert.py": "eef5238766ed48e3afebef88d038493fc75cd9aa6cf6d03f11f3c1269f0e7abd",
        "features.py": "b729d700e80f61ab955b09204ea500d97a41a095f6331557a40b215da92fa4d1",
        "wrist-recorded-development-sha256.txt": "2f6422705881398013b3245fb0d5fb4b0c5bb0528160c2325be8bdbc0286ff30",
    },
}
ANGLE_COLUMNS = (
    ("measured_deg", "Measured"),
    ("frozen_motion", "Frozen motion"),
    ("motion_correction", "Motion correction"),
    ("motion_emg_correction", "Motion + EMG correction"),
)


def prepare_local_components():
    for directory, files in COMPONENTS.items():
        for filename, expected_digest in files.items():
            with (directory / filename).open("rb") as stream:
                matches = file_digest(stream, "sha256").hexdigest() == expected_digest
            if not matches:
                raise ValueError(f"The packaged {filename} changed. Extract a fresh copy of the reader ZIP.")

    # The decoder is single-process CPU work. The predictor uses standard Python.
    for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "BLIS_NUM_THREADS"):
        os.environ[name] = "1"
    sys.dont_write_bytecode = True
    sys.path[:0] = [str(HERE), str(CONVERTER)]


def read_verified_signals(path, block):
    from archive_source import select_block, verified_archive_bytes, verify_dictionaries

    # Check the deposited bytes before opening any member, regardless of filename.
    raw, blocks = verified_archive_bytes(path)
    ordinal, pin = select_block(blocks, block, None)
    from archive_features import (EEG, EMG, TASK_RUN_IDS, coordinate_data, decode_edf,
                                  read_dictionary, require_standard_header, trial_ticks)

    run = TASK_RUN_IDS[ordinal - 1]
    edf_name = re.compile(rf"(sub-[0-9]{{2}})/eeg/\1_task-WristPointingTask_run-{run}_eeg\.edf")
    try:
        with ZipFile(BytesIO(raw)) as archive:
            names = archive.namelist()
            if len(names) != len(set(names)):
                raise ValueError("Duplicate ZIP member")
            matches = [match for name in names if (match := edf_name.fullmatch(name))]
            if len(matches) != 1:
                raise ValueError("Expected one EDF for the selected task block")
            match = matches[0]
            alias = match.group(1)
            stem = f"{alias}_task-WristPointingTask"
            motion = f"{alias}/motion/{stem}_tracksys-BiomechWrist"
            verify_dictionaries(
                read_dictionary(archive, f"{alias}/eeg/{stem}_channels.tsv"),
                read_dictionary(archive, f"{motion}_channels.tsv"), EEG, EMG,
            )
            edf = archive.read(match.group(0))
            tsv = archive.read(f"{motion}_run-{run}_motion.tsv")
    except (BadZipFile, KeyError) as error:
        raise ValueError("The selected paired recording members cannot be read") from error

    if sha256(edf).hexdigest() != pin["edfSha256"] or sha256(tsv).hexdigest() != pin["tsvSha256"]:
        raise ValueError("A selected recording member changed")
    if require_standard_header(edf[:6144], len(edf)) != pin["edfHeaderSha256"]:
        raise ValueError("The selected recording header changed")
    signal, _ = decode_edf(edf)
    markers = tuple(ticks.astype("int64", copy=False) for ticks in trial_ticks(signal))
    _, angles, valid = coordinate_data(tsv, signal)
    return signal, angles, valid, markers, pin


def trial_inputs(archive, block, trial):
    import convert
    from portable import rms_emg

    signal, angles, valid, (starts, cues, returns), pin = read_verified_signals(archive, block)
    eeg = signal[:, :8].astype("float32")
    rows = convert.feature_rows(eeg, angles, valid, starts, cues, returns, pin["storedRows"])
    packet = convert.packet_from_run(rows, cues, returns, pin["sourceRunSha256"], trial)
    convert.check_catalogue(packet["contentSha256"])

    # Header and channel dictionary checks establish signed microvolts and L/R order.
    emg = signal[:, 8:16]
    targets = packet["source"]["targetTicks"]
    windows = []
    for target, row in zip(targets, packet["rows"], strict=True):
        # Slices exclude their stop: the final visible row is target - 128.
        emg_rows = emg[target - 383:target - 127].tolist()
        windows.append({
            "target_offset_ticks": row["offsetSamples"],
            "anchor_deg": row["anchorDegrees"],
            "motion_bins_deg_relative_to_anchor": [values[:2] for values in row["bins"]],
            "emg_differential_rms_uv": rms_emg(emg_rows),
        })
    return windows, packet["measuredDegrees"]


def comparison(archive, block, trial):
    windows, measured = trial_inputs(archive, block, trial)
    from portable import load_model, predict

    model = load_model()
    rate = 512
    return {
        "schema": "wrist_forearm_trial_comparison.v1",
        "source": "Verified development archive",
        "archive_sample_rate_hz": rate,
        "axis_order": ["extension", "radial_deviation"],
        "rows": [
            {
                "target_offset_ticks": record["target_offset_ticks"],
                "target_offset_seconds": record["target_offset_ticks"] / rate,
                "measured_deg": observed,
                **predict(record, model),
            }
            for record, observed in zip(windows, measured, strict=True)
        ],
    }


def show_table(comparisons):
    print("Verified WristMotion development trial. Angles in degrees.")
    print("Each pair is extension / radial deviation.")
    labels = "".join(f"{label:>26}" for _, label in ANGLE_COLUMNS)
    print(f"{'After cue':>10}{labels}")
    for row in comparisons["rows"]:
        pairs = "".join(f"{row[key][0]:.3f} / {row[key][1]:.3f}".rjust(26) for key, _ in ANGLE_COLUMNS)
        print(f"{row['target_offset_seconds']:8.3f} s{pairs}")
    print("Keep this recording-derived comparison private.")


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--archive", required=True, type=Path, help="Original WristMotion v3 development ZIP")
    cli.add_argument("--block", required=True, type=int, metavar="1..8", help="Pointing task block")
    cli.add_argument("--trial", required=True, type=int, metavar="1..40", help="Trial in cue order")
    cli.add_argument("--format", choices=("table", "json"), default="table", help="Output format (default: table)")
    args = cli.parse_args()
    if not 1 <= args.block <= 8 or not 1 <= args.trial <= 40:
        cli.error("Choose a task block from 1 to 8 and a trial from 1 to 40.")

    try:
        prepare_local_components()
        results = comparison(args.archive, args.block, args.trial)
        if args.format == "json":
            print(json.dumps(results, indent=2, allow_nan=False))
        else:
            show_table(results)
    except ModuleNotFoundError:
        cli.exit(1, "A local Python dependency is missing. Use Python 3.11+ with NumPy 2. See README.md.\n")
    except FileNotFoundError:
        cli.exit(1, "A required file is missing. Check the archive path and extract the complete reader ZIP.\n")
    except ValueError as error:
        cli.exit(1, f"{error}\n")
    except (OSError, TypeError, IndexError, OverflowError, KeyError):
        cli.exit(1, "Could not read the selected trial or packaged model.\n")


if __name__ == "__main__":
    main()
