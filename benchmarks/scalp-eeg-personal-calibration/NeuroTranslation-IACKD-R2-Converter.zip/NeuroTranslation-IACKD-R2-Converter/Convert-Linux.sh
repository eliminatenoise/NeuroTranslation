#!/bin/sh
set -eu
converter_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ -x "$converter_dir/.venv/bin/python" ]; then
    exec "$converter_dir/.venv/bin/python" "$converter_dir/mat_to_companion.py" "$@"
fi
exec python3 "$converter_dir/mat_to_companion.py" "$@"
