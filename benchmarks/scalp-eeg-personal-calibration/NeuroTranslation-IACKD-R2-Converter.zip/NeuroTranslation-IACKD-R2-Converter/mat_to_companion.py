"""Convert one full held-out IACKD right-hand R2 trial to a local NeuroTranslation packet."""
import argparse
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import stat

import h5py
import numpy as np


ROOT = Path(__file__).resolve().parent
LOCK_SHA256 = "19b9b1e282b00fdf7ceffe6c205276e615c1fa6e6fc566ee6dc36a722ff48416"
FIELDS = ("t_ms", "EEG", "x_mm", "eeg_seg_idx", "lm_trial")
FIELD_DTYPES = {"EEG": "<f4", "t_ms": "<f8", "x_mm": "<f8", "lm_trial": "<f8", "eeg_seg_idx": "<f8"}
TIMEBASE = "IACKD event 14 · cue disappearance"
DEVICE_FRAME = "Leap Motion device frame, right positive"
OFF_GRID = "clock_gapped_or_off_lattice"


def ensure(condition, message):
    if not condition:
        raise ValueError(message)


def file_sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_verified_payload(path, derivative):
    ensure(not path.is_symlink() and stat.S_ISREG(path.stat().st_mode), "Expected a local regular MAT file.")
    with path.open("rb") as stream:
        status = os.fstat(stream.fileno())
        ensure(stat.S_ISREG(status.st_mode), "Expected a local regular MAT file.")
        ensure(status.st_size == derivative["bytes"], f"File size differs for {path.name}.")
        data = stream.read(derivative["bytes"] + 1)
    ensure(len(data) == derivative["bytes"] and hashlib.sha256(data).hexdigest() == derivative["sha256"],
           f"File size or content hash differs for {path.name}")
    return io.BytesIO(data)


def check_record(base, rec):
    path = (base / rec["path"]).resolve()
    ensure(path.is_relative_to(base.resolve()) and path.is_file() and path.stat().st_size == rec["bytes"]
           and file_sha(path) == rec["sha256"], f"Referenced metadata altered: {rec['path']}")
    return path


def require_local_dataset(dataset, name):
    ensure(isinstance(dataset, h5py.Dataset) and dataset.ndim == 2
           and not dataset.is_virtual and not dataset.external, f"Unexpected HDF5 storage in {name}")
    props = dataset.id.get_create_plist()
    for index in range(props.get_nfilters()):
        ensure(props.get_filter(index)[0] in (1, 2, 3), f"Unexpected nonstandard filter in {name}")


def trial_fields(source, fields):
    ensure(sorted(source) == ["#refs#", "OUT"] and isinstance(source.get("OUT", getlink=True), h5py.HardLink),
           "Wrong HDF5 roots")
    out = source["OUT"]
    ensure(isinstance(out, h5py.Group) and out.attrs.get("MATLAB_class") == b"struct", "Expected MATLAB OUT struct")
    reference_columns = {}
    for field in fields:
        ensure(isinstance(out.get(field, getlink=True), h5py.HardLink), f"Missing local OUT.{field}")
        column = out[field]
        require_local_dataset(column, field)
        ensure(0 < column.shape[0] <= 1000 and column.shape[1] == 1
               and h5py.check_dtype(ref=column.dtype) is h5py.Reference, f"Bad reference geometry for {field}")
        reference_columns[field] = column[:, 0]
    ensure(len({len(column) for column in reference_columns.values()}) == 1, "Inconsistent OUT trial count")
    return reference_columns


def trial_arrays(source, fields, index):
    arrays = {}
    for field, column in fields.items():
        ref = column[index]
        ensure(bool(ref), f"Null OUT.{field} reference")
        array = source[ref]
        require_local_dataset(array, field)
        ensure(array.name.startswith("/#refs#/") and 0 < array.size <= 100_000
               and array.dtype == np.dtype(FIELD_DTYPES[field]), f"Bad dtype or size in OUT.{field}")
        arrays[field] = array
    return arrays


def check_shape(arrays, indices, n_channels):
    eeg, clock, x = (arrays[name] for name in ("EEG", "t_ms", "x_mm"))
    n_samples = eeg.shape[0]
    ensure(eeg.shape == (n_samples, n_channels) and clock.shape == (1, n_samples)
           and x.shape == (n_samples, 1) and all(0 <= i < n_channels for i in indices),
           "Derivative widths or orientation do not support the frozen named channel map")
    return n_samples


def identity(dataset, minimum):
    ensure(dataset.shape == (1, 1), "Wrong trial identity shape")
    value = float(dataset[0, 0])
    ensure(value.is_integer() and value >= minimum, "Invalid trial identity")
    return int(value)


def native_anchor(clock, step_ms, tolerance_ms):
    if len(clock) < 2 or not np.isfinite(clock).all() or not np.all(np.diff(clock) > 0):
        return None, None, "clock_nonfinite_or_nonincreasing"
    anchor = int(np.searchsorted(clock, 0.0, side="left"))
    if anchor <= 0 or anchor >= len(clock) or not 0 <= clock[anchor] < step_ms:
        return None, None, "no_native_anchor_bracketing_event"
    relative = clock - clock[anchor]
    ticks = np.rint(relative / step_ms)
    residual = float(np.max(np.abs(relative - ticks * step_ms)))
    if not np.all(np.diff(ticks) == 1) or residual > tolerance_ms:
        return anchor, residual, OFF_GRID
    return anchor, residual, None


def load_source_lock(path):
    data = path.read_bytes()
    ensure(hashlib.sha256(data).hexdigest() == LOCK_SHA256, "The source lock differs from this converter.")
    return json.loads(data)


def verify_release_metadata(base, entry, dataset):
    rights = check_record(base, dataset["rights"])
    derivative = entry["derivative"]
    fields_path = check_record(base, derivative["fields"])
    pointer = check_record(base, derivative["annex_pointer"]).read_text(encoding="utf-8")
    ensure(f"SHA256E-s{derivative['bytes']}--{derivative['sha256']}.mat" in pointer,
           "The derivative pointer disagrees with the locked size and SHA-256.")
    fields = json.loads(fields_path.read_text(encoding="utf-8"))
    ensure("event 14" in fields["OUT.t_ms"] and "µV @100 Hz" in fields["OUT.EEG"]
           and "mm @100 Hz" in fields["OUT.x_mm/y_mm/z_mm"], "The released measurement fields differ.")
    recording = entry["raw_recording"]
    header = check_record(base, recording["brainvision"]).read_text(encoding="utf-8-sig").splitlines()
    table = check_record(base, recording["channels"]).read_text(encoding="utf-8-sig")
    channel_rows = list(csv.DictReader(io.StringIO(table), delimiter="\t"))
    rows = entry["mapping"]["central_rows"]
    ensure([(row["name"], row["index_zero_based"]) for row in rows] == [("C3", 11), ("Cz", 12), ("C4", 13)],
           "The release lock has a different channel map.")
    n_eeg = entry["mapping"]["n_channels_expected_after_non_EEG_removal"]
    ensure(len(channel_rows) == recording["channel_count"] == n_eeg + 3 and n_eeg == 28,
           "The acquisition and expected derivative widths disagree.")
    ensure([row["name"] for row in channel_rows[n_eeg:]] == recording["non_eeg_suffix"]
           and all(row["type"] == "EEG" for row in channel_rows[:n_eeg]),
           "The acquisition table has a different EEG and non-EEG order.")
    for row in rows:
        index = row["index_zero_based"]
        name = row["name"]
        ensure((channel_rows[index]["name"], channel_rows[index]["type"]) == (name, "EEG")
               and any(line.startswith(f"Ch{index + 1}={name},") for line in header),
               f"The BrainVision header and acquisition table disagree at {name}.")
    description = json.loads(rights.read_text(encoding="utf-8"))
    ensure(description["License"] == "CC0" and description["DatasetDOI"] == f"doi:{dataset['doi'].split('/', 3)[-1]}",
           "The dataset rights record or release DOI differs.")
    return description


def make_packet(freeze_path, source_path, trial, *, inspect_excluded_clock=False):
    freeze = load_source_lock(freeze_path)
    found = [entry for entry in freeze["participants"] if entry["derivative"]["basename"] == source_path.name]
    ensure(len(found) == 1, "Choose a pinned right-hand run-02 R2 MAT file for sub-13, sub-14 or sub-15.")
    entry = found[0]
    subject, role, derivative = (entry[name] for name in ("subject", "role", "derivative"))
    ensure((entry["acquisition"], entry["run"], entry["edition"], role) == ("right", "02", "R2", "EVALUATION"),
           "This converter accepts only right-hand R2 evaluation recordings.")
    description = verify_release_metadata(freeze_path.parent, entry, freeze["dataset"])
    mapping = entry["mapping"]
    rows = mapping["central_rows"]
    columns = [row["index_zero_based"] for row in rows]
    n_channels = mapping["n_channels_expected_after_non_EEG_removal"]
    with read_verified_payload(source_path, derivative) as body, h5py.File(body, "r") as source:
        refs = trial_fields(source, FIELDS)
        ensure(len(refs["EEG"]) == entry["released_trials"], "Stored OUT trial count differs from the R2 release.")
        ensure(1 <= trial <= len(refs["EEG"]), f"Choose an OUT trial from 1 to {len(refs['EEG'])}.")
        a = trial_arrays(source, refs, trial - 1)
        n = check_shape(a, columns, n_channels)
        segment, leap = identity(a["eeg_seg_idx"], 1), identity(a["lm_trial"], 0)
        clock = a["t_ms"][0, :]
        eeg = a["EEG"][:, columns]
        x = a["x_mm"][:, 0]
    step_ms, tolerance_ms = (freeze["clock"][name] for name in ("step_ms", "tolerance_ms"))
    anchor, residual, reason = native_anchor(clock, step_ms, tolerance_ms)
    if inspect_excluded_clock:
        ensure(reason == OFF_GRID and entry["clock_exclusions"].get(OFF_GRID) == 1,
               "Clock inspection mode requires the documented off-grid R2 trial.")
    elif reason is not None:
        message = f"This trial is excluded from R2 replay ({reason})."
        if reason == OFF_GRID and entry["clock_exclusions"].get(OFF_GRID) == 1:
            message += " Use --inspect-excluded-clock to export its original rows for local inspection."
        raise ValueError(message)
    ensure(np.isfinite(eeg).all() and not np.isinf(x).any(), "The selected trial has an invalid stored value.")
    ms = clock.tolist()
    seconds = [value / 1000.0 for value in ms]
    ensure(max(abs(t * 1000.0 - value) for t, value in zip(seconds, ms, strict=True)) <= 1e-10,
           "Converting timestamps to seconds lost their source coordinates.")
    parent_id = f"{subject}_task-ihc_acq-right_run-02"
    recording = entry["raw_recording"]
    dataset = {
        "id": f"ds006840-1.0.0-{subject}-ihc-right-r2-heldout-trial-{trial:02d}",
        "name": f"IACKD {subject} · right-hand R2 trial {trial}",
        "sourceUrl": freeze["dataset"]["doi"], "license": "CC0", "organism": "Homo sapiens",
        "subjectId": subject,
        "recordingId": f"{parent_id} · derivative trial {trial} (EEG segment {segment}, Leap trial {leap})",
        "task": "IACKD right-hand movement execution with screen feedback",
        "timebase": TIMEBASE, "split": "heldout", "origin": "derived",
        "provenance": {
            "datasetTitle": description["Name"].strip(), "datasetAuthors": description["Authors"],
            "datasetVersion": "1.0.0", "datasetDoi": freeze["dataset"]["doi"],
            "articleDoi": freeze["dataset"]["descriptor"],
            "rightsUrl": "https://creativecommons.org/publicdomain/zero/1.0/",
            "releaseCommit": freeze["dataset"]["commit"], "releaseSnapshotId": freeze["dataset"]["snapshot"]["id"],
            "derivativePath": derivative["release_path"], "derivativeSha256": derivative["sha256"],
            "derivativeBytes": derivative["bytes"], "s3VersionId": derivative["s3_version_id"],
            "sourceManifestSha256": freeze["intake_freeze_sha256"], "parentRecordingId": parent_id,
            "sourceLockSha256": LOCK_SHA256, "sourceQaSha256": freeze["source_receipt_sha256"],
            "archiveHand": "right", "archiveRun": "02", "archiveDerivative": "R2",
            "calibrationStudy": {**freeze["calibration_study"], "participantId": subject},
            "trial": {"outPositionOneBased": trial, "outIndexZeroBased": trial - 1,
                      "eeg_seg_idx": segment, "lm_trial": leap},
            "selection": {
                "method": "Explicit OUT position, with all rows from the selected released trial.",
                "rowStartZeroBased": 0, "rowEndExclusive": n, "sourceTrialRowCount": n,
                "evaluationRole": role,
                "use": "Off-grid clock inspection only" if inspect_excluded_clock else "Local recorded-data inspection",
            },
            "montage": {
                "acquisitionChannelCount": recording["channel_count"], "derivativeEegColumnCount": n_channels,
                "sourceOrientation": "samples × channels in HDF5 storage", "sourceEegShape": [n, n_channels],
                "selectedChannels": [{"name": row["name"], "sourceColumnZeroBased": row["index_zero_based"]}
                                     for row in rows],
                "acquisitionHeaderSha256": recording["brainvision"]["sha256"],
                "channelsTsvSha256": recording["channels"]["sha256"],
            },
            "clock": {
                "sourceField": "OUT.t_ms", "sourceDtype": "float64", "sourceUnit": "ms", "packetUnit": "s",
                "sourceStepMs": step_ms, "timestampMilliseconds": ms, "timestampSeconds": seconds,
                "firstNonnegativeRowZeroBased": anchor, "nativeGridError": reason,
                "nativeGridToleranceMs": tolerance_ms, "maximumCueRelativeLatticeResidualMs": residual,
                "origin": "Nominal zero marks disappearance of the preparation cue at EEG event 14.",
                "alignment": "The release authors retrospectively placed Leap Motion positions on the EEG sample grid.",
                "hardwareSynchronizationVerified": False, "movementOnsetVerified": False,
            },
            "timestampMetadata": {
                "sourceField": "OUT.t_ms", "sourceUnit": "ms", "packetUnit": "s",
                "millisecondField": "clock.timestampMilliseconds", "secondFields": ["clock.timestampSeconds", "streams[].t"],
                "conversion": "Divide each stored millisecond value by 1000, preserving every sample and the original phase.",
            },
            "glossary": freeze["glossary"],
        },
    }
    streams = []
    for selection_index, row in enumerate(rows):
        name, column = row["name"], row["index_zero_based"]
        streams.append({
            "id": f"eeg-{name.lower()}", "label": f"{name} · scalp EEG", "modality": "neural",
            "region": "brain", "anatomy": "Scalp", "signalType": "EEG", "origin": "derived", "unit": "µV",
            "rateHz": 100, "t": seconds, "values": eeg[:, selection_index].tolist(),
            "measurement": "Recorded scalp voltage, filtered and baseline-corrected by the release authors.",
            "provenance": {
                "sourceField": "OUT.EEG", "sourceDtype": "float32", "channel": name,
                "sourceColumnZeroBased": column, "brainvisionHeaderSha256": entry["raw_recording"]["brainvision"]["sha256"],
                "channelsTsvSha256": entry["raw_recording"]["channels"]["sha256"],
                "channelEvidence": "Same-run acquisition header and channel table support this column with the documented processing order.",
            },
        })
    streams.append({
        "id": "leap-palm-x", "label": "Right palm x · Leap Motion", "modality": "displacement",
        "anatomy": "Right palm centre", "origin": "derived", "unit": "mm", "rateHz": 100, "frame": DEVICE_FRAME,
        "t": seconds, "values": [None if np.isnan(value) else float(value) for value in x],
        "measurement": "Optically tracked palm-centre position. The authors smoothed it and aligned it to the EEG clock.",
        "provenance": {
            "sourceField": "OUT.x_mm", "sourceDtype": "float64", "missingValue": "null",
            "sourceStatus": "Stored estimate of physical movement. Gaps mark missing optical measurements in the derivative.",
        },
    })
    return {"schemaVersion": 1, "dataset": dataset, "streams": streams}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mat", type=Path, required=True, help="Unmodified right-hand run-02 R2 MAT file.")
    parser.add_argument("--trial", type=int, required=True, help="One-based position in the file's OUT array.")
    parser.add_argument("--output", type=Path, required=True, help="Path to a new local JSON file.")
    parser.add_argument("--inspect-excluded-clock", action="store_true",
                        help="Inspect the documented off-grid trial locally with its unmodified clock.")
    args = parser.parse_args()
    os.umask(0o077)
    try:
        ensure(args.output.suffix.lower() == ".json", "Choose an output filename ending in .json.")
        ensure(not args.output.exists() and not args.output.is_symlink(), "Choose a new output path.")
        packet = make_packet(ROOT / "source-lock.json", args.mat, args.trial,
                             inspect_excluded_clock=args.inspect_excluded_clock)
        encoded = json.dumps(packet, ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n"
        output = args.output.open("x", encoding="utf-8", newline="\n")
        try:
            with output:
                output.write(encoded)
        except BaseException:
            args.output.unlink(missing_ok=True)
            raise
    except (OSError, ValueError, KeyError) as error:
        parser.exit(2, f"{error}\n")
    positions = packet["streams"][-1]["values"]
    print(f"Wrote {args.output.name} with {len(positions)} rows and {positions.count(None)} missing palm samples.")
    if args.inspect_excluded_clock:
        print("Off-grid clock preserved. Keep this trial out of R2 replay and scores.")


if __name__ == "__main__":
    main()
