@echo off
setlocal
if not exist "%~dp0.venv\Scripts\python.exe" goto launcher
"%~dp0.venv\Scripts\python.exe" "%~dp0mat_to_companion.py" %*
exit /b %errorlevel%
:launcher
where py >nul 2>nul
if errorlevel 1 goto python
py -3 "%~dp0mat_to_companion.py" %*
exit /b %errorlevel%
:python
python "%~dp0mat_to_companion.py" %*
exit /b %errorlevel%
