# Sources and rights

Mengpu Cai, Rongrong Fu, Yaodong Wang, Bin Lu, Saiwei Guo and Fangyao Xu released the **Intention Action Conflict EEG-Hand Kinematics Dataset** under CC0 1.0. The included dataset description, channel tables, BrainVision headers, field definitions and derivative file pointers come from that release. `source-lock.json` identifies their exact versions and hashes. Cite the dataset and the descriptor when using this material in research. [IACKD v1.0.0](https://doi.org/10.18112/openneuro.ds006840.v1.0.0) · [Cai et al., Scientific Data](https://doi.org/10.1038/s41597-026-07146-x)

The descriptor records the study’s research consent and sharing of anonymised data. Use the local converter to inspect the released measurements and report study results in aggregate. Keep participant recordings and converted trial packets local. The archive contains program text and source metadata. [Data descriptor and ethics statement](https://pmc.ncbi.nlm.nih.gov/articles/PMC13287794/)

The release’s derivative has no embedded channel labels. The channel names selected by this converter are supported by each run’s acquisition header and matching channel table, by the observed derivative width and by the authors’ documented processing order. See the author source links in `source-lock.json` for the path from acquisition to MATLAB export. [IACKD processing source](https://github.com/Boketto1/IACKD/tree/c0b595de7571c7e04abae7477c61d0b92b5702cd)

The NeuroTranslation converter uses the terms in `LICENSE`. The Python dependencies are installed separately and retain their own licences.
