# Open a held-out R2 trial

Pick a right-hand run 02 file from IACKD. The converter opens one complete trial as it sits in the release. It verifies the filename, byte count and SHA-256 before opening the MAT file. These three R2 recordings were held out of the corresponding participant calibration, which used run 01. [OpenNeuro ds006840 v1.0.0](https://doi.org/10.18112/openneuro.ds006840.v1.0.0)

| Participant | Right-hand R2 file | Released trials | Eligible for the study |
| --- | --- | ---: | ---: |
| sub-13 | [Download pinned MAT](https://s3.amazonaws.com/openneuro.org/ds006840/derivatives/movement-execution/sub-13/ihc/sub-13_task-ihc_run-02_eeg_leap_R2.mat?versionId=ZlM8oMmX4PIPBlI.O4QbPYjy7XZVUa4B) | 58 | 58 |
| sub-14 | [Download pinned MAT](https://s3.amazonaws.com/openneuro.org/ds006840/derivatives/movement-execution/sub-14/ihc/sub-14_task-ihc_run-02_eeg_leap_R2.mat?versionId=cux7B1Or3hL7iG3ii7Tg3QgdmPs9HbkS) | 60 | 59 |
| sub-15 | [Download pinned MAT](https://s3.amazonaws.com/openneuro.org/ds006840/derivatives/movement-execution/sub-15/ihc/sub-15_task-ihc_run-02_eeg_leap_R2.mat?versionId=C6XfIaVtSvopkEYSYUJ.IEwcy2KMKiuk) | 59 | 59 |

Keep the release filename. Leave `source-lock.json` and the `metadata` folder beside the converter. Use Python 3.12 or later and install the pinned dependencies once in the extracted folder. The Linux check used Python 3.13.15. The macOS and Windows launch commands are included for those platforms.

## Linux

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
./Convert-Linux.sh --mat "/path/to/sub-13_task-ihc_run-02_eeg_leap_R2.mat" --trial 1 --output "sub-13-r2-trial-01.json"
```

## macOS

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
./Convert-macOS.command --mat "/path/to/sub-13_task-ihc_run-02_eeg_leap_R2.mat" --trial 1 --output "sub-13-r2-trial-01.json"
```

On either Unix platform, if the extractor stripped executable permissions, run the launcher with `sh` in front of its name.

## Windows

```bat
py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
Convert-Windows.cmd --mat "C:\path\to\sub-13_task-ihc_run-02_eeg_leap_R2.mat" --trial 1 --output "sub-13-r2-trial-01.json"
```

Use the same commands in PowerShell with `.\` before `Convert-Windows.cmd`. If your installation provides `python` in place of `py`, create the virtual environment with `python -m venv .venv`.

## Read the trial

Open the JSON with the [NeuroTranslation recording inspector](https://eliminatenoise.github.io/NeuroTranslation/). `--trial 1` selects the first position in the MAT file’s `OUT` array. The JSON keeps that position and both IDs stored by IACKD, for the EEG segment and for the Leap Motion trial. The output path must be new.

The inspector plots scalp voltages at C3, Cz and C4 in µV, alongside the optical estimate of right-palm x position in mm. The three voltages retain their original positions in the 28-column derivative. A gap in the palm trace is a missing measurement from the derivative. The graph uses seconds, while the packet also keeps every original millisecond timestamp from `OUT.t_ms`. Nominal zero marks the disappearance of the preparation cue. The authors placed palm positions on the EEG grid retrospectively, so the time axis establishes neither exact movement onset nor hardware synchronisation. [IACKD acquisition and processing methods](https://doi.org/10.1038/s41597-026-07146-x)

One released trial has a clock that falls outside the study’s 10 ms grid tolerance of 0.01 ms. Normal conversion stops there. For clock inspection, repeat the command with `--inspect-excluded-clock`. It stores the untouched rows and identifies the exclusion in the packet. Keep that packet out of the trial replay and scores.

Keep the MAT file and exported JSON local. The converter carries the study and participant association as metadata and runs without fitting a model or sending data over the network. [Sources and rights](RIGHTS.md)
