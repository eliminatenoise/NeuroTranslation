#!/bin/sh
set -eu
folder=$(CDPATH= cd -P "$(dirname "$0")" && pwd)
exec open "$folder/index.html"
