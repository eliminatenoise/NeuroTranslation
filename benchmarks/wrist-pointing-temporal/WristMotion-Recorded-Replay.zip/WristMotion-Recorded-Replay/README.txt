Replay a wrist movement

Extract the whole folder before opening it. Double-click index.html or use
the launcher for your system. On Linux you can run sh Launch-Linux.sh.
On macOS use Launch-macOS.command or run sh Launch-macOS.command. On Windows
open Launch-Windows.cmd. Your browser reads the files directly.

The opening view shows study errors for each wrist axis and target time.
Open the exact-values table for the underlying numbers. The six fitted
temporal models can also run on an eligible development recording converted
to the wrist trial JSON format. Open the file under “Open a recorded trial”.
The browser checks its complete content against fingerprints taken from the
original development recordings. Changing model fit selects a training seed
or the mean of three predictions. Choose Clear recording to remove its values.

The trial converter and instructions are available in the published study:
https://github.com/eliminatenoise/NeuroTranslation/tree/main/benchmarks/wrist-pointing-temporal#replay-a-recorded-trial

The model works offline in a browser supporting Web Crypto. The study and its
six-time-point table remain readable when the numerical tools are unavailable.
The included files carry fitted parameters, cohort summaries and checksums.
You provide the trial. Browser code sends no recording or telemetry. External
source links require a network connection only when opened.

Source: EEG-EMG-WristMotion Dataset, version 3, Jorge German Perez Blanco
and Javier Mauricio Anteliz Ortiz. DOI 10.6084/m9.figshare.29666735.v3.
CC BY 4.0, https://creativecommons.org/licenses/by/4.0/. NeuroTranslation
derived earlier motion and scalp EEG features, fitted the models, and produced
the plotted development summaries. Project-owned code uses the included licence.

The Linux browser and launcher were tested. Native Windows and macOS launch
have not been verified.
