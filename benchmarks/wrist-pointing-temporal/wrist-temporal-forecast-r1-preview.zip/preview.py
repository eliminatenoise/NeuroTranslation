"""Open the experimental result, or run the included checkpoint on invented inputs."""
import argparse
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def verified_checkpoint():
    metadata = read_json(HERE / "checkpoint" / "CHECKPOINT.json")
    files = {
        "fit-arrays.npz",
        *(f"{name}-{seed}.npz" for name in ("motion", "combined") for seed in (17, 29, 43)),
    }
    if set(metadata["weights_sha256"]) != files:
        raise ValueError("Missing or unexpected checkpoint files")
    for filename, expected in metadata["weights_sha256"].items():
        if digest(HERE / "checkpoint" / filename) != expected:
            raise ValueError(f"Checkpoint identity changed for {filename}")
    return metadata


def synthetic_example():
    import numpy as np

    from forecast import CHANNELS, OFFSETS, featurize
    from run import score_predictions

    ticks = np.arange(1050)
    eeg = (5 * np.sin(ticks[:, None] / (20 + np.arange(len(CHANNELS))))).astype(np.float32)
    angle = np.column_stack((0.025 * ticks, -0.012 * ticks))
    rows, _ = featurize(eeg, angle, np.ones_like(angle, dtype=bool), np.array([10]), np.array([1048]), 0, 1)
    predictions, _ = score_predictions(rows, HERE / "checkpoint")
    print("\nSynthetic example. These input signals and predictions do not represent a recorded person.")
    print("Offset after cue | motion CNN extension/radial | motion + EEG CNN extension/radial (degrees)")
    for offset, motion, combined in zip(OFFSETS, predictions["motion_temporal"], predictions["combined_temporal"]):
        print(f"{offset / 512:>7.3f} s  | {motion[0]:>9.3f} {motion[1]:>9.3f}         | {combined[0]:>9.3f} {combined[1]:>9.3f}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--synthetic", action="store_true", help="Run the model on invented inputs (NumPy and CPU PyTorch required)")
    args = parser.parse_args()
    metadata = verified_checkpoint()
    result = read_json(HERE / "DEVELOPMENT-AGGREGATE.json")
    if digest(HERE / "DEVELOPMENT-AGGREGATE.json") != metadata["aggregate_sha256"]:
        raise ValueError("Aggregate result identity changed")
    print("NeuroTranslation | 250 ms wrist-angle forecast | experimental preview")
    support = result["support"]["development"]
    print(f"Development: {support['participants']} people, {support['eligible_trials']} matched trials")
    print("Equal-person two-axis root mean square error (degrees, smaller is better)")
    for method, score in result["participant_balanced"].items():
        if "_seed_" not in method:
            print(f"{method.replace('_', ' '):26s} {score['rmse_deg']:.4f}")
    delta = result["primary"]["participant_balanced_delta_rmse_deg"]
    print(f"Motion + EEG temporal minus motion temporal: {delta:+.4f} degrees")
    print("Development only. Stored cue timing and encoder history are inputs. Physical lead is unmeasured.")
    if args.synthetic:
        synthetic_example()


if __name__ == "__main__":
    main()
