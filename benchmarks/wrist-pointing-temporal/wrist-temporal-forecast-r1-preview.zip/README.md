# How far does the wrist move in a quarter of a second?

By the time we take an encoder reading in this pointing task, the wrist can already be moving. Its last angle tells you where it was. Its last half-second gives you a course to extrapolate. We gave a model both, along with elapsed time after the cue, then asked what eight scalp EEG channels added. The target was the angle measured by the right-wrist exoskeleton's encoder at a later row in the archive.

## What happened

Training used 1,879 of 1,880 recorded trials from six people. The frozen models then forecast 960 of 960 recorded trials from three other people. The motion model's two-axis root mean square error was 4.053°. With EEG it was 4.523°, a signed change of +0.469°. The primary comparison therefore favoured motion history and timing alone. The same EEG model scored 4.880° after rotating trials. The weaker linear models offer a second comparison. Motion ridge scored 6.530°, and adding EEG brought that to 6.439°. The seed-by-seed changes span +0.450° to +0.793°. The fixed linear-velocity forecast scored 8.578° and leaving the angle where it was scored 7.925°. Each person has equal weight. The archive's six forecast offsets and both axes have equal weight.

The trial started from the stored single-target cue. The six targets fall 0.75 to 2 seconds after that cue, in steps of 0.25 seconds. For each target the model sees 256 earlier stored rows, binned in groups of 16. The last input is 128 rows before the target on the 512 Hz archive grid. The encoder reports flexion and extension on one axis and radial and ulnar deviation on the other. Positive degrees mean extension and radial deviation. Each fitted head gets the same elapsed-time flags and encoder history, including the last two angles. EEG gives one head eight extra channels. The input excludes the direction cue and the recorded EMG signals. One planned TRAIN acquisition lacks both source files. Development supplied all 24 paired task acquisitions. Its extra EEG-only file fell outside those task blocks and stayed outside the experiment.

Scalp EEG can carry muscle activity, movement artefacts and signals locked to the cue. Rotating the EEG between trials keeps acquisition and cue offset fixed while breaking the original trial pairing. A gap between rotated and aligned input is evidence about that pairing under the model. The EEG file's encoder state columns and the separate motion file match word for word on the stored clock. Connection, sampling, processing and actuator delays remain unmeasured, so 250 ms describes a lead on the stored grid. Repeated encoder samples on that grid are retained. The nominal encoder update rate is 100 Hz. The study does not establish a physiological lead, a clinical result, or real-time operation. Three development participants and three fixed seeds describe this cohort and these fits. An independent replay checked 3,690 counts and 29,528 numeric estimates across the reported groups. The sealed test participants were kept outside this run.

## Open the preview

Extract the whole archive. On Linux run `sh launch-linux.sh`. On macOS open `Launch-macOS.command` or run `sh Launch-macOS.command` in Terminal. On Windows open `Launch-Windows.cmd`. The launchers use a local Python 3.11 or newer and show the aggregate result. They do not connect to the network or open participant files. `python preview.py --synthetic` runs the included checkpoint on invented input and requires NumPy and CPU PyTorch. The model output in that example is a software demonstration.

The Linux run was verified with Python 3.13, NumPy 2.4.6 and PyTorch 2.14.1+cpu, one PyTorch intra-op thread and one inter-op thread. Windows and macOS launchers are supplied as source. Their native execution remains unverified.

## Reproduce the experiment

The bundled model arrays use NumPy's NPZ format with pickling disabled. The checkpoint records the model-array hashes and the original TRAIN checkpoint's seal. `DESIGN-public.json` retains the protocol and omits identities outside TRAIN and development. `prepare/ROLE-FREEZE-PUBLIC.json` preserves the two admitted roles and their deposit checksums.

The preparation commands fetch the expressly named role only and verify each ZIP against the v3 deposit. Run from an extracted copy dedicated to this experiment. Read the data source terms and keep the resulting `prepare/private` folders local. The commands below are written for a Unix shell. Set the same environment variables in your shell on other platforms.

```sh
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export BLIS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
python3 prepare/stage_archives.py train
python3 prepare/extract_with_standard_headers.py train --evidence prepare/train-source-gate.json
TRAIN_MANIFEST=prepare/private/train/runs/MANIFEST.json
TRAIN_HASH=$(python3 -c 'from pathlib import Path; import hashlib,sys; print(hashlib.sha256(Path(sys.argv[1]).read_bytes()).hexdigest())' "$TRAIN_MANIFEST")
python3 run.py --threads 1 fit --manifest "$TRAIN_MANIFEST" --manifest-sha256 "$TRAIN_HASH" --output reproduced-train
```

Verify the role and source manifest before using its hash. The training command seals the final states and all normalization arrays. Once it has finished, prepare development in its own directory and score it in a new process. Existing output directories are preserved.

```sh
python3 prepare/stage_archives.py development
FIT_HASH=$(python3 -c 'from pathlib import Path; import hashlib,sys; print(hashlib.sha256(Path(sys.argv[1]).read_bytes()).hexdigest())' reproduced-train/FIT-SEAL.json)
python3 prepare/extract_verified_development.py --training-directory reproduced-train --train-seal-sha256 "$FIT_HASH"
DEV_MANIFEST=prepare/private/development/runs/MANIFEST.json
DEV_HASH=$(python3 -c 'from pathlib import Path; import hashlib,sys; print(hashlib.sha256(Path(sys.argv[1]).read_bytes()).hexdigest())' "$DEV_MANIFEST")
python3 run.py --threads 1 score-development --manifest "$DEV_MANIFEST" --manifest-sha256 "$DEV_HASH" --fit-dir reproduced-train --fit-seal-sha256 "$FIT_HASH" --output reproduced-development
```

The model code is the same as the scored run. The bundled preparation code verifies the public role receipt and accepts the sealed TRAIN checkpoint for this reproduction. Runtime versions, transport metadata and preparation-code identity can change the new manifest hash. Compare replayed scores and data support as well as checking the new invocation's own file hashes.

## Credits

The deposit lists Jorge German Perez Blanco and Javier Mauricio Anteliz Ortiz. Use the versioned [EEG-EMG-WristMotion Dataset, version 3](https://doi.org/10.6084/m9.figshare.29666735.v3) and its [CC BY 4.0 license](https://creativecommons.org/licenses/by/4.0/). The original study describes participant consent for open research sharing and the Biomech Wrist measurements. [Primary study and data descriptor](https://doi.org/10.1038/s41597-026-07287-z)

This experiment derives angle predictions from a subset of the deposit's task blocks. It retains unsigned encoder decoding, flips the second axis to positive radial deviation, removes invalid support and bins the earlier scalp samples. The package contains trained models, reproducibility code and error aggregates. Participant recordings are available from the deposit under the deposit's own terms.

Brain2Body terminology follows glossary revision 36, SHA-256 `40b98695e6204bc9e305ecdea853756aec30f48a6ae67d29e92c8bb220b3e406`.
