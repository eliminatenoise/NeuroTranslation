"""Validate common-grid wrist runs and produce a private NPZ per task block."""

import argparse
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import re
import zipfile

import numpy as np

from stage_archives import FREEZE_SHA256, ROLES, ROOT, read_roles


EEG = ("C3", "C1", "Cz", "C2", "C4", "CP3", "CPz", "CP4")
EMG = ("M1L", "M1R", "M2L", "M2R", "M3L", "M3R", "M4L", "M4R")
MARKERS = ("TrialInitStamp", "AllTargetShowSta", "TrialInitMovStam",
           "CurrentTarget", "TrialEndMovStamp", "XCoordinates", "YCoordinates")
EDF_LABELS = tuple(f"Ch{channel}" for channel in range(1, 17)) + MARKERS
SAMPLE_RATE = 512
FRAME_TICKS = 8
TRIALS_PER_BLOCK = 40
TASK_RUN_IDS = tuple(f"{run:02d}" for run in range(3, 11))


def sha256_file(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_dictionary(archive, path):
    raw = archive.read(path)
    return list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig")), delimiter="\t"))


def archive_run_ids(archive, pid):
    eeg_pattern = re.compile(rf"{pid}/eeg/{pid}_task-WristPointingTask_run-(\d\d)_eeg\.edf")
    motion_pattern = re.compile(
        rf"{pid}/motion/{pid}_task-WristPointingTask_tracksys-BiomechWrist_run-(\d\d)_motion\.tsv"
    )
    members = archive.namelist()
    if len(members) != len(set(members)):
        raise ValueError(f"{pid}: duplicate archive member")
    eeg_runs = {match[1] for name in members if (match := eeg_pattern.fullmatch(name))}
    motion_runs = {match[1] for name in members if (match := motion_pattern.fullmatch(name))}
    published_layout = {"01", "11", *TASK_RUN_IDS}
    if eeg_runs != motion_runs or not {"01", "11"} <= eeg_runs or not eeg_runs <= published_layout:
        raise ValueError(f"{pid}: cannot identify task blocks flanked by rest: {eeg_runs=} {motion_runs=}")
    return eeg_runs


def decode_edf(raw):
    if raw[:8] != b"0       ":
        raise ValueError("Unexpected EEG recording file signature")
    header = int(raw[184:192])
    records = int(raw[236:244])
    seconds = float(raw[244:252])
    channel_count = int(raw[252:256])
    if (header, channel_count, seconds) != (6144, len(EDF_LABELS), FRAME_TICKS / SAMPLE_RATE):
        raise ValueError("EDF fixed metadata changed")
    if not 25_000 <= records <= 26_000:
        raise ValueError("EDF record count disagrees with the documented task duration")
    if len(raw) != header + records * channel_count * FRAME_TICKS * 2:
        raise ValueError("EDF payload bytes disagree with the independently checked frame size")
    sections = {}
    offset = 256
    for field, width in (
        ("label", 16), ("transducer", 80), ("unit", 8), ("physical_min", 8),
        ("physical_max", 8), ("digital_min", 8), ("digital_max", 8),
        ("prefilter", 80), ("record_samples", 8), ("reserved", 32),
    ):
        sections[field] = tuple(
            raw[start:start + width].strip() for start in range(offset, offset + width * channel_count, width)
        )
        offset += width * channel_count
    if tuple(label.decode("ascii") for label in sections["label"]) != EDF_LABELS:
        raise ValueError("EDF electrode/channel identity, marker identity or order changed")
    if sections["unit"][:16] != (b"uV",) * 16 or sections["unit"][16:] != (b"",) * 7:
        raise ValueError("EDF physical signal or state units changed")
    if any(sections[f"{domain}_{limit}"][:16] != (value,) * 16
           for domain in ("physical", "digital")
           for limit, value in (("min", b"-32768"), ("max", b"32767"))):
        raise ValueError("EDF bioelectric calibration changed")
    if sections["physical_min"][16:] != (b"0",) * 7 or sections["digital_min"][16:] != (b"0",) * 7:
        raise ValueError("EDF state lower ranges changed")
    if sections["physical_max"][16:] != (b"255",) * 5 + (b"32767",) * 2:
        raise ValueError("EDF state upper ranges changed")
    if sections["digital_max"][16:] != sections["physical_max"][16:]:
        raise ValueError("EDF state header physical/digital declarations disagree")
    if sections["prefilter"][:16] != (b"HP:0.1LP:200N:60",) * 16:
        raise ValueError("EDF hardware filter declarations changed")
    # The producer repeats the frame-count token within each fixed-width field.
    # Common frame size above is constrained by file length, run duration, channel
    # count, footer-free EDF layout, ordered marker roles and exact TSV parity.
    repeated_samples_field = sum(len(field.split()) > 1 for field in sections["record_samples"])
    if not repeated_samples_field and sections["record_samples"] != (b"8",) * channel_count:
        raise ValueError("Unknown EDF frame-count encoding")
    signals = np.frombuffer(raw, dtype="<i2", offset=header)
    return signals.reshape(records, channel_count, FRAME_TICKS).transpose(0, 2, 1).reshape(-1, channel_count), {
        "source_records": records, "frame_ticks": FRAME_TICKS,
        "header_bytes": header, "header_sha256": hashlib.sha256(raw[:header]).hexdigest(),
        "repeated_samples_header_fields": repeated_samples_field,
    }


def marker_ticks(pulses):
    if np.any((pulses != 0) & (pulses != 1)):
        raise ValueError("Unexpected non-binary state in source marker channel")
    return np.flatnonzero(pulses.astype(bool) & np.r_[True, pulses[:-1] == 0])


def trial_ticks(signal):
    starts = marker_ticks(signal[:, 16])
    all_targets = marker_ticks(signal[:, 17])
    cues = marker_ticks(signal[:, 18])
    returns = marker_ticks(signal[:, 20])
    if len(starts) not in (TRIALS_PER_BLOCK, TRIALS_PER_BLOCK + 1) or any(
        len(series) != TRIALS_PER_BLOCK for series in (all_targets, cues, returns)
    ):
        raise ValueError("Wrong count of stored source trial and movement markers")
    first = starts[:TRIALS_PER_BLOCK]
    stop = np.r_[starts[1:], len(signal)][:TRIALS_PER_BLOCK]
    if not np.all((first < all_targets) & (all_targets < cues) & (cues < returns) & (returns < stop)):
        raise ValueError("Stored source marker order is inconsistent")
    if not np.all(returns - cues > 1024):
        raise ValueError("Prespecified forecast support extends past the source movement interval")
    return first, cues, returns


def coordinate_data(motion, signal):
    raw_signed = np.loadtxt(io.BytesIO(motion), dtype=np.int32, delimiter="\t", ndmin=2)
    if raw_signed.shape != (len(signal), 2) or np.any(raw_signed < 0) or np.any(raw_signed > 65535):
        raise ValueError("Motion TSV shape or unsigned 16-bit word range disagrees with timed source")
    counts = raw_signed.astype("<u2")
    if not np.array_equal(counts, signal[:, 21:23].view("<u2")):
        raise ValueError("Motion TSV and EDF auxiliary states differ in the same stored row")
    angle_deg = (counts.astype(np.float64) * (25.0 / 65535.0) - 12.5) * (180.0 / np.pi)
    angle_deg[:, 1] *= -1.0
    # A raw zero is a missing sentinel, not a device-neutral reading. No
    # participant-specific normal range is applied to nonzero positions.
    valid = (counts != 0) & (np.abs(angle_deg) <= 180.0)
    angle_deg[~valid] = np.nan
    return counts, angle_deg, valid


def invalid_intervals(valid):
    intervals = []
    for axis in range(2):
        missing = ~valid[:, axis]
        changes = np.flatnonzero(np.diff(np.r_[False, missing, False]))
        intervals.append(changes.reshape(-1, 2).tolist())
    return intervals


def extract_run(archive, pid, archive_run, ordinal, destination):
    stem = f"{pid}_task-WristPointingTask"
    eeg_member = f"{pid}/eeg/{stem}_run-{archive_run}_eeg.edf"
    motion_member = f"{pid}/motion/{stem}_tracksys-BiomechWrist_run-{archive_run}_motion.tsv"
    eeg_blob = archive.read(eeg_member)
    motion_blob = archive.read(motion_member)
    signal, framing = decode_edf(eeg_blob)
    starts, cues, returns = trial_ticks(signal)
    counts, angle_deg, valid = coordinate_data(motion_blob, signal)

    filename = f"{pid}_task-block-{ordinal:02d}_run-{archive_run}.npz"
    final = destination / filename
    with final.open("xb") as storage:
        np.savez(storage, eeg_uv=signal[:, :8].astype(np.float32), angle_deg=angle_deg, valid=valid,
                 cue_tick=cues, return_tick=returns, trial_start_tick=starts, raw_encoder=counts)
    intervals = invalid_intervals(valid)
    encoder_change_deltas = []
    for axis in range(2):
        changes = np.flatnonzero((np.diff(counts[:, axis]) != 0) & valid[:-1, axis] & valid[1:, axis])
        gap, frequency = np.unique(np.diff(changes), return_counts=True)
        top = np.argsort(-frequency, kind="stable")[:5]
        encoder_change_deltas.append({str(int(gap[pos])): int(frequency[pos]) for pos in top})
    return {
        "archive_run": archive_run, "task_block_ordinal": ordinal, "stored_rows": len(signal),
        "source_record_framing": framing,
        "eeg_member": eeg_member, "eeg_sha256": hashlib.sha256(eeg_blob).hexdigest(),
        "motion_member": motion_member, "motion_sha256": hashlib.sha256(motion_blob).hexdigest(),
        "archive_pairing": "every unsigned 16-bit encoder word identical across EEG and motion members at the same index",
        "cue_range_of_forward_duration_ticks": [int((returns-cues).min()), int((returns-cues).max())],
        "cue_count": len(cues),
        "cue_ticks_with_direction_state_present": int(np.isin(signal[cues, 19], (1, 2, 3, 4)).sum()),
        "invalid_zero_word_counts": (counts == 0).sum(axis=0).tolist(),
        "invalid_nonzero_outside_180_counts": ((counts != 0) & ~valid).sum(axis=0).tolist(),
        "invalid_tick_intervals_per_axis_end_exclusive": intervals,
        "common_ticks_between_observed_encoder_value_changes_per_axis": encoder_change_deltas,
        "npz": filename, "npz_bytes": final.stat().st_size, "npz_sha256": sha256_file(final),
    }


def extract(role):
    freeze = read_roles()
    folder = ROOT / "private" / role
    archive_path = folder / "archives" / "MANIFEST.json"
    archive_manifest = json.loads(archive_path.read_text())
    if (archive_manifest["role"], archive_manifest["role_freeze_sha256"]) != (role, FREEZE_SHA256):
        raise ValueError("Wrong source archive receipt")
    if [row["subject"] for row in archive_manifest["records"]] != freeze["roles"][role]:
        raise ValueError("Role participant order does not match freeze")
    destination = folder / "runs"
    destination.mkdir(exist_ok=False)
    participants = []
    for row in archive_manifest["records"]:
        pid = row["subject"]
        archive_file = archive_path.parent / f"{pid}.zip"
        if row["file"] != archive_file.name or sha256_file(archive_file) != row["sha256"]:
            raise ValueError(f"{pid}: staged source archive identity changed")
        with zipfile.ZipFile(archive_file) as archive:
            stem = f"{pid}_task-WristPointingTask"
            eeg = read_dictionary(archive, f"{pid}/eeg/{stem}_channels.tsv")
            motion = read_dictionary(archive, f"{pid}/motion/{stem}_tracksys-BiomechWrist_channels.tsv")
            if [(item["name"], item["type"], item["units"]) for item in eeg] != [
                *((label, "EEG", "microV") for label in EEG), *((label, "EMG", "microV") for label in EMG)
            ]:
                raise ValueError(f"{pid}: exact biosignal dictionary changed")
            if [(item["name"], item["tracked_point"], item["units"]) for item in motion] != [
                ("X", "RightWrist", "rad"), ("Y", "RightWrist", "rad")
            ]:
                raise ValueError(f"{pid}: exact motion dictionary changed")
            run_ids = archive_run_ids(archive, pid)
            runs = [extract_run(archive, pid, archive_run, ordinal, destination)
                    for ordinal, archive_run in enumerate(TASK_RUN_IDS, start=1) if archive_run in run_ids]
        participants.append({
            "subject": pid, "source_archive_sha256": row["sha256"],
            "excluded_baseline_archive_runs": ["01", "11"],
            "missing_task_blocks": [{"archive_run": run_id, "task_block_ordinal": ordinal,
                                     "reason": "Both matching member names absent from published archive"}
                                    for ordinal, run_id in enumerate(TASK_RUN_IDS, start=1) if run_id not in run_ids],
            "runs": runs,
        })
    manifest = {
        "role": role, "role_freeze_sha256": FREEZE_SHA256, "deposit": freeze["dataset"],
        "archive_manifest_sha256": sha256_file(archive_path),
        "extractor_sha256": sha256_file(Path(__file__)), "numpy_version": np.__version__,
        "sample_rate_hz": SAMPLE_RATE, "eeg_order": EEG, "eeg_units": "microvolts",
        "angle_columns_degrees": ["positive extension", "positive radial deviation"],
        "tick_definition": "zero-based within verified source file; no stitching between runs",
        "source_latency": "512 Hz stored shared clock, encoder nominally refreshed at 100 Hz, retained stair steps with no interpolation; acquisition or mechanical lead not bounded",
        "participant_order": participants,
    }
    with (destination / "MANIFEST.json").open("x") as storage:
        json.dump(manifest, storage, indent=2)
        storage.write("\n")


if __name__ == "__main__":
    os.umask(0o077)
    parser = argparse.ArgumentParser()
    parser.add_argument("role", choices=ROLES)
    extract(parser.parse_args().role)
