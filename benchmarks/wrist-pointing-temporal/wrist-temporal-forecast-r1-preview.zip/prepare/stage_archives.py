"""Stage an allowlisted role from the checksum-pinned Figshare release."""

import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
import zipfile


ROOT = Path(__file__).resolve().parent
FREEZE_SHA256 = "5ba02aa108cf9406dd48bcfa5576f50f3aae3d2ea033fda968a4de52c9fcea6b"
ROLES = ("train", "development")


def read_roles():
    payload = (ROOT / "ROLE-FREEZE-PUBLIC.json").read_bytes()
    if hashlib.sha256(payload).hexdigest() != "d4990dd9f1dc8b2bcad078251d5bab479baeef7b186ab92c3302e424d2af7f64":
        raise ValueError("Role freeze identity changed")
    return json.loads(payload)


def stage(role):
    freeze = read_roles()
    folder = ROOT / "private" / role / "archives"
    folder.mkdir(parents=True, exist_ok=True)
    manifest_file = folder / "MANIFEST.json"
    if manifest_file.exists():
        raise FileExistsError(manifest_file)

    def fetch(subject):
        meta = freeze["metadata_identities_for_pilot"][subject]
        source_url = f"https://ndownloader.figshare.com/files/{meta['file_id']}"
        if meta["download_url"] != source_url:
            raise ValueError("Role manifest URL disagrees with fixed Figshare transport")
        final = folder / f"{subject}.zip"
        if final.exists():
            raise FileExistsError(final)
        part = final.with_suffix(".zip.part")
        md5 = hashlib.md5(usedforsecurity=False)
        sha256 = hashlib.sha256()
        size = 0
        request = Request(source_url + "?download=neuro-wrist-v3-r1", headers={"Accept-Encoding": "identity"})
        with part.open("xb") as storage, urlopen(request, timeout=35) as response:
            endpoint = urlsplit(response.url)
            if response.status != 200 or endpoint.scheme != "https" or endpoint.hostname is None:
                raise ValueError(f"{subject}: unexpected archive response")
            if response.headers.get("Content-Length") != str(meta["bytes"]):
                raise ValueError(f"{subject}: archive response length disagrees with Figshare deposit")
            for chunk in iter(lambda: response.read(1_048_576), b""):
                size += len(chunk)
                if size > meta["bytes"]:
                    raise ValueError(f"{subject}: archive exceeds the pinned length")
                storage.write(chunk)
                md5.update(chunk)
                sha256.update(chunk)
            if size != meta["bytes"] or md5.hexdigest() != meta["md5"]:
                raise ValueError(f"{subject}: archive length/MD5 mismatch")
        if not zipfile.is_zipfile(part):
            raise ValueError(f"{subject}: checksum matched but ZIP directory does not parse")
        part.replace(final)
        return {
            "subject": subject, "deposit": freeze["dataset"], "file_id": meta["file_id"],
            "file": final.name, "bytes": size, "md5": md5.hexdigest(),
            "sha256": sha256.hexdigest(), "transport_host": endpoint.hostname,
        }

    with ThreadPoolExecutor(max_workers=2) as pool:
        manifest = {"role": role, "role_freeze_sha256": FREEZE_SHA256,
                    "records": list(pool.map(fetch, freeze["roles"][role]))}
    with manifest_file.open("x") as storage:
        json.dump(manifest, storage, indent=2)
        storage.write("\n")


if __name__ == "__main__":
    os.umask(0o077)
    parser = argparse.ArgumentParser()
    parser.add_argument("role", choices=ROLES)
    stage(parser.parse_args().role)
