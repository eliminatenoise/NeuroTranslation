"""Decode the admitted development sources without reading the extra unpaired member."""

import argparse
import json
import os
import sys
from pathlib import Path
import zipfile

from extract_runs import EEG, EMG, ROOT, SAMPLE_RATE, TASK_RUN_IDS, extract_run, read_dictionary, sha256_file
from extract_with_standard_headers import require_standard_header
from stage_archives import FREEZE_SHA256, read_roles


RUNS = ("01", *TASK_RUN_IDS, "11")


def member_paths(subject, suffix):
    stem = f"{subject}_task-WristPointingTask"
    eeg = f"{subject}/eeg/{stem}_run-{suffix}_eeg.edf"
    motion = f"{subject}/motion/{stem}_tracksys-BiomechWrist_run-{suffix}_motion.tsv"
    return eeg, motion


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--training-directory", required=True, type=Path)
    parser.add_argument("--train-seal-sha256", required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(ROOT.parent))
    from run import verified_seal
    verified_seal(args.training_directory, args.train_seal_sha256)
    source = ROOT / "private" / "development"
    staged = source / "archives" / "MANIFEST.json"
    manifest = json.loads(staged.read_text())
    freeze = read_roles()
    subjects = freeze["roles"]["development"]
    if (manifest["role"], manifest["role_freeze_sha256"]) != ("development", FREEZE_SHA256):
        raise ValueError("Unexpected raw source role")
    if subjects != ["sub-41", "sub-12", "sub-26"] or [r["subject"] for r in manifest["records"]] != subjects:
        raise ValueError("Exact development participant membership or order changed")
    archive_checks = []
    for row in manifest["records"]:
        subject = row["subject"]
        metadata = freeze["metadata_identities_for_pilot"][subject]
        if any(row[key] != metadata[key] for key in ("file_id", "bytes", "md5")):
            raise ValueError("Developer role custody no longer matches the independent dataset version")
        archive_path = staged.parent / f"{subject}.zip"
        if row["file"] != archive_path.name or sha256_file(archive_path) != row["sha256"]:
            raise ValueError("Archive changed after verification")
        with zipfile.ZipFile(archive_path) as archive:
            names = archive.namelist()
            if len(set(names)) != len(names):
                raise ValueError("Duplicate archive member")
            expected_members = {name for run in RUNS for name in member_paths(subject, run)}
            actual_members = {name for name in names if name.startswith(subject + "/")
                              and name.endswith(("_eeg.edf", "_motion.tsv"))}
            extra = set()
            exclusions = []
            if subject == "sub-41":
                outside_schedule, absent_motion = member_paths(subject, "02")
                if outside_schedule not in actual_members or absent_motion in actual_members:
                    raise ValueError("The precise source-disclosed unmatched run changed")
                size = archive.getinfo(outside_schedule).file_size
                if size != 9_312_864:
                    raise ValueError("The precise excluded extra EEG member changed")
                extra.add(outside_schedule)
                exclusions.append({"member": outside_schedule, "uncompressed_bytes": size, "source_header_read": False,
                                   "reason": "Outside preregistered task ordinals and absent exact motion member"})
            if actual_members != expected_members | extra:
                raise ValueError("Unexpected matching or unpaired source-file inventory")
            stem = f"{subject}_task-WristPointingTask"
            eeg = read_dictionary(archive, f"{subject}/eeg/{stem}_channels.tsv")
            motion = read_dictionary(archive, f"{subject}/motion/{stem}_tracksys-BiomechWrist_channels.tsv")
            expected_channels = [(label, "EEG", "microV") for label in EEG]
            expected_channels.extend((label, "EMG", "microV") for label in EMG)
            if [(c["name"], c["type"], c["units"]) for c in eeg] != expected_channels:
                raise ValueError("Biosignal channel dictionary changed")
            if [(c["name"], c["tracked_point"], c["units"]) for c in motion] != [
                ("X", "RightWrist", "rad"), ("Y", "RightWrist", "rad")
            ]:
                raise ValueError("Motion channel dictionary changed")
            checks = []
            for run in TASK_RUN_IDS:
                member, _ = member_paths(subject, run)
                with archive.open(member) as stream:
                    header = require_standard_header(stream.read(6144), archive.getinfo(member).file_size)
                checks.append({"archive_run": run, "member": member, "header_sha256": header})
        archive_checks.append({"subject": subject, "archive_file": str(archive_path),
                               "sha256": row["sha256"], "header_checks": checks, "exclusions": exclusions})

    output = source / "runs"
    if output.exists():
        raise FileExistsError(output)
    temporary = output.with_name("runs.partial")
    temporary.mkdir(exist_ok=False)
    participants = []
    for row in archive_checks:
        archive_path = Path(row["archive_file"])
        if sha256_file(archive_path) != row["sha256"]:
            raise ValueError("Archive changed after strict header preflight")
        with zipfile.ZipFile(archive_path) as archive:
            runs = [extract_run(archive, row["subject"], item["archive_run"], index, temporary)
                    for index, item in enumerate(row["header_checks"], start=1)]
        if any(item["source_record_framing"]["header_sha256"] != check["header_sha256"]
               for item, check in zip(runs, row["header_checks"], strict=True)):
            raise ValueError("Extracted headers differ from the strict preflight")
        participants.append({"subject": row["subject"], "source_archive_sha256": row["sha256"],
                             "excluded_baseline_archive_runs": ["01", "11"], "missing_task_blocks": [],
                             "excluded_unpaired_members": row["exclusions"], "runs": runs})
    result = {
        "role": "development", "role_freeze_sha256": FREEZE_SHA256, "deposit": freeze["dataset"],
        "archive_manifest_sha256": sha256_file(staged), "extractor_sha256": sha256_file(Path(__file__)),
        "unchanged_run_decoder_sha256": sha256_file(ROOT / "extract_runs.py"),
        "strict_header_gate_sha256": sha256_file(ROOT / "extract_with_standard_headers.py"),
        "training_seal_sha256": args.train_seal_sha256, "sample_rate_hz": SAMPLE_RATE, "eeg_order": EEG,
        "eeg_units": "microvolts", "angle_columns_degrees": ["positive extension", "positive radial deviation"],
        "tick_definition": "zero-based within verified source file; no stitching between runs",
        "source_latency": "512 Hz shared storage clock, nominal 100 Hz encoder update, physical acquisition latency unbounded",
        "required_standard_edf_count_fields_checked": 23 * sum(len(row["runs"]) for row in participants),
        "participant_order": participants,
    }
    with (temporary / "MANIFEST.json").open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    temporary.rename(output)


if __name__ == "__main__":
    main()
