"""Require standard EDF count fields before the frozen wrist run extractor."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import zipfile

from extract_runs import ROOT, TASK_RUN_IDS, archive_run_ids, extract, sha256_file
from stage_archives import FREEZE_SHA256, ROLES, read_roles


def require_standard_header(header, member_size):
    if len(header) != 6144 or header[:8] != b"0       ":
        raise ValueError("Unexpected source EDF header envelope")
    if int(header[184:192]) != 6144 or float(header[244:252]) != 0.015625:
        raise ValueError("Unexpected header length or EDF record clock")
    signals = int(header[252:256])
    records = int(header[236:244])
    if signals != 23 or records <= 0 or member_size != 6144 + records * signals * 8 * 2:
        raise ValueError("Unexpected standard EDF signal count or payload byte count")
    sample_count_start = 256 + 216 * signals
    sample_count_table = header[sample_count_start:sample_count_start + 8 * signals]
    for offset in range(0, len(sample_count_table), 8):
        field = sample_count_table[offset:offset + 8]
        if re.fullmatch(rb" *8 *", field) is None:
            raise ValueError("Every EDF samples-per-record field must be the standard integer 8")
    return hashlib.sha256(header).hexdigest()


def check_role(role):
    root = ROOT / "private" / role / "archives"
    receipt_file = root / "MANIFEST.json"
    receipt = json.loads(receipt_file.read_text())
    if (receipt["role"], receipt["role_freeze_sha256"]) != (role, FREEZE_SHA256):
        raise ValueError("Unexpected acquisition role or source freeze")
    subjects = [item["subject"] for item in receipt["records"]]
    if subjects != read_roles()["roles"][role]:
        raise ValueError("Source acquisition roles changed")
    records = []
    for item in receipt["records"]:
        subject = item["subject"]
        archive_path = root / f"{subject}.zip"
        if item["file"] != archive_path.name or sha256_file(archive_path) != item["sha256"]:
            raise ValueError(f"{subject}: archive SHA changed")
        with zipfile.ZipFile(archive_path) as archive:
            actual_runs = archive_run_ids(archive, subject)
            for run in TASK_RUN_IDS:
                if run not in actual_runs:
                    continue
                member = f"{subject}/eeg/{subject}_task-WristPointingTask_run-{run}_eeg.edf"
                with archive.open(member) as stream:
                    header_hash = require_standard_header(stream.read(6144), archive.getinfo(member).file_size)
                records.append({"subject": subject, "archive_run": run, "member": member,
                                "header_sha256": header_hash, "standard_count_fields": 23})
    return {
        "schema_version": 1, "role": role, "source_receipt_sha256": sha256_file(receipt_file),
        "strict_gate_code_sha256": sha256_file(Path(__file__)),
        "unchanged_extractor_code_sha256": sha256_file(ROOT / "extract_runs.py"),
        "standard_eight_count_fields_required": 23 * len(records), "source_headers": records,
        "waveform_rows_decoded_by_header_gate": 0,
    }


if __name__ == "__main__":
    os.umask(0o077)
    parser = argparse.ArgumentParser()
    parser.add_argument("role", choices=ROLES)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--headers-only", action="store_true")
    args = parser.parse_args()
    result = check_role(args.role)
    with args.evidence.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    if not args.headers_only:
        extract(args.role)
