"""Feature construction and fixed estimators for the wrist forecast protocol."""

from dataclasses import dataclass

import numpy as np
import torch
from torch import nn


OFFSETS = np.array([384, 512, 640, 768, 896, 1024])
CHANNELS = ("C3", "C1", "Cz", "C2", "C4", "CP3", "CPz", "CP4")
AXES = ("extension", "radial_deviation")
SEEDS = (17, 29, 43)
EPOCHS = 30
BATCH = 128
FIT_PENALTY = 0.01
MODEL_CHANNELS = {"motion": 2, "combined": 10}
HISTORY_ROWS = np.arange(-383, -127)
ANCHOR_LEAD = 128
VELOCITY_INTERVAL = 64
NUM_BINS = 16
DENOMINATOR_TRIALS_PER_RUN = 40


@dataclass(frozen=True)
class Rows:
    bins: np.ndarray
    anchor: np.ndarray
    past: np.ndarray
    target: np.ndarray
    offset: np.ndarray
    subject: np.ndarray
    block: np.ndarray
    trial: np.ndarray

    @property
    def residual(self):
        return self.target - self.anchor

    @property
    def timing_flags(self):
        return np.eye(len(OFFSETS), dtype=np.float64)[self.offset]

    @classmethod
    def combine(cls, runs):
        return cls(**{
            name: np.concatenate([getattr(run, name) for run in runs])
            for name in cls.__dataclass_fields__
        })


def validate_run(eeg, angle, valid, starts, cues, returns, n_rows):
    if eeg.dtype != np.float32 or eeg.shape != (n_rows, len(CHANNELS)):
        raise ValueError("Invalid EEG array")
    if angle.dtype != np.float64 or angle.shape != (n_rows, len(AXES)):
        raise ValueError("Invalid encoder angle array")
    if valid.dtype != np.bool_ or valid.shape != angle.shape:
        raise ValueError("Invalid encoder eligibility mask")
    if not np.all(np.isfinite(angle[valid])) or not np.all(np.isnan(angle[~valid])):
        raise ValueError("Encoder validity mask disagrees with decoded data")
    for ticks in (starts, cues, returns):
        if ticks.dtype != np.int64 or ticks.shape != (DENOMINATOR_TRIALS_PER_RUN,):
            raise ValueError("Invalid marker dtype or source count")
        if not np.all((0 <= ticks) & (ticks < n_rows)) or np.any(np.diff(ticks) <= 0):
            raise ValueError("Out-of-range or non-monotonic run-local markers")
    if not np.all((starts < cues) & (cues < returns)) or not np.all(returns[:-1] < starts[1:]):
        raise ValueError("Nonsequential or overlapping source trials")


def featurize(eeg, angle, valid, cues, returns, subject, block):
    targets = cues[:, None] + OFFSETS
    support = targets[:, :, None] + HISTORY_ROWS
    bounded = ((support[:, :, 0] >= cues[:, None]) &
               (targets < returns[:, None]) & (targets < len(angle))).all(axis=1)
    bounded_ids = np.flatnonzero(bounded)
    t = targets[bounded_ids]
    support = support[bounded_ids]
    encoder_ok = valid[t].all(axis=(1, 2)) & valid[support].all(axis=(1, 2, 3))
    eeg_ok = np.isfinite(eeg[support]).all(axis=(1, 2, 3))
    keep = encoder_ok & eeg_ok
    t, support, trials = t[keep], support[keep], bounded_ids[keep]
    flattened = t.ravel()
    support = support.reshape(len(flattened), len(HISTORY_ROWS))
    anchor = angle[flattened - ANCHOR_LEAD]
    past = angle[flattened - ANCHOR_LEAD - VELOCITY_INTERVAL]
    motion_bins = angle[support].reshape(-1, NUM_BINS, 16, 2).mean(axis=2)
    eeg_bins = eeg[support].reshape(-1, NUM_BINS, 16, len(CHANNELS)).mean(axis=2, dtype=np.float64)
    bins = np.concatenate((motion_bins - anchor[:, None, :], eeg_bins), axis=2)
    rows = Rows(
        bins=bins, anchor=anchor, past=past, target=angle[flattened],
        offset=np.tile(np.arange(len(OFFSETS)), len(trials)),
        subject=np.full(len(flattened), subject),
        block=np.full(len(flattened), block),
        trial=np.repeat(trials, len(OFFSETS)),
    )
    exclusions = {
        "recorded_trials": len(cues),
        "eligible_trials": len(trials),
        "outside_movement": int((~bounded).sum()),
        "invalid_encoder_only": int((~encoder_ok & eeg_ok).sum()),
        "nonfinite_eeg_only": int((encoder_ok & ~eeg_ok).sum()),
        "invalid_encoder_and_nonfinite_eeg": int((~encoder_ok & ~eeg_ok).sum()),
    }
    return rows, exclusions


def moments(features, axis):
    center = features.mean(axis=axis)
    scale = features.std(axis=axis)
    return center, np.where(scale == 0, 1.0, scale)


def train_normalization(rows):
    bins_center, bins_scale = moments(rows.bins, axis=(0, 1))
    anchor_center, anchor_scale = moments(rows.anchor, axis=0)
    residual_center, residual_scale = moments(rows.residual, axis=0)
    return {
        "bins_center": bins_center, "bins_scale": bins_scale,
        "anchor_center": anchor_center, "anchor_scale": anchor_scale,
        "residual_center": residual_center, "residual_scale": residual_scale,
    }


def subject_weights(rows):
    _, person, counts = np.unique(rows.subject, return_inverse=True, return_counts=True)
    return 1.0 / (len(counts) * counts[person])


def timing_prediction(rows, weights):
    means = []
    for offset in range(len(OFFSETS)):
        subset = rows.offset == offset
        means.append(np.average(rows.target[subset], weights=weights[subset], axis=0))
    return np.stack(means)


def feature_arrays(rows, normalization, channels, eeg_order=None):
    bins = (rows.bins[:, :, :channels] - normalization["bins_center"][:channels]) / normalization["bins_scale"][:channels]
    if eeg_order is not None:
        if channels != MODEL_CHANNELS["combined"]:
            raise ValueError("EEG rotation requires the combined input")
        bins[:, :, 2:] = bins[eeg_order, :, 2:]
    anchor = (rows.anchor - normalization["anchor_center"]) / normalization["anchor_scale"]
    auxiliary = np.concatenate((anchor, rows.timing_flags), axis=1)
    return bins, auxiliary


def ridge_matrix(bins, auxiliary):
    return np.concatenate((bins.reshape(len(bins), -1), auxiliary), axis=1)


def fit_ridge(matrix, target, weights):
    weighted = weights[:, None] * matrix
    penalty = np.full(matrix.shape[1], FIT_PENALTY)
    penalty[-len(OFFSETS):] = 0.0
    return np.linalg.solve(matrix.T @ weighted + np.diag(penalty), weighted.T @ target)


def rotated_rows(rows):
    index = np.arange(len(rows.target))
    singletons = []
    for subject in np.unique(rows.subject):
        for block in np.unique(rows.block[rows.subject == subject]):
            at_run = (rows.subject == subject) & (rows.block == block)
            for offset in range(len(OFFSETS)):
                indices = np.flatnonzero(at_run & (rows.offset == offset))
                ordered = indices[np.argsort(rows.trial[indices], kind="stable")]
                index[ordered] = np.roll(ordered, -1)
                if len(ordered) == 1 and offset == 0:
                    singletons.append((int(subject), int(block)))
    return index, singletons


class TemporalNet(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Conv1d(channels, 16, kernel_size=3),
            nn.ReLU(),
            nn.Conv1d(16, 16, kernel_size=3),
            nn.ReLU(),
            nn.Flatten(),
        )
        self.predictor = nn.Sequential(nn.Linear(16 * 12 + 8, 32), nn.ReLU(), nn.Linear(32, 2))

    def forward(self, bins, auxiliary):
        return self.predictor(torch.cat((self.encoder(bins), auxiliary), dim=1))


def torch_inputs(arrays):
    bins, auxiliary = arrays
    return (
        torch.from_numpy(np.ascontiguousarray(bins.transpose(0, 2, 1), dtype=np.float32)),
        torch.from_numpy(np.ascontiguousarray(auxiliary, dtype=np.float32)),
    )


def schedule_for_seed(subjects, seed, epochs=EPOCHS):
    rng = np.random.default_rng(seed)
    groups = [np.flatnonzero(subjects == number) for number in np.unique(subjects)]
    group_sizes = np.array([len(group) for group in groups])
    group_starts = np.r_[0, np.cumsum(group_sizes)[:-1]]
    row_list = np.concatenate(groups)
    batches = (len(subjects) + BATCH - 1) // BATCH
    people = rng.integers(len(groups), size=(epochs, batches, BATCH))
    locations = rng.integers(group_sizes[people])
    return row_list[group_starts[people] + locations]


def fit_temporal(model_channels, inputs, target, initial_bias, seed, schedule):
    torch.manual_seed(seed)
    model = TemporalNet(model_channels)
    with torch.no_grad():
        model.predictor[-1].weight.zero_()
        model.predictor[-1].bias.copy_(torch.from_numpy(initial_bias.astype(np.float32)))
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.001, weight_decay=0.0001)
    history = []
    for epoch in schedule:
        batch_losses = []
        for indices in epoch:
            bins, auxiliary = (array[indices] for array in inputs)
            loss = nn.functional.mse_loss(model(bins, auxiliary), target[indices])
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
            batch_losses.append(loss.detach())
        mean_loss = float(torch.stack(batch_losses).mean())
        if not np.isfinite(mean_loss):
            raise ValueError("Nonfinite temporal training loss")
        history.append(mean_loss)
    return model, history


def save_parameters(model):
    return {name: parameter.detach().numpy().copy() for name, parameter in model.state_dict().items()}


def restore_parameters(channels, parameters):
    model = TemporalNet(channels)
    expected = model.state_dict()
    if set(parameters) != set(expected):
        raise ValueError("Saved parameter names do not match architecture")
    tensors = {}
    for name, value in parameters.items():
        if value.dtype != np.float32 or value.shape != tuple(expected[name].shape) or not np.isfinite(value).all():
            raise ValueError(f"Invalid persisted temporal parameter {name}")
        tensors[name] = torch.from_numpy(value)
    model.load_state_dict(tensors)
    return model.eval()


@torch.no_grad()
def predict_temporal(model, inputs):
    bins, auxiliary = inputs
    return np.concatenate([
        model(bins[start:start+1024], auxiliary[start:start+1024]).numpy()
        for start in range(0, len(bins), 1024)
    ])
