"""Separate entry points for role-bound preflight, TRAIN fit and frozen DEV score."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import time

import numpy as np
import torch

from forecast import (
    ANCHOR_LEAD, AXES, BATCH, CHANNELS, DENOMINATOR_TRIALS_PER_RUN, EPOCHS,
    MODEL_CHANNELS, OFFSETS, SEEDS, Rows, feature_arrays, featurize, fit_ridge,
    fit_temporal, predict_temporal, restore_parameters, ridge_matrix,
    rotated_rows, save_parameters, schedule_for_seed, subject_weights,
    timing_prediction, torch_inputs, train_normalization, validate_run,
)


CODE = Path(__file__).resolve().parent
DESIGN_SHA256 = "69518d134127f762d7199f1fb64b28c471655f158d63bf8592199388af03ec35"
ROLE_FREEZE_SHA256 = "5ba02aa108cf9406dd48bcfa5576f50f3aae3d2ea033fda968a4de52c9fcea6b"
SOURCE_DOI = "10.6084/m9.figshare.29666735.v3"
ROLES = {
    "train": ["sub-37", "sub-03", "sub-15", "sub-17", "sub-38", "sub-43"],
    "development": ["sub-41", "sub-12", "sub-26"],
}
CODE_FILES = ("forecast.py", "run.py", "IMPLEMENTATION-RULES.json")
RUN_FIELDS = ("eeg_uv", "angle_deg", "valid", "trial_start_tick", "cue_tick", "return_tick")
FIT_FILES = (
    "fit-metadata.json", "fit-arrays.npz", "training-histories.json", "train-support.json",
    *(f"{head}-{seed}.npz" for head in MODEL_CHANNELS for seed in SEEDS),
)
NORMALIZATION_SHAPES = {
    "bins_center": (10,), "bins_scale": (10,), "anchor_center": (2,),
    "anchor_scale": (2,), "residual_center": (2,), "residual_scale": (2,),
}


def sha256(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def local_file(folder, filename):
    filename = Path(filename)
    if filename.is_absolute() or filename.parent != Path("."):
        raise ValueError("Manifest paths must name local files")
    path = folder / filename
    if not path.is_file() or path.is_symlink():
        raise ValueError(f"Missing or non-local file: {filename}")
    return path


def code_hashes():
    design = CODE / "DESIGN.json"
    if design.exists() and sha256(design) != DESIGN_SHA256:
        raise ValueError("Original frozen DESIGN.json changed")
    return {filename: sha256(CODE / filename) for filename in CODE_FILES}


def load_json(path):
    with path.open(encoding="utf-8") as stream:
        return json.load(stream)


def write_json(path, data):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(data, stream, allow_nan=False, indent=2)
        stream.write("\n")


def write_npz(path, arrays):
    with path.open("xb") as stream:
        np.savez_compressed(stream, **arrays)


def load_role(manifest_path, manifest_sha256, role):
    if manifest_path.is_symlink():
        raise ValueError("Role manifest must be a direct file")
    manifest_path = manifest_path.resolve(strict=True)
    suffix = ("private", role, "runs", "MANIFEST.json")
    if manifest_path.parts[-len(suffix):] != suffix:
        raise ValueError("Manifest path disagrees with the selected role")
    if sha256(manifest_path) != manifest_sha256:
        raise ValueError("Manifest disagrees with the accepted role hash")
    manifest = load_json(manifest_path)
    expected = {
        "role": role, "role_freeze_sha256": ROLE_FREEZE_SHA256, "deposit": SOURCE_DOI,
        "sample_rate_hz": 512, "eeg_order": list(CHANNELS), "eeg_units": "microvolts",
        "angle_columns_degrees": ["positive extension", "positive radial deviation"],
    }
    if any(manifest.get(key) != value for key, value in expected.items()):
        raise ValueError("Source role, clock, unit or channel metadata disagrees with the protocol")
    participants = manifest["participant_order"]
    if [item["subject"] for item in participants] != ROLES[role]:
        raise ValueError("Unexpected role subjects or ordering")

    all_runs = []
    support = {
        "role": role,
        "manifest_sha256": manifest_sha256,
        "archive_manifest_sha256": manifest["archive_manifest_sha256"],
        "rows_per_trial": len(OFFSETS),
        "nominal_trials": len(participants) * 8 * DENOMINATOR_TRIALS_PER_RUN,
        "participants": [],
    }
    seen_files = set()
    for subject, item in enumerate(participants):
        runs, missing = item["runs"], item["missing_task_blocks"]
        expected_ordinals = list(range(1, 9))
        if sorted(row["task_block_ordinal"] for row in runs + missing) != expected_ordinals:
            raise ValueError("Each official task ordinal needs exactly one source or missing disposition")
        if sorted(row["task_block_ordinal"] for row in runs) != [row["task_block_ordinal"] for row in runs]:
            raise ValueError("Staged acquisitions are out of verified order")
        if item["excluded_baseline_archive_runs"] != ["01", "11"]:
            raise ValueError("Source baseline disposition changed")
        if len({run["archive_run"] for run in runs + missing}) != 8:
            raise ValueError("Duplicate or ambiguous source acquisition labels")
        tally = {
            "subject": item["subject"], "source_archive_sha256": item["source_archive_sha256"],
            "baseline_archive_runs_excluded": item["excluded_baseline_archive_runs"],
            "missing_task_blocks": missing, "runs": [],
        }
        for run in runs:
            ordinal = run["task_block_ordinal"]
            if run["archive_run"] in item["excluded_baseline_archive_runs"]:
                raise ValueError("Source baseline entered task sampling")
            expected_filename = f"{item['subject']}_task-block-{ordinal:02d}_run-{run['archive_run']}.npz"
            path = local_file(manifest_path.parent, run["npz"])
            if (path.name != expected_filename or path in seen_files or
                    path.stat().st_size != run["npz_bytes"] or sha256(path) != run["npz_sha256"]):
                raise ValueError("Source run file disagrees with its role manifest")
            seen_files.add(path)
            with np.load(path, allow_pickle=False) as data:
                eeg, angle, valid, starts, cues, returns = (data[field] for field in RUN_FIELDS)
            validate_run(eeg, angle, valid, starts, cues, returns, run["stored_rows"])
            if len(cues) != run["cue_count"]:
                raise ValueError("Source cue count disagrees with run receipt")
            features, exclusions = featurize(eeg, angle, valid, cues, returns, subject, ordinal)
            all_runs.append(features)
            tally["runs"].append({
                "task_block": ordinal, "archive_run": run["archive_run"], "npz_sha256": run["npz_sha256"],
                **exclusions,
            })
        tally["eligible_trials"] = sum(run["eligible_trials"] for run in tally["runs"])
        tally["recorded_trials"] = sum(run["recorded_trials"] for run in tally["runs"])
        tally["eligible_blocks"] = sum(run["eligible_trials"] > 0 for run in tally["runs"])
        tally["meets_minimum"] = tally["eligible_trials"] >= 20 and tally["eligible_blocks"] >= 2
        support["participants"].append(tally)
    support["minimum_met"] = all(person["meets_minimum"] for person in support["participants"])
    for key in ("eligible_trials", "recorded_trials"):
        support[key] = sum(person[key] for person in support["participants"])
    support["materialized_rows"] = support["eligible_trials"] * len(OFFSETS)
    return Rows.combine(all_runs), support


def runtime(threads):
    for pool in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "BLIS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        if os.environ.get(pool) != "1":
            raise ValueError(f"Set {pool}=1 before importing numeric libraries")
    torch.set_num_threads(threads)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    if torch.version.cuda is not None or torch.version.hip is not None:
        raise ValueError("This experiment uses the qualified CPU-only PyTorch build")
    return {
        "device": "CPU only", "python": platform.python_version(), "numpy": np.__version__,
        "torch": str(torch.__version__), "torch_intra_op_threads": torch.get_num_threads(),
        "torch_inter_op_threads": torch.get_num_interop_threads(), "torch_build": torch.__config__.show(),
        "numpy_config": np.show_config(mode="dicts"),
        "affinity": sorted(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else None,
        "loader_workers": 0, "processes": 1,
        "blas_pool_requested_threads": 1, "deterministic_algorithms": True,
        "float": "NumPy float64 feature/aggregations/Ridge, PyTorch float32",
    }


def fit(rows, support, output, environment, started):
    output.mkdir(exist_ok=False)
    write_json(output / "train-support.json", support)
    if not support["minimum_met"]:
        raise ValueError("Required TRAIN support not met")
    preprocessing_start = time.perf_counter()
    normalization = train_normalization(rows)
    weights = subject_weights(rows)
    timing = timing_prediction(rows, weights)
    target = (rows.residual - normalization["residual_center"]) / normalization["residual_scale"]
    tensor_target = torch.from_numpy(target.astype(np.float32))
    initial_bias = -normalization["residual_center"] / normalization["residual_scale"]
    arrays = dict(normalization, timing_mean_deg=timing)
    heads = {}
    for name, channels in MODEL_CHANNELS.items():
        features = feature_arrays(rows, normalization, channels)
        arrays[f"ridge_{name}"] = fit_ridge(ridge_matrix(*features), target, weights)
        heads[name] = torch_inputs(features)
    write_npz(output / "fit-arrays.npz", arrays)
    preprocessing_seconds = time.perf_counter() - preprocessing_start
    histories = {}
    counts = {}
    for seed in SEEDS:
        schedule = schedule_for_seed(rows.subject, seed)
        histories[str(seed)] = {
            "sampled_row_order_sha256": hashlib.sha256(schedule.astype("<i8", copy=False).tobytes()).hexdigest(),
            "batches_per_epoch": schedule.shape[1],
        }
        for name, channels in MODEL_CHANNELS.items():
            head_start = time.perf_counter()
            model, losses = fit_temporal(channels, heads[name], tensor_target, initial_bias, seed, schedule)
            write_npz(output / f"{name}-{seed}.npz", save_parameters(model))
            counts[name] = sum(parameter.numel() for parameter in model.parameters())
            histories[str(seed)][name] = {
                "normalized_sampled_train_mse_by_epoch": losses,
                "fit_and_export_seconds": time.perf_counter() - head_start,
            }
    write_json(output / "training-histories.json", histories)
    write_json(output / "fit-metadata.json", {
        "design_sha256": DESIGN_SHA256, "role_freeze_sha256": ROLE_FREEZE_SHA256,
        "code_sha256": code_hashes(), "environment": environment,
        "epochs": EPOCHS, "batch_rows": BATCH, "seeds": SEEDS,
        "parameter_count": counts, "preprocessing_and_ridge_seconds": preprocessing_seconds,
        "local_invocation_seconds_before_seal": time.perf_counter() - started,
        "selection": "All exact final epochs, three-seed mean in degrees, no role other than TRAIN read",
    })
    seal = {
        "design_sha256": DESIGN_SHA256, "role": "train",
        "source_manifest_sha256": support["manifest_sha256"], "code_sha256": code_hashes(),
        "sealed_at_utc_epoch": time.time(),
        "files_sha256": {filename: sha256(output / filename) for filename in FIT_FILES},
    }
    write_json(output / "FIT-SEAL.json", seal)
    print(f"TRAIN seal {sha256(output / 'FIT-SEAL.json')}", flush=True)


def verified_seal(fit_dir, seal_hash):
    seal_path = local_file(fit_dir, "FIT-SEAL.json")
    if sha256(seal_path) != seal_hash:
        raise ValueError("Expected immutable TRAIN seal is absent or changed")
    seal = load_json(seal_path)
    if ((seal["role"], seal["design_sha256"], seal["code_sha256"]) != ("train", DESIGN_SHA256, code_hashes())
            or set(seal["files_sha256"]) != set(FIT_FILES)):
        raise ValueError("Checkpoint scope, code or frozen artifact inventory changed")
    for filename, digest in seal["files_sha256"].items():
        if sha256(local_file(fit_dir, filename)) != digest:
            raise ValueError(f"Frozen TRAIN artifact changed: {filename}")
    return seal


def degrees(standardized_residual, rows, normalization):
    return rows.anchor + standardized_residual * normalization["residual_scale"] + normalization["residual_center"]


def score_predictions(rows, fit_dir):
    with np.load(fit_dir / "fit-arrays.npz", allow_pickle=False) as archive:
        arrays = dict(archive)
    shapes = NORMALIZATION_SHAPES | {
        "timing_mean_deg": (len(OFFSETS), 2),
        **{f"ridge_{name}": (16 * channels + 2 + len(OFFSETS), 2) for name, channels in MODEL_CHANNELS.items()},
    }
    if set(arrays) != set(shapes) or any(
        array.dtype != np.float64 or array.shape != shapes[name] or not np.isfinite(array).all() or
        (name.endswith("_scale") and (array <= 0).any()) for name, array in arrays.items()
    ):
        raise ValueError("Invalid frozen normalization or regression arrays")
    order, singletons = rotated_rows(rows)
    methods = {
        "persistence": rows.anchor,
        "linear_velocity": rows.anchor + (rows.anchor - rows.past) * 2,
        "training_timing": arrays["timing_mean_deg"][rows.offset],
    }
    features = {
        "motion": feature_arrays(rows, arrays, MODEL_CHANNELS["motion"]),
        "combined": feature_arrays(rows, arrays, MODEL_CHANNELS["combined"]),
        "rotated_eeg": feature_arrays(rows, arrays, MODEL_CHANNELS["combined"], order),
    }
    for name, data in features.items():
        source_name = "combined" if name == "rotated_eeg" else name
        methods[f"{name}_ridge"] = degrees(ridge_matrix(*data) @ arrays[f"ridge_{source_name}"], rows, arrays)
        inputs = torch_inputs(data)
        seed_predictions = []
        for seed in SEEDS:
            with np.load(fit_dir / f"{source_name}-{seed}.npz", allow_pickle=False) as archive:
                model = restore_parameters(MODEL_CHANNELS[source_name], dict(archive))
            prediction = degrees(predict_temporal(model, inputs).astype(np.float64), rows, arrays)
            methods[f"{name}_temporal_seed_{seed}"] = prediction
            seed_predictions.append(prediction)
        methods[f"{name}_temporal"] = np.mean(seed_predictions, axis=0)
    if not all(value.shape == rows.target.shape and np.isfinite(value).all() for value in methods.values()):
        raise ValueError("Incomplete or nonfinite matched predictions")
    return methods, singletons


def error_metrics(errors, weights=None):
    mse_axis = np.average(np.square(errors), axis=0, weights=weights)
    mae_axis = np.average(np.abs(errors), axis=0, weights=weights)
    return {
        "rows": len(errors),
        "mse_deg2": float(mse_axis.mean()),
        "rmse_deg": float(np.sqrt(mse_axis.mean())),
        "axes": {
            axis: {"mse_deg2": float(mse_axis[i]), "rmse_deg": float(np.sqrt(mse_axis[i])),
                   "mae_deg": float(mae_axis[i])}
            for i, axis in enumerate(AXES)
        },
    }


def balanced_weights(subjects):
    _, indices, counts = np.unique(subjects, return_inverse=True, return_counts=True)
    return 1.0 / (len(counts) * counts[indices])


def scored_results(rows, methods, role):
    errors = {name: values - rows.target for name, values in methods.items()}
    complete = np.full(len(rows.target), True)

    def metrics(mask, participants_balanced=False):
        weights = balanced_weights(rows.subject[mask]) if participants_balanced else None
        return {name: error_metrics(values[mask], weights) for name, values in errors.items()}

    by_person = {}
    by_block = {}
    for subject, name in enumerate(ROLES[role]):
        at_person = rows.subject == subject
        by_person[name] = {"all": metrics(at_person), "blocks": {}, "offsets": {}}
        for offset, ticks in enumerate(OFFSETS):
            by_person[name]["offsets"][str(ticks)] = metrics(at_person & (rows.offset == offset))
        for block in np.unique(rows.block[at_person]):
            label = f"{block:02d}"
            mask = at_person & (rows.block == block)
            by_person[name]["blocks"][label] = {
                "all": metrics(mask), "offsets": {
                    str(ticks): metrics(mask & (rows.offset == offset))
                    for offset, ticks in enumerate(OFFSETS)
                },
            }
    for block in np.unique(rows.block):
        mask = rows.block == block
        by_block[f"{block:02d}"] = metrics(mask, participants_balanced=True)
    return {
        "participant_balanced": metrics(complete, participants_balanced=True),
        "pooled_sensitivity": metrics(complete),
        "by_offset_ticks_participant_balanced": {
            str(ticks): metrics(rows.offset == offset, participants_balanced=True)
            for offset, ticks in enumerate(OFFSETS)
        },
        "by_task_block_participant_balanced": by_block,
        "by_participant": by_person,
    }


def contrast(table, suffix=""):
    motion = table[f"motion_temporal{suffix}"]["rmse_deg"]
    combined = table[f"combined_temporal{suffix}"]["rmse_deg"]
    return combined - motion


def development_score(rows, support, fit_dir, seal_hash, seal, output, environment, started):
    output.mkdir(exist_ok=False)
    write_json(output / "development-support.json", support)
    if not support["minimum_met"]:
        raise ValueError("Required DEV support not met")
    predictions, singleton_blocks = score_predictions(rows, fit_dir)
    results = scored_results(rows, predictions, "development")
    primary = {
        "contrast": "combined temporal minus motion temporal RMSE in degrees",
        "participant_balanced_delta_rmse_deg": contrast(results["participant_balanced"]),
        "pooled_delta_rmse_deg": contrast(results["pooled_sensitivity"]),
        "seeds_delta_rmse_deg": {
            str(seed): contrast(results["participant_balanced"], f"_seed_{seed}") for seed in SEEDS
        },
        "by_participant_delta_rmse_deg": {
            person: contrast(scores["all"]) for person, scores in results["by_participant"].items()
        },
    }
    if verified_seal(fit_dir, seal_hash) != seal:
        raise ValueError("Checkpoint seal changed during development scoring")
    write_json(output / "development-results.json", {
        "role": "development", "design_sha256": DESIGN_SHA256, "train_seal_sha256": seal_hash,
        "development_manifest_sha256": support["manifest_sha256"],
        "code_sha256": code_hashes(), "environment": environment,
        "invocation_seconds_before_report": time.perf_counter() - started,
        "sample_rate_hz": 512, "nominal_forecast_horizon_samples": ANCHOR_LEAD,
        "rotation_singleton_blocks": [
            [ROLES["development"][subject], f"{block:02d}"] for subject, block in singleton_blocks
        ],
        "claim_scope": "Fixed offline development, stored clock only, no refit or score-conditioned selection",
        "primary": primary, **results,
    })
    print(f"DEV result {sha256(output / 'development-results.json')}", flush=True)


def main():
    started = time.perf_counter()
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--threads", required=True, type=int)
    action = parser.add_subparsers(dest="action", required=True)
    for name in ("preflight-train", "fit", "score-development"):
        command = action.add_parser(name)
        command.add_argument("--manifest", required=True, type=Path)
        command.add_argument("--manifest-sha256", required=True)
        command.add_argument("--output", required=True, type=Path)
        if name == "score-development":
            command.add_argument("--fit-dir", required=True, type=Path)
            command.add_argument("--fit-seal-sha256", required=True)
    args = parser.parse_args()
    environment = runtime(args.threads)
    code_hashes()
    if args.action == "score-development":
        seal = verified_seal(args.fit_dir, args.fit_seal_sha256)
        rows, support = load_role(args.manifest, args.manifest_sha256, "development")
        if support["manifest_sha256"] == seal["source_manifest_sha256"]:
            raise ValueError("TRAIN custody overlaps DEV")
        development_score(rows, support, args.fit_dir, args.fit_seal_sha256, seal, args.output, environment, started)
        return
    rows, support = load_role(args.manifest, args.manifest_sha256, "train")
    if args.action == "preflight-train":
        write_json(args.output, support)
        if not support["minimum_met"]:
            raise ValueError("Required TRAIN support not met")
        print(f"TRAIN prescore support {sha256(args.output)}", flush=True)
        return
    fit(rows, support, args.output, environment, started)


if __name__ == "__main__":
    main()
