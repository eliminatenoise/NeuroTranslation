#!/bin/sh
set -eu
cd -P "$(dirname "$0")"
exec open "$PWD/index.html"
