#!/bin/sh
set -eu
cd -P "$(dirname "$0")"
exec xdg-open "$PWD/index.html"
