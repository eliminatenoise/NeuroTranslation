Open the browser comparison

Extract all files into a single folder. Open the launcher for your computer, or
open index.html in a browser. The Simple edition has the recorded comparison
and a coordinate editor. The Technical edition has the calculation and results.

The editor uses invented numbers until you enter your own. The recorded results
use three already evaluated dates from one macaque. The browser runs the
comparison from the files in this folder. The source links open online.

On Linux, run Open on Linux.sh.
On macOS, open Open on macOS.command.
On Windows, open Open on Windows.cmd.

The saved neural forecast rows and Python replay are on GitHub.
https://github.com/eliminatenoise/NeuroTranslation/tree/main/benchmarks/cortical-movement-blend/position-history
