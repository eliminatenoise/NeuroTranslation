@echo off
start "" "%~dp0Open insole pressure.html"
