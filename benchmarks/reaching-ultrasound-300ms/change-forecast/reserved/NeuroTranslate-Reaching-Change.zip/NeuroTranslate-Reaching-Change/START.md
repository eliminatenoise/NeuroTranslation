# Run the reaching-change forecast

Extract the ZIP into one folder. Install Python 3.10 or later. If you need NumPy, use the install command for your computer.

Open a terminal in the extracted folder and run the launcher for your computer.

| Computer | Install NumPy | Launcher |
| --- | --- | --- |
| Windows, Command Prompt | `py -3 -m pip install numpy` | `Launch-Windows.cmd` |
| macOS | `python3 -m pip install numpy` | `sh Launch-macOS.command` |
| Linux | `python3 -m pip install numpy` | `sh Launch-Linux.sh` |

On Windows, use `python -m pip install numpy` if the `py` launcher is unavailable. The included launcher uses the same fallback.

The launcher reads invented measurements from `example.json`. The output shows the predicted **change in point spread** in millimetres, in triceps and brachialis order. Positive values mean wider spread and negative values mean narrower spread. All five methods run on the same example.

Use `--input` followed by your compatible JSON file to run the program on another history. The forecasts use ten 20 ms slots from before the starting time. [Input fields and units](INPUT.md)

[Simple study](SIMPLE.md) · [Technical study](TECHNICAL.md) · [Measured scores](RESULTS.json)
