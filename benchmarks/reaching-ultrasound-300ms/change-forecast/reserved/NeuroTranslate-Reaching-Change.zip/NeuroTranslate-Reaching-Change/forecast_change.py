"""Forecast 300 ms changes in ultrasound point spread using NumPy."""

from argparse import ArgumentParser
import json
from pathlib import Path

import numpy as np

from kernels import normalized, relative_history, residual


HERE = Path(__file__).resolve().parent
FLAGS = (12, 13, 14, 15, 19, 20, 21)


def histories(value):
    data = np.asarray(value, dtype=np.float64)
    if data.ndim == 2:
        data = data[None]
    if data.ndim != 3 or data.shape[1] != 10 or data.shape[2] not in (22, 26) or not len(data):
        raise ValueError('Supply ten history rows with 22 or 26 numbers per row.')
    past = data[..., :22]
    if not np.isfinite(past).all():
        raise ValueError('Motion and muscle inputs need finite numbers.')
    if not np.isin(past[..., FLAGS], (0, 1)).all():
        raise ValueError('Use 0 for an absent reading and 1 for an available reading.')
    return {'absolute': past, 'relative': relative_history(past)}


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def read_weights(path):
    with np.load(path, allow_pickle=False) as archive:
        return {name: archive[name].astype(np.float64) for name in archive.files}


def bundle():
    configuration = read_json(HERE / 'methods.json')
    norm = read_json(HERE / 'normalizer.json')
    weights = {name: read_weights(HERE / name) for row in configuration['learned'] for name in row['files']}
    coefficients = read_weights(HERE / 'ridge.npz')[configuration['linear']['name']]
    return configuration, norm, weights, coefficients


def forecast(value, bundle_data):
    configuration, norm, weights, coefficients = bundle_data
    frames = histories(value)
    results = {configuration['zero']: np.zeros((len(frames['absolute']), 2))}
    linear = configuration['linear']
    source = linear['representation']
    past = normalized(frames[source], norm['features'][source], linear['motion_only']).astype(np.float64)
    results[linear['name']] = coefficients[0] + past.reshape(len(past), -1) @ coefficients[1:]
    individual = {}
    scale = np.asarray(norm['target_scale_mm'])
    for row in configuration['learned']:
        frame = row['representation']
        past = normalized(frames[frame], norm['features'][frame], row['motion_only']).astype(np.float64)
        seeds = []
        for seed, name in zip(configuration['seeds'], row['files'], strict=True):
            estimate = residual(past, weights[name], row['passes']) * scale
            individual[f'{row["name"]}_seed{seed}'] = estimate
            seeds.append(estimate)
        results[row['name']] = np.mean(seeds, axis=0)
    if not all(np.isfinite(row).all() for row in results.values()):
        raise ValueError('The input values are too large to forecast.')
    return results, individual


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=HERE / 'example.json')
    args = parser.parse_args()
    source = read_json(args.input)
    results, _ = forecast(source['history'], bundle())
    response = {'forecast_horizon_ms': 300, 'tissue_order': ['triceps', 'brachialis'],
                'change_in_spread_mm': {name: values.tolist() for name, values in results.items()}}
    print(json.dumps(response, indent=2))


if __name__ == '__main__':
    main()
