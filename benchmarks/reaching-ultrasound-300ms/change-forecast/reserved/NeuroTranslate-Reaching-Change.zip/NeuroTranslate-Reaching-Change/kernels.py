"""Numerical kernels taken from the verified reaching runtimes."""

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

VALUE_COLUMNS = np.r_[0:12, 16:19]
AVAILABILITY_COLUMNS = np.r_[np.repeat(np.arange(12, 16), 3), 19:22]


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -60.0, 60.0)))


def update(incoming, state, weight, bias):
    hidden = state @ weight.T + bias
    input_reset, input_update, input_candidate = np.split(incoming, 3, axis=1)
    hidden_reset, hidden_update, hidden_candidate = np.split(hidden, 3, axis=1)
    reset = sigmoid(input_reset + hidden_reset)
    keep = sigmoid(input_update + hidden_update)
    candidate = np.tanh(input_candidate + reset * hidden_candidate)
    # The trained runtime stores each successive hidden state in FP32.
    return (candidate + keep * (state - candidate)).astype(np.float32)


def residual(inputs, weights, passes):
    conv = weights['conv.weight']
    history = np.pad(inputs, ((0, 0), (2, 0), (0, 0)))
    kernels = sliding_window_view(history, 3, axis=1).reshape(len(inputs), 10, -1)
    linear = kernels @ conv.reshape(len(conv), -1).T + weights['conv.bias']
    encoded = linear * sigmoid(linear)
    incoming = encoded @ weights['recurrent.weight_ih_l0'].T + weights['recurrent.bias_ih_l0']
    state = np.zeros((len(inputs), len(conv)))
    for time in range(10):
        state = update(incoming[:, time], state, weights['recurrent.weight_hh_l0'],
                       weights['recurrent.bias_hh_l0'])
    known = state @ weights['shared_step.weight_ih'].T + weights['shared_step.bias_ih']
    for _ in range(passes):
        state = update(known, state, weights['shared_step.weight_hh'], weights['shared_step.bias_hh'])
    return state @ weights['out.weight'].T + weights['out.bias']


def normalized(history, norm, motion_only=False):
    result = np.zeros((*history.shape[:-1], 26), dtype=np.float32)
    data = np.array(history, copy=True)
    measured = data[..., AVAILABILITY_COLUMNS] > .5
    scaled = (data[..., VALUE_COLUMNS] - np.asarray(norm['mean'])) / np.asarray(norm['scale'])
    data[..., VALUE_COLUMNS] = np.where(measured, scaled, 0)
    limit = 16 if motion_only else 22
    result[..., :limit] = data[..., :limit]
    assert np.isfinite(result).all()
    return result


def relative_history(absolute):
    result = absolute.copy()
    for marker in range(4):
        first = np.argmax(absolute[..., 12 + marker] > .5, axis=1)
        coordinates = absolute[..., marker * 3:(marker + 1) * 3]
        position = coordinates[np.arange(len(absolute)), first]
        available = absolute[..., 12 + marker:13 + marker] > .5
        result[..., marker * 3:(marker + 1) * 3] = np.where(available, coordinates - position[:, None], 0)
    return result
