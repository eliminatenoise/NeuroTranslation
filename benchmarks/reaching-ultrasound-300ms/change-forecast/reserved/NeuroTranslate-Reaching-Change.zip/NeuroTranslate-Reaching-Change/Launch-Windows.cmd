@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 (
  python forecast_change.py %*
) else (
  py -3 forecast_change.py %*
)
