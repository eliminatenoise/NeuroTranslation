# Readings for the change forecast

Put `history.json` in the extracted folder or pass its full path in quotes. Follow the Python and NumPy setup for your computer in [START.md](START.md).

| Computer | Run a custom input |
| --- | --- |
| Windows, Command Prompt | `Launch-Windows.cmd --input "history.json"` |
| macOS | `sh Launch-macOS.command --input "history.json"` |
| Linux | `sh Launch-Linux.sh --input "history.json"` |

In the JSON file, give `history` ten rows from the 200 milliseconds before the forecast starts. Put the oldest slot first. Each row has 22 values in the order listed in `methods.json` under `field_order`.

| Columns | Reading |
| --- | --- |
| 1–12 | x, y and z position of hand, forearm, elbow and upper arm, measured relative to shoulder, in millimetres |
| 13–16 | Position availability in the same marker order |
| 17–19 | Root mean square voltages over the slot for triceps, biceps and palm, in millivolts |
| 20–22 | Voltage availability in the same order |

Use the newest position within each slot and fill availability fields with 1 for measured or 0 for absent. Put 0 in missing value fields. A 26-column input from the earlier reaching preview also works. The program uses the first 22 fields. For multiple histories, provide one ten-row array per case under `history`. Output arrays follow that order.

The package preserves every stored FP32 weight. NumPy uses 64-bit arithmetic for gate and matrix calculations and rounds normalized inputs and each successive recurrent state to 32 bits. Both seeds contribute to each printed recurrent forecast. [Test methods and results](TECHNICAL.md)
