"""Frozen WristMotion surface EMG forecast. The CLI accepts TRAIN and released DEV only."""

import argparse
from dataclasses import dataclass, fields
import hashlib
import io
from itertools import product
import json
import os
from pathlib import Path
import sys
import types
import zipfile

import numpy as np


HOME = Path(__file__).resolve().parent
DESIGN_SHA = "8549f19e5446a3dd44a12c16eae5a3df0795e2cbd5166d6ae188ea9d1f709fe7"
OFFSETS = np.array([384, 512, 640, 768, 896, 1024])
HISTORY = np.arange(-383, -127)
ANCHOR_LEAD = 128
VELOCITY_LEAD = 64
BIN_COUNT = 16
BIN_WIDTH = 16
TRIALS_PER_BLOCK = 40
AXES = ("extension", "radial_deviation")
HEADS = {"motion_ridge": 2, "motion_emg_ridge": 6, "motion_emg_eeg_ridge": 14}
CONTRASTS = {
    "add_surface_emg": ("motion_emg_ridge", "motion_ridge"),
    "add_scalp_eeg_after_emg": ("motion_emg_eeg_ridge", "motion_emg_ridge"),
    "aligned_vs_rotated_emg": ("motion_emg_ridge", "rotate_emg"),
    "aligned_vs_rotated_eeg": ("motion_emg_eeg_ridge", "rotate_eeg"),
}


def sha_bytes(payload):
    return hashlib.sha256(payload).hexdigest()


def hash_file(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_pinned(path, expected):
    raw = path.read_bytes()
    if sha_bytes(raw) != expected:
        raise ValueError(f"Unexpected SHA256: {path}")
    return raw


def write_json(path, item):
    encoded = json.dumps(item, indent=2, allow_nan=False) + "\n"
    with path.open("x") as stream:
        stream.write(encoded)


def exact_module(name, path, expected):
    module = types.ModuleType(name)
    module.__file__ = str(path)
    source = read_pinned(path, expected)
    sys.modules[name] = module
    exec(compile(source, str(path), "exec"), module.__dict__)
    return module


def hash_archive(path):
    md5 = hashlib.md5(usedforsecurity=False)
    sha = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1_048_576), b""):
            size += len(block)
            md5.update(block)
            sha.update(block)
    return size, md5.hexdigest(), sha.hexdigest()


@dataclass(frozen=True)
class Rows:
    bins: np.ndarray
    anchor: np.ndarray
    past: np.ndarray
    target: np.ndarray
    slot: np.ndarray
    person: np.ndarray
    block: np.ndarray
    trial: np.ndarray

    @classmethod
    def join(cls, runs):
        return cls(**{
            field.name: np.concatenate([getattr(run, field.name) for run in runs])
            for field in fields(cls)
        })


def collect_rows(eeg, captured_emg, angles, valid, cues, returns, person, block):
    targets = cues[:, None] + OFFSETS
    histories = targets[:, :, None] + HISTORY
    bounded = ((histories[:, :, 0] >= cues[:, None]) &
               (targets < returns[:, None]) & (targets < len(angles))).all(axis=1)
    trial = np.flatnonzero(bounded)
    target_ticks = targets[trial]
    support = histories[trial]
    encoder_valid = valid[target_ticks].all(axis=(1, 2)) & valid[support].all(axis=(1, 2, 3))
    eeg_valid = np.isfinite(eeg[support]).all(axis=(1, 2, 3))
    emg_valid = np.isfinite(captured_emg[support]).all(axis=(1, 2, 3))
    keep = encoder_valid & eeg_valid & emg_valid
    target_ticks = target_ticks[keep].ravel()
    kept_trial = trial[keep]
    input_ticks = support[keep].reshape(len(target_ticks), len(HISTORY))
    anchor = angles[target_ticks - ANCHOR_LEAD]
    past = angles[target_ticks - ANCHOR_LEAD - VELOCITY_LEAD]
    motion = angles[input_ticks].reshape(-1, BIN_COUNT, BIN_WIDTH, 2).mean(axis=2)
    scalp = eeg[input_ticks].reshape(-1, BIN_COUNT, BIN_WIDTH, 8).mean(axis=2, dtype=np.float64)
    emg = captured_emg[input_ticks].astype(np.float64).reshape(-1, BIN_COUNT, BIN_WIDTH, 4, 2)
    differential = emg[..., 0] - emg[..., 1]
    rms = np.sqrt(np.mean(np.square(differential), axis=2))
    bins = np.concatenate((motion - anchor[:, None, :], rms, scalp), axis=2)
    if not np.isfinite(bins).all():
        raise ValueError("Nonfinite feature on eligible support")
    support_emg = captured_emg[np.unique(input_ticks)]
    at_rail = (support_emg == -32768) | (support_emg == 32767)
    exclusions = {
        "recorded": len(cues),
        "eligible": len(kept_trial),
        "outside_window": int((~bounded).sum()),
        "invalid_encoder": int((~encoder_valid).sum()),
        "nonfinite_eeg": int((~eeg_valid).sum()),
        "nonfinite_emg": int((~emg_valid).sum()),
        "invalid_on_bounded_joint_support": int((~keep).sum()),
        "emg_unique_feature_ticks": len(support_emg),
        "emg_rail_ticks_by_channel": at_rail.sum(axis=0).tolist(),
    }
    return Rows(
        bins, anchor, past, angles[target_ticks], np.tile(np.arange(len(OFFSETS)), len(kept_trial)),
        np.full(len(target_ticks), person), np.full(len(target_ticks), block),
        np.repeat(kept_trial, len(OFFSETS)),
    ), exclusions


def check_archive_members(parser, archive, participant, parent):
    stem = f"{participant}_task-WristPointingTask"
    eeg = parser.read_dictionary(archive, f"{participant}/eeg/{stem}_channels.tsv")
    motion = parser.read_dictionary(archive, f"{participant}/motion/{stem}_tracksys-BiomechWrist_channels.tsv")
    if [(entry["name"], entry["type"], entry["units"]) for entry in eeg] != [
        *((label, "EEG", "microV") for label in parser.EEG),
        *((label, "EMG", "microV") for label in parser.EMG),
    ]:
        raise ValueError("Unexpected channel labels, order or physical units")
    if [(entry["name"], entry["tracked_point"], entry["units"]) for entry in motion] != [
        ("X", "RightWrist", "rad"), ("Y", "RightWrist", "rad")
    ]:
        raise ValueError("Unexpected motion dictionary")
    observed = parser.archive_run_ids(archive, participant)
    expected = [(run, ordinal) for ordinal, run in enumerate(parser.TASK_RUN_IDS, 1) if run in observed]
    absent = [(run, ordinal) for ordinal, run in enumerate(parser.TASK_RUN_IDS, 1) if run not in observed]
    if [(row["archive_run"], row["task_block_ordinal"]) for row in parent["runs"]] != expected:
        raise ValueError("Primary manifest cannot verify the exact archive block ordinals")
    if [(row["archive_run"], row["task_block_ordinal"]) for row in parent["missing_task_blocks"]] != absent:
        raise ValueError("Primary manifest cannot verify the excluded archive block ordinals")
    return stem, absent


def read_block(parser, archive, runs_path, pid, stem, record, person):
    run = record["archive_run"]
    block = record["task_block_ordinal"]
    eeg_member = f"{pid}/eeg/{stem}_run-{run}_eeg.edf"
    motion_member = f"{pid}/motion/{stem}_tracksys-BiomechWrist_run-{run}_motion.tsv"
    npz_name = f"{pid}_task-block-{block:02d}_run-{run}.npz"
    if (record["npz"], record["eeg_member"], record["motion_member"]) != (npz_name, eeg_member, motion_member):
        raise ValueError("Source member and primary NPZ paths disagree")
    raw_eeg = archive.read(eeg_member)
    raw_motion = archive.read(motion_member)
    if (sha_bytes(raw_eeg), sha_bytes(raw_motion)) != (record["eeg_sha256"], record["motion_sha256"]):
        raise ValueError("Stored source payload does not match primary custody")
    signal, framing = parser.decode_edf(raw_eeg)
    starts, cues, returns = parser.trial_ticks(signal)
    counts, angles, valid = parser.coordinate_data(raw_motion, signal)
    if len(signal) != record["stored_rows"] or framing != record["source_record_framing"]:
        raise ValueError("EDF frame identity changed")
    primary_blob = read_pinned(runs_path / npz_name, record["npz_sha256"])
    with np.load(io.BytesIO(primary_blob), allow_pickle=False) as primary:
        values = {
            "eeg_uv": signal[:, :8].astype(np.float32),
            "raw_encoder": counts,
            "angle_deg": angles,
            "valid": valid,
            "cue_tick": cues,
            "return_tick": returns,
            "trial_start_tick": starts,
        }
        if len(primary.files) != len(values) or set(primary.files) != set(values):
            raise ValueError("Unexpected primary NPZ schema")
        for name, actual in values.items():
            cached = primary[name]
            if cached.dtype != actual.dtype or not np.array_equal(actual, cached, equal_nan=name == "angle_deg"):
                raise ValueError(f"Primary and EMG source disagree on {name}")
        rows, stats = collect_rows(
            values["eeg_uv"], signal[:, 8:16], angles, valid, cues, returns, person, block
        )
    stats.update({
        "archive_run": run, "task_block_ordinal": block,
        "same_archive_member_sha256": record["eeg_sha256"], "same_npz_sha256": record["npz_sha256"],
    })
    support_sha = sha_bytes(np.column_stack((rows.block, rows.trial, rows.slot)).astype("<i8").tobytes())
    stats["eligible_row_identity_sha256"] = support_sha
    return rows, stats


def collect_role(resource, name, design, primary_manifest_sha):
    source = design["source"]
    read_pinned(HOME / "CHANNEL-EVIDENCE.md", source["channel_evidence_sha256"])
    archive_root = resource / "private" / name / "archives"
    runs_root = resource / "private" / name / "runs"
    role_sha = source["role_freeze_sha256"]
    freeze = json.loads(read_pinned(resource / "ROLE-FREEZE.json", role_sha))
    deposit = json.loads(read_pinned(resource / "evidence" / "Figshare-v3.json", source["data_deposit_metadata_sha256"]))
    if (deposit["doi"], deposit["license"]["name"], deposit["version"]) != (
        source["deposit"], source["deposit_license"], 3
    ):
        raise ValueError("Wrong data release or rights")
    read_pinned(resource / "evidence" / "code.zip", source["deposited_author_code_zip_sha256"])
    read_pinned(resource / "evidence" / "eeg.json", source["deposited_eeg_sidecar_sha256"])
    known_files = {entry["id"]: entry for entry in deposit["files"]}
    archive_sha = source[f"{name}_archive_manifest_sha256"]
    archive_manifest = json.loads(read_pinned(archive_root / "MANIFEST.json", archive_sha))
    primary_manifest = json.loads(read_pinned(runs_root / "MANIFEST.json", primary_manifest_sha))
    exact_module("stage_archives", resource / "stage_archives.py", source["parser_role_module_sha256"])
    parser = exact_module("extract_runs", resource / "extract_runs.py", source["qualified_parser_sha256"])
    cohort = freeze["roles"][name]
    expected_people = 6 if name == "train" else 3
    if len(cohort) != expected_people or len(set(cohort)) != expected_people:
        raise ValueError("Unexpected number of allocated participants")
    if [row["subject"] for row in archive_manifest["records"]] != cohort or [
        row["subject"] for row in primary_manifest["participant_order"]
    ] != cohort:
        raise ValueError("Participant order or assignment disagrees with the frozen cohort")
    if (archive_manifest["role"], archive_manifest["role_freeze_sha256"]) != (name, role_sha):
        raise ValueError("Wrong archive receipt")
    if (
        primary_manifest["role"], primary_manifest["role_freeze_sha256"], primary_manifest["deposit"],
        primary_manifest["archive_manifest_sha256"], primary_manifest["extractor_sha256"],
        primary_manifest["sample_rate_hz"], tuple(primary_manifest["eeg_order"]),
        primary_manifest["eeg_units"], primary_manifest["angle_columns_degrees"],
    ) != (
        name, role_sha, source["deposit"], archive_sha, source["qualified_parser_sha256"],
        design["clock_and_trials"]["source_hz"], parser.EEG, "microvolts",
        ["positive extension", "positive radial deviation"],
    ):
        raise ValueError("Wrong synchronized primary manifest")
    blocks, participant_stats = [], []
    collated = zip(cohort, archive_manifest["records"], primary_manifest["participant_order"], strict=True)
    for person, (pid, receipt, parent) in enumerate(collated):
        public_meta = freeze["metadata_identities_for_pilot"][pid]
        deposit_file = known_files[public_meta["file_id"]]
        file_id = receipt["file_id"]
        basename = f"{pid}.zip"
        if (
            receipt["file"], receipt["deposit"], file_id, receipt["bytes"], receipt["md5"], receipt["sha256"]
        ) != (
            basename, source["deposit"], public_meta["file_id"], public_meta["bytes"], public_meta["md5"],
            parent["source_archive_sha256"],
        ) or (deposit_file["name"], deposit_file["size"], deposit_file["computed_md5"]) != (
            basename, receipt["bytes"], receipt["md5"]
        ):
            raise ValueError("Archive receipt, release and primary manifest differ")
        path = archive_root / basename
        if hash_archive(path) != (receipt["bytes"], receipt["md5"], receipt["sha256"]):
            raise ValueError("Staged archive changed bytes")
        person_stats = {"role_position": person + 1, "archive_sha256": receipt["sha256"], "runs": []}
        with zipfile.ZipFile(path) as archive:
            stem, absent = check_archive_members(parser, archive, pid, parent)
            person_stats["absent_task_blocks"] = absent
            for run in parent["runs"]:
                rows, stats = read_block(parser, archive, runs_root, pid, stem, run, person)
                blocks.append(rows)
                person_stats["runs"].append(stats)
        count = sum(run["eligible"] for run in person_stats["runs"])
        populated = sum(run["eligible"] > 0 for run in person_stats["runs"])
        if count < design["clock_and_trials"]["min_eligible_trials_per_participant"] or populated < (
            design["clock_and_trials"]["min_eligible_blocks_per_participant"]
        ):
            raise ValueError(f"Role position {person + 1} is below the frozen support threshold")
        participant_stats.append(person_stats)
    return Rows.join(blocks), participant_stats


def std_parameters(values, axis):
    center, scale = values.mean(axis=axis), values.std(axis=axis)
    return center, np.where(scale == 0, 1.0, scale)


def normalized(rows, parameters, channels, rotate=None, channel_slice=None):
    keep = np.s_[..., :channels]
    bins = (rows.bins[keep] - parameters["bins_center"][:channels]) / parameters["bins_scale"][:channels]
    if rotate is not None:
        bins[..., channel_slice] = bins[rotate, :, channel_slice]
    anchor = (rows.anchor - parameters["anchor_center"]) / parameters["anchor_scale"]
    timing = np.eye(len(OFFSETS))[rows.slot]
    return np.column_stack((bins.reshape(len(rows.slot), -1), anchor, timing))


def fit(rows, penalty):
    parameters = {}
    residual = rows.target - rows.anchor
    for label, values, axis in (
        ("bins", rows.bins, (0, 1)), ("anchor", rows.anchor, 0), ("residual", residual, 0),
    ):
        parameters[f"{label}_center"], parameters[f"{label}_scale"] = std_parameters(values, axis)
    target = (residual - parameters["residual_center"]) / parameters["residual_scale"]
    _, partition, counts = np.unique(rows.person, return_inverse=True, return_counts=True)
    weights = 1.0 / (len(counts) * counts[partition])
    parameters["training_timing"] = np.stack([
        np.average(rows.target[rows.slot == offset], axis=0, weights=weights[rows.slot == offset])
        for offset in range(len(OFFSETS))
    ])
    for head, channels in HEADS.items():
        matrix = normalized(rows, parameters, channels)
        penalize = np.full(matrix.shape[1], penalty)
        penalize[-len(OFFSETS):] = 0.0
        weighted = weights[:, None] * matrix
        parameters[head] = np.linalg.solve(matrix.T @ weighted + np.diag(penalize), weighted.T @ target)
    check_parameters(parameters)
    return parameters


def check_parameters(parameters):
    expected = {
        "bins_center": (14,), "bins_scale": (14,),
        "anchor_center": (2,), "anchor_scale": (2,),
        "residual_center": (2,), "residual_scale": (2,), "training_timing": (6, 2),
    }
    expected.update({head: (BIN_COUNT * n_channels + 2 + len(OFFSETS), 2)
                     for head, n_channels in HEADS.items()})
    if set(parameters) != set(expected):
        raise ValueError("Weights do not match the frozen estimator")
    for key, shape in expected.items():
        value = parameters[key]
        if value.shape != shape or value.dtype != np.float64 or not np.isfinite(value).all():
            raise ValueError(f"Invalid values for {key}")
        if key.endswith("_scale") and np.any(value <= 0.0):
            raise ValueError(f"Invalid scale for {key}")


def next_trial(rows):
    rotated = np.arange(len(rows.slot))
    singleton_blocks = 0
    for person in np.unique(rows.person):
        person_mask = rows.person == person
        for block in np.unique(rows.block[person_mask]):
            block_mask = person_mask & (rows.block == block)
            for slot in range(len(OFFSETS)):
                indices = np.flatnonzero(block_mask & (rows.slot == slot))
                ordered = indices[np.argsort(rows.trial[indices], kind="stable")]
                rotated[ordered] = np.roll(ordered, -1)
                singleton_blocks += int(slot == 0 and len(ordered) == 1)
    return rotated, singleton_blocks


def predictions(rows, parameters, rotation):
    result = {
        "persistence": rows.anchor,
        "linear_velocity": rows.anchor + (rows.anchor - rows.past) * 2.0,
        "training_timing": parameters["training_timing"][rows.slot],
    }
    for head, channels in HEADS.items():
        features = normalized(rows, parameters, channels)
        output = features @ parameters[head]
        result[head] = output * parameters["residual_scale"] + parameters["residual_center"] + rows.anchor
    for desc, head, columns in (
        ("rotate_emg", "motion_emg_ridge", slice(2, 6)),
        ("rotate_eeg", "motion_emg_eeg_ridge", slice(6, 14)),
    ):
        features = normalized(rows, parameters, HEADS[head], rotation, columns)
        output = features @ parameters[head]
        result[desc] = output * parameters["residual_scale"] + parameters["residual_center"] + rows.anchor
    return result


def score(rows, outcomes):
    participants = np.unique(rows.person)
    published, per_person = {}, {}
    for head, prediction in outcomes.items():
        errors = np.square(prediction - rows.target)
        means = np.stack([errors[rows.person == person].mean(axis=0) for person in participants])
        per_person[head] = means
        published[head] = {
            "equal_person_two_axis_rmse_deg": float(np.sqrt(means.mean())),
            "equal_person_axis_rmse_deg": dict(zip(AXES, np.sqrt(means.mean(axis=0)).tolist(), strict=True)),
            "pooled_two_axis_rmse_deg": float(np.sqrt(errors.mean())),
        }
    return published, per_person


def paired_delta(new, reference, index=None):
    if index is not None:
        new, reference = new[index], reference[index]
    return float(np.sqrt(new.mean()) - np.sqrt(reference.mean()))


def summaries(rows, parameters):
    rotated, singleton_blocks = next_trial(rows)
    head_scores, individual_losses = score(rows, predictions(rows, parameters, rotated))
    contrasts = {}
    private_contrasts = {}
    for name, (treatment, reference) in CONTRASTS.items():
        left, right = individual_losses[treatment], individual_losses[reference]
        contrasts[name] = paired_delta(left, right)
        private_contrasts[name] = [paired_delta(a, b) for a, b in zip(left, right, strict=True)]
    primary_left, primary_right = (individual_losses[head] for head in CONTRASTS["add_surface_emg"])
    if len(primary_left) != 3:
        raise ValueError("Three DEV participant losses are required for frozen sensitivity summaries")
    dev_index = list(range(len(primary_left)))
    all_resamples = np.array(list(product(dev_index, repeat=3)), dtype=int)
    resample_deltas = [paired_delta(primary_left, primary_right, index) for index in all_resamples]
    loo = [paired_delta(primary_left, primary_right, [item for item in dev_index if item != held])
           for held in dev_index]
    public = {
        "model_rmse": head_scores, "paired_rmse_differences_deg": contrasts,
        "primary_descriptive_resample_percentiles_deg": np.percentile(resample_deltas, [2.5, 97.5]).tolist(),
        "primary_leave_one_person_out_range_deg": [min(loo), max(loo)],
        "resample_count": len(resample_deltas), "singleton_rotation_blocks": singleton_blocks,
    }
    private = {
        "per_person_axis_mse_deg2_in_frozen_role_order": {k: v.tolist() for k, v in individual_losses.items()},
        "per_person_paired_differences_deg_in_frozen_role_order": private_contrasts,
    }
    return public, private


def support_totals(participants):
    runs = [run for person in participants for run in person["runs"]]
    totals = {
        "participants": len(participants),
        "planned_task_blocks": len(participants) * 8,
        "present_task_blocks": len(runs),
        "absent_task_blocks": sum(len(person["absent_task_blocks"]) for person in participants),
        "planned_trials_from_full_design": len(participants) * 8 * TRIALS_PER_BLOCK,
        "recorded_trials": sum(run["recorded"] for run in runs),
        "eligible_trials": sum(run["eligible"] for run in runs),
    }
    for key in ("outside_window", "invalid_encoder", "nonfinite_eeg", "nonfinite_emg",
                "invalid_on_bounded_joint_support", "emg_unique_feature_ticks"):
        totals[key] = sum(run[key] for run in runs)
    totals["emg_rail_ticks_by_channel"] = np.array([run["emg_rail_ticks_by_channel"] for run in runs]).sum(axis=0).tolist()
    if totals["recorded_trials"] != totals["eligible_trials"] + totals["outside_window"] + (
        totals["invalid_on_bounded_joint_support"]
    ):
        raise ValueError("Support accounting does not close")
    return totals


def write_checkpoint(resource, output, design):
    rows, participants = collect_role(resource, "train", design, design["source"]["train_primary_manifest_sha256"])
    with (output / "TRAIN-SUPPORT.json").open("x") as stream:
        json.dump({"participants": participants, "totals": support_totals(participants)}, stream, indent=2)
        stream.write("\n")
    parameters = fit(rows, design["fitting"]["ridge_lambda"])
    with (output / "WEIGHTS.npz").open("xb") as stream:
        np.savez(stream, **parameters)
    record = {
        "kind": "wrist_surface_emg_train_checkpoint",
        "design_sha256": DESIGN_SHA, "implementation_sha256": hash_file(Path(__file__)),
        "source_primary_train_manifest_sha256": design["source"]["train_primary_manifest_sha256"],
        "weights_sha256": hash_file(output / "WEIGHTS.npz"),
        "train_support_sha256": hash_file(output / "TRAIN-SUPPORT.json"),
        "support": support_totals(participants), "fit_uses_dev": False,
        "numpy_version": np.__version__,
        "cpu_affinity": sorted(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else None,
        "blas_threads": {name: os.environ.get(name) for name in (
            "OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
        )},
    }
    write_json(output / "TRAIN-CHECKPOINT.json", record)


def development(resource, output, design, release, release_sha, parent_checkpoint):
    token = json.loads(read_pinned(release, release_sha))
    if token["kind"] != "root_release_wrist_muscle_dev" or token["design_sha256"] != DESIGN_SHA:
        raise ValueError("Root release is not scoped to this design")
    checkpoint = json.loads(read_pinned(output / "TRAIN-CHECKPOINT.json", token["train_checkpoint_sha256"]))
    if (
        checkpoint["design_sha256"] != DESIGN_SHA or checkpoint["implementation_sha256"] != hash_file(Path(__file__))
        or checkpoint["fit_uses_dev"] or checkpoint["numpy_version"] != np.__version__
    ):
        raise ValueError("Design, code or environment changed after TRAIN")
    read_pinned(parent_checkpoint, token["parent_train_checkpoint_sha256"])
    read_pinned(output / "TRAIN-SUPPORT.json", checkpoint["train_support_sha256"])
    with np.load(io.BytesIO(read_pinned(output / "WEIGHTS.npz", checkpoint["weights_sha256"])), allow_pickle=False) as file:
        parameters = {key: file[key] for key in file.files}
    check_parameters(parameters)
    write_json(output / "DEV-STARTED.json", {
        "kind": "single_dev_attempt", "root_release_sha256": release_sha,
        "train_checkpoint_sha256": token["train_checkpoint_sha256"],
        "dev_primary_manifest_sha256": token["dev_primary_manifest_sha256"],
    })
    rows, participants = collect_role(resource, "development", design, token["dev_primary_manifest_sha256"])
    public, private = summaries(rows, parameters)
    write_json(output / "DEV-DETAIL.json", {
        "participants": participants, "score_details": private,
    })
    write_json(output / "RESULTS.json", {
        "study": design["study"], "design_sha256": DESIGN_SHA,
        "glossary_revision": design["source"]["glossary_revision"],
        "glossary_sha256": design["source"]["glossary_sha256"],
        "dataset": design["source"]["deposit"], "status": "exploratory participant-disjoint DEV only",
        "train_support": checkpoint["support"], "dev_support": support_totals(participants),
        "pending_held_out_test": True, **public,
    })


def launch():
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("role", choices=("train", "development"))
    parser.add_argument("--resource-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--release", type=Path)
    parser.add_argument("--release-sha")
    parser.add_argument("--parent-checkpoint", type=Path)
    args = parser.parse_args()
    design = json.loads(read_pinned(HOME / "DESIGN.json", DESIGN_SHA))
    if args.role == "train":
        args.output.mkdir(mode=0o700, exist_ok=False)
        write_checkpoint(args.resource_root, args.output, design)
    else:
        if not all((args.release, args.release_sha, args.parent_checkpoint)):
            parser.error("development requires the exact Root release file, SHA256 and parent TRAIN checkpoint")
        development(args.resource_root, args.output, design, args.release, args.release_sha, args.parent_checkpoint)


if __name__ == "__main__":
    launch()
