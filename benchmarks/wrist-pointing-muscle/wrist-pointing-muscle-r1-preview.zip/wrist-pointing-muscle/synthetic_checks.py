"""Check frozen feature support, controls and estimator with artificial inputs only."""

import argparse
from pathlib import Path

import numpy as np

from benchmark import OFFSETS, Rows, collect_rows, fit, next_trial, normalized, summaries


def verify_causal_support():
    tick = np.arange(6000, dtype=np.float64)
    angle = np.stack((tick, -tick), axis=1)
    valid = np.ones(angle.shape, dtype=bool)
    cues = np.array([32, 1600, 3200, 4700])
    returns = cues + np.array([1280, 1280, 1280, 800])
    eeg = np.repeat(tick[:, None], 8, axis=1)
    recorded = np.tile([32767, -32768, 104, 100, 12, 1, -5, 2], (len(tick), 1)).astype(np.int16)
    valid[3201, 1] = False
    rows, stats = collect_rows(eeg, recorded, angle, valid, cues, returns, 0, 1)
    assert (stats["outside_window"], stats["invalid_encoder"], stats["eligible"]) == (1, 1, 2)
    assert np.array_equal(rows.trial, np.repeat([0, 1], len(OFFSETS)))
    assert np.all(rows.bins[..., 2:6] == np.array([65535, 4, 11, 7]))
    assert np.all(rows.anchor[:, 0] == rows.target[:, 0] - 128)
    assert rows.bins[0, -1, 6] == rows.anchor[0, 0] - 7.5
    assert rows.bins[0, -1, 0] == -7.5
    # The row after the cutoff may belong to another offset, but cannot affect this row.
    first_future = cues[0] + OFFSETS[0] - 127
    eeg[first_future] = -321
    recorded[first_future, 0] = 0
    angle[first_future] = -234
    second, _ = collect_rows(eeg, recorded, angle, valid, cues, returns, 0, 1)
    assert np.array_equal(rows.bins[0], second.bins[0])
    assert np.array_equal(rows.target[0], second.target[0])
    rotated, singletons = next_trial(rows)
    assert singletons == 0
    assert np.array_equal(rotated, np.r_[6:12, 0:6])
    assert np.array_equal(rows.slot[rotated], rows.slot)


def artificial_fit(path):
    rng = np.random.default_rng(451)
    person = np.repeat(np.arange(6), 320 * len(OFFSETS))[:11_274]
    trial = np.tile(np.repeat(np.arange(320), len(OFFSETS)), 6)[:len(person)]
    slot = np.tile(np.arange(len(OFFSETS)), len(person) // len(OFFSETS))
    bins = rng.normal(size=(len(person), 16, 14))
    anchor = rng.normal(size=(len(person), 2))
    target = anchor + 3.0 * bins[:, 8, 2:4] + rng.normal(size=(len(person), 2), scale=0.03)
    rows = Rows(bins, anchor, np.ones_like(anchor), target, slot, person, trial // 40, trial)
    for _ in range(3):
        parameters = fit(rows, 0.01)
    dev_mask = rows.person < 3
    dev = Rows(*(getattr(rows, field)[dev_mask] for field in Rows.__dataclass_fields__))
    rotation, _ = next_trial(dev)
    rotated = normalized(dev, parameters, 6, rotation, slice(2, 6))
    aligned = normalized(dev, parameters, 6)
    as_bins = rotated[:, :-8].reshape(len(rotated), 16, 6)
    aligned_bins = aligned[:, :-8].reshape(len(aligned), 16, 6)
    assert np.array_equal(rotated[:, -8:], aligned[:, -8:])
    assert np.array_equal(as_bins[..., :2], aligned_bins[..., :2])
    assert np.array_equal(as_bins[..., 2:], aligned_bins[rotation, :, 2:])
    public, _ = summaries(dev, parameters)
    assert public["paired_rmse_differences_deg"]["add_surface_emg"] < -2.5
    assert public["paired_rmse_differences_deg"]["aligned_vs_rotated_emg"] < -3.5
    assert public["resample_count"] == 27
    with path.open("xb") as stream:
        np.savez(stream, **parameters)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("weights", type=Path)
    args = parser.parse_args()
    verify_causal_support()
    artificial_fit(args.weights)
    print("Matched causal-support, rotation and artificial-estimator checks passed.")
