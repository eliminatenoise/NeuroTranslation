"""Bind the unchanged benchmark to the strictly verified DEV archive layout."""

import argparse
import io
import json
import os
from pathlib import Path
import zipfile

import numpy as np

import benchmark as b


JOINT_SHA = "8da36d95d39db6aa1f6e82eead01d542366da10c51d4e2d48701555266aa070e"
DEV_CAPTURE_SHA = "eb957afdefd86ede0072a327292ca7b51a123bf4c46d7ed295914d9d5097b92b"
DEV_READY_SHA = "19bca7be4c880050276fbe95dd21f034a55e4880fef53f59e1406608120746cc"
DEV_EXTRACTOR_SHA = "7a72a5429ebf2b75d73dbbb01c5d64a59249d0fc33012b7a1a3fa444618390fc"
STRICT_HEADER_SHA = "75d52949744ecfe720b4b81800639fd4fa4cd7287061f424c114d1ec16192720"
TRAIN_IMPLEMENTATION_SHA = "f292dd74c50a44719002451558ad73eef22bba37667aa7927738e2af1ce67901"


def verify_joint(admission, parent_checkpoint, output, design, freeze):
    joint = json.loads(b.read_pinned(admission, JOINT_SHA))
    first = json.loads(b.read_pinned(parent_checkpoint, joint["temporal_seal_sha256"]))
    second = json.loads(b.read_pinned(output / "TRAIN-CHECKPOINT.json", joint["emg_seal_sha256"]))
    source = design["source"]
    if (
        joint["heldout_test_open"] or joint["roles"] != freeze["roles"]["development"]
        or joint["train_manifest_sha256"] != source["train_primary_manifest_sha256"]
        or first["source_manifest_sha256"] != joint["train_manifest_sha256"]
        or first["design_sha256"] != source["parent_temporal_design_sha256"]
        or first["role"] != "train"
        or second["source_primary_train_manifest_sha256"] != joint["train_manifest_sha256"]
        or second["design_sha256"] != b.DESIGN_SHA or second["fit_uses_dev"]
        or second["implementation_sha256"] != TRAIN_IMPLEMENTATION_SHA
        or joint["emg_implementation_sha256"] != TRAIN_IMPLEMENTATION_SHA
        or b.hash_file(Path(b.__file__)) != TRAIN_IMPLEMENTATION_SHA
        or second["weights_sha256"] != joint["emg_weights_sha256"]
        or second["numpy_version"] != np.__version__
    ):
        raise ValueError("Joint release and frozen TRAIN lineage disagree")
    train_aliases, dev_aliases = freeze["roles"]["train"], freeze["roles"]["development"]
    if len(set(train_aliases)) != 6 or len(set(dev_aliases)) != 3 or set(train_aliases) & set(dev_aliases):
        raise ValueError("TRAIN or DEV set is no longer valid")
    support = json.loads(b.read_pinned(output / "TRAIN-SUPPORT.json", second["train_support_sha256"]))
    if support["totals"]["participants"] != len(train_aliases) or support["totals"] != second["support"]:
        raise ValueError("TRAIN support disagrees with the frozen cohort")
    with np.load(io.BytesIO(b.read_pinned(output / "WEIGHTS.npz", second["weights_sha256"])), allow_pickle=False) as file:
        parameters = {name: file[name] for name in file.files}
    b.check_parameters(parameters)
    return joint, second, parameters


def member_inventory(archive, pid, run_ids, exclusions, first_participant):
    stem = f"{pid}_task-WristPointingTask"
    expected = {
        member for run in ("01", *run_ids, "11")
        for member in (f"{pid}/eeg/{stem}_run-{run}_eeg.edf",
                       f"{pid}/motion/{stem}_tracksys-BiomechWrist_run-{run}_motion.tsv")
    }
    names = archive.namelist()
    recorded = {name for name in names if name.startswith(pid + "/") and name.endswith(("_eeg.edf", "_motion.tsv"))}
    if len(set(names)) != len(names) or len(exclusions) != int(first_participant):
        raise ValueError("Unexpected duplicate or excluded archive member")
    if first_participant:
        extra = f"{pid}/eeg/{stem}_run-02_eeg.edf"
        item = exclusions[0]
        if (item["member"], item["uncompressed_bytes"], item["source_header_read"]) != (extra, 9_312_864, False):
            raise ValueError("Exact extra EEG-only member metadata disagree")
        if archive.getinfo(extra).file_size != item["uncompressed_bytes"]:
            raise ValueError("Extra member size disagrees with frozen inventory")
        expected.add(extra)
    if recorded != expected:
        raise ValueError("Extra or mismatched paired archive member")
    return stem


def read_dev_frozen_sources(resource, design, freeze):
    source = design["source"]
    b.read_pinned(b.HOME / "CHANNEL-EVIDENCE.md", source["channel_evidence_sha256"])
    b.read_pinned(resource / "evidence" / "code.zip", source["deposited_author_code_zip_sha256"])
    b.read_pinned(resource / "evidence" / "eeg.json", source["deposited_eeg_sidecar_sha256"])
    deposit = json.loads(b.read_pinned(resource / "evidence" / "Figshare-v3.json", source["data_deposit_metadata_sha256"]))
    if (deposit["doi"], deposit["license"]["name"], deposit["version"]) != (
        source["deposit"], source["deposit_license"], 3
    ):
        raise ValueError("Wrong staged deposit or license")
    archive_root = resource / "private" / "development" / "archives"
    run_root = resource / "private" / "development" / "runs"
    staged = json.loads(b.read_pinned(archive_root / "MANIFEST.json", source["development_archive_manifest_sha256"]))
    capture = json.loads(b.read_pinned(run_root / "MANIFEST.json", DEV_CAPTURE_SHA))
    ready = json.loads(b.read_pinned(resource / "DEVELOPMENT-READY.json", DEV_READY_SHA))
    if (
        capture["role"], capture["role_freeze_sha256"], capture["deposit"], capture["archive_manifest_sha256"],
        capture["extractor_sha256"], capture["unchanged_run_decoder_sha256"], capture["strict_header_gate_sha256"],
        capture["root_joint_admission_sha256"], capture["sample_rate_hz"], capture["eeg_units"],
        capture["angle_columns_degrees"],
    ) != (
        "development", source["role_freeze_sha256"], source["deposit"], source["development_archive_manifest_sha256"],
        DEV_EXTRACTOR_SHA, source["qualified_parser_sha256"], STRICT_HEADER_SHA,
        JOINT_SHA, design["clock_and_trials"]["source_hz"], "microvolts",
        ["positive extension", "positive radial deviation"],
    ):
        raise ValueError("Manifest lineage, calibration or grid changed")
    b.read_pinned(resource / "extract_verified_development.py", DEV_EXTRACTOR_SHA)
    b.exact_module("stage_archives", resource / "stage_archives.py", source["parser_role_module_sha256"])
    decoder = b.exact_module("extract_runs", resource / "extract_runs.py", source["qualified_parser_sha256"])
    strict = b.exact_module("extract_with_standard_headers", resource / "extract_with_standard_headers.py", STRICT_HEADER_SHA)
    cohort = freeze["roles"]["development"]
    if (
        (staged["role"], staged["role_freeze_sha256"]) != ("development", source["role_freeze_sha256"])
        or tuple(capture["eeg_order"]) != decoder.EEG or capture["required_standard_edf_count_fields_checked"] != 552
        or [row["subject"] for row in staged["records"]] != cohort
        or [row["subject"] for row in capture["participant_order"]] != cohort
        or [row["subject"] for row in ready["participant_results"]] != cohort
        or ready["manifest_sha256"] != DEV_CAPTURE_SHA or ready["role"] != "development"
        or ready["design_sha256"] != source["parent_temporal_design_sha256"]
        or ready["blocks_verified"] != 24 or not ready["all_frozen_participant_minima_met"]
    ):
        raise ValueError("DEV source is not the qualified participant set and block support")
    records = zip(cohort, staged["records"], capture["participant_order"], ready["participant_results"], strict=True)
    return archive_root, run_root, decoder, strict, records, deposit


def extract_dev_participant(archive_root, run_root, decoder, strict, pid, staged, captured, ready, person, deposit, freeze):
    basename = f"{pid}.zip"
    meta = freeze["metadata_identities_for_pilot"][pid]
    public = next(row for row in deposit["files"] if row["id"] == meta["file_id"])
    identity = (basename, meta["file_id"], meta["bytes"], meta["md5"])
    if (
        (staged["file"], staged["file_id"], staged["bytes"], staged["md5"]) != identity
        or (public["name"], public["id"], public["size"], public["computed_md5"]) != identity
        or staged["deposit"] != freeze["dataset"] or staged["sha256"] != captured["source_archive_sha256"]
        or captured["excluded_baseline_archive_runs"] != ["01", "11"] or captured["missing_task_blocks"]
        or [(run["archive_run"], run["task_block_ordinal"]) for run in captured["runs"]]
        != list(zip(decoder.TASK_RUN_IDS, range(1, 9), strict=True))
    ):
        raise ValueError("DEV archive identity or retained task order changed")
    path = archive_root / basename
    if b.hash_archive(path) != (staged["bytes"], staged["md5"], staged["sha256"]):
        raise ValueError("DEV archive bytes do not match the qualified release")
    runs, stats = [], []
    with zipfile.ZipFile(path) as archive:
        stem = member_inventory(archive, pid, decoder.TASK_RUN_IDS, captured["excluded_unpaired_members"], person == 0)
        eeg = decoder.read_dictionary(archive, f"{pid}/eeg/{stem}_channels.tsv")
        motion = decoder.read_dictionary(archive, f"{pid}/motion/{stem}_tracksys-BiomechWrist_channels.tsv")
        if [(row["name"], row["type"], row["units"]) for row in eeg] != [
            *((label, "EEG", "microV") for label in decoder.EEG),
            *((label, "EMG", "microV") for label in decoder.EMG),
        ] or [(row["name"], row["tracked_point"], row["units"]) for row in motion] != [
            ("X", "RightWrist", "rad"), ("Y", "RightWrist", "rad")
        ]:
            raise ValueError("Archived biosignal or kinematic identity changed")
        for item in captured["runs"]:
            member = f"{pid}/eeg/{stem}_run-{item['archive_run']}_eeg.edf"
            with archive.open(member) as stream:
                header_sha = strict.require_standard_header(stream.read(6144), archive.getinfo(member).file_size)
            if header_sha != item["source_record_framing"]["header_sha256"]:
                raise ValueError("Strict header does not match qualified capture")
            rows, tally = b.read_block(decoder, archive, run_root, pid, stem, item, person)
            runs.append(rows)
            stats.append(tally)
    if (
        sum(run["recorded"] for run in stats) != ready["cues_checked"]
        or sum(run["eligible"] for run in stats) != ready["eligible_trials"]
        or [run["task_block_ordinal"] for run in stats if run["eligible"]] != ready["blocks_with_eligible_trials"]
    ):
        raise ValueError("DEV common eligibility differs from the qualified main manifest")
    return runs, {
        "role_position": person + 1, "archive_sha256": staged["sha256"], "runs": stats,
        "absent_task_blocks": [], "out_of_schedule_unpaired_members": len(captured["excluded_unpaired_members"]),
    }


def run(resource, output, admission, parent_checkpoint):
    design = json.loads(b.read_pinned(b.HOME / "DESIGN.json", b.DESIGN_SHA))
    freeze = json.loads(b.read_pinned(resource / "ROLE-FREEZE.json", design["source"]["role_freeze_sha256"]))
    joint, train, parameters = verify_joint(admission, parent_checkpoint, output, design, freeze)
    archive_root, run_root, decoder, strict, records, deposit = read_dev_frozen_sources(resource, design, freeze)
    attempt = {
        "kind": "single_dev_attempt_with_verified_source_adapter", "root_joint_admission_sha256": JOINT_SHA,
        "train_checkpoint_sha256": joint["emg_seal_sha256"], "dev_primary_manifest_sha256": DEV_CAPTURE_SHA,
        "dev_adapter_sha256": b.hash_file(Path(__file__)), "unchanged_benchmark_sha256": TRAIN_IMPLEMENTATION_SHA,
    }
    b.write_json(output / "DEV-STARTED.json", attempt)
    rows, stats = [], []
    for person, (pid, staged, captured, ready) in enumerate(records):
        retained, tally = extract_dev_participant(
            archive_root, run_root, decoder, strict, pid, staged, captured, ready, person, deposit, freeze
        )
        rows.extend(retained)
        stats.append(tally)
    results, private_results = b.summaries(b.Rows.join(rows), parameters)
    b.write_json(output / "DEV-DETAIL.json", {"participants": stats, "score_details": private_results})
    b.write_json(output / "RESULTS.json", {
        "study": design["study"], "design_sha256": b.DESIGN_SHA,
        "glossary_revision": design["source"]["glossary_revision"],
        "glossary_sha256": design["source"]["glossary_sha256"], "dataset": design["source"]["deposit"],
        "status": "exploratory participant-disjoint DEV only", "train_support": train["support"],
        "dev_support": b.support_totals(stats), "out_of_schedule_unpaired_dev_members": 1,
        "pending_held_out_test": True, **results,
    })


if __name__ == "__main__":
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--resource-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--admission", type=Path, required=True)
    parser.add_argument("--parent-checkpoint", type=Path, required=True)
    args = parser.parse_args()
    run(args.resource_root, args.output, args.admission, args.parent_checkpoint)
