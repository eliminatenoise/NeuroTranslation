# Surface EMG channel evidence

The WristMotion study recorded eight surface EMG channels from eight passive electrodes on the right forearm. The Methods describe the eight recorded signals as monopolar. Figure 3 describes bipolar electrode placement with an elbow reference. The authors’ analysis resolves the distinction: their deposited notebook subtracts neighboring inputs for each muscle to derive four bipolar traces, in the same order as the instrument mapping in Table 1. The archived BIDS channel dictionary lists eight EMG channels; Ch9–Ch16 are their EDF positions. [Scientific Data descriptor, Methods, Table 1 and Fig. 3](https://doi.org/10.1038/s41597-026-07287-z) · [Figshare v3 data deposit and author code](https://doi.org/10.6084/m9.figshare.29666735.v3)

| EDF pair | Archived inputs | Right forearm electrode sites named in the descriptor | Derived waveform |
| --- | --- | --- | --- |
| Ch9–Ch10 | M1L, M1R | Extensor carpi radialis longus | M1L − M1R |
| Ch11–Ch12 | M2L, M2R | Extensor carpi ulnaris | M2L − M2R |
| Ch13–Ch14 | M3L, M3R | Flexor carpi radialis | M3L − M3R |
| Ch15–Ch16 | M4L, M4R | Palmaris longus | M4L − M4R |

All four pairs measure voltages at the skin. The anatomical labels describe electrode sites. A pair can pick up nearby muscle activity, changes in skin contact, and electrical or movement artifacts. The archive does not identify the force from an individual muscle or record peripheral nerve spikes. The example muscle associations used in the publication never enter the model as movement classes.

The v3 BIDS dictionary labels these eight streams `microV`. The source parser checks `uV` and equal signed 16-bit digital and physical ranges in the EDF, which imply unity scale and zero offset as stored. The deposited conversion script sets channel names and passes signed 16-bit data to `save_bcidat`. This establishes the nominal archive scaling, not a traceable amplifier gain, measurement-chain calibration, between-person comparability of absolute amplitudes, or measured acquisition latency. We use nominal values to construct amplitudes, and standardize features using TRAIN data only. No absolute physiological amplitude is reported. [Figshare v3 acquisition sidecar](https://ndownloader.figshare.com/files/60086807) · [Figshare v3 author scripts](https://ndownloader.figshare.com/files/62570704)

The descriptor reports adult participants, an unpowered exoskeleton recording two wrist axes during voluntary pointing, written consent and approval PR2024-05v1. The v3 repository lists CC BY 4.0. The benchmark uses the available de-identified records from the frozen participant roles and retains raw waveforms, identifiers and data custody records locally. The result is a new analysis of the authors’ deposit. [Scientific Data descriptor, Ethics Statement](https://doi.org/10.1038/s41597-026-07287-z) · [Figshare CC BY 4.0 deposit](https://doi.org/10.6084/m9.figshare.29666735.v3)
