# What does a wrist's muscle signal add?

The target appears. The encoders tell us where the wrist is and where it has just been. Add the recent electrical activity picked up at the skin of the forearm, and the model has a second record of what happened between the cue and the forecast. On three development participants in the WristMotion study, that addition lowered the two-axis forecast error from **6.530° to 6.174°**. Substituting the muscle signal from the next trial raised the error to **6.941°**.

This separately specified analysis uses the same people and source files as the companion WristMotion temporal forecast. Six participants supplied the fits. The next three supplied 960 complete development trials, across all 24 scheduled task blocks. The six reserved test participants remain sealed. The result describes these recordings and this specific task. [WristMotion v3 data](https://doi.org/10.6084/m9.figshare.29666735.v3) · [Scientific Data descriptor](https://doi.org/10.1038/s41597-026-07287-z)

## The forecast

During voluntary right-wrist pointing, an unpowered exoskeleton recorded flexion–extension and radial–ulnar deviation while the acquisition system recorded scalp EEG and right-forearm surface electromyography (EMG). Each forecast used the same six instants from 0.75 to 2.00 seconds after the movement cue. Its latest input was 128 stored ticks before the target. That is a nominal 250 ms forecast at 512 Hz. The encoder refresh is reported as nominally 100 Hz, so the result preserves the stored stair steps. The hardware and physiological delays remain unmeasured by this experiment. [Scientific Data descriptor](https://doi.org/10.1038/s41597-026-07287-z) · [WristMotion v3](https://doi.org/10.6084/m9.figshare.29666735.v3)

The first ridge model used elapsed cue time, the last measured wrist angles and mean encoder angles over the preceding half second. Those means were calculated in 16 bins relative to the last angle. The second ridge model added four surface EMG amplitudes per bin. Each amplitude is the root mean square of a software difference between two recorded electrode signals. The third ridge model added mean signals from eight scalp EEG channels in the same bins. All three used the same 0.01 penalty on standardized slopes, the same two residual angle targets, and the same participants and eligible samples. Means, scales and model coefficients came from TRAIN only. [Frozen design](DESIGN.json) · [Surface EMG channel evidence](CHANNEL-EVIDENCE.md)

## Development results

The table gives root-mean-square error in degrees. To obtain the two-axis error, average the squared error across axes and samples within each participant, average across participants with equal weight, and take the square root.

| Predictor | Two axes | Flexion–extension | Radial–ulnar deviation |
| --- | ---: | ---: | ---: |
| TRAIN mean at each cue offset | 24.888 | 32.329 | 13.916 |
| Repeat last angle | 7.925 | 10.129 | 4.796 |
| Extrapolate recent angle change | 8.578 | 10.780 | 5.566 |
| Cue time + recent wrist angles | 6.530 | 8.287 | 4.075 |
| Cue time + wrist angles + surface EMG | 6.174 | 7.768 | 3.987 |
| Cue time + wrist angles + surface EMG + scalp EEG | 6.127 | 7.687 | 3.998 |
| Surface EMG model with EMG from the next trial | 6.941 | 8.861 | 4.222 |
| Full model with EEG from the next trial | 6.379 | 8.065 | 4.041 |

Surface EMG reduced the two-axis error by 0.355°. Repeating the contrast while dropping one person at a time gave reductions of 0.232° to 0.469°. Across all 27 ordered three-person resamples, the descriptive 2.5th and 97.5th percentiles for the signed change were −0.519° and −0.135°. With three people these values describe sensitivity to who was included. A population estimate requires a larger independent evaluation. After EMG was included, EEG reduced overall error by 0.048° and increased radial–ulnar deviation error by 0.011°. [Full-precision aggregate results](RESULTS.json)

The rotation samples the next eligible trial within the same participant, recording block and cue offset, wrapping at the final trial. It leaves the model weights, timing, other inputs and outcomes in place. The lower error with aligned signals is consistent with useful trial-specific information. Surface EMG can carry activity from adjacent muscles, contact changes and movement artifact. Scalp EEG can carry movement and muscle-related signals too. The evaluation leaves their contributions unresolved, along with physiological onset, causal mediation, force, peripheral nerve activity and real-time control.

TRAIN retained 1,879 of 1,880 recorded trials from 47 of 48 scheduled blocks. One encoder-invalid trial was removed from every model. All 960 scheduled DEV trials qualified. One additional EEG-only source file sat outside the scheduled runs and lacked matching motion. It was identified from the ZIP inventory, and its header and signal were left unopened. Neither role lost a trial to EMG or EEG missingness inside the required input support, and no EMG samples hit either stored 16-bit rail in the eligible windows. These checks leave subtler artifacts and calibration errors possible. [Aggregate support and scores](RESULTS.json)

## Check the code

The benchmark.py source fits the frozen estimators from the qualified TRAIN sources. The development_adapter.py source validates the qualified DEV layout and uses the same per-block decoder, feature computation, weights, controls and scoring. The synthetic_checks.py source checks the feature cutoff, pair subtraction, rotation and regression on artificial inputs. It runs with Python 3.14 and NumPy 2.4.2.

    python -B synthetic_checks.py /path/to/new-synthetic-weights.npz

Actual data reproduction requires the qualified primary WristMotion parser, the frozen source roles, matching staged archives and run manifests, and the exact TRAIN checkpoint receipts. Those inputs are kept under separate custody. The public packet contains code, design and role-level aggregates. [Design and source identities](DESIGN.json)

## Data attribution

Jorge German Perez Blanco and Javier Mauricio Anteliz Ortiz deposited *EEG-EMG-WristMotion Dataset*, version 3. The deposit is licensed CC BY 4.0. This benchmark derives software bipolar amplitude features from the authors' recordings and evaluates a fixed regression experiment. The analysis is independent of the data authors. [Dataset DOI](https://doi.org/10.6084/m9.figshare.29666735.v3) · [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)

## Open the preview

Extract the ZIP and start with Launch-Windows.cmd on Windows, Launch-macOS.command on macOS, or Launch-Linux.sh on Linux. Each opens the bundled index.html in your browser. You can open index.html directly on any desktop. The browser view is offline and uses no Python, package installation or external data.

The optional NumPy demonstration runs the actual three ridge heads on artificial feature inputs. MODEL-STATE.json carries the complete cohort-wide ridge coefficients and TRAIN-only normalization, as well as the training-only cue-time means. It contains no per-person model, recording or outcome. The exported arrays are float64 and use JSON without executable objects.

    python -B synthetic_model.py

SYNTHETIC-CASES.json shows the input format. To evaluate a local file with cases of the same shape:

    python -B synthetic_model.py --input binned-cases.json --json

Each case has one cue_offset_ticks value in {384, 512, 640, 768, 896, 1024}, two last-known encoder angles in anchor_deg, and 16 chronological rows in bins. Each row contains two mean motion angles relative to the anchor, four root-mean-square surface EMG differences in archive scaling, then mean scalp EEG for C3, C1, Cz, C2, C4, CP3, CPz and CP4 in archive scaling. Motion columns are flexion–extension with positive extension, then radial–ulnar deviation with positive radial deviation. The four EMG pair columns follow M1–M4 in the channel note. The model emits absolute angles in degrees in the same order. Keep the forecast's stored-time support and units when working with comparable observations. The program is an offline benchmark. See the design and data descriptor for acquisition and validity limits.

The companion temporal forecast describes the shared source, frozen sampling grid and separate development results. Replaying the full recorded source requires the exact qualified parser and custody receipts named in DESIGN.json. [Companion temporal forecast](https://github.com/eliminatenoise/NeuroTranslation/tree/main/benchmarks/wrist-pointing-temporal/)
