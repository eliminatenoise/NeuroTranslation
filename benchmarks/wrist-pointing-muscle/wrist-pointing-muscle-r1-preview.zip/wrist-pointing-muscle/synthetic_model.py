"""Run the frozen WristMotion regression heads on artificial or binned inputs."""

import argparse
import json
from pathlib import Path

import numpy as np


OFFSETS = (384, 512, 640, 768, 896, 1024)
HEADS = {"motion_ridge": 2, "motion_emg_ridge": 6, "motion_emg_eeg_ridge": 14}
ARRAY_SHAPES = {"bins_center": (14,), "bins_scale": (14,), "anchor_center": (2,), "anchor_scale": (2,),
                "residual_center": (2,), "residual_scale": (2,), "training_timing": (6, 2),
                "motion_ridge": (40, 2), "motion_emg_ridge": (104, 2), "motion_emg_eeg_ridge": (232, 2)}


def numeric(items, shape, name):
    value = np.asarray(items, dtype=np.float64)
    if value.shape != shape or not np.isfinite(value).all():
        raise ValueError(f"{name} requires finite numeric values with shape {shape}")
    return value


def load_model(path):
    document = json.loads(path.read_text(encoding="utf-8"))
    if document["schema"] != "WristMotion cohort-wide ridge state, format 1":
        raise ValueError("Unexpected model format")
    arrays = document["arrays"]
    if set(arrays) != set(ARRAY_SHAPES):
        raise ValueError("Unexpected array layout")
    parameters = {key: numeric(arrays[key], expected, key) for key, expected in ARRAY_SHAPES.items()}
    if any(np.any(value <= 0) for key, value in parameters.items() if key.endswith("_scale")):
        raise ValueError("Scale parameters must be positive")
    return parameters


def evaluate(parameters, example):
    bins = numeric(example["bins"], (16, 14), "bins")
    anchor = numeric(example["anchor_deg"], (2,), "anchor_deg")
    tick = example["cue_offset_ticks"]
    if type(tick) is not int or tick not in OFFSETS:
        raise ValueError(f"cue_offset_ticks must be one of {OFFSETS}")
    if np.any(bins[:, 2:6] < 0):
        raise ValueError("EMG RMS features must be nonnegative")
    index = OFFSETS.index(tick)
    with np.errstate(over="raise", divide="raise", invalid="raise"):
        standard_bins = (bins - parameters["bins_center"]) / parameters["bins_scale"]
        standard_anchor = (anchor - parameters["anchor_center"]) / parameters["anchor_scale"]
        one_hot = np.eye(len(OFFSETS))[index]
        results = {}
        for head, channels in HEADS.items():
            features = np.concatenate((standard_bins[:, :channels].ravel(), standard_anchor, one_hot))
            standardized = features @ parameters[head]
            prediction = (standardized * parameters["residual_scale"] + parameters["residual_center"]) + anchor
            results[head] = prediction.tolist()
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, help="JSON file mapping case names to binned feature examples")
    parser.add_argument("--json", action="store_true", help="write machine-readable model angles")
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    parameters = load_model(base / "MODEL-STATE.json")
    source = args.input if args.input else base / "SYNTHETIC-CASES.json"
    examples = json.loads(source.read_text(encoding="utf-8"))
    results = {name: evaluate(parameters, example) for name, example in examples.items()}
    if args.json:
        print(json.dumps(results, indent=2, allow_nan=False))
    else:
        print("Model angles in degrees (extension, radial deviation).")
        if args.input is None:
            print("Preset example inputs are artificial.")
        for case, predictions in results.items():
            print(case.replace("_", " "))
            for head, (horizontal, vertical) in predictions.items():
                print(f"  {head}: {horizontal:.3f}°, {vertical:.3f}°")


if __name__ == "__main__":
    main()
