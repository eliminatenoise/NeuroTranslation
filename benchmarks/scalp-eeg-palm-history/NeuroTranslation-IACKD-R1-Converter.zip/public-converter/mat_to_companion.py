"""Open one full IACKD trial in the NeuroTranslation recording inspector."""
import argparse
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import stat

import h5py
import numpy as np


ROOT = Path(__file__).resolve().parent
LOCK_SHA256 = "cbb9425f1540d9ff2c705aaed928140b88e8b7da52295286697d136a03f4f90b"
GLOSSARY = {"revision": 36, "sha256": "40b98695e6204bc9e305ecdea853756aec30f48a6ae67d29e92c8bb220b3e406"}
FIELDS = ("t_ms", "EEG", "x_mm", "eeg_seg_idx", "lm_trial")
FIELD_DTYPES = {"EEG": "<f4", "t_ms": "<f8", "x_mm": "<f8", "lm_trial": "<f8", "eeg_seg_idx": "<f8"}
TIMEBASE = "IACKD event 14 · cue disappearance"
DEVICE_FRAME = "Leap Motion device frame, right positive"


def ensure(condition, message):
    if not condition:
        raise ValueError(message)


def file_sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def verified_payload(path, derivative):
    status = path.stat()
    ensure(not path.is_symlink() and stat.S_ISREG(status.st_mode), "Expected a local regular MAT file")
    ensure(status.st_size == derivative["bytes"] and file_sha(path) == derivative["sha256"],
           f"File size or content hash differs for {path.name}")


def check_record(base, rec):
    path = (base / rec["path"]).resolve()
    ensure(path.is_relative_to(base.resolve()) and path.is_file() and path.stat().st_size == rec["bytes"]
           and file_sha(path) == rec["sha256"], f"Referenced metadata altered: {rec['path']}")
    return path


def require_local_dataset(dataset, name):
    ensure(isinstance(dataset, h5py.Dataset) and dataset.ndim == 2
           and not dataset.is_virtual and not dataset.external, f"Unexpected HDF5 storage in {name}")
    props = dataset.id.get_create_plist()
    for index in range(props.get_nfilters()):
        ensure(props.get_filter(index)[0] in (1, 2, 3), f"Unexpected nonstandard filter in {name}")


def trial_fields(source, fields):
    ensure(sorted(source) == ["#refs#", "OUT"] and isinstance(source.get("OUT", getlink=True), h5py.HardLink),
           "Wrong HDF5 roots")
    out = source["OUT"]
    ensure(isinstance(out, h5py.Group) and out.attrs.get("MATLAB_class") == b"struct", "Expected MATLAB OUT struct")
    reference_columns = {}
    for field in fields:
        ensure(isinstance(out.get(field, getlink=True), h5py.HardLink), f"Missing local OUT.{field}")
        column = out[field]
        require_local_dataset(column, field)
        ensure(0 < column.shape[0] <= 1000 and column.shape[1] == 1
               and h5py.check_dtype(ref=column.dtype) is h5py.Reference, f"Bad reference geometry for {field}")
        reference_columns[field] = column[:, 0]
    ensure(len({len(column) for column in reference_columns.values()}) == 1, "Inconsistent OUT trial count")
    return reference_columns


def trial_arrays(source, fields, index):
    arrays = {}
    for field, column in fields.items():
        ref = column[index]
        ensure(bool(ref), f"Null OUT.{field} reference")
        array = source[ref]
        require_local_dataset(array, field)
        ensure(array.name.startswith("/#refs#/") and 0 < array.size <= 100_000
               and array.dtype == np.dtype(FIELD_DTYPES[field]), f"Bad dtype or size in OUT.{field}")
        arrays[field] = array
    return arrays


def check_shape(arrays, indices, n_channels):
    eeg, clock, x = (arrays[name] for name in ("EEG", "t_ms", "x_mm"))
    n_samples = eeg.shape[0]
    ensure(eeg.shape == (n_samples, n_channels) and clock.shape == (1, n_samples)
           and x.shape == (n_samples, 1) and all(0 <= i < n_channels for i in indices),
           "Derivative widths or orientation do not support the frozen named channel map")
    return n_samples


def identity(dataset, minimum):
    ensure(dataset.shape == (1, 1), "Wrong trial identity shape")
    value = float(dataset[0, 0])
    ensure(value.is_integer() and value >= minimum, "Invalid trial identity")
    return int(value)


def native_anchor(clock):
    if not np.isfinite(clock).all() or not np.all(np.diff(clock) > 0):
        return None, "clock_nonfinite_or_nonincreasing"
    anchor = int(np.searchsorted(clock, 0.0, side="left"))
    if anchor <= 0 or anchor >= len(clock) or not 0 <= clock[anchor] < 10:
        return None, "no_native_anchor_bracketing_event"
    expected = clock[anchor] + (np.arange(len(clock)) - anchor) * 10
    if not np.all(np.abs(clock - expected) <= 0.01):
        return None, "clock_not_continuous_on_native_grid"
    return anchor, None


def load_source_lock(path):
    data = path.read_bytes()
    ensure(hashlib.sha256(data).hexdigest() == LOCK_SHA256, "The source lock differs from this converter.")
    return json.loads(data)


def verify_release_metadata(base, entry, dataset):
    rights = check_record(base, dataset["rights"])
    fields_path = check_record(base, dataset["fields"])
    fields = json.loads(fields_path.read_text(encoding="utf-8"))
    ensure("event 14" in fields["OUT.t_ms"] and "µV @100 Hz" in fields["OUT.EEG"]
           and "mm @100 Hz" in fields["OUT.x_mm/y_mm/z_mm"], "The released measurement fields differ.")
    recording = entry["raw_recording"]
    header = check_record(base, recording["brainvision"]).read_text(encoding="utf-8-sig").splitlines()
    table = check_record(base, recording["channels"]).read_text(encoding="utf-8-sig")
    channel_rows = list(csv.DictReader(io.StringIO(table), delimiter="\t"))
    rows = entry["mapping"]["central_rows"]
    ensure([row["name"] for row in rows] == ["C3", "Cz", "C4"], "The release lock has a different channel map.")
    ensure(len(channel_rows) == entry["mapping"]["n_channels_expected_after_non_EEG_removal"] + 3,
           "The acquisition and expected derivative widths disagree.")
    for row in rows:
        index = row["index_zero_based"]
        name = row["name"]
        ensure((channel_rows[index]["name"], channel_rows[index]["type"]) == (name, "EEG")
               and any(line.startswith(f"Ch{index + 1}={name},") for line in header),
               f"The BrainVision header and acquisition table disagree at {name}.")
    description = json.loads(rights.read_text(encoding="utf-8"))
    ensure(description["License"] == "CC0" and description["DatasetDOI"] == f"doi:{dataset['doi'].split('/', 3)[-1]}",
           "The dataset rights record or release DOI differs.")
    return description


def make_packet(freeze_path, source_path, trial):
    freeze = load_source_lock(freeze_path)
    found = [entry for entry in freeze["participants"] if entry["derivative"]["basename"] == source_path.name]
    ensure(len(found) == 1, "Choose an exact right-hand R1 MAT file for cohort participants sub-07 through sub-12.")
    entry = found[0]
    subject, role, derivative = (entry[name] for name in ("subject", "role", "derivative"))
    description = verify_release_metadata(freeze_path.parent, entry, freeze["dataset"])
    verified_payload(source_path, derivative)
    mapping = entry["mapping"]
    rows = mapping["central_rows"]
    columns = [row["index_zero_based"] for row in rows]
    with h5py.File(source_path, "r") as source:
        refs = trial_fields(source, FIELDS)
        ensure(1 <= trial <= len(refs["EEG"]), f"Choose an OUT trial from 1 to {len(refs['EEG'])}.")
        a = trial_arrays(source, refs, trial - 1)
        n = check_shape(a, columns, mapping["n_channels_expected_after_non_EEG_removal"])
        segment, leap = identity(a["eeg_seg_idx"], 1), identity(a["lm_trial"], 0)
        clock = a["t_ms"][0, :]
        eeg = a["EEG"][:, sorted(columns)]
        x = a["x_mm"][:, 0]
    anchor, reason = native_anchor(clock)
    ensure(reason is None, "This trial lacks its contiguous native 10 ms source clock through cue disappearance.")
    ensure(np.isfinite(eeg).all() and not np.isinf(x).any(), "The selected trial has an invalid stored value.")
    ms = clock.tolist()
    seconds = [value / 1000.0 for value in ms]
    ensure(max(abs(t * 1000.0 - value) for t, value in zip(seconds, ms, strict=True)) <= 1e-10,
           "Converting timestamps to seconds lost their source coordinates.")
    parent_id = f"{subject}_task-ihc_acq-right_run-01"
    split = {"TRAIN": "train", "DEVELOPMENT": "validation"}[role]
    dataset = {
        "id": f"ds006840-1.0.0-{subject}-ihc-right-r1-{split}-trial-{trial:02d}",
        "name": f"IACKD {subject} · right-hand trial {trial}",
        "sourceUrl": freeze["dataset"]["doi"], "license": "CC0", "organism": "Homo sapiens",
        "subjectId": subject,
        "recordingId": f"{parent_id} · derivative trial {trial} (EEG segment {segment}, Leap trial {leap})",
        "task": "IACKD right-hand movement execution with screen feedback",
        "timebase": TIMEBASE, "split": split, "origin": "derived",
        "provenance": {
            "datasetTitle": description["Name"].strip(), "datasetAuthors": description["Authors"],
            "datasetVersion": "1.0.0", "datasetDoi": freeze["dataset"]["doi"],
            "articleDoi": freeze["dataset"]["descriptor"],
            "rightsUrl": "https://creativecommons.org/publicdomain/zero/1.0/",
            "releaseCommit": freeze["dataset"]["commit"], "releaseSnapshotId": freeze["dataset"]["snapshot"]["id"],
            "derivativePath": derivative["release_path"], "derivativeSha256": derivative["sha256"],
            "derivativeBytes": derivative["bytes"], "s3VersionId": derivative["s3_version_id"],
            "sourceManifestSha256": freeze["intake_freeze_sha256"], "parentRecordingId": parent_id,
            "archiveHand": "right", "archiveRun": "01",
            "trial": {"outPositionOneBased": trial, "outIndexZeroBased": trial - 1,
                      "eeg_seg_idx": segment, "lm_trial": leap},
            "selection": {
                "method": "Explicit OUT position, with all rows from the selected released trial.",
                "rowStartZeroBased": 0, "rowEndExclusive": n, "sourceTrialRowCount": n,
                "developmentRole": role, "use": "Local recorded-data inspection",
            },
            "clock": {
                "sourceField": "OUT.t_ms", "sourceDtype": "float64", "sourceUnit": "ms", "packetUnit": "s",
                "sourceStepMs": 10, "timestampMilliseconds": ms, "timestampSeconds": seconds,
                "firstNonnegativeRowZeroBased": anchor,
                "origin": "Nominal zero marks disappearance of the preparation cue at EEG event 14.",
                "alignment": "The release authors retrospectively placed Leap Motion positions on the EEG sample grid.",
                "hardwareSynchronizationVerified": False, "movementOnsetVerified": False,
            },
            "timestampMetadata": {
                "sourceField": "OUT.t_ms", "sourceUnit": "ms", "packetUnit": "s",
                "millisecondField": "clock.timestampMilliseconds", "secondFields": ["clock.timestampSeconds", "streams[].t"],
                "conversion": "Divide each stored millisecond value by 1000, preserving every sample and the original phase.",
            },
            "glossary": GLOSSARY,
        },
    }
    streams = []
    for row in rows:
        name, column = row["name"], row["index_zero_based"]
        streams.append({
            "id": f"eeg-{name.lower()}", "label": f"{name} · scalp EEG", "modality": "neural",
            "region": "brain", "anatomy": "Scalp", "signalType": "EEG", "origin": "derived", "unit": "µV",
            "rateHz": 100, "t": seconds, "values": eeg[:, sorted(columns).index(column)].tolist(),
            "measurement": "Recorded scalp voltage, filtered and baseline-corrected by the release authors.",
            "provenance": {
                "sourceField": "OUT.EEG", "sourceDtype": "float32", "channel": name,
                "sourceColumnZeroBased": column, "brainvisionHeaderSha256": entry["raw_recording"]["brainvision"]["sha256"],
                "channelsTsvSha256": entry["raw_recording"]["channels"]["sha256"],
                "channelEvidence": "Same-run acquisition header and channel table support this column with the documented processing order.",
            },
        })
    streams.append({
        "id": "leap-palm-x", "label": "Right palm x · Leap Motion", "modality": "displacement",
        "anatomy": "Right palm centre", "origin": "derived", "unit": "mm", "rateHz": 100, "frame": DEVICE_FRAME,
        "t": seconds, "values": [None if np.isnan(value) else float(value) for value in x],
        "measurement": "Optically tracked palm-centre position. The authors smoothed it and aligned it to the EEG clock.",
        "provenance": {
            "sourceField": "OUT.x_mm", "sourceDtype": "float64", "missingValue": "null",
            "sourceStatus": "Stored estimate of physical movement. Gaps mark missing optical measurements in the derivative.",
        },
    })
    return {"schemaVersion": 1, "dataset": dataset, "streams": streams}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mat", type=Path, required=True, help="Unmodified MAT file from this cohort.")
    parser.add_argument("--trial", type=int, required=True, help="One-based position in the file's OUT array.")
    parser.add_argument("--output", type=Path, required=True, help="Path to a new local JSON file.")
    args = parser.parse_args()
    os.umask(0o077)
    try:
        ensure(args.output.suffix.lower() == ".json", "Choose an output filename ending in .json.")
        ensure(not args.output.exists() and not args.output.is_symlink(), "Choose a new output path.")
        packet = make_packet(ROOT / "source-lock.json", args.mat, args.trial)
        encoded = json.dumps(packet, ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n"
        with args.output.open("x", encoding="utf-8", newline="\n") as output:
            output.write(encoded)
    except (OSError, ValueError, KeyError) as error:
        parser.exit(2, f"{error}\n")
    positions = packet["streams"][-1]["values"]
    print(f"Wrote {args.output.name} with {len(positions)} rows and {positions.count(None)} missing palm samples.")


if __name__ == "__main__":
    main()
