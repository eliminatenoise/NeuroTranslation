# Sources and rights

This NeuroTranslation converter uses the project’s CC0 1.0 terms. See `LICENSE`.

The included BrainVision headers, channel tables and field definitions are metadata from the CC0 1.0 release of IACKD. The source lock records the exact version, S3 object IDs and content hashes. It lists the release authors’ implementation as the basis for the channel correspondence. This package contains no participant recordings or extracted trial samples. [IACKD v1.0.0 dataset and attribution](https://doi.org/10.18112/openneuro.ds006840.v1.0.0)

The data descriptor explains consent to share anonymised records and describes the task, instruments and preprocessing. Cite the descriptor alongside the dataset when you use these files in research. [Cai et al., Scientific Data](https://doi.org/10.1038/s41597-026-07146-x)

Python dependencies retain their own licences and are installed separately.
