# Open one recorded trial

Download the right-hand R1 file for the participant you want to inspect. Find the versioned download URL under that participant in `source-lock.json`. The converter checks the file’s name, byte count and SHA-256 before it reads any samples. [OpenNeuro ds006840 v1.0.0](https://doi.org/10.18112/openneuro.ds006840.v1.0.0)

Install the Python dependencies in your own environment. Run the converter from this directory with a new JSON output name.

```sh
python -m pip install -r requirements.txt
python mat_to_companion.py --mat /path/to/sub-10_task-ihc_run-01_eeg_leap_R1.mat --trial 1 --output sub-10-trial-01.json
```

On Windows, use `py` if that is how you launch Python. `--trial 1` opens the first position in the release’s `OUT` array. It keeps every stored row of that trial and records the author’s separate EEG segment and Leap Motion trial IDs. The input may live outside this directory. Keep `source-lock.json` and `metadata/` beside `mat_to_companion.py`. An existing output is protected.

Open the JSON with the NeuroTranslation companion’s recording import. C3, Cz and C4 show scalp voltage in µV. Palm x shows the Leap Motion estimate in mm, with right positive on the device axis. Gaps in that trace are missing optical measurements. The inspector uses seconds and the packet also carries the original milliseconds. The preparation cue disappears at nominal zero. [IACKD acquisition and processing methods](https://doi.org/10.1038/s41597-026-07146-x)

Treat the export as recorded data. Keep participant packets local. The release applies filtering, re-referencing and retrospective alignment before export. The clock establishes where a sample sits in the released trial. Each channel identity comes from that run’s acquisition header and channel table, supported by the exported array width and the documented processing order. [IACKD author source](https://github.com/Boketto1/IACKD/tree/c0b595de7571c7e04abae7477c61d0b92b5702cd)
