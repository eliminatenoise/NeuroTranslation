#!/bin/sh
set -eu
package_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec python3 "$package_dir/transfer_predict.py" "$@"
