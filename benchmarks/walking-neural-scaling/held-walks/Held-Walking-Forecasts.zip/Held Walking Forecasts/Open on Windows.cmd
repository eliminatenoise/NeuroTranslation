@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" -B predict.py %*
) else (
    py -3.13 -B predict.py %*
)
exit /b %errorlevel%
