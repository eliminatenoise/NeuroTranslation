"""Frozen model and input preparation used for the held walking comparison."""


import numpy as np
from torch import nn
from torch.nn import functional as F


def need(condition, message):
    if not condition:
        raise ValueError(message)


def history_features(emg, emg_available, force, force_available):
    """Return 10 past bins with force, two muscle summaries and two masks."""
    need(force.shape == force_available.shape and emg.shape == emg_available.shape and
         emg.shape[:2] == force.shape and force.shape[1] == 10, 'Incompatible 200 ms histories.')
    strength = np.where(emg_available, np.square(emg), 0.)
    sum_strength = np.cumsum(strength, axis=1)[:, 2:-1]
    count = np.cumsum(emg_available, axis=1)[:, 2:-1]
    baseline = np.sqrt(sum_strength / np.maximum(count, 1))
    use = (count >= 3) & (baseline > 1e-12) & emg_available[:, 3:]
    ratio = np.log1p(np.divide(emg[:, 3:], baseline, out=np.zeros_like(baseline), where=use))
    summary = np.zeros((len(force), 10, 2), dtype=np.float64)
    present = np.zeros_like(force_available)
    # The last axis is six or four sensors. Its order does not enter the model.
    for row, tick in np.ndindex(use.shape[:2]):
        sensors = ratio[row, tick, use[row, tick]]
        if sensors.size:
            summary[row, tick + 3] = np.quantile(sensors, [.5, .8])
            present[row, tick + 3] = True
    values = np.concatenate((np.where(force_available, force / 800., 0.)[..., None], summary,
                             force_available[..., None], present[..., None]), axis=-1)
    need(np.isfinite(values).all(), 'Nonfinite encoded input.')
    return values.astype(np.float32)


def perturbed(data, condition):
    """Generate sensor timing or availability problems without changing target arrays."""
    if condition == 'clean':
        return data['x']
    x = data['x'].copy()
    channels = [1, 2, 4]
    if condition == 'delayed_muscle_history':
        x[:, 1:, channels] = data['x'][:, :-1, channels]
        x[:, 0, channels] = 0
    else:
        need(condition == 'missing_recent_muscle', 'Unknown generated sensor condition.')
        x[:, -3:, channels] = 0
    need(np.array_equal(x[..., [0, 3]], data['x'][..., [0, 3]]), 'A stress fixture changed force information.')
    return x


class RecordedForecast(nn.Module):
    def __init__(self, width, passes=None):
        super().__init__()
        self.passes = passes
        self.conv = nn.Conv1d(5, width, 3)
        if passes is None:
            self.recurrent = nn.LSTM(width, width, batch_first=True)
        else:
            self.recurrent = nn.GRU(width, width, batch_first=True)
            self.shared_step = nn.GRUCell(width, width)
        self.out = nn.Linear(width, 2)

    def forward(self, inputs):
        encoded = F.silu(self.conv(F.pad(inputs.transpose(1, 2), (2, 0)))).transpose(1, 2)
        steps, _ = self.recurrent(encoded)
        summary = steps[:, -1]
        if self.passes is not None:
            state = summary
            for _ in range(self.passes):
                state = self.shared_step(summary, state)
            summary = state
        return self.out(summary)
