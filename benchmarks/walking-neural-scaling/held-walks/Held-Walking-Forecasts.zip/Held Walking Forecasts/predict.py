"""Compare 100 ms walking-force forecasts from frozen NeuroTranslate 0.1 models."""

import argparse
from hashlib import file_digest
import json
from pathlib import Path

import numpy as np
import torch
from safetensors.torch import load_file

from model import RecordedForecast, history_features, perturbed


HERE = Path(__file__).resolve().parent
CONDITIONS = {'recorded':'clean', 'delay-muscle':'delayed_muscle_history', 'hide-muscle':'missing_recent_muscle'}


def example_history():
    return {
        'measured_plate_force_n': [4., 5., 8., 14., 105., 260., 380., 480., 515., 528.],
        'emg_rms_volts': [[.000032 + .000009 * step * (channel + 1) for channel in range(4)] for step in range(10)],
    }


def encode(example):
    force = np.asarray(example['measured_plate_force_n'], dtype=np.float64)
    muscle = np.asarray(example['emg_rms_volts'], dtype=np.float64)
    if (force.shape != (10,) or muscle.ndim != 2 or muscle.shape[0] != 10 or muscle.shape[1] not in (4, 6) or
            not np.isfinite(force).all() or np.any(np.isinf(muscle) | (muscle < 0))):
        raise ValueError('Supply ten finite mean force readings and ten rows of four or six nonnegative voltage readings. '
                         'Use null for a missing muscle reading.')
    fused = history_features(muscle[None], np.isfinite(muscle)[None], force[None], np.isfinite(force)[None])
    return {'x':fused, 'persistence':force[-1:]*.1}


def predict(spec, examples, condition, selection=None):
    current = perturbed(examples, condition)
    results = {'last_force': examples['persistence']}
    with torch.inference_mode():
        features = torch.from_numpy(current)
        for name, checkpoint in spec['models'].items():
            if selection and name != selection:
                continue
            path = HERE / 'checkpoints' / f'{name}.safetensors'
            with path.open('rb') as stream:
                actual = file_digest(stream, 'sha256').hexdigest()
            if actual != checkpoint['sha256']:
                raise ValueError(f'Checkpoint failed its file check: {path.name}')
            model = RecordedForecast(24, checkpoint['passes']).eval()
            model.load_state_dict(load_file(path, device='cpu'), strict=True)
            results[name] = examples['persistence'] + model(features).numpy()[:, 1]
    if not all(np.isfinite(values).all() for values in results.values()):
        raise ValueError('The supplied input produced a nonfinite force forecast.')
    return results


def main():
    spec = json.loads((HERE/'model.json').read_text())
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, help='A JSON history. With no file, the example uses invented values.')
    parser.add_argument('--condition', choices=CONDITIONS, default='recorded')
    parser.add_argument('--model', choices=spec['models'])
    flags = parser.parse_args()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    if flags.input:
        example = json.loads(flags.input.read_text(encoding='utf-8'))
    else:
        example = example_history()
    scores = predict(spec, encode(example), CONDITIONS[flags.condition], flags.model)
    print(json.dumps({'input': 'supplied' if flags.input else 'invented example', 'condition':flags.condition,
        'horizon_ms':100, 'forecast_impulse_ns':{name:float(values[0]) for name,values in scores.items()}},
        indent=2, allow_nan=False))


if __name__ == '__main__':
    main()
